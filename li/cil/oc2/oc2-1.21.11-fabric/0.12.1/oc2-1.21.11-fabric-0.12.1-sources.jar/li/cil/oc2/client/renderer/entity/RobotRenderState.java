/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.entity;

import net.minecraft.class_10017;

public final class RobotRenderState extends class_10017 {
    public float rotation;
    public float baseY;
    public float topY;
    public float topRotationY;
    public boolean isRunning;
    public int statusColor;
    public float statusValue;
    public long gameTime;
    public float partialTicks;
}
