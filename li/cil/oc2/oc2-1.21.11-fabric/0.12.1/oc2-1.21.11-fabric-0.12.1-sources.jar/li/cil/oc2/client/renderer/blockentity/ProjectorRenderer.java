/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.client.renderer.ProjectorDepthRenderer;
import li.cil.oc2.common.block.FlippableOrientableBlock;
import li.cil.oc2.common.blockentity.ProjectorBlockEntity;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import javax.annotation.Nullable;

public class ProjectorRenderer implements class_827<ProjectorBlockEntity, ProjectorRenderer.State> {
    public static final class State extends class_11954 {
        private boolean isProjecting;
        private boolean hasEnergy;
    }

    // --------------------------------------------------------------------- //

    private static final int LIGHT_COLOR_NEAR = 0x22FFFFFF;
    private static final int LIGHT_COLOR_FAR = 0x00FFFFFF;
    private static final int LENS_COLOR = 0xDDFFFFFF;
    private static final int MISSING_ENERGY_COLOR = 0xEEFF6666;
    private static final int LED_COLOR = 0xCC6688DD;

    private static final float LENS_RIGHT = 0 + 4 / 16f;
    private static final float LENS_LEFT = 1 - 4 / 16f;
    private static final float LENS_BOTTOM = 0 + 4 / 16f;
    private static final float LENS_TOP = 1 - 4 / 16f;

    // --------------------------------------------------------------------- //

    public ProjectorRenderer(final class_5614.class_5615 ignored) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public State method_74335() {
        return new State();
    }

    @Override
    public boolean shouldRender(final ProjectorBlockEntity projector, final class_243 position) {
        return !ProjectorDepthRenderer.isRenderingProjectorDepth() &&
            class_827.super.method_33892(projector, position);
    }

    @Override
    public boolean method_3563() {
        // Render bounding box of projectors (vastly) exceeds their block position, so they need
        // to be treated as global renderers, and cannot be culled with their chunk.
        return true;
    }

    @Override
    public void extractRenderState(final ProjectorBlockEntity projector, final State state, final float partialTicks, final class_243 cameraPosition,
                                   @Nullable final class_11683.class_11792 crumbling) {
        class_827.super.method_74331(projector, state, partialTicks, cameraPosition, crumbling);

        state.isProjecting = projector.isProjecting();
        state.hasEnergy = projector.hasEnergy();
        if (state.isProjecting && state.hasEnergy) {
            ProjectorDepthRenderer.addProjector(projector);
        }
    }

    @Override
    public void submit(final State state, final class_4587 stack, final class_11659 collector, final class_12075 camera) {
        if (!state.isProjecting) {
            return;
        }

        stack.method_22903();

        alignToFrontFace(state, stack);
        stack.method_22904(-0.5, 0, 0.5);

        collector.method_73483(stack, ModRenderType.getProjectorLight(), state.hasEnergy
            ? ProjectorRenderer::renderProjectorLight
            : ProjectorRenderer::renderMissingEnergyIndicator);

        stack.method_22909();
    }

    // --------------------------------------------------------------------- //

    private static void alignToFrontFace(final State state, final class_4587 stack) {
        stack.method_46416(0.5f, 0.5f, 0.5f);
        stack.method_22907(state.field_62674.method_11654(FlippableOrientableBlock.ORIENTATION).getRotation());
        stack.method_22907(class_7833.field_40716.rotationDegrees(180));
        stack.method_46416(0, -0.5f, 0);
    }

    private static void renderProjectorLight(final class_4587.class_4665 pose, final class_4588 consumer) {
        final float leftFar = 1.25f;
        final float rightFar = -0.25f;
        final float topFar = 1.5f;
        final float bottomFar = 0 + 1 / 16f;

        // Top.
        consumer.method_56824(pose, leftFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top left far
        consumer.method_56824(pose, LENS_LEFT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top left near
        consumer.method_56824(pose, LENS_RIGHT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top right near
        consumer.method_56824(pose, rightFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top right far

        // Bottom.
        consumer.method_56824(pose, leftFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom left far
        consumer.method_56824(pose, LENS_LEFT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom left near
        consumer.method_56824(pose, LENS_RIGHT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom right near
        consumer.method_56824(pose, rightFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom right far

        // Left.
        consumer.method_56824(pose, leftFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top left far
        consumer.method_56824(pose, leftFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom left far
        consumer.method_56824(pose, LENS_LEFT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom left near
        consumer.method_56824(pose, LENS_LEFT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top left near

        // Right.
        consumer.method_56824(pose, rightFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top right far
        consumer.method_56824(pose, LENS_RIGHT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top right near
        consumer.method_56824(pose, LENS_RIGHT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom right near
        consumer.method_56824(pose, rightFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom right far

        renderLens(pose, consumer, LENS_COLOR);
        renderLed(pose, consumer);
    }

    private static void renderMissingEnergyIndicator(final class_4587.class_4665 pose, final class_4588 consumer) {
        renderLens(pose, consumer, MISSING_ENERGY_COLOR);
        renderLed(pose, consumer);
    }

    private static void renderLens(final class_4587.class_4665 pose, final class_4588 consumer, final int color) {
        final float lensDepth = -1 / 16f;
        consumer.method_56824(pose, LENS_RIGHT, LENS_BOTTOM, lensDepth).method_39415(color);
        consumer.method_56824(pose, LENS_LEFT, LENS_BOTTOM, lensDepth).method_39415(color);
        consumer.method_56824(pose, LENS_LEFT, LENS_TOP, lensDepth).method_39415(color);
        consumer.method_56824(pose, LENS_RIGHT, LENS_TOP, lensDepth).method_39415(color);
    }

    private static void renderLed(final class_4587.class_4665 pose, final class_4588 consumer) {
        final float ledRight = 0 + 7 / 16f;
        final float ledLeft = 0 + 9 / 16f;
        final float ledBottom = 0 + 3 / 16f;
        final float ledTop = 0 + 4 / 16f;
        final float ledDepth = -0.75f / 16f;

        consumer.method_56824(pose, ledRight, ledBottom, ledDepth).method_39415(LED_COLOR);
        consumer.method_56824(pose, ledLeft, ledBottom, ledDepth).method_39415(LED_COLOR);
        consumer.method_56824(pose, ledLeft, ledTop, ledDepth).method_39415(LED_COLOR);
        consumer.method_56824(pose, ledRight, ledTop, ledDepth).method_39415(LED_COLOR);
    }
}
