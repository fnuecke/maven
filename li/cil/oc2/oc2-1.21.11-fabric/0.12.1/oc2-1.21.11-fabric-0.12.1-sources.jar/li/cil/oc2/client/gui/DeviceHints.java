/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.architectury.registry.ReloadListenerRegistry;
import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.device.DeviceType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_2073;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_4013;
import net.minecraft.class_4309;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6903;
import net.minecraft.class_7654;
import net.minecraft.class_7924;
import javax.annotation.Nullable;
import java.util.*;

@Environment(EnvType.CLIENT)
public final class DeviceHints {
    public record Hint(Optional<class_2073> item, boolean isRequired) {
    }

    // --------------------------------------------------------------------- //

    private static final String DIRECTORY = "device_hints";

    @Nullable
    private static DeviceHints cached;
    @Nullable
    private static class_5455 cachedRegistries;

    // --------------------------------------------------------------------- //

    private final List<Rule> rules;

    // --------------------------------------------------------------------- //

    private DeviceHints(final List<Rule> rules) {
        this.rules = rules;
    }

    // --------------------------------------------------------------------- //

    public static void initialize() {
        ReloadListenerRegistry.register(class_3264.field_14188, (class_4013) manager -> cached = null,
            class_2960.method_60655(API.MOD_ID, DIRECTORY));
    }

    public static DeviceHints get() {
        final class_5455 registries = Objects.requireNonNull(class_310.method_1551().method_1562()).method_29091();
        if (cached == null || !registries.equals(cachedRegistries)) {
            cached = load(registries);
            cachedRegistries = registries;
        }
        return cached;
    }

    public List<Hint> get(final DeviceType type) {
        final List<Hint> hints = new ArrayList<>();
        for (final Rule rule : rules) {
            if (rule.requires().contains(type.getTag())) {
                hints.add(new Hint(rule.item(), true));
            }
            if (rule.suggests().contains(type.getTag())) {
                hints.add(new Hint(rule.item(), false));
            }
        }
        hints.sort(Comparator.comparing(hint -> !hint.isRequired()));
        return hints;
    }

    // --------------------------------------------------------------------- //

    private static DeviceHints load(final class_5455 registries) {
        final class_6903<JsonElement> ops = class_6903.method_46632(JsonOps.INSTANCE, registries);
        final Map<class_2960, Rule> rules = new HashMap<>();
        class_4309.method_51148(class_310.method_1551().method_1478(), class_7654.method_45114(DIRECTORY), ops, Rule.CODEC, rules);
        return new DeviceHints(List.copyOf(rules.values()));
    }

    // --------------------------------------------------------------------- //

    private record Rule(Optional<class_2073> item, List<class_6862<class_1792>> requires, List<class_6862<class_1792>> suggests) {
        public static final Codec<Rule> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_2073.field_45754.optionalFieldOf("item").forGetter(Rule::item),
            class_6862.method_40093(class_7924.field_41197).listOf().optionalFieldOf("requires", List.of()).forGetter(Rule::requires),
            class_6862.method_40093(class_7924.field_41197).listOf().optionalFieldOf("suggests", List.of()).forGetter(Rule::suggests)
        ).apply(instance, Rule::new));
    }
}
