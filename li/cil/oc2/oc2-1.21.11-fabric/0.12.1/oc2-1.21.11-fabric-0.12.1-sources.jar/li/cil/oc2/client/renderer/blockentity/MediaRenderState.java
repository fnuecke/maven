/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import net.minecraft.class_10444;
import net.minecraft.class_11954;

public final class MediaRenderState extends class_11954 {
    public final class_10444 media = new class_10444();
    public int neighborLight;
}
