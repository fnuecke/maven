/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity;

import li.cil.oc2.common.block.Blocks;
import li.cil.oc2.common.block.ComputerBlock;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1367;
import net.minecraft.class_1408;
import net.minecraft.class_1451;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4538;

public final class CatBehaviorGoal extends class_1367 {
    private static final int PRIORITY = 7;
    private static final double SPEED_MODIFIER = 0.8;
    private static final int SEARCH_RANGE = 8;

    // --------------------------------------------------------------------- //

    private final class_1451 cat;

    // --------------------------------------------------------------------- //

    public CatBehaviorGoal(final class_1451 cat) {
        super(cat, SPEED_MODIFIER, SEARCH_RANGE);
        this.cat = cat;
    }

    // --------------------------------------------------------------------- //

    public static void onEntityLoad(final class_1297 entity) {
        if (entity instanceof final class_1451 cat && cat.field_6201.method_35115().stream()
            .noneMatch(goal -> goal.method_19058() instanceof CatBehaviorGoal)) {
            cat.field_6201.method_6277(PRIORITY, new CatBehaviorGoal(cat));
        }
    }

    public static boolean isCatSittingAt(final class_1937 level, final class_2338 pos) {
        for (final class_1451 cat : level.method_18467(class_1451.class, new class_238(pos))) {
            if (cat.method_6172()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_6264() {
        return cat.method_6181() && !cat.method_24345() && super.method_6264();
    }

    @Override
    public void method_6269() {
        super.method_6269();
        cat.method_6179(false);
    }

    @Override
    public void method_6270() {
        super.method_6270();
        cat.method_6179(false);
    }

    @Override
    public void method_6268() {
        super.method_6268();
        if (!method_6295() && super.method_6294()) {
            method_6290();
        }

        cat.method_6179(method_6295());
        if (method_6295() && field_6516.method_73183().method_8320(field_6512).method_27852(Blocks.COMPUTER.get())) {
            cat.method_5988().method_19615(class_243.method_24953(field_6512));
        }
    }

    @Override
    public boolean method_6294() {
        return false; // Re-pathed in tick() with accuracy 0.
    }

    // --------------------------------------------------------------------- //

    @Override
    protected boolean method_6296(final class_4538 level, final class_2338 pos) {
        final class_2680 state = level.method_8320(pos);
        if (state.method_27852(Blocks.KEYBOARD.get())) {
            return level.method_22347(pos.method_10084());
        }

        if (state.method_27852(Blocks.COMPUTER.get())) {
            final class_2338 front = pos.method_10093(state.method_11654(ComputerBlock.field_11177));
            return level.method_22347(front) &&
                level.method_8320(front.method_10074()).method_26206(level, front.method_10074(), class_2350.field_11036) &&
                level.method_8321(pos) instanceof final ComputerBlockEntity computer &&
                computer.getVirtualMachine().isRunning();
        }

        return false;
    }

    @Override
    protected class_2338 method_30953() {
        final class_2680 state = field_6516.method_73183().method_8320(field_6512);
        if (state.method_27852(Blocks.COMPUTER.get())) {
            return field_6512.method_10093(state.method_11654(ComputerBlock.field_11177));
        }
        return super.method_30953();
    }

    @Override
    protected void method_6290() {
        final class_1408 navigation = field_6516.method_5942();
        navigation.method_6334(navigation.method_6348(method_30953(), 0), field_6514);
    }
}
