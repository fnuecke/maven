/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity;

import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.DeviceContext;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.api.bus.device.io.IOBusContext;
import li.cil.oc2.api.bus.device.io.IOInputStream;
import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.*;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.api.bus.device.rpc.RPCBusContext;
import li.cil.oc2.api.capabilities.TerminalUserProvider;
import li.cil.oc2.api.util.RobotOperationSide;
import li.cil.oc2.client.audio.TerminalBell;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.bus.AbstractDeviceBusElement;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.bus.device.util.FluidHandlerProtocol;
import li.cil.oc2.common.bus.device.util.ItemHandlerProtocol;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityProvider;
import li.cil.oc2.common.capabilities.CapabilityType;
import li.cil.oc2.common.container.FixedSizeItemStackHandler;
import li.cil.oc2.common.container.ItemStackHandler;
import li.cil.oc2.common.container.RobotInventoryContainer;
import li.cil.oc2.common.container.RobotTerminalContainer;
import li.cil.oc2.common.energy.FixedEnergyHandler;
import li.cil.oc2.common.entity.robot.*;
import li.cil.oc2.common.fluid.FluidHandler;
import li.cil.oc2.common.fluid.FluidStack;
import li.cil.oc2.common.fluid.FluidTank;
import li.cil.oc2.common.integration.Wrenches;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.*;
import li.cil.oc2.common.serialization.NBTSerialization;
import li.cil.oc2.common.util.*;
import li.cil.oc2.common.vm.*;
import li.cil.oc2.common.vm.arch.AbstractArchitecture;
import li.cil.oc2.common.vm.device.Terminal;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10255;
import net.minecraft.class_10584;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_247;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3980;
import net.minecraft.class_4208;
import net.minecraft.class_4844;
import net.minecraft.class_5569;
import net.minecraft.class_7225;
import net.minecraft.core.*;
import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.*;
import java.util.function.IntPredicate;

import static java.util.Collections.singleton;
import static li.cil.oc2.common.Constants.ENERGY_TAG_NAME;
import static li.cil.oc2.common.Constants.ITEMS_TAG_NAME;

public final class Robot extends class_1297 implements li.cil.oc2.api.capabilities.Robot, TerminalUserProvider {
    public static final class_2940<class_2338> TARGET_POSITION = class_2945.method_12791(Robot.class, class_2943.field_13324);
    public static final class_2940<class_2350> TARGET_DIRECTION = class_2945.method_12791(Robot.class, class_2943.field_13321);
    public static final class_2940<Byte> SELECTED_SLOT = class_2945.method_12791(Robot.class, class_2943.field_13319);
    public static final class_2940<Integer> STATUS_COLOR = class_2945.method_12791(Robot.class, class_2943.field_13327);
    public static final class_2940<Float> STATUS_VALUE = class_2945.method_12791(Robot.class, class_2943.field_13320);

    public static final int DEFAULT_STATUS_COLOR = 0xEEEEFF;
    public static final float DEFAULT_STATUS_VALUE = 1;

    private static final String TERMINAL_TAG_NAME = "terminal";
    private static final String STATE_TAG_NAME = "state";
    private static final String BUS_ELEMENT_TAG_NAME = "bus_element";
    private static final String DEVICES_TAG_NAME = "devices";
    private static final String COMMAND_PROCESSOR_TAG_NAME = "commands";
    private static final String INVENTORY_TAG_NAME = "inventory";
    private static final String TANK_TAG_NAME = "tank";
    private static final String SELECTED_SLOT_TAG_NAME = "selected_slot";
    private static final String STATUS_COLOR_TAG_NAME = "status_color";
    private static final String STATUS_VALUE_TAG_NAME = "status_value";
    private static final String ORIGIN_TAG_NAME = "origin";

    private static final int MAX_QUEUED_ACTIONS = 16;
    private static final int MAX_QUEUED_RESULTS = 16;

    private static final int CPU_SLOTS = 1;
    private static final int MEMORY_SLOTS = 4;
    private static final int HARD_DRIVE_SLOTS = 1;
    private static final int FLOPPY_SLOTS = 1;
    private static final int FLASH_MEMORY_SLOTS = 1;
    private static final int MODULE_SLOTS = 4;
    private static final int INVENTORY_SIZE = 12;
    private static final int TANK_CAPACITY = 12 * FluidHandler.BUCKET;

    private static final int CONTAINING_BLOCK_CHECK_INTERVAL = TickUtils.toTicks(Duration.ofSeconds(1));
    private static final double MOVING_POSITION_SYNC_THRESHOLD = 1;
    private static final float TURNING_ROTATION_SYNC_THRESHOLD = 45;

    // --------------------------------------------------------------------- //

    private final Runnable unloadListener = this::handleUnload;
    private final class_2338.class_2339 mutablePosition = new class_2338.class_2339();

    @Nullable
    private class_238 lastContainingBlockSweepBounds;
    private int containingBlockSweepCountdown;

    private final AnimationState animationState = new AnimationState();
    private final RobotActionProcessor actionProcessor = new RobotActionProcessor();
    private final Terminal terminal = new Terminal();
    private final RobotDevice robotDevice = new RobotDevice();
    private final RobotBusElement busElement = new RobotBusElement();
    private final RobotItemStackHandlers deviceItems = new RobotItemStackHandlers();
    private final FixedEnergyHandler energy = new FixedEnergyHandler(Config.robotEnergyStorage);
    private final RobotVirtualMachine virtualMachine = new RobotVirtualMachine(new CommonDeviceBusController(busElement, this::cpuEnergyPerTick, deviceItems::getArchitectureType));
    private final ItemStackHandler inventory = new FixedSizeItemStackHandler(INVENTORY_SIZE);
    private final FluidTank tank = new FluidTank(TANK_CAPACITY);
    // Applying server position and rotation while animating (which also runs on client) causes jitter, so
    // only snap to the authoritative values when actually relevant.
    private final class_10584 interpolation = new class_10584(this, 0) {
        @Override
        public void method_66267(final class_243 pos, final float yRot, final float xRot) {
            if (RobotMovementAction.isComplete(Robot.this) ||
                method_66265().method_1025(pos) > MOVING_POSITION_SYNC_THRESHOLD * MOVING_POSITION_SYNC_THRESHOLD) {
                method_33574(pos);
            }
            if (RobotRotationAction.isComplete(Robot.this) ||
                class_3532.method_15356(method_36454(), yRot) > TURNING_ROTATION_SYNC_THRESHOLD) {
                method_5710(yRot, xRot);
            }
        }
    };
    private final Set<class_1657> terminalUsers = Collections.newSetFromMap(new WeakHashMap<>());
    private final List<CapabilityProvider> capabilityProviders = new ArrayList<>();
    private volatile List<class_3222> terminalRecipients = List.of(); // Copy for threaded send.
    private long lastPistonMovement;
    private List<class_1297> ignoredColliders = List.of();
    @Nullable
    private class_4208 origin;

    // --------------------------------------------------------------------- //

    public Robot(final class_1299<?> type, final class_1937 world) {
        super(type, world);
        this.field_23807 = true;
        method_5875(true);

        if (world.method_8608()) {
            terminal.setDisplayOnly(true);
        }

        virtualMachine.setGameTimeSource(LevelUtils.gameTimeSupplier(world));
        virtualMachine.getBusController().onAfterDeviceScan.add(this::handleAfterDeviceScan);
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    public AnimationState getAnimationState() {
        return animationState;
    }

    public Terminal getTerminal() {
        return terminal;
    }

    public VirtualMachine getVirtualMachine() {
        return virtualMachine;
    }

    public VirtualMachineClientState getVirtualMachineClientState() {
        return virtualMachine;
    }

    public VMItemStackHandlers getItemStackHandlers() {
        return deviceItems;
    }

    public ItemStackHandler getInventory() {
        return inventory;
    }

    public FluidTank getTank() {
        return tank;
    }

    @Override
    public int getSelectedSlot() {
        return method_5841().method_12789(SELECTED_SLOT);
    }

    @Override
    public void setSelectedSlot(final int value) {
        method_5841().method_12778(SELECTED_SLOT, (byte) class_3532.method_15340(value, 0, INVENTORY_SIZE - 1));
    }

    public int getStatusColor() {
        return method_5841().method_12789(STATUS_COLOR);
    }

    public void setStatusColor(final int value) {
        method_5841().method_12778(STATUS_COLOR, value & 0xFFFFFF);
    }

    public float getStatusValue() {
        return method_5841().method_12789(STATUS_VALUE);
    }

    public void setStatusValue(final float value) {
        method_5841().method_12778(STATUS_VALUE, Float.isNaN(value) ? 0 : class_3532.method_15363(value, 0, 1));
    }

    @Nullable
    @SuppressWarnings("unchecked")
    public <T> T getCapability(final CapabilityType<T> capability, @Nullable final class_2350 side) {
        if (capability == Capabilities.ITEM_HANDLER) {
            return (T) inventory;
        }
        if (capability == Capabilities.FLUID_HANDLER) {
            return (T) tank;
        }
        if (capability == Capabilities.ENERGY_STORAGE && Config.robotsUseEnergy()) {
            return (T) energy;
        }
        if (capability == Capabilities.ROBOT) {
            return (T) this;
        }
        if (capability == Capabilities.TERMINAL_USER_PROVIDER) {
            return (T) this;
        }

        for (final CapabilityProvider capabilityProvider : capabilityProviders) {
            final T value = capabilityProvider.getCapability(capability, side);
            if (value != null) {
                return value;
            }
        }

        return null;
    }

    public long getLastPistonMovement() {
        return lastPistonMovement;
    }

    public void move(final class_243 delta, final List<class_1297> ignoredColliders) {
        this.ignoredColliders = ignoredColliders; //NOPMD - read by canCollideWith during move
        method_5784(class_1313.field_6308, delta);
        this.ignoredColliders = List.of();
    }

    public void start() {
        if (!method_73183().method_8608()) {
            virtualMachine.start();
        }
    }

    public void shutdown() {
        if (!method_73183().method_8608()) {
            virtualMachine.shutdown();
        }
    }

    public void reboot() {
        if (!method_73183().method_8608()) {
            virtualMachine.reboot();
        }
    }

    public void stop() {
        if (!method_73183().method_8608()) {
            virtualMachine.stop();
        }
    }

    public void openTerminalScreen(final class_3222 player) {
        // For full terminal snapshot.
        Network.sendToClient(new RobotInitializationMessage(this), player);

        RobotTerminalContainer.createServer(this, energy, virtualMachine.getBusController(), player);
    }

    public void openInventoryScreen(final class_3222 player) {
        RobotInventoryContainer.createServer(this, energy, virtualMachine.getBusController(), player);
    }

    public void addTerminalUser(final class_1657 player) {
        terminalUsers.add(player);
        updateTerminalRecipients();
    }

    public void removeTerminalUser(final class_1657 player) {
        terminalUsers.remove(player);
        updateTerminalRecipients();
    }

    @Override
    public Iterable<class_1657> getTerminalUsers() {
        return terminalUsers;
    }

    public void dropSelf() {
        if (!method_5805()) {
            return;
        }

        final class_1799 stack = new class_1799(Items.ROBOT.get());
        exportToItemStack(stack);
        if (method_73183() instanceof final class_3218 serverLevel) {
            method_5775(serverLevel, stack);
        }

        method_31472();
        LevelUtils.playSound(method_73183(), method_24515(), class_2498.field_11533, class_2498::method_10595);
    }

    @Override
    public void method_5773() {
        final boolean isClient = method_73183().method_8608();

        if (field_5953) {
            if (isClient) {
                requestInitialState();
            } else {
                registerListeners();

                if (origin == null || !origin.comp_2207().equals(method_73183().method_27983())) {
                    calibratePosition();
                }
            }
        }

        super.method_5773();

        if (isClient && terminal.consumePendingBell()) {
            TerminalBell.play();
        }

        if (isClient) {
            animationState.tick();
        }

        if (!isClient) {
            virtualMachine.tick();
        }

        actionProcessor.tick();

        if (!isClient && method_73183() instanceof final class_3218 serverLevel) {
            // Getting stuck in a block should be rare / impossible unless world-editing,
            // so we avoid checking this every frame.
            final class_238 bounds = method_5829();
            if (--containingBlockSweepCountdown <= 0 || !bounds.equals(lastContainingBlockSweepBounds)) {
                containingBlockSweepCountdown = CONTAINING_BLOCK_CHECK_INTERVAL;
                lastContainingBlockSweepBounds = bounds;
                clearContainingBlocks(serverLevel, bounds);
            }
        }
    }

    @Override
    public boolean method_5698(final class_1297 entity) {
        if (entity instanceof class_1657 player && player.method_68878()) {
            dropSelf();
        }
        return true;
    }

    @Override
    public class_1269 method_5688(final class_1657 player, final class_1268 hand) {
        final class_1799 stack = player.method_5998(hand);
        if (!method_73183().method_8608()) {
            if (Wrenches.isWrench(stack)) {
                if (player.method_5715()) {
                    dropSelf();
                } else if (player instanceof final class_3222 serverPlayer) {
                    openInventoryScreen(serverPlayer);
                }
            } else {
                if (player.method_5715()) {
                    start();
                } else if (player instanceof final class_3222 serverPlayer) {
                    openTerminalScreen(serverPlayer);
                }
            }
        }

        return class_1269.field_5812;
    }

    @Override
    public void method_31744(final class_5569 callback) {
        super.method_31744(callback);

        if (!method_73183().method_8608()) {
            final class_5529 reason = method_35049();
            if (callback == class_5569.field_27243 && reason != null) {
                if (reason.method_31486()) {
                    handleDestroy();
                } else {
                    handleUnload();
                }
            }
        }
    }

    @Override
    public class_10584 method_66233() {
        return interpolation;
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public boolean method_30949(final class_1297 entity) {
        return !ignoredColliders.contains(entity) && class_10255.method_64486(this, entity);
    }

    @Override
    public boolean method_30948(@Nullable final class_1297 entity) {
        return true;
    }

    @Override
    public boolean method_64397(final class_3218 level, final class_1282 damageSource, final float amount) {
        return false;
    }

    @Override
    public boolean method_27298() {
        return false;
    }

    public void exportToItemStack(final class_1799 stack) {
        ItemStackUtils.modifyModDataTag(stack, modTag -> modTag.method_10543(SerializationUtils.saveToTag(method_71370(), method_73183().method_30349(), output -> {
            final class_11372 itemsOutput = output.method_71461(ITEMS_TAG_NAME);
            deviceItems.saveItems(itemsOutput); // One tag per device type, as TooltipUtils expects.
            inventory.save(itemsOutput.method_71461(INVENTORY_TAG_NAME)); // Won't show up in tooltip.

            tank.serialize(output, TANK_TAG_NAME);
            energy.serialize(output.method_71461(ENERGY_TAG_NAME));
        })));
    }

    public void importFromItemStack(final class_1799 stack) {
        SerializationUtils.loadFromTag(method_71370(), method_73183().method_30349(), ItemStackUtils.getModDataTag(stack), input -> {
            final class_11368 itemsInput = input.method_71434(ITEMS_TAG_NAME);
            deviceItems.loadItems(itemsInput);
            inventory.load(itemsInput.method_71434(INVENTORY_TAG_NAME));

            tank.deserialize(input, TANK_TAG_NAME);
            energy.deserialize(input.method_71434(ENERGY_TAG_NAME));
        });
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_5693(final class_2945.class_9222 builder) {
        builder.method_56912(TARGET_POSITION, class_2338.field_10980);
        builder.method_56912(TARGET_DIRECTION, class_2350.field_11043);
        builder.method_56912(SELECTED_SLOT, (byte) 0);
        builder.method_56912(STATUS_COLOR, DEFAULT_STATUS_COLOR);
        builder.method_56912(STATUS_VALUE, DEFAULT_STATUS_VALUE);
    }

    @Override
    protected void method_5652(final class_11372 output) {
        if (virtualMachine.getRunState() != VMRunState.STOPPED) {
            virtualMachine.serialize(output.method_71461(STATE_TAG_NAME));
            synchronized (terminal) {
                output.method_71468(TERMINAL_TAG_NAME, class_2487.field_25128, NBTSerialization.serialize(terminal));
            }
        }

        actionProcessor.serialize(output.method_71461(COMMAND_PROCESSOR_TAG_NAME));
        busElement.serialize(output.method_71461(BUS_ELEMENT_TAG_NAME));
        deviceItems.saveItems(output.method_71461(ITEMS_TAG_NAME));
        deviceItems.saveDevices(output.method_71461(DEVICES_TAG_NAME));
        energy.serialize(output.method_71461(ENERGY_TAG_NAME));
        inventory.save(output.method_71461(INVENTORY_TAG_NAME));
        tank.serialize(output, TANK_TAG_NAME);
        output.method_71462(SELECTED_SLOT_TAG_NAME, method_5841().method_12789(SELECTED_SLOT));
        output.method_71465(STATUS_COLOR_TAG_NAME, getStatusColor());
        output.method_71464(STATUS_VALUE_TAG_NAME, getStatusValue());
        output.method_71477(ORIGIN_TAG_NAME, class_4208.field_25066, origin);
    }

    @Override
    protected void method_5749(final class_11368 input) {
        virtualMachine.deserialize(input.method_71434(STATE_TAG_NAME));
        NBTSerialization.deserialize(SerializationUtils.getCompoundOrEmpty(input, TERMINAL_TAG_NAME), terminal);
        actionProcessor.deserialize(input.method_71434(COMMAND_PROCESSOR_TAG_NAME));
        busElement.deserialize(input.method_71434(BUS_ELEMENT_TAG_NAME));
        deviceItems.resetDevices();
        deviceItems.loadItems(input.method_71434(ITEMS_TAG_NAME));
        deviceItems.loadDevices(input.method_71434(DEVICES_TAG_NAME));
        energy.deserialize(input.method_71434(ENERGY_TAG_NAME));
        inventory.load(input.method_71434(INVENTORY_TAG_NAME));
        tank.deserialize(input, TANK_TAG_NAME);
        setSelectedSlot(input.method_71421(SELECTED_SLOT_TAG_NAME, (byte) 0));
        setStatusColor(input.method_71424(STATUS_COLOR_TAG_NAME, DEFAULT_STATUS_COLOR));
        setStatusValue(input.method_71423(STATUS_VALUE_TAG_NAME, DEFAULT_STATUS_VALUE));
        origin = input.method_71426(ORIGIN_TAG_NAME, class_4208.field_25066).orElse(null);

        RobotActions.initializeData(this);
        final AbstractRobotAction currentAction = actionProcessor.action;
        if (currentAction != null) {
            currentAction.initialize(this);
        }
    }

    @Override
    protected class_1297.class_5799 method_33570() {
        return class_1297.class_5799.field_28630;
    }

    @Override
    protected class_243 method_18794(final class_243 pos) {
        lastPistonMovement = method_73183().method_75260();
        return super.method_18794(pos);
    }

    // --------------------------------------------------------------------- //

    private int cpuEnergyPerTick() {
        return Config.robotCpuEnergyPerTick(deviceItems.getArchitectureType().orElse(null));
    }

    @Environment(EnvType.CLIENT)
    private void requestInitialState() {
        Network.sendToServer(new RobotInitializationRequestMessage(this));
    }

    private void registerListeners() {
        ServerScheduler.scheduleOnUnload(method_73183(), unloadListener);
    }

    private void unregisterListeners() {
        ServerScheduler.cancelOnUnload(method_73183(), unloadListener);
    }

    private class_2338 getBodyPosition() {
        return class_2338.method_49638(method_5829().method_1005());
    }

    private void calibratePosition() {
        origin = class_4208.method_19443(method_73183().method_27983(), getBodyPosition());
    }

    private void handleUnload() {
        unregisterListeners();
        virtualMachine.suspend();
        virtualMachine.dispose();
    }

    private void handleDestroy() {
        unregisterListeners();
        virtualMachine.stop();
        virtualMachine.dispose();
    }

    private void handleAfterDeviceScan() {
        capabilityProviders.clear();
        for (final Device device : virtualMachine.getBusController().getDevices()) {
            if (device instanceof final CapabilityProvider capabilityProvider) {
                capabilityProviders.add(capabilityProvider);
            }
        }
    }

    private void updateTerminalRecipients() {
        final ArrayList<class_3222> recipients = new ArrayList<>();
        for (final class_1657 player : terminalUsers) {
            if (player instanceof final class_3222 serverPlayer) {
                recipients.add(serverPlayer);
            }
        }

        terminalRecipients = List.copyOf(recipients);
    }

    private void clearContainingBlocks(final class_3218 serverLevel, final class_238 bounds) {
        final class_265 shape = class_259.method_1078(bounds);
        final class_3980 iterator = getBlockPosIterator();
        while (iterator.method_17963()) {
            final int x = iterator.method_18671();
            final int y = iterator.method_18672();
            final int z = iterator.method_18673();
            mutablePosition.method_10103(x, y, z);
            final class_2680 blockState = serverLevel.method_8320(mutablePosition);
            if (blockState.method_26215() ||
                blockState.method_27852(class_2246.field_10008) ||
                blockState.method_27852(class_2246.field_10379)) {
                continue;
            }

            final class_265 blockShape = blockState.method_26220(serverLevel, mutablePosition);
            if (class_259.method_1074(shape, blockShape.method_1096(x, y, z), class_247.field_16896)) {
                tryClearContainingBlock(serverLevel, mutablePosition.method_10062(), blockState);
            }
        }
    }

    private class_3980 getBlockPosIterator() {
        final class_238 bounds = method_5829();
        return new class_3980(
            class_3532.method_15357(bounds.field_1323), class_3532.method_15357(bounds.field_1322), class_3532.method_15357(bounds.field_1321),
            class_3532.method_15357(bounds.field_1320), class_3532.method_15357(bounds.field_1325), class_3532.method_15357(bounds.field_1324)
        );
    }

    private void tryClearContainingBlock(final class_3218 level, final class_2338 blockPos, final class_2680 blockState) {
        // Quick and dirty pre-fake-player check.
        if (blockState.method_26214(level, blockPos) < 0) {
            return;
        }

        final class_3222 player = FakePlayerUtils.getFakePlayer(level, this);

        if (!LevelUtils.fireBlockBreak(level, player, blockPos, blockState)) {
            return;
        }

        if (!level.method_8651(blockPos, true, player)) {
            // We tried being nice... kill it. Might revisit this :D
            level.method_8501(blockPos, class_2246.field_10124.method_9564());
        }
    }

    private static float lerpClamped(final float from, final float to, final float delta) {
        if (from < to) {
            return Math.min(from + delta, to);
        } else if (from > to) {
            return Math.max(from - delta, to);
        } else {
            return from;
        }
    }

    private static float remapFrom01To(final float x, final float a1, final float b1) {
        if (a1 == b1) {
            return a1;
        } else {
            return x * (b1 - a1) + a1;
        }
    }

    // --------------------------------------------------------------------- //

    public final class AnimationState {
        public static final float TOP_IDLE_Y = -2f / 16f;
        private static final float BASE_IDLE_Y = -1f / 16f;

        private static final float TRANSLATION_SPEED = 0.015f;
        private static final float ROTATION_SPEED = 1f;
        private static final float MAX_ROTATION = 5f;
        private static final float MIN_ROTATION_SPEED = 0.165f;
        private static final float MAX_ROTATION_SPEED = 0.180f;
        private static final float HOVER_ANIMATION_SPEED = 0.03f;

        private float topRenderOffsetY = TOP_IDLE_Y;
        private float baseRenderOffsetY = BASE_IDLE_Y;
        private float topRenderRotationY;
        private float topRenderOffsetYO = TOP_IDLE_Y;
        private float baseRenderOffsetYO = BASE_IDLE_Y;
        private float topRenderRotationYO;
        private float topRenderTargetRotationY;
        private float topRenderRotationSpeed;
        private final float hoverPhase = hashCode() & 0xFFFF;

        public float getTopRenderOffsetY(final float partialTicks) {
            return class_3532.method_16439(partialTicks, topRenderOffsetYO, topRenderOffsetY);
        }

        public float getBaseRenderOffsetY(final float partialTicks) {
            return class_3532.method_16439(partialTicks, baseRenderOffsetYO, baseRenderOffsetY);
        }

        public float getTopRenderRotationY(final float partialTicks) {
            return class_3532.method_16439(partialTicks, topRenderRotationYO, topRenderRotationY);
        }

        private void tick() {
            topRenderOffsetYO = topRenderOffsetY;
            baseRenderOffsetYO = baseRenderOffsetY;
            topRenderRotationYO = topRenderRotationY;

            if (getVirtualMachine().isRunning() || actionProcessor.hasQueuedActions()) {
                final float topOffsetY = (float) Math.sin(method_73183().method_75260() * HOVER_ANIMATION_SPEED + hoverPhase) / 32f;

                topRenderOffsetY = lerpClamped(topRenderOffsetY, topOffsetY, TRANSLATION_SPEED);
                baseRenderOffsetY = lerpClamped(baseRenderOffsetY, topOffsetY, TRANSLATION_SPEED);

                topRenderRotationY = lerpClamped(topRenderRotationY, topRenderTargetRotationY, topRenderRotationSpeed);
                if (topRenderRotationY == topRenderTargetRotationY) {
                    topRenderTargetRotationY = remapFrom01To(field_5974.method_43057(), -MAX_ROTATION, MAX_ROTATION);
                    topRenderRotationSpeed = remapFrom01To(field_5974.method_43057(), MIN_ROTATION_SPEED, MAX_ROTATION_SPEED);
                }
            } else {
                topRenderOffsetY = lerpClamped(topRenderOffsetY, TOP_IDLE_Y, TRANSLATION_SPEED * 2);
                baseRenderOffsetY = lerpClamped(baseRenderOffsetY, BASE_IDLE_Y, TRANSLATION_SPEED);

                topRenderRotationY = lerpClamped(topRenderRotationY, 0, ROTATION_SPEED);
            }
        }
    }

    private static final class RobotActionProcessorResult {
        private static final String ACTION_ID_TAG_NAME = "action_id";
        private static final String RESULT_TAG_NAME = "result";

        public int actionId;
        public RobotActionResult result;

        public RobotActionProcessorResult(final int actionId, final RobotActionResult result) {
            this.actionId = actionId;
            this.result = result;
        }

        public RobotActionProcessorResult(final class_11368 input) {
            deserialize(input);
        }

        public void serialize(final class_11372 output) {
            output.method_71465(ACTION_ID_TAG_NAME, actionId);
            SerializationUtils.putEnum(output, RESULT_TAG_NAME, result);
        }

        public void deserialize(final class_11368 input) {
            actionId = input.method_71424(ACTION_ID_TAG_NAME, 0);
            result = SerializationUtils.getEnum(input, RESULT_TAG_NAME, RobotActionResult.class);
        }
    }

    private final class RobotActionProcessor {
        private static final String QUEUE_TAG_NAME = "queue";
        private static final String ACTION_TAG_NAME = "action";
        private static final String RESULTS_TAG_NAME = "results";
        private static final String LAST_ACTION_ID_TAG_NAME = "last_action_id";

        private final Queue<AbstractRobotAction> queue = new ArrayDeque<>(MAX_QUEUED_ACTIONS - 1);
        @Nullable
        private volatile AbstractRobotAction action; // VM -> server thread

        private final Queue<RobotActionProcessorResult> results = new ArrayDeque<>(MAX_QUEUED_RESULTS);
        private int lastActionId;

        public boolean hasQueuedActions() {
            synchronized (queue) {
                return action != null || !queue.isEmpty();
            }
        }

        public int getQueuedActionCount() {
            synchronized (queue) {
                return (action != null ? 1 : 0) + queue.size();
            }
        }

        public boolean move(final MovementDirection direction) {
            return addAction(new RobotMovementAction(direction));
        }

        public boolean rotate(final RotationDirection direction) {
            return addAction(new RobotRotationAction(direction));
        }

        public void tick() {
            if (method_73183().method_8608()) {
                RobotActions.performClient(Robot.this);
            } else {
                if (action != null) {
                    final RobotActionResult result = action.perform(Robot.this);
                    if (result != RobotActionResult.INCOMPLETE) {
                        final int actionId = action.getId();

                        synchronized (results) {
                            if (results.size() == MAX_QUEUED_RESULTS) {
                                results.remove();
                            }

                            results.add(new RobotActionProcessorResult(actionId, result));
                        }

                        action = null;

                        robotDevice.contexts.sendEvent(RobotActionCompletedEvent.TYPE, new RobotActionCompletedEvent(actionId, result));
                        robotDevice.contexts.sendEvent(RobotDevice.ACTION_COMPLETED_EVENT_CODE, actionId & 0xFFFF);
                    }
                }
                if (action == null) {
                    synchronized (queue) {
                        action = queue.poll();
                    }
                    if (action != null) {
                        action.initialize(Robot.this);
                    }
                }
                RobotActions.performServer(Robot.this, action);
            }
        }

        public void clear() {
            synchronized (queue) {
                queue.clear();
            }
            synchronized (results) {
                results.clear();
            }
        }

        public void serialize(final class_11372 output) {
            final class_11372.class_11374 queueOutput = output.method_71476(QUEUE_TAG_NAME);
            synchronized (queue) {
                for (final AbstractRobotAction action : queue) {
                    RobotActions.serialize(action, queueOutput.method_71480());
                }
            }

            final AbstractRobotAction currentAction = action;
            if (currentAction != null) {
                RobotActions.serialize(currentAction, output.method_71461(ACTION_TAG_NAME));
            }

            final class_11372.class_11374 resultsOutput = output.method_71476(RESULTS_TAG_NAME);
            synchronized (results) {
                for (final RobotActionProcessorResult result : results) {
                    result.serialize(resultsOutput.method_71480());
                }
            }

            synchronized (queue) {
                output.method_71465(LAST_ACTION_ID_TAG_NAME, lastActionId);
            }
        }

        public void deserialize(final class_11368 input) {
            synchronized (queue) {
                queue.clear();
                input.method_71438(QUEUE_TAG_NAME).method_71447()
                    .limit(MAX_QUEUED_ACTIONS - 1)
                    .map(RobotActions::deserialize)
                    .filter(Objects::nonNull)
                    .forEach(queue::add);
                lastActionId = input.method_71424(LAST_ACTION_ID_TAG_NAME, 0);
            }

            action = RobotActions.deserialize(input.method_71434(ACTION_TAG_NAME));

            synchronized (results) {
                results.clear();
                input.method_71438(RESULTS_TAG_NAME).method_71447()
                    .limit(MAX_QUEUED_RESULTS)
                    .map(RobotActionProcessorResult::new)
                    .filter(result -> result.actionId != 0)
                    .forEach(results::add);
            }
        }

        private boolean addAction(final AbstractRobotAction action) {
            if (method_73183().method_8608()) {
                return false;
            }

            if (!getVirtualMachine().isRunning()) {
                return false;
            }

            synchronized (queue) {
                if (queue.size() >= MAX_QUEUED_ACTIONS - 1) { // -1 for current action
                    return false;
                }

                lastActionId = (lastActionId + 1) & 0x7FFFFFFF; // only positive ids; unlikely to ever wrap, but eh.
                action.setId(lastActionId);
                queue.add(action);
                return true;
            }
        }
    }

    private final class RobotItemStackHandlers extends AbstractVMItemStackHandlers {
        public RobotItemStackHandlers() {
            super(
                new GroupDefinition(DeviceTypes.CPU.get(), CPU_SLOTS),
                new GroupDefinition(DeviceTypes.MEMORY.get(), MEMORY_SLOTS),
                new GroupDefinition(DeviceTypes.HARD_DRIVE.get(), HARD_DRIVE_SLOTS),
                new GroupDefinition(DeviceTypes.FLOPPY.get(), FLOPPY_SLOTS),
                new GroupDefinition(DeviceTypes.FLASH_MEMORY.get(), FLASH_MEMORY_SLOTS),
                new GroupDefinition(DeviceTypes.ROBOT_MODULE.get(), MODULE_SLOTS)
            );
        }

        @Override
        protected boolean isClientSide() {
            return method_73183().method_8608();
        }

        @Override
        protected class_7225.class_7874 getRegistries() {
            return method_73183().method_30349();
        }

        @Override
        protected ItemDeviceQuery makeQuery(final class_1799 stack) {
            return Devices.makeQuery(deviceItems.getArchitectureType().orElse(null), Robot.this, stack);
        }

        @Override
        protected void onChanged() {
            super.onChanged();
            if (!method_73183().method_8608()) {
                virtualMachine.getBusController().scheduleBusScan();
            }
        }
    }

    private final class RobotBusElement extends AbstractDeviceBusElement {
        private static final String DEVICE_ID_TAG_NAME = "device_id";

        private final Device device = new ObjectDevice(robotDevice);
        private UUID deviceId = UUID.randomUUID();

        @Override
        public Optional<Collection<DeviceBusElement>> getNeighbors() {
            return Optional.of(singleton(deviceItems.busElement));
        }

        @Override
        public Collection<Device> getLocalDevices() {
            return singleton(device);
        }

        @Override
        public Optional<UUID> getDeviceIdentifier(final Device device) {
            if (device == this.device) {
                return Optional.of(deviceId);
            }
            return super.getDeviceIdentifier(device);
        }

        public void serialize(final class_11372 output) {
            output.method_71468(DEVICE_ID_TAG_NAME, class_4844.field_25122, deviceId);
        }

        public void deserialize(final class_11368 input) {
            deviceId = input.method_71426(DEVICE_ID_TAG_NAME, class_4844.field_25122).orElse(deviceId);
        }
    }

    private final class RobotVMRunner extends AbstractTerminalVMRunner {
        public RobotVMRunner(final AbstractArchitecture architecture, final Terminal terminal) {
            super(architecture, terminal);
        }

        @Override
        protected void sendTerminalUpdateToClient(final ByteBuffer output) {
            final List<class_3222> recipients = terminalRecipients;
            if (recipients.isEmpty()) {
                return;
            }

            final RobotTerminalOutputMessage message = new RobotTerminalOutputMessage(Robot.this, output);
            for (final class_3222 player : recipients) {
                Network.sendToClient(message, player);
            }
        }
    }

    private final class RobotVirtualMachine extends AbstractVirtualMachine {
        private RobotVirtualMachine(final CommonDeviceBusController busController) {
            super(busController);
            setDeviceLocationProvider(deviceItems::getDeviceLocation);
        }

        @Override
        protected boolean hasEnergy(final int amount) {
            return !Config.robotsUseEnergy() || amount <= energy.getEnergyStored();
        }

        @Override
        protected boolean consumeEnergy(final int amount) {
            return !Config.robotsUseEnergy() || energy.consume(amount);
        }

        @Override
        protected void stopRunnerAndReset() {
            super.stopRunnerAndReset();

            TerminalUtils.resetTerminal(terminal, output -> {
                for (final class_3222 player : terminalRecipients) {
                    Network.sendToClient(new RobotTerminalOutputMessage(Robot.this, output), player);
                }
            });

            actionProcessor.clear();

            setStatusColor(DEFAULT_STATUS_COLOR);
            setStatusValue(DEFAULT_STATUS_VALUE);
        }

        @Override
        protected AbstractTerminalVMRunner createRunner(final AbstractArchitecture architecture) {
            return new RobotVMRunner(architecture, terminal);
        }

        @Override
        protected void handleBusStateChanged(final CommonDeviceBusController.BusState value) {
            Network.sendToClientsTrackingEntity(new RobotBusStateMessage(Robot.this, value), Robot.this);
        }

        @Override
        protected void handleRunStateChanged(final VMRunState value) {
            Network.sendToClientsTrackingEntity(new RobotRunStateMessage(Robot.this, value), Robot.this);
        }

        @Override
        protected void handleBootErrorChanged(@Nullable final class_2561 value) {
            Network.sendToClientsTrackingEntity(new RobotBootErrorMessage(Robot.this, value), Robot.this);
        }
    }

    @RPCDeviceDescription(typeName = "robot", description = """
        Provided by the [robot](../item/robot.md).

        ### Directions
        The direction parameter in the following methods represents a direction relative to the robot. Valid values are: `forward`, `backward`, `upward`, `downward` for movement actions, `left` and `right` for rotation actions. These directions are always from the point of view of the robot at the time it executes an action.

        Short form aliases of these values can be used for convenience: `back`, `up`, `down`. For extreme brevity, the initial letter of each direction can be used as well.

        ### Sides
        The side parameter of `detect()` represents a face of the robot rather than a movement direction. Valid values are: `front`, `up` and `down`.

        ### Position
        `getFacing()` reports a compass direction: `north`, `east`, `south` or `west`. `getPosition()` reports where the robot is relative to its origin, in blocks. `x` grows towards east, `y` upward and `z` towards south. The origin is where the robot was placed, until `calibratePosition()` moves it to where the robot is now. The position stays correct however the robot gets moved, pistons included. Breaking the robot clears the origin, changing dimension resets it to the new position.

        Note that the `robot` Lua library described in the [robot](../item/robot.md) entry offers useful wrappers for all of these methods. It is recommended to use the library instead of interacting with the device directly.""")
    @IODeviceDescription(name = "ROBOT", description = """
        Directions and sides are numbered. Movement directions are `0` forward, `1` backward, `2` upward and `3` downward. Rotation directions are `0` left and `1` right. Sides for `detect` are `0` front, `1` up and `2` down. Anything outside those ranges fails with `OCEARG`. Facings are `0` north, `1` east, `2` south and `3` west. Item and fluid ids are two bytes, low byte first; [`SYSTEM`](system.md) provides name lookup.

        ### Events
        `1 actionCompleted` is sent when an action finishes. The value is its id; `getActionResult` tells how it turned out.""")
    public final class RobotDevice implements LifecycleAwareDevice {
        public record Position(int x, int y, int z) {
        }

        private static final String DETECT_AIR = "air";
        private static final String DETECT_FLUID = "fluid";
        private static final String DETECT_SOLID = "solid";

        private static final int DETECT_CODE = 1;
        private static final int GET_ENERGY_STORED_CODE = 2;
        private static final int GET_ENERGY_CAPACITY_CODE = 3;
        private static final int GET_SELECTED_SLOT_CODE = 4;
        private static final int SET_SELECTED_SLOT_CODE = 5;
        private static final int GET_STACK_IN_SLOT_CODE = 6;
        private static final int MOVE_CODE = 7;
        private static final int TURN_CODE = 8;
        private static final int GET_LAST_ACTION_ID_CODE = 9;
        private static final int GET_QUEUED_ACTION_COUNT_CODE = 10;
        private static final int GET_ACTION_RESULT_CODE = 11;
        private static final int GET_STATUS_COLOR_CODE = 12;
        private static final int SET_STATUS_COLOR_CODE = 13;
        private static final int GET_STATUS_VALUE_CODE = 14;
        private static final int SET_STATUS_VALUE_CODE = 15;
        private static final int GET_FLUID_CODE = 16;
        private static final int GET_FACING_CODE = 17;
        private static final int GET_POSITION_CODE = 18;
        private static final int CALIBRATE_POSITION_CODE = 19;

        private static final int ACTION_COMPLETED_EVENT_CODE = 1;

        private static final MovementDirection[] IO_MOVEMENTS = {
            MovementDirection.FORWARD, MovementDirection.BACKWARD, MovementDirection.UPWARD, MovementDirection.DOWNWARD};
        private static final class_2350[] IO_FACINGS = {
            class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039};
        private static final RotationDirection[] IO_ROTATIONS = {
            RotationDirection.LEFT, RotationDirection.RIGHT};

        private final DeviceContext contexts = new DeviceContext();

        // ----------------------------------------------------------------- //

        @Override
        public void onDeviceMounted(final RPCBusContext context) {
            contexts.add(context);
        }

        @Override
        public void onDeviceUnmounted(final RPCBusContext context) {
            contexts.remove(context);
        }

        @Override
        public void onIODeviceMounted(final IOBusContext context) {
            contexts.add(context);
        }

        @Override
        public void onIODeviceUnmounted(final IOBusContext context) {
            contexts.remove(context);
        }

        // ----------------------------------------------------------------- //

        @Callback(description = "Gets the compass direction the robot is facing.",
            returnValueDescription = "`north`, `east`, `south` or `west`.")
        public String getFacing() {
            return method_5735().method_15434();
        }

        @Callback(description = "Gets the robot's position relative to its origin.",
            returnValueDescription = "the offset from the origin in `x`, `y` and `z`, in blocks.")
        public Position getPosition() {
            final class_2338 offset = getBodyPosition().method_10059(origin.comp_2208());
            return new Position(offset.method_10263(), offset.method_10264(), offset.method_10260());
        }

        @Callback(description = "Makes the robot's current position its reference origin.")
        @IOCallback(value = CALIBRATE_POSITION_CODE,
            description = "Makes the robot's current position its reference origin.")
        public void calibratePosition() {
            Robot.this.calibratePosition();
        }

        @Callback(synchronize = false,
            description = "Gets the current amount of energy stored in the robot's internal energy storage.",
            returnValueDescription = "the stored amount of energy.")
        public int getEnergyStored() {
            return (int) energy.getEnergyStored();
        }

        @Callback(synchronize = false,
            description = "Gets the maximum amount of energy that can be stored in the robot's internal energy storage.",
            returnValueDescription = "the maximum amount of energy stored.")
        public int getEnergyCapacity() {
            return (int) energy.getMaxEnergyStored();
        }

        @Callback(description = "Gets the currently selected robot inventory slot. This is used by many modules as an implicit input.",
            returnValueDescription = "the index of the selected inventory slot.")
        public int getSelectedSlot() {
            return Robot.this.getSelectedSlot();
        }

        @Callback(description = "Sets the currently selected robot inventory slot. This is used by many modules as an implicit input.",
            returnValueDescription = "the index of the newly selected slot. This may differ from `slot` if the specified value was invalid.")
        public int setSelectedSlot(@Parameter(value = "slot", description = "the index of the inventory slot to select.") final int slot) {
            Robot.this.setSelectedSlot(slot);
            return Robot.this.getSelectedSlot();
        }

        @Callback(description = "Gets a description of the item in the specified slot.",
            returnValueDescription = "a description of the item in the slot.")
        public class_1799 getStackInSlot(@Parameter(value = "slot", description = "the index of the slot to get the item description for.") final int slot) {
            return inventory.getStackInSlot(slot);
        }

        @Callback(description = "Gets what is in the robot's tank.",
            returnValueDescription = "a description of the fluid in the tank.")
        public FluidStack getFluid() {
            return tank.getFluid();
        }

        @Callback(description = "Reports what occupies the space on the specified side of the robot. " +
            "This only tells you whether the space is free, not what is in it.",
            returnValueDescription = "`solid` if something there blocks movement, `fluid` if the space holds a " +
                "fluid the robot can move through, or `air` if the space is free. Blocks the robot can pass " +
                "through, such as grass, count as `air`.")
        public String detect(@Parameter(value = "side", description = "the side to look at: `front`, `up` or `down`.") @Nullable final RobotOperationSide side) {
            if (side == null) throw new IllegalArgumentException();

            final class_1937 level = method_73183();
            final class_2338 pos = method_24515().method_10093(RobotOperationSide.toGlobal(Robot.this, side));

            final class_1923 chunkPos = new class_1923(pos);
            if (!level.method_8393(chunkPos.field_9181, chunkPos.field_9180)) {
                return DETECT_SOLID;
            }

            final class_2680 state = level.method_8320(pos);
            if (!state.method_26220(level, pos).method_1110()) {
                return DETECT_SOLID;
            }

            if (!state.method_26227().method_15769()) {
                return DETECT_FLUID;
            }

            return DETECT_AIR;
        }

        @Callback(synchronize = false,
            description = "Tries to enqueue a movement action in the specified direction.",
            returnValueDescription = "whether the action was enqueued successfully.")
        public boolean move(@Parameter(value = "direction", description = "the direction to move in: `forward`, `backward`, `upward` or `downward`, or a short form.") @Nullable final MovementDirection direction) {
            if (direction == null) throw new IllegalArgumentException();
            return actionProcessor.move(direction);
        }

        @Callback(synchronize = false,
            description = "Tries to enqueue a turn action towards the specified direction.",
            returnValueDescription = "whether the action was enqueued successfully.")
        public boolean turn(@Parameter(value = "direction", description = "the direction to turn towards: `left` or `right`.") @Nullable final RotationDirection direction) {
            if (direction == null) throw new IllegalArgumentException();
            return actionProcessor.rotate(direction);
        }

        @Callback(synchronize = false,
            description = "Gets the opaque id of the last enqueued action. Call this after a successful `move()` or " +
                "`turn()` call to obtain the id associated with the enqueued action.",
            returnValueDescription = "the id of the last enqueued action.")
        public int getLastActionId() {
            // Written by addAction under the queue monitor; read it under the same one
            // or the guest can see an id older than the action it just queued.
            synchronized (actionProcessor.queue) {
                return actionProcessor.lastActionId;
            }
        }

        @Callback(synchronize = false,
            description = "Gets the number of actions currently waiting in the action queue to be processed. " +
                "Use this to wait for actions to finish when enqueueing fails.",
            returnValueDescription = "the number of currently pending actions.")
        public int getQueuedActionCount() {
            return actionProcessor.getQueuedActionCount();
        }

        @Nullable
        @Callback(synchronize = false,
            description = "Gets the result of the action with the specified id. Action ids can be obtained from " +
                "`getLastActionId()`. Only a limited number of past action results are available.",
            returnValueDescription = "the result for the specified action id, or nothing if unavailable. When " +
                "available, possible values are: `INCOMPLETE`, `SUCCESS` and `FAILURE`.")
        public RobotActionResult getActionResult(@Parameter(value = "actionId", description = "the id of the action to get the result for.") final int actionId) {
            return findActionResult(id -> id == actionId);
        }

        @Callback(description = "Gets the color of the status light on the front of the robot.",
            returnValueDescription = "the current color, as a packed `0xRRGGBB` value.")
        public int getStatusColor() {
            return Robot.this.getStatusColor();
        }

        @Callback(description = "Sets the color of the status light on the front of the robot.",
            returnValueDescription = "the color that was applied.")
        public int setStatusColor(@Parameter(value = "color", description = "the color to set, as a packed `0xRRGGBB` value.") final int color) {
            Robot.this.setStatusColor(color);
            return Robot.this.getStatusColor();
        }

        @Callback(description = "Gets how far the status light is filled.",
            returnValueDescription = "the current fill value, in the range of [0, 1].")
        public double getStatusValue() {
            return Robot.this.getStatusValue();
        }

        @Callback(description = "Sets how far the status light is filled. It fills from the bottom, so zero hides it entirely and one fills it.",
            returnValueDescription = "the fill value that was applied.")
        public double setStatusValue(@Parameter(value = "value", description = "the fill value to set, will be clamped to [0, 1].") final double value) {
            Robot.this.setStatusValue((float) value);
            return Robot.this.getStatusValue();
        }

        // ----------------------------------------------------------------- //

        @IOCallback(value = GET_FACING_CODE,
            description = "Gets the compass direction the robot is facing.",
            resultsDescription = "one byte, the facing.")
        public void getFacing(final IOOutputStream results) throws IOException {
            results.writeU8(Arrays.asList(IO_FACINGS).indexOf(method_5735()));
        }

        @IOCallback(value = GET_POSITION_CODE,
            description = "Gets the robot's position relative to its origin.",
            resultsDescription = "six bytes, the signed two byte offsets `x`, `y` and `z`, each low byte first.")
        public void getPosition(final IOOutputStream results) throws IOException {
            final Position position = getPosition();
            results.writeU16(position.x());
            results.writeU16(position.y());
            results.writeU16(position.z());
        }

        @IOCallback(value = GET_ENERGY_STORED_CODE, synchronize = false,
            description = "Reads how much energy the robot has left.",
            resultsDescription = "four bytes, the amount, low byte first.")
        public void getEnergyStored(final IOOutputStream results) throws IOException {
            results.writeU32(energy.getEnergyStored());
        }

        @IOCallback(value = GET_ENERGY_CAPACITY_CODE, synchronize = false,
            description = "Reads how much energy the robot holds when full.",
            resultsDescription = "four bytes, the amount, low byte first.")
        public void getEnergyCapacity(final IOOutputStream results) throws IOException {
            results.writeU32(energy.getMaxEnergyStored());
        }

        @IOCallback(value = GET_SELECTED_SLOT_CODE,
            description = "Reads which inventory slot is selected.",
            resultsDescription = "one byte, the slot.")
        public void getSelectedSlot(final IOOutputStream results) throws IOException {
            results.writeU8(getSelectedSlot());
        }

        @IOCallback(value = SET_SELECTED_SLOT_CODE,
            description = "Selects an inventory slot.",
            argumentsDescription = "one byte, the slot. A slot the robot does not have is clamped into range.",
            resultsDescription = "one byte, the slot in effect after the call.")
        public void setSelectedSlot(final IOInputStream arguments, final IOOutputStream results) throws IOException {
            results.writeU8(setSelectedSlot(arguments.readU8()));
        }

        @IOCallback(value = GET_STACK_IN_SLOT_CODE,
            description = "Reads what is in an inventory slot.",
            argumentsDescription = "one byte, the slot. A slot the robot does not have fails with `OCEARG`.",
            resultsDescription = "four bytes, one slot record in the form the `ITEMS` device uses: the item as two bytes, the number of items, and damage.")
        public void getStackInSlot(final IOInputStream arguments, final IOOutputStream results) throws IOException {
            ItemHandlerProtocol.writeSlot(inventory, arguments.readU8(), results);
        }

        @IOCallback(value = GET_FLUID_CODE,
            description = "Reads what is in the robot's tank.",
            resultsDescription = "six bytes: the fluid as two bytes and the amount as four bytes. An empty tank reads as fluid 0.")
        public void getFluid(final IOOutputStream results) throws IOException {
            FluidHandlerProtocol.writeTankAt(tank, 0, results);
        }

        @IOCallback(value = DETECT_CODE,
            description = "Reports what occupies the space on that side.",
            argumentsDescription = "one byte, the side.",
            resultsDescription = "one byte: `0` air, `1` fluid, `2` solid. Only `2` stops a move.")
        public void detect(final IOInputStream arguments, final IOOutputStream results) throws IOException {
            results.writeU8(switch (detect(RobotOperationSide.byIndex(arguments.readU8()))) {
                case DETECT_AIR -> 0;
                case DETECT_FLUID -> 1;
                case DETECT_SOLID -> 2;
                default -> throw new AssertionError("unmapped detect result");
            });
        }

        @IOCallback(value = MOVE_CODE, synchronize = false,
            description = "Tries to enqueue a movement action in the specified direction.",
            argumentsDescription = "one byte, the direction.",
            resultsDescription = "one byte, `1` when the action was enqueued, `0` when the queue was full or the robot was not ready.")
        public void move(final IOInputStream arguments, final IOOutputStream results) throws IOException {
            results.writeU8(move(fromOrdinal(IO_MOVEMENTS, arguments.readU8())) ? 1 : 0);
        }

        @IOCallback(value = TURN_CODE, synchronize = false,
            description = "Tries to enqueue a turn action towards the specified direction.",
            argumentsDescription = "one byte, the direction.",
            resultsDescription = "one byte, `1` when the action was enqueued, `0` when the queue was full or the robot was not ready.")
        public void turn(final IOInputStream arguments, final IOOutputStream results) throws IOException {
            results.writeU8(turn(fromOrdinal(IO_ROTATIONS, arguments.readU8())) ? 1 : 0);
        }

        @IOCallback(value = GET_LAST_ACTION_ID_CODE, synchronize = false,
            description = "Gets the opaque id of the last enqueued action. Call this after a successful `move` or " +
                "`turn` call to obtain the id associated with the enqueued action.",
            resultsDescription = "two bytes, the id, low byte first.")
        public void getLastActionId(final IOOutputStream results) throws IOException {
            results.writeU16(getLastActionId());
        }

        @IOCallback(value = GET_QUEUED_ACTION_COUNT_CODE, synchronize = false,
            description = "Gets the number of actions currently waiting in the action queue to be processed. " +
                "Use this to wait for actions to finish when enqueueing fails.",
            resultsDescription = "one byte, the count.")
        public void getQueuedActionCount(final IOOutputStream results) throws IOException {
            results.writeU8(getQueuedActionCount());
        }

        @IOCallback(value = GET_ACTION_RESULT_CODE, synchronize = false,
            description = "Gets the result of the action with the specified id. Returns `1` until the action finishes. " +
                "May be awaited using the `actionCompleted` event.",
            argumentsDescription = "two bytes, the id.",
            resultsDescription = "one byte: `0` unknown, `1` incomplete, `2` success, `3` failure.")
        public void getActionResult(final IOInputStream arguments, final IOOutputStream results) throws IOException {
            final int actionId = arguments.readU16();
            final RobotActionResult result = findActionResult(id -> (id & 0xFFFF) == actionId);
            results.writeU8(switch (result) {
                case null -> 0;
                case INCOMPLETE -> 1;
                case SUCCESS -> 2;
                case FAILURE -> 3;
            });
        }

        @IOCallback(value = GET_STATUS_COLOR_CODE,
            description = "Reads the color of the status light.",
            resultsDescription = "three bytes, the red, green and blue components.")
        public void getStatusColor(final IOOutputStream results) throws IOException {
            final int color = getStatusColor();
            results.writeU8(color >>> 16);
            results.writeU8((color >>> 8) & 0xFF);
            results.writeU8(color & 0xFF);
        }

        @IOCallback(value = SET_STATUS_COLOR_CODE,
            description = "Sets the color of the status light.",
            argumentsDescription = "three bytes, the red, green and blue components.")
        public void setStatusColor(final IOInputStream arguments) throws IOException {
            setStatusColor((arguments.readU8() << 16) | (arguments.readU8() << 8) | arguments.readU8());
        }

        @IOCallback(value = GET_STATUS_VALUE_CODE,
            description = "Reads how far the status light is filled.",
            resultsDescription = "one byte, the fill value, where `0` is empty and `255` is full.")
        public void getStatusValue(final IOOutputStream results) throws IOException {
            results.writeU8((int) Math.round(getStatusValue() * 0xFF));
        }

        @IOCallback(value = SET_STATUS_VALUE_CODE,
            description = "Sets how far the status light is filled.",
            argumentsDescription = "one byte, the fill value, where `0` is empty and `255` is full.")
        public void setStatusValue(final IOInputStream arguments) throws IOException {
            setStatusValue(arguments.readU8() / (double) 0xFF);
        }

        // ----------------------------------------------------------------- //

        @Nullable
        private RobotActionResult findActionResult(final IntPredicate matches) {
            final AbstractRobotAction currentAction = actionProcessor.action;
            if (currentAction != null && matches.test(currentAction.getId())) {
                return RobotActionResult.INCOMPLETE;
            }
            synchronized (actionProcessor.queue) {
                for (final AbstractRobotAction action : actionProcessor.queue) {
                    if (matches.test(action.getId())) {
                        return RobotActionResult.INCOMPLETE;
                    }
                }
            }
            synchronized (actionProcessor.results) {
                for (final RobotActionProcessorResult result : actionProcessor.results) {
                    if (matches.test(result.actionId)) {
                        return result.result;
                    }
                }
            }

            return null;
        }

        private static <T> T fromOrdinal(final T[] values, final int code) {
            if (code >= values.length) {
                throw new IllegalArgumentException("value out of range: " + code
                    + " (expected 0 to " + (values.length - 1) + ")");
            }
            return values[code];
        }

        // ----------------------------------------------------------------- //

        private RobotDevice() {
        }
    }
}
