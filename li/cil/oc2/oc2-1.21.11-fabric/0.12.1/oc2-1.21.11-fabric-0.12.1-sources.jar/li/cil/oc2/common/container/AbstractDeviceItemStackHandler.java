/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.bus.AbstractItemDeviceBusElement;
import li.cil.oc2.common.transaction.TransactionContext;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public abstract class AbstractDeviceItemStackHandler extends FixedSizeItemStackHandler {
    public AbstractDeviceItemStackHandler(final int size) {
        this(class_2371.method_10213(size, class_1799.field_8037));
    }

    public AbstractDeviceItemStackHandler(final class_2371<class_1799> stacks) {
        super(stacks);
    }

    // --------------------------------------------------------------------- //

    public abstract AbstractItemDeviceBusElement getBusElement();

    public void exportDeviceDataToItemStacks() {
        for (int slot = 0; slot < getSlots(); slot++) {
            getBusElement().exportDeviceDataToItemStack(slot, getStackInSlot(slot));
        }
    }

    @Override
    public final void save(final class_11372 output) {
        throw new UnsupportedOperationException("Use saveItems and saveDevices instead.");
    }

    @Override
    public final void load(final class_11368 input) {
        throw new UnsupportedOperationException("Use loadItems and loadDevices instead.");
    }

    public void saveItems(final class_11372 output) {
        exportDeviceDataToItemStacks();

        super.save(output);
    }

    public void saveDevices(final class_11372 output) {
        getBusElement().save(output);
    }

    public void loadItems(final class_11368 input) {
        super.load(input);
        updateDevices();
    }

    public void updateDevices() {
        for (int slot = 0; slot < getSlots(); slot++) {
            getBusElement().handleSlotContentsChanged(slot, getStackInSlot(slot));
        }
    }

    public void loadDevices(final class_11368 input) {
        getBusElement().load(input);
    }

    @Override
    public class_1799 getStackInSlot(final int slot) {
        final class_1799 stack = super.getStackInSlot(slot);
        getBusElement().exportDeviceDataToItemStack(slot, stack);
        return stack;
    }

    @Override
    public class_1799 extractItem(final int slot, final int amount, final TransactionContext transaction) {
        if (amount > 0) {
            getBusElement().exportDeviceDataToItemStack(slot, super.getStackInSlot(slot));
        }

        return super.extractItem(slot, amount, transaction);
    }

    @Override
    public int getSlotLimit(final int slot) {
        return 1;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void onContentsChanged(final int slot) {
        super.onContentsChanged(slot);
        getBusElement().handleSlotContentsChanged(slot, super.getStackInSlot(slot));
    }
}
