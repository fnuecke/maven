/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.model.fabric;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import li.cil.oc2.api.API;
import net.fabricmc.fabric.api.client.model.loading.v1.CustomUnbakedBlockStateModel;
import net.minecraft.class_10821;
import net.minecraft.class_1087;
import net.minecraft.class_10889;
import net.minecraft.class_2960;
import net.minecraft.class_7775;
import net.minecraft.class_813;

public record BusCableModel(class_1087.class_10892 proxy) implements CustomUnbakedBlockStateModel {
    public static final class_2960 ID = class_2960.method_60655(API.MOD_ID, "bus_cable");
    public static final class_2960 BUS_CABLE_STRAIGHT_MODEL = class_2960.method_60655(API.MOD_ID, "block/cable_straight");
    public static final class_2960 BUS_CABLE_SUPPORT_MODEL = class_2960.method_60655(API.MOD_ID, "block/cable_support");

    public static final MapCodec<BusCableModel> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_1087.class_10892.field_57944.fieldOf("proxy").forGetter(BusCableModel::proxy)
    ).apply(instance, BusCableModel::new));

    // --------------------------------------------------------------------- //
    // CustomUnbakedBlockStateModel

    @Override
    public MapCodec<? extends CustomUnbakedBlockStateModel> codec() {
        return CODEC;
    }

    @Override
    public class_1087 method_68521(final class_7775 baker) {
        final class_10889[] straightModelByAxis = {
            bake(baker, BUS_CABLE_STRAIGHT_MODEL, class_10821.field_57029, class_10821.field_57030),
            bake(baker, BUS_CABLE_STRAIGHT_MODEL, class_10821.field_57030, class_10821.field_57029),
            bake(baker, BUS_CABLE_STRAIGHT_MODEL, class_10821.field_57029, class_10821.field_57029)
        };
        final class_10889[] supportModelByFace = {
            bake(baker, BUS_CABLE_SUPPORT_MODEL, class_10821.field_57032, class_10821.field_57029), // -y
            bake(baker, BUS_CABLE_SUPPORT_MODEL, class_10821.field_57030, class_10821.field_57029), // +y
            bake(baker, BUS_CABLE_SUPPORT_MODEL, class_10821.field_57029, class_10821.field_57031), // -z
            bake(baker, BUS_CABLE_SUPPORT_MODEL, class_10821.field_57029, class_10821.field_57029), // +z
            bake(baker, BUS_CABLE_SUPPORT_MODEL, class_10821.field_57029, class_10821.field_57030), // -x
            bake(baker, BUS_CABLE_SUPPORT_MODEL, class_10821.field_57029, class_10821.field_57032) // +x
        };

        return new BusCableBakedModel(proxy.method_68521(baker), straightModelByAxis, supportModelByFace);
    }

    @Override
    public void method_62326(final class_10103 resolver) {
        proxy.method_62326(resolver);
        resolver.markDependency(BUS_CABLE_STRAIGHT_MODEL);
        resolver.markDependency(BUS_CABLE_SUPPORT_MODEL);
    }

    // --------------------------------------------------------------------- //

    private static class_10889 bake(final class_7775 baker, final class_2960 model, final class_10821 x, final class_10821 y) {
        return new class_813(model).method_67940(x).method_67942(y).method_68510(baker);
    }
}
