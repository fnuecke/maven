/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.*;
import li.cil.oc2.client.gui.node.SideConfigurationWidget;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import java.util.List;

import static li.cil.oc2.common.util.TranslationUtils.text;

public abstract class AbstractSideConfigurationScreen extends UiScreen {
    private static final class_2561 HELP_TEXT = text("gui.{mod}.sided_device.help");
    private static final class_2561 HELP_LABEL = class_2561.method_43470("?");
    private static final int HELP_MARGIN = 2;

    // --------------------------------------------------------------------- //

    protected final class_1657 player;
    protected final class_1268 hand;

    private final class_1792 item;

    // --------------------------------------------------------------------- //

    protected AbstractSideConfigurationScreen(final class_1657 player, final class_1268 hand, final class_1792 item) {
        super(item.method_63680(), Sprites.THEME);
        this.player = player;
        this.hand = hand;
        this.item = item;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25393() {
        super.method_25393();

        final class_1799 heldItem = player.method_5998(hand);
        if (!heldItem.method_31574(item)) {
            method_25419();
        }
    }

    // --------------------------------------------------------------------- //

    protected abstract boolean getConfiguration(final class_2350 side);

    protected abstract void sendConfiguration(final class_2350 side, final boolean value);

    protected Node[] createControls() {
        return new Node[0];
    }

    @Override
    protected Window createWindow() {
        final NodeStack help = NodeStack.horizontal(new LabelNode(HELP_LABEL).tooltip(() -> List.of(HELP_TEXT)))
            .padding(HELP_MARGIN).alignment(Align.END, Align.START).overlay();
        final NodeStack blockView = Ui.insetBlack(new WidgetNode(new SideConfigurationWidget(this::getConfiguration, this::sendConfiguration)))
            .add(help);
        final NodeStack content = NodeStack.vertical(blockView).alignment(Align.START, Align.CENTER);
        content.add(createControls());
        return new Window(Ui.section(field_22785, content));
    }
}
