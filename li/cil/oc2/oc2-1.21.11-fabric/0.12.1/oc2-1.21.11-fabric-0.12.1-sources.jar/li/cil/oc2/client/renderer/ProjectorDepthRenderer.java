/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalNotification;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import dev.architectury.event.events.client.ClientTickEvent;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import li.cil.oc2.client.ClientPlatform;
import li.cil.oc2.common.block.FlippableOrientableBlock;
import li.cil.oc2.common.block.FlippableOrientation;
import li.cil.oc2.common.blockentity.ProjectorBlockEntity;
import li.cil.oc2.common.bus.device.block.ProjectorDevice;
import li.cil.oc2.common.ext.LevelRendererExt;
import li.cil.oc2.common.ext.MinecraftExt;
import li.cil.oc2.common.util.FakePlayerUtils;
import li.cil.oc2.jcodec.common.model.Picture;
import li.cil.oc2.jcodec.scale.Yuv420jToRgb;
import net.minecraft.class_10017;
import net.minecraft.class_10055;
import net.minecraft.class_1011;
import net.minecraft.class_10366;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_11284;
import net.minecraft.class_11286;
import net.minecraft.class_11531;
import net.minecraft.class_11658;
import net.minecraft.class_11661;
import net.minecraft.class_11684;
import net.minecraft.class_11943;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_12137;
import net.minecraft.class_12393;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_276;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4076;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_4618;
import net.minecraft.class_6367;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_761;
import net.minecraft.class_824;
import net.minecraft.class_898;
import net.minecraft.class_9779;
import net.minecraft.class_9799;
import net.minecraft.class_9976;
import net.minecraft.client.renderer.*;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;
import org.lwjgl.system.MemoryStack;

import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ExecutionException;

public final class ProjectorDepthRenderer {
    private static final int DEPTH_CAPTURE_SIZE = 256;
    private static final int DEPTH_BUFFER_SOURCE_BYTES = 768 * 1024;
    private static final float EMISSIVE_STRENGTH = 1.0f;
    private static final int PROJECTORS_CONFIG_SIZE = (1 + ModShaders.MAX_PROJECTORS) * 64 + 16;
    private static final String[] PROJECTOR_COLOR_NAMES = {"ProjectorColor0", "ProjectorColor1", "ProjectorColor2"};
    private static final String[] PROJECTOR_DEPTH_NAMES = {"ProjectorDepth0", "ProjectorDepth1", "ProjectorDepth2"};

    private static final List<ProjectorBlockEntity> VISIBLE_PROJECTORS = new ArrayList<>();
    private static final LazyDepthOnlyRenderBuffer[] PROJECTOR_DEPTH_BUFFER_LEDGER = new LazyDepthOnlyRenderBuffer[ModShaders.MAX_PROJECTORS];
    private static final class_276[] PROJECTOR_DEPTH_BUFFERS = new class_276[ModShaders.MAX_PROJECTORS];
    private static final class_1043[] PROJECTOR_COLOR_BUFFERS = new class_1043[ModShaders.MAX_PROJECTORS];
    private static final Matrix4f[] PROJECTOR_CAMERA_MATRICES = new Matrix4f[ModShaders.MAX_PROJECTORS];
    private static final class_4184 PROJECTOR_DEPTH_CAMERA = new class_4184();
    private static final float PROJECTOR_FORWARD_SHIFT = 7 / 16f; // From center of projector block.
    private static final float PROJECTOR_NEAR = 0.5f - PROJECTOR_FORWARD_SHIFT;
    private static final float PROJECTOR_FAR = ProjectorBlockEntity.MAX_RENDER_DISTANCE;
    private static final int HALF_FRUSTUM_WIDTH = (ProjectorBlockEntity.MAX_WIDTH - 1) / 2;
    private static final int FRUSTUM_HEIGHT = ProjectorBlockEntity.MAX_HEIGHT - 1;
    private static final Matrix4f DEPTH_CAMERA_PROJECTION_MATRIX = getFrustumMatrix(
        PROJECTOR_NEAR, PROJECTOR_FAR,
        ProjectorBlockEntity.MAX_GOOD_RENDER_DISTANCE,
        -HALF_FRUSTUM_WIDTH, HALF_FRUSTUM_WIDTH,
        FRUSTUM_HEIGHT, 0);
    private static final Matrix4f UPSIDE_DOWN_DEPTH_CAMERA_PROJECTION_MATRIX = getFrustumMatrix(
        PROJECTOR_NEAR, PROJECTOR_FAR,
        ProjectorBlockEntity.MAX_GOOD_RENDER_DISTANCE,
        -HALF_FRUSTUM_WIDTH, HALF_FRUSTUM_WIDTH,
        0, -FRUSTUM_HEIGHT);
    private static final Quaternionf VIEW_ROTATION = new Quaternionf();
    private static final Matrix4f MODEL_VIEW_MATRIX = new Matrix4f();
    private static final Matrix4f PROJECTION_MATRIX = new Matrix4f();
    private static final Matrix4f INVERSE_MAIN_CAMERA_MATRIX = new Matrix4f();
    private static final class_11658 DEPTH_LEVEL_RENDER_STATE = new class_11658();
    private static final class_11943 DEPTH_PARTICLES_RENDER_STATE = new class_11943();

    private static final Cache<ProjectorBlockEntity, RenderInfo> RENDER_INFO = CacheBuilder.newBuilder()
        .expireAfterAccess(Duration.ofSeconds(5))
        .removalListener(ProjectorDepthRenderer::handleProjectorNoLongerRendering)
        .build();

    @Nullable
    private static class_276 activeProjectorDepthTarget;
    @Nullable
    private static DepthPassResources depthPassResources;
    @Nullable
    private static GpuBuffer projectorsConfig;

    private static int pendingRenderCount;
    private static int refreshSlot;
    private static boolean isRenderingProjectorDepth;
    private static boolean isRenderedBeforeTransparencyChain;
    @Nullable
    private static class_4184 gameRendererMainCameraBak;
    @Nullable
    private static GpuBuffer globalSettingsBak;

    private static void handleProjectorNoLongerRendering(final RemovalNotification<ProjectorBlockEntity, RenderInfo> notification) {
        final ProjectorBlockEntity projector = notification.getKey();
        if (projector != null) {
            projector.setFrameConsumer(null);
        }
        final RenderInfo renderInfo = notification.getValue();
        if (renderInfo != null) {
            renderInfo.close();
        }
    }

    static {
        for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
            PROJECTOR_CAMERA_MATRICES[i] = new Matrix4f();
        }
    }

    private static LazyDepthOnlyRenderBuffer[] projectorDepthBuffers() {
        if (PROJECTOR_DEPTH_BUFFER_LEDGER[0] == null) {
            for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
                PROJECTOR_DEPTH_BUFFER_LEDGER[i] = new LazyDepthOnlyRenderBuffer();
            }
        }
        return PROJECTOR_DEPTH_BUFFER_LEDGER;
    }

    private static DepthPassResources depthPassResources() {
        if (depthPassResources == null) {
            depthPassResources = new DepthPassResources(class_310.method_1551());
        }
        return depthPassResources;
    }

    private static GpuBuffer projectorsConfig() {
        if (projectorsConfig == null) {
            projectorsConfig = RenderSystem.getDevice().createBuffer(() -> "oc2 projectors config",
                GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST, PROJECTORS_CONFIG_SIZE);
        }
        return projectorsConfig;
    }

    // --------------------------------------------------------------------- //

    public static void addProjector(final ProjectorBlockEntity projector) {
        // Projectors may be rendered multiple times, e.g. in shadow passes when shaders are enabled.
        if (!VISIBLE_PROJECTORS.contains(projector) && isProjectionVisible(projector)) {
            VISIBLE_PROJECTORS.add(projector);
        }
    }

    public static boolean isRenderingProjectorDepth() {
        return isRenderingProjectorDepth;
    }

    @Nullable
    public static class_276 getActiveProjectorDepthTarget() {
        return activeProjectorDepthTarget;
    }

    public static void onBeforeLevel(final class_9779 deltaTracker) {
        try {
            if (VISIBLE_PROJECTORS.isEmpty()) {
                return;
            }

            final int projectorIndex = getNextDepthTargetSlotToRender(Math.min(VISIBLE_PROJECTORS.size(), ModShaders.MAX_PROJECTORS));
            if (projectorIndex < 0) {
                return;
            }

            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(projectorIndex);
            final class_310 minecraft = class_310.method_1551();
            final class_638 level = minecraft.field_1687;
            if (level == null || projector.method_11015() || projector.method_10997() != level) {
                return;
            }

            renderDepthBuffer(minecraft, level, deltaTracker, projectorIndex, projector);
        } finally {
            VISIBLE_PROJECTORS.clear();
        }
    }

    public static void captureMainCamera(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
        MODEL_VIEW_MATRIX.set(modelViewMatrix);
        PROJECTION_MATRIX.set(projectionMatrix);
    }

    public static void onBeforeTransparencyChain() {
        isRenderedBeforeTransparencyChain = true;
        if (prepareProjectorRendering()) {
            renderProjectors(class_310.method_1551());
        }
    }

    public static void onAfterLevel() {
        try {
            if (!isRenderedBeforeTransparencyChain && prepareProjectorRendering()) {
                renderProjectors(class_310.method_1551());
            }
        } finally {
            isRenderedBeforeTransparencyChain = false;
            pendingRenderCount = 0;
            Arrays.fill(PROJECTOR_COLOR_BUFFERS, null);
            Arrays.fill(PROJECTOR_DEPTH_BUFFERS, null);
        }
    }

    public static void initialize() {
        IrisCompat.copyPipeline(class_10799.field_56825, ModRenderType.getProjectorLight().method_73243());

        ClientTickEvent.CLIENT_POST.register(minecraft -> {
            RENDER_INFO.cleanUp();
            if (minecraft.field_1687 == null) {
                VISIBLE_PROJECTORS.clear();
            }
        });
    }

    // --------------------------------------------------------------------- //

    private static boolean isProjectionVisible(final ProjectorBlockEntity projector) {
        final class_4604 frustum = ((LevelRendererExt) class_310.method_1551().field_1769).oc2$getCullingFrustum();
        return frustum != null && frustum.method_23093(projectionBounds(projector));
    }

    private static class_238 projectionBounds(final ProjectorBlockEntity projector) {
        return projector.getExpandedRenderBoundingBox()
            .method_1014(1); // Compensate e.g. view bobbing and allow init a bit early.
    }

    private static boolean prepareProjectorRendering() {
        if (VISIBLE_PROJECTORS.isEmpty()) {
            return false;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_638 level = minecraft.field_1687;
        final class_746 player = minecraft.field_1724;
        if (level == null || player == null) {
            VISIBLE_PROJECTORS.clear();
            return false;
        }

        VISIBLE_PROJECTORS.sort((projector1, projector2) -> {
            final double distance1 = player.method_5707(class_243.method_24953(projector1.method_11016()));
            final double distance2 = player.method_5707(class_243.method_24953(projector2.method_11016()));
            return Double.compare(distance1, distance2);
        });

        final int projectorCount = Math.min(VISIBLE_PROJECTORS.size(), ModShaders.MAX_PROJECTORS);
        for (int i = 0; i < projectorCount; i++) {
            VISIBLE_PROJECTORS.get(i).onRendering();
        }

        pendingRenderCount = updateProjectorDepths(minecraft, projectorCount);

        return pendingRenderCount > 0;
    }

    private static int updateProjectorDepths(final class_310 minecraft, final int projectorCount) {
        final class_243 mainCameraPosition = minecraft.field_1773.method_19418().method_71156();
        final class_4587 viewModelStack = new class_4587();

        matchDepthTargetsToOwningProjectors(projectorCount);

        final int validDepthTargetCount = sortByDepthBufferValidity(projectorCount);

        for (int i = 0; i < validDepthTargetCount; i++) {
            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(i);
            final FlippableOrientation orientation = projector.method_11010().method_11654(FlippableOrientableBlock.ORIENTATION);
            final class_243 projectorPos = class_243
                .method_24953(projector.method_11016())
                .method_1019(new class_243(orientation.getFacing().method_23955()).method_1021(PROJECTOR_FORWARD_SHIFT));

            setupViewModelMatrix(viewModelStack, orientation);

            storeProjectorMatrix(i, projectorPos, mainCameraPosition, viewModelStack, getProjectionMatrix(orientation));

            storeProjectorBuffers(i, projector);
        }

        return validDepthTargetCount;
    }

    private static void matchDepthTargetsToOwningProjectors(final int projectorCount) {
        for (int i = 0; i < projectorCount; i++) {
            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(i);
            for (int j = i; j < ModShaders.MAX_PROJECTORS; j++) {
                if (projectorDepthBuffers()[j].isOwnedBy(projector)) {
                    swapDepthTargets(i, j);
                    break;
                }
            }
        }
    }

    private static int sortByDepthBufferValidity(final int projectorCount) {
        int validDepthTargetCount = 0;

        for (int i = 0; i < projectorCount; i++) {
            if (!projectorDepthBuffers()[i].isOwnedBy(VISIBLE_PROJECTORS.get(i))) {
                continue;
            }

            Collections.swap(VISIBLE_PROJECTORS, i, validDepthTargetCount);
            swapDepthTargets(i, validDepthTargetCount);

            validDepthTargetCount++;
        }

        return validDepthTargetCount;
    }

    private static void swapDepthTargets(final int a, final int b) {
        if (a == b) {
            return;
        }

        final var target = PROJECTOR_DEPTH_BUFFER_LEDGER[a];
        PROJECTOR_DEPTH_BUFFER_LEDGER[a] = PROJECTOR_DEPTH_BUFFER_LEDGER[b];
        PROJECTOR_DEPTH_BUFFER_LEDGER[b] = target;
    }

    private static void renderDepthBuffer(final class_310 minecraft, final class_638 level,
                                          final class_9779 deltaTracker, final int projectorIndex,
                                          final ProjectorBlockEntity projector) {
        final class_4587 viewModelStack = new class_4587();
        final FlippableOrientation orientation = projector.method_11010().method_11654(FlippableOrientableBlock.ORIENTATION);
        final class_243 projectorPos = class_243
            .method_24953(projector.method_11016())
            .method_1019(new class_243(orientation.getFacing().method_23955()).method_1021(PROJECTOR_FORWARD_SHIFT));

        try {
            prepareDepthBufferRendering(minecraft);

            configureProjectorDepthCamera(level, projectorPos, orientation);
            updateGlobalSettings(minecraft, deltaTracker);

            final Matrix4f projectionMatrix = getProjectionMatrix(orientation);
            RenderSystem.setProjectionMatrix(depthPassResources().projectionMatrixBuffer.method_71123(projectionMatrix), class_10366.field_54953);
            setupViewModelMatrix(viewModelStack, orientation);

            bindProjectorDepthRenderTarget(projectorIndex, projector, minecraft);

            renderProjectorDepthBuffer(minecraft, level, deltaTracker, viewModelStack, projectionMatrix);
        } finally {
            finishDepthBufferRendering(minecraft);
        }
    }

    private static int getNextDepthTargetSlotToRender(final int projectorCount) {
        refreshSlot = (refreshSlot + 1) % ModShaders.MAX_PROJECTORS;
        return refreshSlot < projectorCount ? refreshSlot : -1;
    }

    private static void prepareDepthBufferRendering(final class_310 minecraft) {
        isRenderingProjectorDepth = true;

        gameRendererMainCameraBak = minecraft.field_1773.field_18765;
        minecraft.field_1773.field_18765 = PROJECTOR_DEPTH_CAMERA;
        prepareRenderDispatchers(minecraft, PROJECTOR_DEPTH_CAMERA);

        RenderSystem.backupProjectionMatrix();
        globalSettingsBak = RenderSystem.getGlobalSettingsUniform();
    }

    private static void finishDepthBufferRendering(final class_310 minecraft) {
        isRenderingProjectorDepth = false;
        activeProjectorDepthTarget = null;

        ((MinecraftExt) minecraft).setMainRenderTargetOverride(null);

        RenderSystem.restoreProjectionMatrix();
        RenderSystem.setGlobalSettingsUniform(globalSettingsBak);

        minecraft.field_1773.field_18765 = gameRendererMainCameraBak;
        prepareRenderDispatchers(minecraft, gameRendererMainCameraBak);
    }

    // Same as in GameRenderer::render(), but for the projector camera.
    private static void updateGlobalSettings(final class_310 minecraft, final class_9779 deltaTracker) {
        depthPassResources().globalSettingsUniform.method_71116(
            minecraft.method_22683().method_4489(),
            minecraft.method_22683().method_4506(),
            minecraft.field_1690.method_48581().method_41753(),
            minecraft.field_1687 == null ? 0L : minecraft.field_1687.method_75260(),
            deltaTracker,
            minecraft.field_1690.method_57703(),
            PROJECTOR_DEPTH_CAMERA,
            minecraft.field_1690.method_76747().method_41753() == class_12393.field_64664
        );
    }

    private static void prepareRenderDispatchers(final class_310 minecraft, final class_4184 camera) {
        // Same calls as in LevelRenderer::renderLevel() before it extracts entities.
        minecraft.method_31975().method_3549(camera);
        minecraft.method_1561().method_3941(camera, minecraft.field_1692);
    }

    // Manual level rendering a la LevelRenderer::renderLevel(), with the bits we need for the projector depth.
    private static void renderProjectorDepthBuffer(final class_310 minecraft, final class_638 level, final class_9779 deltaTracker, final class_4587 viewModelStack, final Matrix4f projectionMatrix) {
        final class_761 levelRenderer = minecraft.field_1769;
        final LevelRendererExt levelRendererExt = (LevelRendererExt) levelRenderer;
        final DepthPassResources resources = depthPassResources();
        final Matrix4f frustumMatrix = viewModelStack.method_23760().method_23761();
        final class_243 cameraPosition = PROJECTOR_DEPTH_CAMERA.method_71156();
        final double cameraX = cameraPosition.method_10216(), cameraY = cameraPosition.method_10214(), cameraZ = cameraPosition.method_10215();
        final float partialTicks = deltaTracker.method_60637(false);

        final class_4604 frustum = new class_4604(frustumMatrix, projectionMatrix);
        frustum.method_23088(cameraX, cameraY, cameraZ);

        final Object sodiumMatrices = SodiumCompat.setChunkRenderMatrices(levelRenderer, projectionMatrix, frustumMatrix);
        try {
            levelRendererExt.oc2$cullTerrain(PROJECTOR_DEPTH_CAMERA, frustum);
            levelRendererExt.oc2$prepareChunkRenders(frustumMatrix, cameraX, cameraY, cameraZ)
                .method_72170(class_11531.field_61022, resources.terrainSampler);
        } finally {
            SodiumCompat.restoreChunkRenderMatrices(levelRenderer, sodiumMatrices);
        }

        NetworkCableRenderer.render(PROJECTOR_DEPTH_CAMERA, frustumMatrix, frustum);

        final class_11658 renderState = DEPTH_LEVEL_RENDER_STATE;
        final class_12075 cameraRenderState = renderState.field_63082;
        cameraRenderState.field_63079 = true;
        cameraRenderState.field_63078 = cameraPosition;
        cameraRenderState.field_63077 = PROJECTOR_DEPTH_CAMERA.method_19328();
        cameraRenderState.field_63080 = cameraPosition;
        cameraRenderState.field_63081.set(PROJECTOR_DEPTH_CAMERA.method_23767());

        final Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.pushMatrix().mul(frustumMatrix);
        try {
            final class_4587 poseStack = new class_4587();

            extractEntities(minecraft, level, frustum, partialTicks, cameraX, cameraY, cameraZ, renderState);
            final class_898 entityRenderDispatcher = minecraft.method_1561();
            for (final class_10017 entityRenderState : renderState.field_61735) {
                entityRenderDispatcher.method_72976(entityRenderState, cameraRenderState,
                    entityRenderState.field_53325 - cameraX, entityRenderState.field_53326 - cameraY, entityRenderState.field_53327 - cameraZ,
                    poseStack, resources.submitNodeStorage);
            }

            extractBlockEntities(minecraft, level, frustum, partialTicks, cameraX, cameraY, cameraZ, renderState);
            final class_824 blockEntityRenderDispatcher = minecraft.method_31975();
            for (final class_11954 blockEntityRenderState : renderState.field_62646) {
                final class_2338 pos = blockEntityRenderState.field_62673;
                poseStack.method_22903();
                poseStack.method_22904(pos.method_10263() - cameraX, pos.method_10264() - cameraY, pos.method_10260() - cameraZ);
                blockEntityRenderDispatcher.method_3555(blockEntityRenderState, poseStack, resources.submitNodeStorage, cameraRenderState);
                poseStack.method_22909();
            }

            minecraft.field_1713.method_74283(DEPTH_PARTICLES_RENDER_STATE, frustum, PROJECTOR_DEPTH_CAMERA, partialTicks);
            DEPTH_PARTICLES_RENDER_STATE.method_74319(resources.submitNodeStorage, cameraRenderState);

            resources.featureRenderDispatcher.method_73002();
            resources.bufferSource.method_22993();

            // Weather only writes depth with "Fabulous!", same as for the main camera.
            if (class_310.method_29611()) {
                resources.weatherEffectRenderer.method_62315(level, levelRendererExt.oc2$getTicks(), partialTicks, cameraPosition, renderState.field_63085);
                resources.weatherEffectRenderer.method_62320(resources.bufferSource, cameraPosition, renderState.field_63085);
                resources.bufferSource.method_22993();
            }
        } finally {
            modelViewStack.popMatrix();
            resources.submitNodeStorage.method_72953();
            resources.submitNodeStorage.method_72954();
            resources.featureRenderDispatcher.method_74817();
            DEPTH_PARTICLES_RENDER_STATE.method_74317();
            renderState.method_72913();
        }
    }

    private static void extractEntities(final class_310 minecraft, final class_638 level, final class_4604 frustum,
                                        final float partialTicks,
                                        final double cameraX, final double cameraY, final double cameraZ,
                                        final class_11658 renderState) {
        final class_898 dispatcher = minecraft.method_1561();
        for (final class_1297 entity : level.method_18112()) {
            if (dispatcher.method_3950(entity, frustum, cameraX, cameraY, cameraZ)) {
                final class_10017 entityRenderState = dispatcher.method_72977(entity, partialTicks);
                entityRenderState.field_61821 = 0;
                entityRenderState.field_53337 = null;
                if (entityRenderState instanceof final class_10055 avatarRenderState) {
                    avatarRenderState.field_53525 = null;
                }
                // Skip shadow rendering for perf.
                entityRenderState.field_61823.clear();
                renderState.field_61735.add(entityRenderState);
            }
        }
    }

    // Same as in LevelRenderer::renderLevel() with the relevant block entity subset (chunks in projector frustum).
    private static void extractBlockEntities(final class_310 minecraft, final class_638 level, final class_4604 frustum,
                                             final float partialTicks,
                                             final double cameraX, final double cameraY, final double cameraZ,
                                             final class_11658 renderState) {
        final class_238 bounds = frustumBounds(cameraX, cameraY, cameraZ);
        final int minChunkX = class_4076.method_18675(class_3532.method_15357(bounds.field_1323));
        final int maxChunkX = class_4076.method_18675(class_3532.method_15357(bounds.field_1320));
        final int minChunkZ = class_4076.method_18675(class_3532.method_15357(bounds.field_1321));
        final int maxChunkZ = class_4076.method_18675(class_3532.method_15357(bounds.field_1324));
        final int minSectionY = class_4076.method_18675(class_3532.method_15357(bounds.field_1322));
        final int maxSectionY = class_4076.method_18675(class_3532.method_15357(bounds.field_1325));
        final class_824 dispatcher = minecraft.method_31975();

        for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
            for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
                final class_2818 chunk = level.method_2935().method_21730(chunkX, chunkZ);
                if (chunk == null) {
                    continue;
                }

                for (final class_2586 blockEntity : chunk.method_12214().values()) {
                    final int sectionY = class_4076.method_18675(blockEntity.method_11016().method_10264());
                    if (sectionY < minSectionY || sectionY > maxSectionY) {
                        continue;
                    }

                    final class_11954 blockEntityRenderState = ClientPlatform.tryExtractBlockEntityRenderState(dispatcher, blockEntity, partialTicks, frustum);
                    if (blockEntityRenderState != null) {
                        renderState.field_62646.add(blockEntityRenderState);
                    }
                }
            }
        }
    }

    private static void configureProjectorDepthCamera(final class_638 level, final class_243 pos, final FlippableOrientation orientation) {
        final FlippableOrientation viewOrientation = orientation.getUpright();
        final float rotationY = viewOrientation.getRotationY() + 180;
        final float rotationX = viewOrientation.getRotationX();
        PROJECTOR_DEPTH_CAMERA.method_19321(level, ProjectorCameraEntity.get(level, pos, rotationY, rotationX), false, false, 0);
    }

    private static void setupViewModelMatrix(final class_4587 viewModelStack, final FlippableOrientation orientation) {
        viewModelStack.method_34426();
        viewModelStack.method_22907(orientation.getUpright().getRotation().conjugate(VIEW_ROTATION));
    }

    private static Matrix4f getProjectionMatrix(final FlippableOrientation orientation) {
        return orientation.isUpsideDown() ? UPSIDE_DOWN_DEPTH_CAMERA_PROJECTION_MATRIX : DEPTH_CAMERA_PROJECTION_MATRIX;
    }

    private static class_238 frustumBounds(final double cameraX, final double cameraY, final double cameraZ) {
        final double reach = ProjectorBlockEntity.MAX_RENDER_DISTANCE;
        return new class_238(cameraX - reach, cameraY - reach, cameraZ - reach,
            cameraX + reach, cameraY + reach, cameraZ + reach);
    }

    private static void bindProjectorDepthRenderTarget(final int projectorIndex, final ProjectorBlockEntity projector, final class_310 minecraft) {
        final var projectorDepthTarget = projectorDepthBuffers()[projectorIndex];
        if (!projectorDepthTarget.isOwnedBy(projector)) {
            projectorDepthTarget.owner = new WeakReference<>(projector);
        }
        final class_276 target = projectorDepthTarget.target();
        RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(target.method_30277(), 0, target.method_30278(), 1.0);
        activeProjectorDepthTarget = target;
        ((MinecraftExt) minecraft).setMainRenderTargetOverride(target);
    }

    private static void storeProjectorMatrix(final int projectorIndex, final class_243 projectorPos, final class_243 mainCameraPosition, final class_4587 viewModelStack, final Matrix4f projectionMatrix) {
        // Save model-view-projection matrix for mapping in compositing shader. We use the position relative to the
        // main camera here, so that the main camera can sit at the origin. This avoids loss of precision.
        PROJECTOR_CAMERA_MATRICES[projectorIndex].set(projectionMatrix);
        viewModelStack.method_22903();
        viewModelStack.method_22904(
            mainCameraPosition.method_10216() - projectorPos.method_10216(),
            mainCameraPosition.method_10214() - projectorPos.method_10214(),
            mainCameraPosition.method_10215() - projectorPos.method_10215()
        );
        PROJECTOR_CAMERA_MATRICES[projectorIndex].mul(viewModelStack.method_23760().method_23761());
        viewModelStack.method_22909();
    }

    private static void storeProjectorBuffers(final int projectorIndex, final ProjectorBlockEntity projector) {
        PROJECTOR_COLOR_BUFFERS[projectorIndex] = getColorBuffer(projector);
        PROJECTOR_DEPTH_BUFFERS[projectorIndex] = projectorDepthBuffers()[projectorIndex].target();
    }

    private static void renderProjectors(final class_310 minecraft) {
        final class_276 mainRenderTarget = minecraft.method_1522();
        final CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();

        INVERSE_MAIN_CAMERA_MATRIX.set(PROJECTION_MATRIX).mul(MODEL_VIEW_MATRIX).invert();
        try (MemoryStack stack = MemoryStack.stackPush()) {
            final Std140Builder builder = Std140Builder.onStack(stack, PROJECTORS_CONFIG_SIZE)
                .putMat4f(INVERSE_MAIN_CAMERA_MATRIX);
            for (final Matrix4f matrix : PROJECTOR_CAMERA_MATRICES) {
                builder.putMat4f(matrix);
            }
            final ByteBuffer data = builder
                .putInt(pendingRenderCount)
                .putFloat(EMISSIVE_STRENGTH)
                .get();
            commandEncoder.writeToBuffer(projectorsConfig().slice(), data);
        }

        final class_12137 nearest = RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST);
        final class_12137 linear = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
        try (RenderPass pass = commandEncoder.createRenderPass(() -> "oc2 projectors", mainRenderTarget.method_71639(), OptionalInt.empty())) {
            pass.setPipeline(ModShaders.PROJECTORS_PIPELINE);
            pass.setUniform("ProjectorsConfig", projectorsConfig());
            pass.bindTexture("MainCameraDepth", mainRenderTarget.method_71640(), nearest);
            for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
                // Unused slots are skipped by the shader, but every sampler must be bound.
                final int slot = i < pendingRenderCount ? i : 0;
                pass.bindTexture(PROJECTOR_COLOR_NAMES[i], PROJECTOR_COLOR_BUFFERS[slot].method_71659(), linear);
                pass.bindTexture(PROJECTOR_DEPTH_NAMES[i], PROJECTOR_DEPTH_BUFFERS[slot].method_71640(), nearest);
            }
            pass.draw(0, 3);
        }
    }

    private static Matrix4f getFrustumMatrix(final float near, final float far, final float dist,
                                             final float left, final float right,
                                             final float top, final float bottom) {
        return new Matrix4f().set(new float[]{
            2 * dist / (right - left), 0, 0, 0,
            0, 2 * dist / (top - bottom), 0, 0,
            (right + left) / (right - left), (top + bottom) / (top - bottom), -(far + near) / (far - near), -1,
            0, 0, -(2 * far * near) / (far - near), 0,
        });
    }

    private static class_1043 getColorBuffer(final ProjectorBlockEntity projector) {
        try {
            final RenderInfo renderInfo = RENDER_INFO.get(projector, () -> {
                final class_1043 texture = new class_1043("oc2 projector", ProjectorDevice.WIDTH, ProjectorDevice.HEIGHT, true);
                final RenderInfo info = new RenderInfo(texture);
                info.upload();
                projector.setFrameConsumer(info);
                return info;
            });

            renderInfo.uploadIfDirty();

            return renderInfo.texture();
        } catch (final ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    // --------------------------------------------------------------------- //

    private static final class DepthPassResources {
        public final class_11284 globalSettingsUniform = new class_11284();
        public final class_11286 projectionMatrixBuffer = new class_11286("oc2 projector depth");
        public final class_12137 terrainSampler = RenderSystem.getSamplerCache().method_76520(FilterMode.LINEAR, true);
        public final class_4597.class_4598 bufferSource;
        public final class_11661 submitNodeStorage = new class_11661();
        public final class_11684 featureRenderDispatcher;
        public final class_9976 weatherEffectRenderer = new class_9976();

        public DepthPassResources(final class_310 minecraft) {
            // Same fixed buffers as vanilla. Layered consumers, e.g. enchantment glint, need their own buffer.
            // Direct field access of bufferSource for Iris compatibility (it changes what the getter method returns).
            final SequencedMap<class_1921, class_9799> fixedBuffers = new Object2ObjectLinkedOpenHashMap<>();
            for (final class_1921 renderType : minecraft.method_22940().field_46901.field_20953.keySet()) {
                fixedBuffers.put(renderType, new class_9799(renderType.method_22722()));
            }
            bufferSource = class_4597.method_22992(fixedBuffers, new class_9799(DEPTH_BUFFER_SOURCE_BYTES));

            featureRenderDispatcher = new class_11684(
                submitNodeStorage,
                minecraft.method_1541(),
                bufferSource,
                minecraft.method_72703(),
                new class_4618(),
                minecraft.method_22940().method_23001(),
                minecraft.field_1772
            );
        }
    }

    private static class LazyDepthOnlyRenderBuffer {
        @Nullable
        public class_276 target;
        @Nullable
        public WeakReference<?> owner;

        public class_276 target() {
            if (target == null) {
                target = new class_6367("oc2 projector depth", DEPTH_CAPTURE_SIZE, DEPTH_CAPTURE_SIZE, true);
            }
            return target;
        }

        public boolean isOwnedBy(ProjectorBlockEntity projector) {
            return owner != null && owner.get() == projector;
        }
    }

    private static final class RenderInfo implements ProjectorBlockEntity.FrameConsumer {
        private static final ThreadLocal<byte[]> RGB = ThreadLocal.withInitial(() -> new byte[3]);

        private final class_1043 texture;
        private boolean hasNewFrame;

        RenderInfo(final class_1043 texture) {
            this.texture = texture;
        }

        public class_1043 texture() {
            return texture;
        }

        public synchronized void close() {
            texture.close();
        }

        public synchronized void uploadIfDirty() {
            if (hasNewFrame) {
                hasNewFrame = false;
                upload();
            }
        }

        public void upload() {
            texture.method_4524();
        }

        @Override
        public synchronized void processFrame(final Picture picture) {
            final class_1011 image = texture.method_4525();
            if (image == null) {
                return;
            }

            final byte[] y = picture.getPlaneData(0);
            final byte[] u = picture.getPlaneData(1);
            final byte[] v = picture.getPlaneData(2);

            // Convert in quads, based on the half resolution of UV. As such, skip every other row, since
            // we're setting the current and the next.
            int lumaIndex = 0, chromaIndex = 0;
            for (int halfRow = 0; halfRow < ProjectorDevice.HEIGHT / 2; halfRow++, lumaIndex += ProjectorDevice.WIDTH * 2) {
                final int row = halfRow * 2;
                for (int halfCol = 0; halfCol < ProjectorDevice.WIDTH / 2; halfCol++, chromaIndex++) {
                    final int col = halfCol * 2;
                    final int yIndex = lumaIndex + col;
                    final byte cb = u[chromaIndex];
                    final byte cr = v[chromaIndex];
                    setFromYUV420(image, col, row, y[yIndex], cb, cr);
                    setFromYUV420(image, col + 1, row, y[yIndex + 1], cb, cr);
                    setFromYUV420(image, col, row + 1, y[yIndex + ProjectorDevice.WIDTH], cb, cr);
                    setFromYUV420(image, col + 1, row + 1, y[yIndex + ProjectorDevice.WIDTH + 1], cb, cr);
                }
            }

            hasNewFrame = true;
        }

        private static void setFromYUV420(final class_1011 image, final int col, final int row, final byte y, final byte cb, final byte cr) {
            final byte[] bytes = RGB.get();
            Yuv420jToRgb.YUVJtoRGB(y, cb, cr, bytes, 0);
            final int r = bytes[0] + 128;
            final int g = bytes[1] + 128;
            final int b = bytes[2] + 128;
            image.method_4305(col, row, r | (g << 8) | (b << 16) | (0xFF << 24));
        }
    }

    private static final class ProjectorCameraEntity extends class_1657 {
        @Nullable
        private static ProjectorCameraEntity instance;

        public static ProjectorCameraEntity get(final class_1937 level, final class_243 pos, final float rotationY, final float rotationX) {
            if (instance == null) {
                instance = new ProjectorCameraEntity(level);
            }

            instance.method_51502(level);
            instance.method_5808(pos.method_10216(), pos.method_10214(), pos.method_10215(), rotationY, rotationX);

            return instance;
        }

        private ProjectorCameraEntity(final class_1937 level) {
            super(level, FakePlayerUtils.getFakePlayerProfile());
        }

        @Override
        public float method_5705(final float partialTicks) {
            return field_5982;
        }

        @Override
        public float method_5695(final float partialTicks) {
            return field_6004;
        }

        @Override
        public class_1934 method_68876() {
            return class_1934.field_9220;
        }
    }
}
