/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.fabric;

import net.minecraft.class_11954;
import net.minecraft.class_2586;
import net.minecraft.class_4604;
import net.minecraft.class_824;
import org.jetbrains.annotations.Nullable;

public final class ClientPlatformImpl {
    private static boolean isHotbarVisible = true;

    public static void setHotbarVisible(final boolean value) {
        isHotbarVisible = value;
    }

    public static boolean isHotbarVisible() {
        return isHotbarVisible;
    }

    @Nullable
    public static class_11954 tryExtractBlockEntityRenderState(final class_824 dispatcher, final class_2586 blockEntity, final float partialTicks, final class_4604 ignoredFrustum) {
        return dispatcher.method_74348(blockEntity, partialTicks, null);
    }

    private ClientPlatformImpl() {
    }
}
