/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.api.API;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_11659;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4730;
import org.joml.Vector3f;

public final class Overlays {
    private static final int PULSE_TICKS = 40;

    private static final class_2960 POWER_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/power");
    private static final class_2960 STATUS_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/status");
    private static final class_2960 TERMINAL_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/terminal");

    private static final class_4730 POWER = new class_4730(class_1059.field_5275, POWER_LOCATION);
    private static final class_4730 STATUS = new class_4730(class_1059.field_5275, STATUS_LOCATION);
    private static final class_4730 TERMINAL = new class_4730(class_1059.field_5275, TERMINAL_LOCATION);

    private static final class_1921 UNLIT_BLOCKS = ModRenderType.getUnlitBlock(class_1059.field_5275);
    private static final class_11659.class_11660 POWER_QUAD = quad(POWER);
    private static final class_11659.class_11660 STATUS_QUAD = quad(STATUS);
    private static final class_11659.class_11660 TERMINAL_QUAD = quad(TERMINAL);

    // --------------------------------------------------------------------- //

    public static void renderPower(final class_4587 stack, final class_11659 collector) {
        collector.method_73483(stack, UNLIT_BLOCKS, POWER_QUAD);
    }

    public static void renderStatus(final class_4587 stack, final class_11659 collector) {
        collector.method_73483(stack, UNLIT_BLOCKS, STATUS_QUAD);
    }

    public static void renderStatus(final class_4587 stack, final class_11659 collector, final int frequency) {
        if (System.currentTimeMillis() / frequency % 2 == 1) {
            renderStatus(stack, collector);
        }
    }

    public static void renderTerminal(final class_4587 stack, final class_11659 collector) {
        collector.method_73483(stack, UNLIT_BLOCKS, TERMINAL_QUAD);
    }

    public static void renderBox(final class_4587 stack, final class_11659 collector, final class_238 bounds, final Vector3f color, final Vector3f colorBright, final long gameTime, final float partialTicks) {
        renderBox(ModRenderType.getIndicator(), stack, collector, bounds, color, colorBright, gameTime, partialTicks);
    }

    public static void renderBox(final class_1921 renderType, final class_4587 stack, final class_11659 collector, final class_238 bounds, final Vector3f color, final Vector3f colorBright, final long gameTime, final float partialTicks) {
        final float phase = (gameTime % PULSE_TICKS + partialTicks) / PULSE_TICKS;
        final float blend = (1 + class_3532.method_15374(phase * (float) (Math.PI * 2))) * 0.5f;

        final float r = class_3532.method_16439(blend, color.x(), colorBright.x());
        final float g = class_3532.method_16439(blend, color.y(), colorBright.y());
        final float b = class_3532.method_16439(blend, color.z(), colorBright.z());

        collector.method_73483(stack, renderType, (pose, consumer) -> addBoxVertices(pose, consumer, bounds, r, g, b));
    }

    // --------------------------------------------------------------------- //

    private static void addBoxVertices(final class_4587.class_4665 matrix, final class_4588 consumer, final class_238 bounds, final float r, final float g, final float b) {
        final float x0 = (float) bounds.field_1323;
        final float y0 = (float) bounds.field_1322;
        final float z0 = (float) bounds.field_1321;
        final float x1 = (float) bounds.field_1320;
        final float y1 = (float) bounds.field_1325;
        final float z1 = (float) bounds.field_1324;

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x0, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z0, r, g, b);

        addVertex(matrix, consumer, x0, y0, z1, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x0, y0, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z0, r, g, b);

        addVertex(matrix, consumer, x1, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);
        addVertex(matrix, consumer, x0, y0, z1, r, g, b);

        addVertex(matrix, consumer, x0, y1, z0, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
    }

    private static void addVertex(final class_4587.class_4665 matrix, final class_4588 consumer, final float x, final float y, final float z, final float r, final float g, final float b) {
        consumer.method_56824(matrix, x, y, z).method_22915(r, g, b, 1f);
    }

    private static class_11659.class_11660 quad(final class_4730 material) {
        return (pose, consumer) -> {
            final class_1058 sprite = class_310.method_1551().method_72703().method_73030(material);
            consumer.method_56824(pose, 0, 0, 0).method_22913(sprite.method_4594(), sprite.method_4593());
            consumer.method_56824(pose, 0, 16, 0).method_22913(sprite.method_4594(), sprite.method_4575());
            consumer.method_56824(pose, 16, 16, 0).method_22913(sprite.method_4577(), sprite.method_4575());
            consumer.method_56824(pose, 16, 0, 0).method_22913(sprite.method_4577(), sprite.method_4593());
        };
    }

    private Overlays() {
    }
}
