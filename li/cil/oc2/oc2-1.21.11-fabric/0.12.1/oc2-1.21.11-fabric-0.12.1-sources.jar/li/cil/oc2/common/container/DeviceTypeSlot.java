/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.api.bus.device.DeviceType;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import org.jetbrains.annotations.NotNull;

public final class DeviceTypeSlot extends class_1735 {
    private final DeviceType deviceType;

    public DeviceTypeSlot(final class_1263 container, final DeviceType deviceType, final int index, final int x, final int y) {
        super(container, index, x, y);
        this.deviceType = deviceType;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Override
    public boolean method_7680(@NotNull final class_1799 stack) {
        return super.method_7680(stack) && stack.method_31573(deviceType.getTag());
    }
}
