/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.inventory.ItemHandler;
import li.cil.oc2.common.transaction.SnapshotJournal;
import li.cil.oc2.common.transaction.TransactionContext;
import li.cil.oc2.jcodec.common.tools.MathUtil;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public class ItemStackHandler implements ItemHandler {
    private static final String SIZE_TAG_NAME = "Size";

    protected class_2371<class_1799> stacks;
    private SnapshotJournal[] journals;

    // --------------------------------------------------------------------- //

    public ItemStackHandler(final int size) {
        this(class_2371.method_10213(size, class_1799.field_8037));
    }

    public ItemStackHandler(final class_2371<class_1799> stacks) {
        this.stacks = stacks;
        this.journals = new SnapshotJournal[stacks.size()];
    }

    // --------------------------------------------------------------------- //

    @Override
    public int getSlots() {
        return stacks.size();
    }

    @Override
    public class_1799 getStackInSlot(final int slot) {
        validateSlot(slot);
        return stacks.get(slot);
    }

    public void setStackInSlot(final int slot, final class_1799 stack) {
        validateSlot(slot);
        stacks.set(slot, stack);
        onContentsChanged(slot);
    }

    @Override
    public class_1799 insertItem(final int slot, final class_1799 stack, final TransactionContext transaction) {
        if (stack.method_7960()) {
            return class_1799.field_8037;
        }

        if (!isItemValid(slot, stack)) {
            return stack;
        }

        validateSlot(slot);

        final class_1799 existing = stacks.get(slot);

        int limit = getStackLimit(slot, stack);
        if (!existing.method_7960()) {
            if (!class_1799.method_31577(stack, existing)) {
                return stack;
            }
            limit -= existing.method_7947();
        }

        if (limit <= 0) {
            return stack;
        }

        final int inserted = Math.min(limit, stack.method_7947());
        getSlotJournal(slot).updateSnapshots(transaction);
        stacks.set(slot, existing.method_7960()
            ? stack.method_46651(inserted)
            : existing.method_46651(existing.method_7947() + inserted));

        return inserted < stack.method_7947() ? stack.method_46651(stack.method_7947() - inserted) : class_1799.field_8037;
    }

    @Override
    public class_1799 extractItem(final int slot, final int amount, final TransactionContext transaction) {
        if (amount <= 0) {
            return class_1799.field_8037;
        }

        validateSlot(slot);

        final class_1799 existing = stacks.get(slot);
        if (existing.method_7960()) {
            return class_1799.field_8037;
        }

        final int extracted = MathUtil.min3(amount, existing.method_7947(), existing.method_7914());
        getSlotJournal(slot).updateSnapshots(transaction);
        stacks.set(slot, existing.method_7947() > extracted ? existing.method_46651(existing.method_7947() - extracted) : class_1799.field_8037);

        return existing.method_46651(extracted);
    }

    @Override
    public int getSlotLimit(final int slot) {
        return class_1792.field_30887;
    }

    // --------------------------------------------------------------------- //

    public void save(final class_11372 output) {
        output.method_71465(SIZE_TAG_NAME, stacks.size());
        class_1262.method_5426(output, stacks);
    }

    public void load(final class_11368 input) {
        setSize(readSize(input));
        class_1262.method_5429(input, stacks);
        onLoad();
    }

    // --------------------------------------------------------------------- //

    protected void setSize(final int size) {
        stacks = class_2371.method_10213(size, class_1799.field_8037);
        journals = new SnapshotJournal[size];
    }

    protected int readSize(final class_11368 input) {
        return input.method_71424(SIZE_TAG_NAME, stacks.size());
    }

    protected int getStackLimit(final int slot, final class_1799 stack) {
        return Math.min(getSlotLimit(slot), stack.method_7914());
    }

    protected void onContentsChanged(final int slot) {
    }

    protected void onLoad() {
    }

    // --------------------------------------------------------------------- //

    private SnapshotJournal getSlotJournal(final int slot) {
        if (journals[slot] == null) {
            journals[slot] = SnapshotJournal.create(() -> stacks.get(slot), stack -> stacks.set(slot, stack), () -> onContentsChanged(slot));
        }
        return journals[slot];
    }

    private void validateSlot(final int slot) {
        if (slot < 0 || slot >= stacks.size()) {
            throw new IndexOutOfBoundsException("Slot " + slot + " not in range [0," + stacks.size() + ")");
        }
    }
}
