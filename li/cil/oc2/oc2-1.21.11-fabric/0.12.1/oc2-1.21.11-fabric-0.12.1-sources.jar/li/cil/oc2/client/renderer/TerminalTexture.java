/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.*;
import com.mojang.blaze3d.vertex.*;
import li.cil.oc2.common.vm.device.Terminal;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1044;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_11278;
import net.minecraft.class_11659;
import net.minecraft.class_12137;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import net.minecraft.class_9801;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import javax.annotation.Nullable;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public final class TerminalTexture implements Terminal.Listener, AutoCloseable {
    private static final float CURSOR_DEPTH_OFFSET = 0.025f;
    private static final class_1921 CURSOR_RENDER_TYPE = ModRenderType.getTerminalScreen(TerminalRenderer.getFontTexture());
    private static final Vector4f NO_COLOR_MODULATION = new Vector4f(1, 1, 1, 1);
    private static final Vector3f NO_MODEL_OFFSET = new Vector3f();
    private static final Matrix4f IDENTITY = new Matrix4f();
    private static final class_11278 PROJECTION = new class_11278("oc2 terminal", -1, 1, true);

    // --------------------------------------------------------------------- //

    private final Terminal terminal;
    private final TerminalRenderer renderer;
    private final class_2960 location;
    private final class_1921 renderType;
    private final class_11659.class_11660 screenGeometry = this::buildScreen;
    private final class_11659.class_11660 cursorGeometry = this::buildCursor;

    @Nullable
    private TargetTexture texture;
    private volatile boolean isDirty = true;

    // --------------------------------------------------------------------- //

    public TerminalTexture(final Terminal terminal, final class_2960 location) {
        this.terminal = terminal;
        this.renderer = new TerminalRenderer(terminal);
        this.location = location;
        this.renderType = ModRenderType.getTerminalScreen(location);
        terminal.addListener(this);
    }

    // --------------------------------------------------------------------- //

    public class_2960 getLocation() {
        return location;
    }

    public void draw(final class_4587 stack, final class_11659 collector) {
        if (texture == null) {
            return;
        }

        collector.method_73483(stack, renderType, screenGeometry);

        if (!TerminalRenderer.shouldRenderCursor(terminal)) {
            return;
        }

        stack.method_22903();
        stack.method_46416(0, 0, CURSOR_DEPTH_OFFSET);
        collector.method_73483(stack, CURSOR_RENDER_TYPE, cursorGeometry);
        stack.method_22909();
    }

    public void drawGui(final class_332 graphics, final int x, final int y, final int width, final int height) {
        refresh();
        if (texture == null) {
            return;
        }

        final int textureWidth = terminal.getWidth(), textureHeight = terminal.getHeight();
        graphics.method_25302(ModShaders.GUI_TERMINAL_PIPELINE, location, x, y, 0, textureHeight, width, height,
            textureWidth, -textureHeight, textureWidth, textureHeight);

        if (!TerminalRenderer.shouldRenderCursor(terminal)) {
            return;
        }

        final Matrix3x2f pose = new Matrix3x2f(graphics.method_51448())
            .translate(x, y)
            .scale(width / (float) textureWidth, height / (float) textureHeight);
        final class_1044 font = class_310.method_1551().method_1531().method_4619(TerminalRenderer.getFontTexture());
        graphics.field_59826.method_70919(new GuiCursorRenderState(renderer, pose,
            class_11231.method_70900(font.method_71659(), font.method_75484()),
            new class_8030(x, y, width, height).method_71523(graphics.method_51448())));
    }

    public void refresh() {
        if (!isDirty) {
            return;
        }
        isDirty = false;

        if (texture == null) {
            texture = new TargetTexture(location.toString(), terminal.getWidth(), terminal.getHeight());
            class_310.method_1551().method_1531().method_4616(location, texture);
        }

        final class_287 builder = class_289.method_1348()
            .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1575);
        renderer.buildBody(builder);

        final MipmapChain chain = MipmapChain.get(terminal.getWidth(), terminal.getHeight());
        final CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (class_9801 mesh = builder.method_60794()) {
            if (mesh == null) {
                encoder.clearColorTexture(chain.levels[0], 0);
            } else {
                renderBody(encoder, mesh, chain.views[0]);
            }
        }

        chain.downsample(encoder);
        chain.copyTo(encoder, texture.levelViews);
    }

    @Override
    public void handleTerminalChanged() {
        isDirty = true;
    }

    @Override
    public void close() {
        terminal.removeListener(this);
        if (texture != null) {
            class_310.method_1551().method_1531().method_4615(location);
            texture = null;
        }
    }

    // --------------------------------------------------------------------- //

    private void renderBody(final CommandEncoder encoder, final class_9801 mesh, final GpuTextureView target) {
        final GpuBufferSlice projectionBuffer = PROJECTION.method_71092(terminal.getWidth(), terminal.getHeight());
        final GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
            .method_71106(IDENTITY, NO_COLOR_MODULATION, NO_MODEL_OFFSET, IDENTITY);
        final GpuBuffer vertices = ModShaders.TERMINAL_PIPELINE.getVertexFormat().uploadImmediateVertexBuffer(mesh.method_60818());
        final RenderSystem.class_5590 indices = RenderSystem.getSequentialBuffer(mesh.method_60822().comp_752());
        final GpuBuffer indexBuffer = indices.method_68274(mesh.method_60822().comp_751());
        final class_1044 font = class_310.method_1551().method_1531().method_4619(TerminalRenderer.getFontTexture());

        try (RenderPass pass = encoder.createRenderPass(() -> "oc2 terminal", target, OptionalInt.of(0))) {
            pass.setPipeline(ModShaders.TERMINAL_PIPELINE);
            pass.setUniform("Projection", projectionBuffer);
            pass.setUniform("DynamicTransforms", transforms);
            pass.bindTexture("Sampler0", font.method_71659(), font.method_75484());
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indexBuffer, indices.method_31924());
            pass.drawIndexed(0, 0, mesh.method_60822().comp_751(), 1);
        }
    }

    private void buildScreen(final class_4587.class_4665 pose, final class_4588 consumer) {
        final float x = terminal.getWidth(), y = terminal.getHeight();
        consumer.method_56824(pose, 0, 0, 0).method_22913(0, 1).method_39415(-1);
        consumer.method_56824(pose, 0, y, 0).method_22913(0, 0).method_39415(-1);
        consumer.method_56824(pose, x, y, 0).method_22913(1, 0).method_39415(-1);
        consumer.method_56824(pose, x, 0, 0).method_22913(1, 1).method_39415(-1);
    }

    private void buildCursor(final class_4587.class_4665 pose, final class_4588 consumer) {
        renderer.buildCursor(pose.method_23761(), consumer);
    }

    private static int mipLevelCount(final int width, final int height) {
        return 32 - Integer.numberOfLeadingZeros(Math.min(width, height));
    }

    // --------------------------------------------------------------------- //

    private record GuiCursorRenderState(TerminalRenderer renderer, Matrix3x2f pose, class_11231 textureSetup,
                                        class_8030 bounds) implements class_11244 {
        @Override
        public void method_70917(final class_4588 consumer) {
            renderer.buildCursor(new Matrix4f().mul(pose), consumer);
        }

        @Override
        public RenderPipeline comp_4055() {
            return ModShaders.GUI_TERMINAL_CURSOR_PIPELINE;
        }

        @Nullable
        @Override
        public class_8030 comp_4069() {
            return null;
        }
    }

    private static final class TargetTexture extends class_1044 {
        private final GpuTextureView[] levelViews;

        private TargetTexture(final String label, final int width, final int height) {
            final GpuDevice device = RenderSystem.getDevice();
            final int levels = mipLevelCount(width, height);
            field_56974 = device.createTexture(label, GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_RENDER_ATTACHMENT,
                TextureFormat.RGBA8, width, height, 1, levels);
            field_60597 = device.createTextureView(field_56974);
            levelViews = new GpuTextureView[levels];
            for (int level = 0; level < levels; level++) {
                levelViews[level] = device.createTextureView(field_56974, level, 1);
            }
            field_63613 = RenderSystem.getSamplerCache().method_76520(FilterMode.LINEAR, true);
        }

        @Override
        public void close() {
            for (final GpuTextureView view : levelViews) {
                view.close();
            }
            super.close();
        }
    }

    private static final class MipmapChain {
        @Nullable
        private static MipmapChain instance;

        private final GpuTexture[] levels;
        private final GpuTextureView[] views;
        private final class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);

        private MipmapChain(final int width, final int height) {
            final GpuDevice device = RenderSystem.getDevice();
            final int count = mipLevelCount(width, height);
            levels = new GpuTexture[count];
            views = new GpuTextureView[count];
            for (int level = 0; level < count; level++) {
                levels[level] = device.createTexture("oc2 terminal mipmap " + level,
                    GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_RENDER_ATTACHMENT,
                    TextureFormat.RGBA8, width >> level, height >> level, 1, 1);
                views[level] = device.createTextureView(levels[level]);
            }
        }

        private static MipmapChain get(final int width, final int height) {
            if (instance == null || instance.levels[0].getWidth(0) != width || instance.levels[0].getHeight(0) != height) {
                if (instance != null) {
                    instance.close();
                }
                instance = new MipmapChain(width, height);
            }
            return instance;
        }

        private void downsample(final CommandEncoder encoder) {
            for (int level = 1; level < views.length; level++) {
                blit(encoder, views[level - 1], views[level]);
            }
        }

        private void copyTo(final CommandEncoder encoder, final GpuTextureView[] targets) {
            for (int level = 0; level < views.length; level++) {
                blit(encoder, views[level], targets[level]);
            }
        }

        private void close() {
            for (int level = 0; level < levels.length; level++) {
                views[level].close();
                levels[level].close();
            }
        }

        private void blit(final CommandEncoder encoder, final GpuTextureView source, final GpuTextureView target) {
            try (RenderPass pass = encoder.createRenderPass(() -> "oc2 terminal mipmap", target, OptionalInt.empty())) {
                pass.setPipeline(ModShaders.TERMINAL_DOWNSAMPLE_PIPELINE);
                pass.bindTexture("InSampler", source, sampler);
                pass.draw(0, 3);
            }
        }
    }
}
