/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client;

import dev.architectury.injectables.annotations.ExpectPlatform;
import javax.annotation.Nullable;
import net.minecraft.class_11954;
import net.minecraft.class_2586;
import net.minecraft.class_4604;
import net.minecraft.class_824;

public final class ClientPlatform {
    @ExpectPlatform
    public static void setHotbarVisible(final boolean value) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static class_11954 tryExtractBlockEntityRenderState(final class_824 dispatcher, final class_2586 blockEntity, final float partialTicks, final class_4604 frustum) {
        throw new AssertionError();
    }

    private ClientPlatform() {
    }
}
