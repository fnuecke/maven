/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.item.NetworkInterfaceCardItem;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.NetworkInterfaceCardConfigurationMessage;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_310;


public final class NetworkInterfaceCardScreen extends AbstractSideConfigurationScreen {
    public static void open(final class_1657 player, final class_1268 hand) {
        class_310.method_1551().method_1507(new NetworkInterfaceCardScreen(player, hand));
    }

    // --------------------------------------------------------------------- //

    public NetworkInterfaceCardScreen(final class_1657 player, final class_1268 hand) {
        super(player, hand, Items.NETWORK_INTERFACE_CARD.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected boolean getConfiguration(final class_2350 side) {
        return NetworkInterfaceCardItem.getSideConfiguration(player.method_5998(hand), side);
    }

    @Override
    protected void sendConfiguration(final class_2350 side, final boolean value) {
        Network.sendToServer(new NetworkInterfaceCardConfigurationMessage(hand, side, value));
    }
}
