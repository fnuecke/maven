/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity.robot;

import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_11368;
import net.minecraft.class_11372;

public abstract class AbstractRobotAction {
    private static final String ID_TAG_NAME = "id";

    // --------------------------------------------------------------------- //

    private final AbstractRobotActionType type;
    private int id;

    // --------------------------------------------------------------------- //

    public AbstractRobotAction(final AbstractRobotActionType type) {
        this.type = type;
    }

    public AbstractRobotAction(final AbstractRobotActionType type, final class_11368 input) {
        this(type);
        deserialize(input);
    }

    // --------------------------------------------------------------------- //

    public AbstractRobotActionType getType() {
        return type;
    }

    public int getId() {
        return id;
    }

    public void setId(final int value) {
        id = value;
    }

    public void initialize(final Robot robot) {
    }

    public abstract RobotActionResult perform(Robot robot);

    public void serialize(final class_11372 output) {
        output.method_71465(ID_TAG_NAME, id);
    }

    public void deserialize(final class_11368 input) {
        id = input.method_71424(ID_TAG_NAME, 0);
    }
}
