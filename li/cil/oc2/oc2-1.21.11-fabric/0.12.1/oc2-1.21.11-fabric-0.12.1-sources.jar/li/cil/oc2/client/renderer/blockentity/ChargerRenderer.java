/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.api.API;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.client.renderer.Overlays;
import li.cil.oc2.common.blockentity.ChargerBlockEntity;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4730;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import org.joml.Vector3f;

import javax.annotation.Nullable;

public class ChargerRenderer implements class_827<ChargerBlockEntity, ChargerRenderer.State> {
    public static final class State extends class_11954 {
        private boolean hasEnergy;
        private long gameTime;
        private float partialTicks;
    }

    // --------------------------------------------------------------------- //

    public static final class_2960 EFFECT_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/charger_glow");

    private static final class_4730 TEXTURE_EFFECT = new class_4730(class_1059.field_5275, EFFECT_LOCATION);

    private static final int EFFECT_LAYERS = 3;
    private static final float EFFECT_HEIGHT = 0.5f;
    private static final float EFFECT_SPEED = 0.3f;
    private static final float EFFECT_SCALE_START = 0.6f;
    private static final float EFFECT_SCALE_END = 0.8f;

    private static final Vector3f INDICATOR_COLOR = new Vector3f(1f, 0.8f, 0.3f);
    private static final Vector3f INDICATOR_COLOR_BRIGHT = new Vector3f(1f, 1f, 0.7f);

    private static final class_238 INDICATOR_BOUNDS = new class_238(0.5 / 16.0, 12 / 16.0, 0.5 / 16.0, 15.5 / 16.0, 15.5 / 16.0, 15.5 / 16.0);

    private static final class_1921 EFFECT_RENDER_TYPE = TEXTURE_EFFECT.method_24146(ModRenderType::getUnlitBlock);

    // --------------------------------------------------------------------- //

    public ChargerRenderer(final class_5614.class_5615 ignoredContext) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public State method_74335() {
        return new State();
    }

    @Override
    public void extractRenderState(final ChargerBlockEntity charger, final State state, final float partialTicks, final class_243 cameraPosition,
                                   @Nullable final class_11683.class_11792 crumbling) {
        class_827.super.method_74331(charger, state, partialTicks, cameraPosition, crumbling);

        final class_1937 level = charger.method_10997();
        state.hasEnergy = charger.hasEnergy();
        state.gameTime = level != null ? level.method_75260() : 0;
        state.partialTicks = partialTicks;
    }

    @Override
    public void submit(final State state, final class_4587 stack, final class_11659 collector, final class_12075 camera) {
        if (!state.hasEnergy) {
            return;
        }

        final long gameTime = state.gameTime;
        final float partialTicks = state.partialTicks;
        final float offset = (gameTime + partialTicks) * EFFECT_SPEED / 20f % (float) (Math.PI * 2);

        Overlays.renderBox(stack, collector, INDICATOR_BOUNDS, INDICATOR_COLOR, INDICATOR_COLOR_BRIGHT, gameTime, partialTicks);

        stack.method_22903();
        stack.method_22904(0.5, 1.1, 0.5);

        for (int i = 0; i < EFFECT_LAYERS; i++) {
            final float relativeY = (1 + class_3532.method_15374(offset + ((float) Math.PI * 2f * i / EFFECT_LAYERS))) * 0.5f;
            final float y = relativeY * EFFECT_HEIGHT;
            final float scale = EFFECT_SCALE_START + relativeY * (EFFECT_SCALE_END - EFFECT_SCALE_START);

            stack.method_22903();
            stack.method_46416(0, y, 0);
            renderScaledQuad(stack, collector, scale);
            stack.method_22909();
        }

        stack.method_22909();
    }

    // --------------------------------------------------------------------- //

    private static void renderScaledQuad(final class_4587 stack, final class_11659 collector, final float scale) {
        stack.method_22903();
        stack.method_22905(scale, scale, scale);
        collector.method_73483(stack, EFFECT_RENDER_TYPE, ChargerRenderer::renderQuad);
        stack.method_22909();
    }

    private static void renderQuad(final class_4587.class_4665 pose, final class_4588 consumer) {
        final class_1058 sprite = class_310.method_1551().method_72703().method_73030(TEXTURE_EFFECT);
        consumer.method_56824(pose, -0.5f, 0, -0.5f).method_22913(sprite.method_4594(), sprite.method_4593());
        consumer.method_56824(pose, -0.5f, 0, 0.5f).method_22913(sprite.method_4594(), sprite.method_4575());
        consumer.method_56824(pose, 0.5f, 0, 0.5f).method_22913(sprite.method_4577(), sprite.method_4575());
        consumer.method_56824(pose, 0.5f, 0, -0.5f).method_22913(sprite.method_4577(), sprite.method_4593());
    }
}
