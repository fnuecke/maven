/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.item;

import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.*;
import li.cil.oc2.api.capabilities.Robot;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.inventory.ItemHandler;
import li.cil.oc2.common.transaction.Transaction;
import li.cil.oc2.common.transaction.TransactionContext;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_3218;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.IntStream;

@RPCDeviceDescription(typeName = "crafting", description = """
    Provided by the [crafting module](../item/crafting_module.md) to robots.

    The top part of the robot's inventory, slots `0` to `8`, serves as the crafting grid. Crafted items go into the bottom row, starting at the selected slot.""")
@IODeviceDescription(name = "CRFTNG")
public final class CraftingModuleDevice extends AbstractItemDevice {
    private static final int CRAFT_CODE = 1;

    private static final int GRID_SIZE = 3;
    private static final int GRID_SLOTS = GRID_SIZE * GRID_SIZE;

    private static final String CRAFT_DESCRIPTION = "Tries to craft once from the crafting grid. Fails if the grid matches no recipe, " +
        "or if the result or the leftover items, such as empty buckets, do not fit.";

    // --------------------------------------------------------------------- //

    private final class_1297 entity;
    private final Robot robot;

    // --------------------------------------------------------------------- //

    public CraftingModuleDevice(final class_1799 identity, final class_1297 entity, final Robot robot) {
        super(identity);
        this.entity = entity;
        this.robot = robot;
    }

    // --------------------------------------------------------------------- //

    @Callback(energy = 1,
        description = CRAFT_DESCRIPTION,
        returnValueDescription = "the number of items crafted, or `0` if crafting failed.")
    public int craft() {
        final class_3218 level = (class_3218) entity.method_73183();
        final ItemHandler inventory = inventory();

        final class_9694.class_9765 positioned = class_9694.method_60505(GRID_SIZE, GRID_SIZE, gridItems(inventory));
        final class_9694 input = positioned.comp_2795();
        final Optional<class_8786<class_3955>> recipe = level.method_64577().method_8132(class_3956.field_17545, input, level);
        if (recipe.isEmpty()) {
            return 0;
        }

        final class_1799 result = recipe.get().comp_1933().method_8116(input, level.method_30349());
        if (result.method_7960()) {
            return 0;
        }

        final class_2371<class_1799> remainders = recipe.get().comp_1933().method_17704(input);
        try (Transaction transaction = Transaction.openRoot()) {
            try (Transaction probe = transaction.openNested()) {
                if (!craft(inventory, result, positioned, remainders, probe)) {
                    return 0;
                }
            }

            result.method_54466(level);
            final int crafted = result.method_7947();
            if (!craft(inventory, result, positioned, remainders, transaction)) {
                return 0;
            }

            transaction.commit();
            return crafted;
        }
    }

    // --------------------------------------------------------------------- //

    @IOCallback(energy = 1, value = CRAFT_CODE,
        description = CRAFT_DESCRIPTION,
        resultsDescription = "one byte, the number of items crafted, `0` if crafting failed.")
    public void craft(final IOOutputStream results) throws IOException {
        results.writeU8(craft());
    }

    // --------------------------------------------------------------------- //

    private List<class_1799> gridItems(final ItemHandler inventory) {
        return IntStream.range(0, GRID_SLOTS).mapToObj(inventory::getStackInSlot).toList();
    }

    private boolean craft(final ItemHandler inventory, final class_1799 result, final class_9694.class_9765 positioned,
                          final class_2371<class_1799> remainders, final TransactionContext transaction) {
        return insertIntoOutput(inventory, result, transaction).method_7960() && consumeIngredients(inventory, positioned, remainders, transaction);
    }

    private boolean consumeIngredients(final ItemHandler inventory, final class_9694.class_9765 positioned,
                                       final class_2371<class_1799> remainders, final TransactionContext transaction) {
        final class_9694 input = positioned.comp_2795();
        for (int row = 0; row < input.method_59992(); row++) {
            for (int column = 0; column < input.method_59991(); column++) {
                final int slot = positioned.comp_2796() + column + (positioned.comp_2797() + row) * GRID_SIZE;
                if (inventory.getStackInSlot(slot).method_7960()) {
                    continue;
                }

                final class_1799 remainder = remainders.get(column + row * input.method_59991());
                if (inventory.extractItem(slot, 1, transaction).method_7960()
                    || !insertIntoOutput(inventory, inventory.insertItem(slot, remainder, transaction), transaction).method_7960()) {
                    return false;
                }
            }
        }

        return true;
    }

    private class_1799 insertIntoOutput(final ItemHandler inventory, class_1799 stack, final TransactionContext transaction) {
        final int outputSlots = inventory.getSlots() - GRID_SLOTS;
        final int start = Math.max(robot.getSelectedSlot() - GRID_SLOTS, 0);
        for (int i = 0; i < outputSlots && !stack.method_7960(); i++) {
            stack = inventory.insertItem(GRID_SLOTS + (start + i) % outputSlots, stack, transaction);
        }

        return stack;
    }

    private ItemHandler inventory() {
        return Objects.requireNonNull(Capabilities.get(entity, Capabilities.ITEM_HANDLER, null));
    }
}
