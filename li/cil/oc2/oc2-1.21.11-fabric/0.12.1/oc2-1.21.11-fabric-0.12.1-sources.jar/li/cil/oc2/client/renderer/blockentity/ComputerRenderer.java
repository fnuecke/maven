/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.client.renderer.Overlays;
import li.cil.oc2.client.renderer.TerminalOverlayRenderer;
import li.cil.oc2.common.block.ComputerBlock;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.vm.VMRunState;
import li.cil.oc2.common.vm.VirtualMachine;
import li.cil.oc2.common.vm.device.Terminal;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_5348;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import org.joml.Quaternionf;

import javax.annotation.Nullable;
import java.util.List;

public final class ComputerRenderer implements class_827<ComputerBlockEntity, ComputerRenderer.State> {
    public static final class State extends class_11954 {
        private Terminal terminal;
        private VirtualMachine virtualMachine;
        private CommonDeviceBusController.BusState busState;
        private VMRunState runState;
        private boolean isRunning;
    }

    // --------------------------------------------------------------------- //

    public ComputerRenderer(final class_5614.class_5615 ignoredContext) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public State method_74335() {
        return new State();
    }

    @Override
    public void extractRenderState(final ComputerBlockEntity computer, final State state, final float partialTicks, final class_243 cameraPosition,
                                   @Nullable final class_11683.class_11792 crumbling) {
        class_827.super.method_74331(computer, state, partialTicks, cameraPosition, crumbling);

        final VirtualMachine virtualMachine = computer.getVirtualMachine();
        state.terminal = computer.getTerminal();
        state.virtualMachine = virtualMachine;
        state.busState = virtualMachine.getBusState();
        state.runState = virtualMachine.getRunState();
        state.isRunning = virtualMachine.isRunning();
    }

    @Override
    public void submit(final State state, final class_4587 stack, final class_11659 collector, final class_12075 camera) {
        final class_2350 blockFacing = state.field_62674.method_11654(ComputerBlock.field_11177);
        final class_243 cameraOffset = TerminalOverlayRenderer.getCameraOffset(stack);

        // If viewer is not in front of the block we can skip the rest, it cannot be visible.
        // We check against the center of the block instead of the actual relevant face for simplicity.
        final double projectedCameraPosition = cameraOffset.method_1026(class_243.method_24954(blockFacing.method_62675()));
        if (projectedCameraPosition <= 0) {
            return;
        }

        stack.method_22903();

        // Align with front face of block.
        final Quaternionf rotation = class_7833.field_40715.rotationDegrees(blockFacing.method_10144() + 180);
        stack.method_46416(0.5f, 0, 0.5f);
        stack.method_22907(rotation);
        stack.method_46416(-0.5f, 0, -0.5f);

        // Flip and align with top left corner.
        stack.method_46416(1, 1, 0);
        stack.method_22905(-1, -1, -1);

        // Scale to make 1/16th of the block one unit and align with top left of terminal area.
        final float pixelScale = 1 / 16f;
        stack.method_22905(pixelScale, pixelScale, pixelScale);

        if (state.isRunning) {
            TerminalOverlayRenderer.renderTerminal(state.terminal, stack, collector, cameraOffset);
        } else {
            renderStatusText(state, stack, collector, cameraOffset);
        }

        stack.method_46416(0, 0, -0.1f);

        switch (state.busState) {
            case SCAN_PENDING:
            case INCOMPLETE:
                Overlays.renderStatus(stack, collector);
                break;
            case TOO_COMPLEX:
                Overlays.renderStatus(stack, collector, 1000);
                break;
            case MULTIPLE_CONTROLLERS:
                Overlays.renderStatus(stack, collector, 250);
                break;
            case READY:
                switch (state.runState) {
                    case STOPPED:
                        break;
                    case LOADING_DEVICES:
                        Overlays.renderStatus(stack, collector);
                        break;
                    case RUNNING:
                        Overlays.renderPower(stack, collector);
                        break;
                }
                break;
        }

        stack.method_22909();
    }

    // --------------------------------------------------------------------- //

    private void renderStatusText(final State state, final class_4587 stack, final class_11659 collector, final class_243 cameraOffset) {
        if (cameraOffset.method_1027() >= 12 * 12) {
            return;
        }

        final class_2561 bootError = state.virtualMachine.getError();
        if (bootError == null) {
            return;
        }

        stack.method_22903();
        stack.method_46416(3, 3, -0.9f);

        drawText(stack, collector, bootError);

        stack.method_22909();
    }

    private void drawText(final class_4587 stack, final class_11659 collector, final class_2561 text) {
        final int maxWidth = 100;

        stack.method_22903();
        stack.method_22905(10f / maxWidth, 10f / maxWidth, 10f / maxWidth);

        final class_327 fontRenderer = class_310.method_1551().field_1772;
        final List<class_5348> wrappedText = fontRenderer.method_27527().method_27495(text, maxWidth, class_2583.field_24360);
        if (wrappedText.size() == 1) {
            final int textWidth = fontRenderer.method_27525(text);
            drawTextLine(collector, stack, text.getString(), (maxWidth - textWidth) * 0.5f, 0);
        } else {
            for (int i = 0; i < wrappedText.size(); i++) {
                drawTextLine(collector, stack, wrappedText.get(i).getString(), 0, i * fontRenderer.field_2000);
            }
        }

        stack.method_22909();
    }

    private static void drawTextLine(final class_11659 collector, final class_4587 stack, final String text, final float x, final float y) {
        collector.method_73478(stack, x, y, class_2477.method_10517().method_30934(class_5348.method_29430(text)), false,
            class_327.class_6415.field_33993, class_765.method_23687(15, 15), 0xFFEE3322, 0, 0);
    }
}
