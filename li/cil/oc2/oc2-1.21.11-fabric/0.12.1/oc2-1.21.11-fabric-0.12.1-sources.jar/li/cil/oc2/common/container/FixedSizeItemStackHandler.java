/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import net.minecraft.class_11368;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public class FixedSizeItemStackHandler extends ItemStackHandler {
    public FixedSizeItemStackHandler(final int size) {
        super(size);
    }

    public FixedSizeItemStackHandler(final class_2371<class_1799> stacks) {
        super(stacks);
    }

    // --------------------------------------------------------------------- //

    public boolean isEmpty() {
        for (int slot = 0; slot < getSlots(); slot++) {
            if (!getStackInSlot(slot).method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    protected int readSize(final class_11368 input) {
        // Our size is fixed, don't trust NBT data we're loading.
        return getSlots();
    }
}
