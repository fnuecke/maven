/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexFormat;
import li.cil.oc2.api.API;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_12247;
import net.minecraft.class_12249;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public final class ModRenderType {
    private static final class_2960 WHITE_TEXTURE = class_2960.method_60655(API.MOD_ID, "textures/misc/white.png");

    private static final RenderPipeline INDICATOR_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/indicator"))
        .withVertexShader("core/position_color")
        .withFragmentShader("core/position_color")
        .withoutBlend()
        .withDepthBias(-1, -10)
        .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
        .build();

    private static final RenderPipeline GLOW_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/glow"))
        .withVertexShader("core/position_color")
        .withFragmentShader("core/position_color")
        .withBlend(BlendFunction.ADDITIVE)
        .withDepthWrite(false)
        .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
        .build();

    private static final RenderPipeline PROJECTOR_LIGHT_PIPELINE = RenderPipeline.builder(class_10799.field_60127)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/projector_light"))
        .withVertexShader("core/rendertype_lightning")
        .withFragmentShader("core/rendertype_lightning")
        .withBlend(BlendFunction.LIGHTNING)
        .withDepthWrite(false)
        .withCull(false)
        .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
        .build();

    private static final RenderPipeline UNLIT_BLOCK_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/unlit_block"))
        .withVertexShader("core/position_tex")
        .withFragmentShader("core/position_tex")
        .withSampler("Sampler0")
        .withBlend(BlendFunction.ADDITIVE)
        .withCull(false)
        .withVertexFormat(class_290.field_1585, VertexFormat.class_5596.field_27382)
        .build();

    private static final RenderPipeline OVERLAY_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/overlay"))
        .withVertexShader("core/position_tex")
        .withFragmentShader("core/position_tex")
        .withSampler("Sampler0")
        .withBlend(BlendFunction.ADDITIVE)
        .withVertexFormat(class_290.field_1585, VertexFormat.class_5596.field_27382)
        .build();

    private static final RenderPipeline TERMINAL_SCREEN_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/terminal_screen"))
        .withVertexShader("core/position_tex_color")
        .withFragmentShader("core/position_tex_color")
        .withSampler("Sampler0")
        .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .build();

    private static final class_1921 INDICATOR = class_1921.method_75940(API.MOD_ID + "/indicator",
        class_12247.method_75927(INDICATOR_PIPELINE).method_75938());

    private static final class_1921 GLOW = class_1921.method_75940(API.MOD_ID + "/glow",
        class_12247.method_75927(GLOW_PIPELINE).method_75938());

    private static final class_1921 PROJECTOR_LIGHT = class_1921.method_75940(API.MOD_ID + "/projector_light",
        class_12247.method_75927(PROJECTOR_LIGHT_PIPELINE).method_75937().method_75938());

    private static final Function<class_2960, class_1921> UNLIT_BLOCK = class_156.method_34866(location -> class_1921.method_75940(
        API.MOD_ID + "/unlit_block/" + location,
        class_12247.method_75927(UNLIT_BLOCK_PIPELINE).method_75934("Sampler0", location).method_75937().method_75938()));

    private static final Function<class_2960, class_1921> OVERLAY = class_156.method_34866(location -> class_1921.method_75940(
        API.MOD_ID + "/overlay/" + location,
        class_12247.method_75927(OVERLAY_PIPELINE).method_75934("Sampler0", location).method_75937().method_75938()));

    private static final Function<class_2960, class_1921> TERMINAL_SCREEN = class_156.method_34866(location -> class_1921.method_75940(
        API.MOD_ID + "/terminal_screen/" + location,
        class_12247.method_75927(TERMINAL_SCREEN_PIPELINE).method_75934("Sampler0", location).method_75938()));

    // --------------------------------------------------------------------- //

    public static void initialize() {
        IrisCompat.assignPipeline(INDICATOR_PIPELINE, "BASIC", "SHADOW_BASIC_COLOR");
        IrisCompat.assignPipeline(GLOW_PIPELINE, "BASIC", "SHADOW_BASIC_COLOR");
        IrisCompat.assignPipeline(UNLIT_BLOCK_PIPELINE, "TEXTURED", "SHADOW_TEX");
        IrisCompat.assignPipeline(OVERLAY_PIPELINE, "TEXTURED", "SHADOW_TEX");
        IrisCompat.assignPipeline(TERMINAL_SCREEN_PIPELINE, "TEXTURED", "SHADOW_TEX_COLOR");
    }

    public static class_1921 getNetworkCable() {
        return class_12249.method_75994(WHITE_TEXTURE);
    }

    public static class_1921 getIndicator() {
        return INDICATOR;
    }

    public static class_1921 getGlow() {
        return GLOW;
    }

    public static class_1921 getProjectorLight() {
        return PROJECTOR_LIGHT;
    }

    public static class_1921 getUnlitBlock(final class_2960 location) {
        return UNLIT_BLOCK.apply(location);
    }

    public static class_1921 getOverlay(final class_2960 location) {
        return OVERLAY.apply(location);
    }

    public static class_1921 getTerminalScreen(final class_2960 location) {
        return TERMINAL_SCREEN.apply(location);
    }

    // --------------------------------------------------------------------- //

    private ModRenderType() {
    }
}
