/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.inventory.ItemHandler;
import li.cil.oc2.common.transaction.TransactionContext;
import net.minecraft.class_1799;
import javax.annotation.Nullable;

public final class ContainerItemHandler implements ItemHandler {
    private final ContainerItemAccess<ItemHandler> access;

    // --------------------------------------------------------------------- //

    private ContainerItemHandler(final ContainerItemAccess<ItemHandler> access) {
        this.access = access;
    }

    @Nullable
    public static ItemHandler of(final ItemHandler inventory, final int slot) {
        final ContainerItemAccess<ItemHandler> access = new ContainerItemAccess<>(inventory, slot, Capabilities.ITEM_HANDLER);
        return access.isPresent() ? new ContainerItemHandler(access) : null;
    }

    // --------------------------------------------------------------------- //

    @Override
    public int getSlots() {
        return access.read(ItemHandler::getSlots, 0);
    }

    @Override
    public class_1799 getStackInSlot(final int slot) {
        return access.read(handler -> handler.getStackInSlot(slot), class_1799.field_8037);
    }

    @Override
    public class_1799 insertItem(final int slot, final class_1799 stack, final TransactionContext transaction) {
        return access.modify((handler, nested) -> handler.insertItem(slot, stack, nested), stack, transaction);
    }

    @Override
    public class_1799 extractItem(final int slot, final int amount, final TransactionContext transaction) {
        return access.modify((handler, nested) -> handler.extractItem(slot, amount, nested), class_1799.field_8037, transaction);
    }

    @Override
    public int getSlotLimit(final int slot) {
        return access.read(handler -> handler.getSlotLimit(slot), 0);
    }
}
