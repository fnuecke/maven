/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.inventory.ItemHandler;
import li.cil.oc2.common.inventory.WorldItemHandler;
import li.cil.oc2.common.transaction.Transaction;
import li.cil.oc2.common.transaction.TransactionContext;
import net.minecraft.class_1799;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public final class ItemHandlerUtils {
    public static final int ANY_SLOT = -1;

    // --------------------------------------------------------------------- //

    public static class_1799 insertItemStack(final ItemHandler handler, class_1799 stack, final TransactionContext transaction) {
        if (stack.method_7960()) {
            return class_1799.field_8037;
        }

        if (stack.method_7946()) {
            for (int slot = 0; slot < handler.getSlots() && !stack.method_7960(); slot++) {
                final class_1799 existing = handler.getStackInSlot(slot);
                if (!existing.method_7960() && class_1799.method_31577(existing, stack)) {
                    stack = handler.insertItem(slot, stack, transaction);
                }
            }

            if (stack.method_7960()) {
                return class_1799.field_8037;
            }
        }

        for (int slot = 0; slot < handler.getSlots() && !stack.method_7960(); slot++) {
            if (handler.getStackInSlot(slot).method_7960()) {
                stack = handler.insertItem(slot, stack, transaction);
            }
        }

        return stack;
    }

    public static int transfer(final ItemHandler source, final int sourceSlot, final ItemHandler target, final int targetSlot,
                               final int count, final TransactionContext transaction) {
        if (count <= 0) {
            return 0;
        }

        final int accepted;
        try (Transaction nested = transaction.openNested()) {
            final class_1799 available = source.extractItem(sourceSlot, count, nested);
            if (available.method_7960()) {
                return 0;
            }

            accepted = available.method_7947() - target.insertItem(targetSlot, available, nested).method_7947();
        }

        if (accepted <= 0) {
            return 0;
        }

        try (Transaction nested = transaction.openNested()) {
            final class_1799 extracted = source.extractItem(sourceSlot, accepted, nested);
            if (extracted.method_7960() || !target.insertItem(targetSlot, extracted, nested).method_7960()) {
                return 0;
            }

            nested.commit();
            return extracted.method_7947();
        }
    }

    public static int transferFirst(final List<ItemHandler> sources, final int sourceSlot,
                                    final List<ItemHandler> targets, final int targetSlot, final int targetStartSlot,
                                    final int count, final TransactionContext transaction) {
        if (count <= 0) {
            return 0;
        }

        for (final ItemHandler source : sources) {
            for (final int from : sourceSlot == ANY_SLOT ? allSlots(source) : new int[]{sourceSlot}) {
                // The world reports an empty slot, but may yield items.
                if (!(source instanceof WorldItemHandler) && source.getStackInSlot(from).method_7960()) {
                    continue;
                }

                final class_1799 available;
                try (Transaction probe = transaction.openNested()) {
                    available = source.extractItem(from, count, probe);
                }
                if (available.method_7960()) {
                    continue;
                }

                for (final ItemHandler target : targets) {
                    for (final int into : targetSlot == ANY_SLOT ? insertionOrder(target, available, targetStartSlot) : new int[]{targetSlot}) {
                        if (source == target && from == into) { //NOPMD - same handler instance
                            continue;
                        }

                        final int moved = transfer(source, from, target, into, count, transaction);
                        if (moved > 0) {
                            return moved;
                        }
                    }
                }
            }
        }

        return 0;
    }

    // --------------------------------------------------------------------- //

    private static int[] allSlots(final ItemHandler handler) {
        return IntStream.range(0, handler.getSlots()).toArray();
    }

    private static int[] insertionOrder(final ItemHandler handler, final class_1799 stack, final int startSlot) {
        final int slots = handler.getSlots();
        final IntStream rotated = IntStream.range(0, slots).map(i -> Math.floorMod(startSlot + i, slots));
        final int[] order = rotated.toArray();
        return IntStream.concat(
            Arrays.stream(order).filter(slot -> class_1799.method_31577(handler.getStackInSlot(slot), stack)),
            Arrays.stream(order).filter(slot -> handler.getStackInSlot(slot).method_7960())
        ).toArray();
    }

    private ItemHandlerUtils() {
    }
}
