/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.node;

import li.cil.oc2.client.gui.SideConfigurationBlockRenderer;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_11909;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

import static li.cil.oc2.common.util.TranslationUtils.key;
import static li.cil.oc2.common.util.TranslationUtils.text;

public final class SideConfigurationWidget extends class_339 {
    private static final String SIDE_STATE_TEXT = key("gui.{mod}.sided_device.side_state");
    private static final class_2561 CONNECTIVITY_ENABLED_TEXT = text("gui.{mod}.sided_device.connectivity.enabled");
    private static final class_2561 CONNECTIVITY_DISABLED_TEXT = text("gui.{mod}.sided_device.connectivity.disabled");
    private static final int MAX_BLOCK_PITCH = 30;
    private static final double DRAG_THRESHOLD = 3;
    private static final int SIZE = 100;

    // --------------------------------------------------------------------- //

    private final Predicate<class_2350> getConfiguration;
    private final BiConsumer<class_2350, Boolean> sendConfiguration;
    private final ComputerBlockItemRenderer computerBlockItemRenderer = new ComputerBlockItemRenderer();

    private Vector3f blockRotation = new Vector3f(-30, 45, 0);
    @Nullable
    private class_2350 focusedSide;
    private boolean isPressed, hasDraggedBlock;
    private double dragStartX, dragStartY;

    // --------------------------------------------------------------------- //

    public SideConfigurationWidget(final Predicate<class_2350> getConfiguration, final BiConsumer<class_2350, Boolean> sendConfiguration) {
        super(0, 0, SIZE, SIZE, class_5244.field_39003);
        this.getConfiguration = getConfiguration;
        this.sendConfiguration = sendConfiguration;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25348(final class_11909 event, final boolean isDoubleClick) {
        isPressed = true;
        hasDraggedBlock = false;
        dragStartX = event.comp_4798();
        dragStartY = event.comp_4799();
    }

    @Override
    public void method_25357(final class_11909 event) {
        if (isPressed && !hasDraggedBlock && focusedSide != null) {
            sendConfiguration.accept(focusedSide, !getConfiguration.test(focusedSide));
            class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1));
        }
        isPressed = false;
    }

    @Override
    public void method_25354(final class_1144 soundManager) {
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25349(final class_11909 event, final double deltaX, final double deltaY) {
        if (!hasDraggedBlock) {
            final double dx = event.comp_4798() - dragStartX;
            final double dy = event.comp_4799() - dragStartY;
            hasDraggedBlock = Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD;
        }
        if (hasDraggedBlock) {
            blockRotation = new Vector3f(
                class_3532.method_15363(blockRotation.x() - (float) deltaY, -MAX_BLOCK_PITCH, MAX_BLOCK_PITCH),
                class_3532.method_15393(blockRotation.y() + (float) deltaX),
                blockRotation.z()
            );
        }
    }

    @Override
    protected void method_48579(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        final int blockX = method_46426() + field_22758 / 2;
        final int blockY = method_46427() + field_22759 / 2;
        focusedSide = method_49606() ? computerBlockItemRenderer.getFocusedSide(blockX - mouseX, blockY - mouseY, blockRotation) : null;
        computerBlockItemRenderer.render(graphics, method_46426(), method_46427(), method_55442(), method_55443(), blockRotation);

        if (focusedSide != null) {
            final class_2561 enabledComponent = getConfiguration.test(focusedSide) ? CONNECTIVITY_ENABLED_TEXT : CONNECTIVITY_DISABLED_TEXT;
            graphics.method_51438(class_310.method_1551().field_1772, class_2561.method_43469(SIDE_STATE_TEXT, enabledComponent), mouseX, mouseY);
        }
    }

    @Override
    protected void method_47399(final class_6382 output) {
    }

    // --------------------------------------------------------------------- //

    private final class ComputerBlockItemRenderer {
        public static final int BLOCK_RENDER_SIZE = 48;

        @Nullable
        private class_2350 getFocusedSide(final float mouseX, final float mouseY, final Vector3f rotation) {
            // Rotate ray inversely around block to represent visual block rotation.
            final Quaternionf quaternion = fromXYZDegrees(toRenderRotation(rotation));
            quaternion.conjugate();

            // Move ray in screen space to mouse position.
            final float relMouseX = -mouseX / BLOCK_RENDER_SIZE;
            final float relMouseY = -mouseY / BLOCK_RENDER_SIZE;

            final Vector3f source = new Vector3f();
            source.add(relMouseX, relMouseY, 1);
            source.rotate(quaternion);

            final Vector3f target = new Vector3f();
            target.add(relMouseX, relMouseY, -1);
            target.rotate(quaternion);

            // Intersect rotated ray with bounding box representing block.
            final class_238 aabb = new class_238(-0.5, -0.5, -0.5, 0.5, 0.5, 0.5);
            return aabb.method_992(new class_243(source), new class_243(target))
                .map(hit -> class_2350.method_10142(-hit.field_1352, -hit.method_10214(), -hit.method_10215()))
                .filter(side -> side != class_2350.field_11035)
                .orElse(null);
        }

        public void render(final class_332 graphics, final int x0, final int y0, final int x1, final int y1, final Vector3f rotation) {
            int enabledSides = 0;
            for (final class_2350 side : class_2350.values()) {
                if (getConfiguration.test(side)) {
                    enabledSides |= 1 << side.method_10146();
                }
            }

            graphics.field_59826.method_70922(new SideConfigurationBlockRenderer.State(
                fromXYZDegrees(toRenderRotation(rotation)), enabledSides, focusedSide,
                x0, y0, x1, y1, BLOCK_RENDER_SIZE));
        }

        private static Vector3f toRenderRotation(final Vector3f rotation) {
            return new Vector3f(rotation).add(0, 180, 0);
        }

        private static Quaternionf fromXYZDegrees(final Vector3f degrees) {
            return new Quaternionf().rotationXYZ(
                (float) Math.toRadians(degrees.x()),
                (float) Math.toRadians(degrees.y()),
                (float) Math.toRadians(degrees.z()));
        }
    }
}
