/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@NullMarked
package li.cil.oc2.common.blockentity;

import org.jspecify.annotations.NullMarked;

import javax.annotation.ParametersAreNonnullByDefault;
