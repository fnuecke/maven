/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.client.renderer.Overlays;
import li.cil.oc2.client.renderer.TerminalOverlayRenderer;
import li.cil.oc2.common.block.OrientableBlock;
import li.cil.oc2.common.blockentity.TerminalBlockEntity;
import li.cil.oc2.common.vm.device.Terminal;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import javax.annotation.Nullable;

public final class TerminalRenderer implements class_827<TerminalBlockEntity, TerminalRenderer.State> {
    public static final class State extends class_11954 {
        private Terminal terminal;
        private boolean isConnected;
        private boolean hasRecentFrameError;
    }

    // --------------------------------------------------------------------- //

    public TerminalRenderer(final class_5614.class_5615 ignoredContext) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public State method_74335() {
        return new State();
    }

    @Override
    public void extractRenderState(final TerminalBlockEntity terminal, final State state, final float partialTicks, final class_243 cameraPosition,
                                   @Nullable final class_11683.class_11792 crumbling) {
        class_827.super.method_74331(terminal, state, partialTicks, cameraPosition, crumbling);

        state.terminal = terminal.getTerminal();
        state.isConnected = terminal.isConnected();
        state.hasRecentFrameError = terminal.hasRecentFrameError();
    }

    @Override
    public void submit(final State state, final class_4587 stack, final class_11659 collector, final class_12075 camera) {
        final class_2680 blockState = state.field_62674;
        final class_2350 blockFacing = blockState.method_11654(OrientableBlock.FACING);
        final class_243 cameraOffset = TerminalOverlayRenderer.getCameraOffset(stack);

        final double projectedCameraPosition = cameraOffset.method_1026(class_243.method_24954(blockFacing.method_62675()));
        if (projectedCameraPosition <= 0) {
            return;
        }

        stack.method_22903();

        // Align with front face of block.
        stack.method_46416(0.5f, 0.5f, 0.5f);
        stack.method_22907(class_7833.field_40715.rotationDegrees(OrientableBlock.getRotationY(blockState)));
        stack.method_22907(class_7833.field_40713.rotationDegrees(OrientableBlock.getRotationX(blockState)));
        stack.method_46416(-0.5f, -0.5f, -0.5f);

        // Flip and align with top left corner.
        stack.method_46416(1, 1, 0);
        stack.method_22905(-1, -1, -1);

        // Scale to make 1/16th of the block one unit and align with top left of terminal area.
        final float pixelScale = 1 / 16f;
        stack.method_22905(pixelScale, pixelScale, pixelScale);

        stack.method_46416(0, 0, -10f);
        TerminalOverlayRenderer.renderTerminal(state.terminal, stack, collector, cameraOffset);

        stack.method_46416(0, 0, -0.1f);

        if (state.isConnected) {
            Overlays.renderPower(stack, collector);
        }

        if (state.hasRecentFrameError) {
            Overlays.renderStatus(stack, collector);
        }

        stack.method_22909();
    }
}
