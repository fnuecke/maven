/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.widget;

import li.cil.oc2.api.API;
import net.minecraft.class_2960;

public final class Texture {
    public final class_2960 location;
    public final int width, height;

    public Texture(final String location, final int width, final int height) {
        this(class_2960.method_60655(API.MOD_ID, location), width, height);
    }

    public Texture(final class_2960 location, final int width, final int height) {
        this.location = location;
        this.width = width;
        this.height = height;
    }
}
