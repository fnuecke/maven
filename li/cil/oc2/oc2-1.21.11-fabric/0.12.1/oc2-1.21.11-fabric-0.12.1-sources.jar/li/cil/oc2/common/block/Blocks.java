/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.api.API;
import li.cil.oc2.common.util.RegistryUtils;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import java.util.function.Function;

public final class Blocks {
    private static final DeferredRegister<class_2248> BLOCKS = RegistryUtils.getInitializerFor(class_7924.field_41254);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<BusCableBlock> BUS_CABLE = register("bus_cable", BusCableBlock::new);
    public static final RegistrySupplier<ChargerBlock> CHARGER = register("charger", ChargerBlock::new);
    public static final RegistrySupplier<ComputerBlock> COMPUTER = register("computer", ComputerBlock::new);
    public static final RegistrySupplier<CreativeEnergyBlock> CREATIVE_ENERGY = register("creative_energy", CreativeEnergyBlock::new);
    public static final RegistrySupplier<DiskDriveBlock> DISK_DRIVE = register("disk_drive", DiskDriveBlock::new);
    public static final RegistrySupplier<FlashDriveBlock> FLASH_DRIVE = register("flash_drive", FlashDriveBlock::new);
    public static final RegistrySupplier<KeyboardBlock> KEYBOARD = register("keyboard", KeyboardBlock::new);
    public static final RegistrySupplier<NetworkConnectorBlock> NETWORK_CONNECTOR = register("network_connector", NetworkConnectorBlock::new);
    public static final RegistrySupplier<NetworkHubBlock> NETWORK_HUB = register("network_hub", NetworkHubBlock::new);
    public static final RegistrySupplier<InternetGatewayBlock> INTERNET_GATEWAY = register("internet_gateway", InternetGatewayBlock::new);
    public static final RegistrySupplier<ProjectorBlock> PROJECTOR = register("projector", ProjectorBlock::new);
    public static final RegistrySupplier<RedstoneInterfaceBlock> REDSTONE_INTERFACE = register("redstone_interface", RedstoneInterfaceBlock::new);
    public static final RegistrySupplier<TerminalBlock> TERMINAL = register("terminal", TerminalBlock::new);
    public static final RegistrySupplier<TransposerBlock> TRANSPOSER = register("transposer", TransposerBlock::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    // --------------------------------------------------------------------- //

    private static <T extends class_2248> RegistrySupplier<T> register(final String name, final Function<class_2251, T> factory) {
        final class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(API.MOD_ID, name));
        return BLOCKS.register(name, () -> factory.apply(class_2251.method_9637().method_63500(key)));
    }
}
