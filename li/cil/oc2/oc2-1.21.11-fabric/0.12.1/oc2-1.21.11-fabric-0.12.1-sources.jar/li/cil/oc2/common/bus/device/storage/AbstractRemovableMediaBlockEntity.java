/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.storage;

import com.google.common.annotations.VisibleForTesting;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.ModBlockEntity;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.container.TypedItemStackHandler;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.AbstractMessage;
import li.cil.oc2.common.transaction.Transaction;
import li.cil.oc2.common.transaction.TransactionContext;
import li.cil.oc2.common.util.ItemDeviceUtils;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.LocationSupplierUtils;
import li.cil.oc2.common.util.SerializationUtils;
import li.cil.oc2.common.util.ThrottledSoundEmitter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.time.Duration;

public abstract class AbstractRemovableMediaBlockEntity<TDevice extends AbstractRemovableMediaDevice> extends ModBlockEntity implements RemovableMediaContainer {
    private final RemovableMediaItemStackHandler itemHandler;
    private final ThrottledSoundEmitter insertSoundEmitter;
    private final ThrottledSoundEmitter ejectSoundEmitter;

    @Nullable
    private TDevice device;

    // --------------------------------------------------------------------- //

    protected AbstractRemovableMediaBlockEntity(
        final class_2591<?> type,
        final class_2338 pos,
        final class_2680 state,
        final class_6862<class_1792> mediaTag,
        final class_3414 insertSound,
        final class_3414 ejectSound
    ) {
        super(type, pos, state);

        this.itemHandler = new RemovableMediaItemStackHandler(mediaTag);
        this.insertSoundEmitter = new ThrottledSoundEmitter(LocationSupplierUtils.of(this),
            insertSound).withMinInterval(Duration.ofMillis(100));
        this.ejectSoundEmitter = new ThrottledSoundEmitter(LocationSupplierUtils.of(this),
            ejectSound).withMinInterval(Duration.ofMillis(100));
    }

    // --------------------------------------------------------------------- //

    protected abstract class_2350 getEjectDirection();

    protected abstract AbstractMessage createMediaMessage();

    // --------------------------------------------------------------------- //

    public boolean canInsert(final class_1799 stack) {
        return itemHandler.isItemValid(0, stack);
    }

    @VisibleForTesting
    public class_1799 insert(final class_1799 stack, @Nullable final class_1657 player) {
        if (field_11863 == null || !canInsert(stack)) {
            return stack;
        }

        final class_1799 ejected;
        final class_1799 remainder;
        try (Transaction transaction = Transaction.openRoot()) {
            ejected = itemHandler.extractItem(0, 1, transaction);
            remainder = itemHandler.insertItem(0, stack, transaction);
            transaction.commit();
        }

        dropEjected(ejected, player);
        insertSoundEmitter.play();
        return remainder;
    }

    public boolean canEject() {
        return !itemHandler.getStackInSlotRaw(0).method_7960();
    }

    public void eject(@Nullable final class_1657 player) {
        if (field_11863 == null) {
            return;
        }

        dropEjected(Transaction.run(transaction -> itemHandler.extractItem(0, 1, transaction)), player);
    }

    public void dropMedia() {
        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        final class_1799 stack = itemHandler.getStackInSlot(0);
        if (!stack.method_7960()) {
            itemHandler.setStackInSlot(0, class_1799.field_8037);
            ItemStackUtils.spawnAsEntity(field_11863, method_11016(), stack);
        }
    }

    @Override
    public void method_66473(final class_2338 pos, final class_2680 state) {
        super.method_66473(pos, state);
        dropMedia();
    }

    public class_1269 useWith(final class_1937 level, final class_1799 heldStack, final class_1657 player, final class_1268 hand) {
        if (player.method_5715()) {
            if (canEject()) {
                if (!level.method_8608()) {
                    eject(player);
                }
                return class_1269.field_5812;
            }
        } else {
            if (canInsert(heldStack)) {
                if (!level.method_8608()) {
                    player.method_6122(hand, insert(heldStack, player));
                }
                return class_1269.field_5812;
            }
        }

        return class_1269.field_52423;
    }

    public class_1269 useWithoutItem(final class_1937 level, final class_1657 player) {
        if (player.method_5715() && canEject()) {
            if (!level.method_8608()) {
                eject(player);
            }
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    public class_1799 getMedia() {
        return itemHandler.getStackInSlot(0);
    }

    @Environment(EnvType.CLIENT)
    public void setMediaClient(final class_1799 stack) {
        itemHandler.setStackInSlot(0, stack);
    }

    @Nullable
    public TDevice getDevice() {
        return device;
    }

    public void setDevice(final TDevice value) {
        device = value;
    }

    @Override
    public class_1799 getMediaItemStack() {
        return itemHandler.getStackInSlotRaw(0);
    }

    @Override
    public void handleMediaChanged() {
        method_5431();
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);
        tag.method_10566(Constants.ITEMS_TAG_NAME, SerializationUtils.saveToTag(method_71402(), registries, itemHandler::save));
        return tag;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.ITEM_HANDLER, itemHandler);
    }

    @Override
    protected void method_11007(final class_11372 output) {
        super.method_11007(output);

        itemHandler.save(output.method_71461(Constants.ITEMS_TAG_NAME));
    }

    @Override
    protected void method_11014(final class_11368 input) {
        super.method_11014(input);

        itemHandler.load(input.method_71434(Constants.ITEMS_TAG_NAME));
    }

    // --------------------------------------------------------------------- //

    private void dropEjected(final class_1799 stack, @Nullable final class_1657 player) {
        if (stack.method_7960()) {
            return;
        }

        final class_2350 facing = getEjectDirection();
        ejectSoundEmitter.play();
        ItemStackUtils.spawnAsEntity(field_11863, method_11016().method_10093(facing), stack, facing).ifPresent(entity -> {
            if (player != null) {
                entity.method_6975();
                entity.method_48349(player.method_5667());
            }
        });
    }

    // --------------------------------------------------------------------- //

    private final class RemovableMediaItemStackHandler extends TypedItemStackHandler {
        public RemovableMediaItemStackHandler(final class_6862<class_1792> mediaTag) {
            super(1, mediaTag);
        }

        public class_1799 getStackInSlotRaw(final int slot) {
            return super.getStackInSlot(slot);
        }

        @Override
        public class_1799 getStackInSlot(final int slot) {
            final class_1799 stack = getStackInSlotRaw(slot);
            exportDeviceDataToItemStack(stack);
            return stack;
        }

        @Override
        public class_1799 extractItem(final int slot, final int amount, final TransactionContext transaction) {
            if (slot == 0 && amount > 0) {
                exportDeviceDataToItemStack(getStackInSlotRaw(0));
            }

            return super.extractItem(slot, amount, transaction);
        }

        @Override
        public int getSlotLimit(final int slot) {
            return 1;
        }

        @Override
        public void save(final class_11372 output) {
            exportDeviceDataToItemStack(getStackInSlotRaw(0));
            super.save(output);
        }

        @Override
        protected void onContentsChanged(final int slot) {
            super.onContentsChanged(slot);

            if (field_11863 == null || field_11863.method_8608()) {
                return;
            }

            final class_1799 stack = getStackInSlotRaw(slot);
            if (device != null) {
                if (stack.method_7960()) {
                    device.removeBlockDevice();
                } else {
                    device.updateBlockDevice(ItemDeviceUtils.getDeviceData(stack, device.getDeviceDataKey()));
                }
            }

            Network.sendToClientsTrackingBlockEntity(createMediaMessage(), AbstractRemovableMediaBlockEntity.this);

            method_5431();
        }

        private void exportDeviceDataToItemStack(final class_1799 stack) {
            if (stack.method_7960()) {
                return;
            }

            if (field_11863 == null || field_11863.method_8608()) {
                return;
            }

            if (device == null) {
                return;
            }

            final class_2487 tag = new class_2487();

            device.exportToItemStack(tag);

            if (tag.method_33133()) {
                return;
            }

            ItemDeviceUtils.setDeviceData(stack, device.getDeviceDataKey(), tag);
        }
    }
}
