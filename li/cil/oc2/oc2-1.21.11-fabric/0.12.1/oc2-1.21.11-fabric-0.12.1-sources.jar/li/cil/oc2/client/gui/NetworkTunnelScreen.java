/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.api.API;
import li.cil.oc2.client.gui.layout.*;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.common.container.NetworkTunnelContainer;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.NetworkTunnelLinkMessage;
import net.minecraft.class_11907;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class NetworkTunnelScreen extends UiContainerScreen<NetworkTunnelContainer> {
    private static final class_2960 LINK = class_2960.method_60655(API.MOD_ID, "network_tunnel/link");
    private static final int LINK_WIDTH = 20, LINK_HEIGHT = 46;
    private static final int SLOT_X = 1, HAND_SLOT_Y = 1, LINK_SLOT_Y = 27;

    private static final class_2561 LINK_BUTTON_CAPTION = text("gui.{mod}.network_tunnel.link");

    // --------------------------------------------------------------------- //

    private final class_1661 inventory;
    private final ImageButton linkButton;

    // --------------------------------------------------------------------- //

    public NetworkTunnelScreen(final NetworkTunnelContainer container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title, Sprites.THEME);
        this.inventory = inventory;
        this.linkButton = new ImageButton(0, 0,
            Sprites.NETWORK_TUNNEL_LINK_BUTTON_INACTIVE.width, Sprites.NETWORK_TUNNEL_LINK_BUTTON_INACTIVE.height,
            Sprites.NETWORK_TUNNEL_LINK_BUTTON_INACTIVE,
            Sprites.NETWORK_TUNNEL_LINK_BUTTON_ACTIVE) {
            @Override
            public void method_25306(final class_11907 input) {
                super.method_25306(input);
                createTunnel();
            }
        }.withMessage(LINK_BUTTON_CAPTION);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        linkButton.field_22763 = method_17577().hasLinkSlotItem();

        super.method_25394(graphics, mouseX, mouseY, partialTicks);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Window createWindow() {
        final NodeStack link = NodeStack.vertical().background(LINK).size(LINK_WIDTH, LINK_HEIGHT);
        link.add(
            new SlotNode(field_2797.getHandItemSlot()).position(SLOT_X, HAND_SLOT_Y),
            new SlotNode(field_2797.getLinkItemSlot()).position(SLOT_X, LINK_SLOT_Y));

        return new Window(NodeStack.vertical(
            Ui.section(field_22785, NodeStack.vertical(link, new WidgetNode(linkButton))
                .alignment(Align.START, Align.CENTER).width(Size.GROW)),
            Ui.section(field_29347, Ui.playerInventory(field_2797, inventory))
        ));
    }

    // --------------------------------------------------------------------- //

    private void createTunnel() {
        final NetworkTunnelLinkMessage message = new NetworkTunnelLinkMessage(method_17577().field_7763);
        Network.sendToServer(message);
    }
}
