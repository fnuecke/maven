/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.capabilities.fabric;

import li.cil.oc2.api.fabric.EnergyStorage;
import li.cil.oc2.api.fabric.FluidStorage;
import li.cil.oc2.api.fabric.ItemStorage;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityCache;
import li.cil.oc2.common.capabilities.CapabilityType;
import li.cil.oc2.common.inventory.ItemHandler;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiLookup;
import net.fabricmc.fabric.api.lookup.v1.entity.EntityApiLookup;
import net.fabricmc.fabric.api.lookup.v1.item.ItemApiLookup;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_3218;
import javax.annotation.Nullable;
import java.util.Optional;
import java.util.function.Supplier;

public final class CapabilitiesImpl {
    @Nullable
    @SuppressWarnings("unchecked")
    public static <T> T get(final class_1937 level, final class_2338 pos, final CapabilityType<T> type, @Nullable final class_2350 side) {
        if (type == Capabilities.ENERGY_STORAGE) {
            return (T) FabricCapabilityAdapters.energy(EnergyStorage.SIDED.find(level, pos, side));
        }

        if (type == Capabilities.ITEM_HANDLER) {
            return (T) FabricCapabilityAdapters.items(ItemStorage.SIDED.find(level, pos, side));
        }

        if (type == Capabilities.FLUID_HANDLER) {
            return (T) FabricCapabilityAdapters.fluids(FluidStorage.SIDED.find(level, pos, side));
        }

        return block(type).find(level, pos, side);
    }

    @Nullable
    public static <T> T get(final class_2586 blockEntity, final CapabilityType<T> type, @Nullable final class_2350 side) {
        final class_1937 level = blockEntity.method_10997();
        if (level == null) {
            return null;
        }

        return get(level, blockEntity.method_11016(), type, side);
    }

    @Nullable
    @SuppressWarnings("unchecked")
    public static <T> T get(final class_1799 stack, final CapabilityType<T> type) {
        final ContainerItemContext context = ContainerItemContext.ofSingleSlot(FabricCapabilityAdapters.stack(stack));

        if (type == Capabilities.ENERGY_STORAGE) {
            return (T) FabricCapabilityAdapters.energy(EnergyStorage.ITEM.find(stack, context));
        }

        if (type == Capabilities.ITEM_HANDLER) {
            return (T) FabricCapabilityAdapters.items(ItemStorage.ITEM.find(stack, context));
        }

        if (type == Capabilities.FLUID_HANDLER) {
            return (T) FabricCapabilityAdapters.fluids(FluidStorage.ITEM.find(stack, context));
        }

        return item(type).find(stack, null);
    }

    @Nullable
    @SuppressWarnings("unchecked")
    public static <T> T get(final ItemHandler handler, final int slot, final CapabilityType<T> type) {
        final ContainerItemContext context = ContainerItemContext.ofSingleSlot(FabricCapabilityAdapters.slot(handler, slot));

        if (type == Capabilities.ENERGY_STORAGE) {
            return (T) FabricCapabilityAdapters.energy(context.find(EnergyStorage.ITEM));
        }

        if (type == Capabilities.ITEM_HANDLER) {
            return (T) FabricCapabilityAdapters.items(context.find(ItemStorage.ITEM));
        }

        if (type == Capabilities.FLUID_HANDLER) {
            return (T) FabricCapabilityAdapters.fluids(context.find(FluidStorage.ITEM));
        }

        throw new IllegalArgumentException("unsupported capability: " + type);
    }

    @Nullable
    @SuppressWarnings("unchecked")
    public static <T> T get(final class_1297 entity, final CapabilityType<T> type, @Nullable final class_2350 side) {
        if (type == Capabilities.ENERGY_STORAGE) {
            return (T) FabricCapabilityAdapters.energy(EnergyStorage.ENTITY.find(entity, side));
        }

        if (type == Capabilities.ITEM_HANDLER) {
            final Storage<ItemVariant> storage = ItemStorage.ENTITY.find(entity, side);
            if (storage != null) {
                return (T) FabricCapabilityAdapters.items(storage);
            }

            // Fabric has no entity lookup that foreign mods register with, so anything that is simply a
            // Container, vanilla's inventory entities included, would otherwise be invisible here.
            if (entity instanceof final class_1263 container) {
                return (T) FabricCapabilityAdapters.items(InventoryStorage.of(container, side));
            }

            return null;
        }

        if (type == Capabilities.FLUID_HANDLER) {
            return (T) FabricCapabilityAdapters.fluids(FluidStorage.ENTITY.find(entity, side));
        }

        return entity(type).find(entity, side);
    }

    public static <T> Optional<CapabilityCache<T>> cache(final class_3218 level, final class_2338 pos, @Nullable final class_2350 side,
                                                         final CapabilityType<T> type) {
        // Unlike NeoForge's cache, BlockApiCache loads the chunk when queried.
        final Supplier<T> source = source(level, pos, side, type);
        final CapabilityCache<T> cache = new CapabilityCache<>(level, pos, side, type,
            () -> level.method_8477(pos) ? source.get() : null);
        if (cache.get() == null) {
            return Optional.empty();
        }

        return Optional.of(cache);
    }

    public static Capabilities.InvalidationHandle listen(final class_3218 level, final class_2338 pos, final Runnable callback) {
        return CapabilityWatchers.listen(level, pos, callback);
    }

    public static void invalidate(final class_2586 blockEntity) {
        final class_1937 level = blockEntity.method_10997();
        if (level != null) {
            CapabilityWatchers.invalidate(level, blockEntity.method_11016());
        }
    }

    // --------------------------------------------------------------------- //

    public static <T> BlockApiLookup<T, class_2350> block(final CapabilityType<T> type) {
        return BlockApiLookup.get(type.id(), type.type(), class_2350.class);
    }

    public static <T> ItemApiLookup<T, Void> item(final CapabilityType<T> type) {
        return ItemApiLookup.get(type.id(), type.type(), Void.class);
    }

    public static <T> EntityApiLookup<T, class_2350> entity(final CapabilityType<T> type) {
        return EntityApiLookup.get(type.id(), type.type(), class_2350.class);
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("unchecked")
    private static <T> Supplier<T> source(final class_3218 level, final class_2338 pos, @Nullable final class_2350 side, final CapabilityType<T> type) {
        if (type == Capabilities.ENERGY_STORAGE) {
            final BlockApiCache<team.reborn.energy.api.EnergyStorage, class_2350> cache = BlockApiCache.create(EnergyStorage.SIDED, level, pos);
            return () -> (T) FabricCapabilityAdapters.energy(cache.find(side));
        }

        if (type == Capabilities.ITEM_HANDLER) {
            final BlockApiCache<Storage<ItemVariant>, class_2350> cache = BlockApiCache.create(ItemStorage.SIDED, level, pos);
            return () -> (T) FabricCapabilityAdapters.items(cache.find(side));
        }

        if (type == Capabilities.FLUID_HANDLER) {
            final BlockApiCache<Storage<FluidVariant>, class_2350> cache = BlockApiCache.create(FluidStorage.SIDED, level, pos);
            return () -> (T) FabricCapabilityAdapters.fluids(cache.find(side));
        }

        final BlockApiCache<T, class_2350> cache = BlockApiCache.create(block(type), level, pos);
        return () -> cache.find(side);
    }

    private CapabilitiesImpl() {
    }
}
