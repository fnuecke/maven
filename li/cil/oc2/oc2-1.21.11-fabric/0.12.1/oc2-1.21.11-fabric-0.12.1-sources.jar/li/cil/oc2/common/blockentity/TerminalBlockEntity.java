/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.block.OrientableBlock;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.AbstractMessage;
import li.cil.oc2.common.network.message.TerminalConfigurationMessage;
import li.cil.oc2.common.network.message.TerminalOutputMessage;
import li.cil.oc2.common.network.message.TerminalStateMessage;
import li.cil.oc2.common.serial.BufferedSerialDevice;
import li.cil.oc2.common.serial.SerialEndpoint;
import li.cil.oc2.common.serialization.NBTSerialization;
import li.cil.oc2.common.util.SerializationUtils;
import li.cil.oc2.common.util.TickUtils;
import li.cil.oc2.common.vm.device.Terminal;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.*;

public final class TerminalBlockEntity extends ModBlockEntity implements TickableBlockEntity {
    private static final String TERMINAL_TAG_NAME = "terminal";
    private static final String IS_CONNECTED_TAG_NAME = "isConnected";

    public static final int CLIENT_KEEPALIVE_EVERY = TickUtils.toTicks(Duration.ofSeconds(1));
    private static final int CLIENT_EXPIRES_AFTER = TickUtils.toTicks(Duration.ofSeconds(2));

    private static final int RECIPIENT_REFRESH_INTERVAL = TickUtils.toTicks(Duration.ofSeconds(1));
    private static final double VIEW_DISTANCE = 8;

    private static final byte FRAME_ERROR_CHAR = '~';
    private static final long FRAME_ERROR_DISPLAY_MILLIS = 100;
    private static final int CONNECTED_TIMEOUT_TICKS = 10;

    // --------------------------------------------------------------------- //

    private final Terminal terminal = new Terminal();
    private final SerialEndpoint endpoint = new SerialEndpoint(this::gameTime);
    private final Map<class_1657, Long> users = new WeakHashMap<>();
    private List<class_3222> recipients = List.of();
    private int recipientRefreshCountdown;
    private boolean isConnected;
    private long lastFrameErrorAt;

    // --------------------------------------------------------------------- //

    public TerminalBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.TERMINAL.get(), pos, state);
    }

    public Terminal getTerminal() {
        return terminal;
    }

    public void handleUsedBy(final class_1657 player) {
        if (users.put(player, gameTime()) == null) {
            recipientRefreshCountdown = 0; // someone just opened the screen, do not make them wait
        }
    }

    public int getAddress() {
        return endpoint.getAddress();
    }

    public int getBaudRate() {
        return endpoint.getBaudRate();
    }

    public void setConfiguration(final int address, final int baudRate) {
        if (!endpoint.setConfiguration(address, baudRate)) {
            return;
        }

        method_5431();
        sendToRecipients(new TerminalConfigurationMessage.ToClient(this, endpoint.getAddress(), endpoint.getBaudRate()));
    }

    public void setConfigurationClient(final int address, final int baudRate) {
        endpoint.setConfiguration(address, baudRate);
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void setConnectedClient(final boolean value) {
        isConnected = value;
    }

    public boolean hasRecentFrameError() {
        return System.currentTimeMillis() - lastFrameErrorAt < FRAME_ERROR_DISPLAY_MILLIS;
    }

    public void handleFrameErrorClient() {
        // Intentional flicker instead of permanent on if we have consistent errors.
        final long now = System.currentTimeMillis();
        if (now - lastFrameErrorAt > FRAME_ERROR_DISPLAY_MILLIS) {
            lastFrameErrorAt = now;
        }
    }

    @Override
    public void serverTick() {
        if (--recipientRefreshCountdown <= 0) {
            recipientRefreshCountdown = RECIPIENT_REFRESH_INTERVAL;
            updateRecipients();
        }

        receive();
        transmit();

        updateConnected();
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);

        synchronized (terminal) {
            tag.method_10566(TERMINAL_TAG_NAME, NBTSerialization.serialize(terminal));
        }
        tag.method_10543(SerializationUtils.saveToTag(method_71402(), registries, endpoint::saveConfiguration));
        tag.method_10556(IS_CONNECTED_TAG_NAME, isConnected);

        return tag;
    }

    @Override
    protected void method_11007(final class_11372 output) {
        super.method_11007(output);

        synchronized (terminal) {
            output.method_71468(TERMINAL_TAG_NAME, class_2487.field_25128, NBTSerialization.serialize(terminal));
        }
        endpoint.save(output);
    }

    @Override
    protected void method_11014(final class_11368 input) {
        super.method_11014(input);

        NBTSerialization.deserialize(SerializationUtils.getCompoundOrEmpty(input, TERMINAL_TAG_NAME), terminal);
        endpoint.load(input);
        isConnected = input.method_71433(IS_CONNECTED_TAG_NAME, false);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        if (direction == method_11010().method_11654(OrientableBlock.FACING).method_10153()) {
            collector.offer(Capabilities.NETWORK_INTERFACE, endpoint.getNetworkInterface());
        }
    }

    @Override
    protected void loadClient() {
        super.loadClient();

        terminal.setDisplayOnly(true);
    }

    // --------------------------------------------------------------------- //

    private void updateConnected() {
        final boolean isConnected = endpoint.getLastReadTick() >= field_11863.method_75260() - CONNECTED_TIMEOUT_TICKS;
        if (isConnected != this.isConnected) {
            this.isConnected = isConnected;
            Network.sendToClientsTrackingBlockEntity(new TerminalStateMessage(this, isConnected), this);
        }
    }

    private void receive() {
        byte[] output = new byte[0];
        int count = 0;
        boolean hasFrameError = false;

        int value;
        while ((value = endpoint.receive()) >= 0) {
            if (count == output.length) {
                output = Arrays.copyOf(output, Math.max(16, output.length * 2));
            }
            if ((value & BufferedSerialDevice.FRAME_ERROR_FLAG) != 0) {
                output[count++] = FRAME_ERROR_CHAR;
                hasFrameError = true;
            } else {
                output[count++] = (byte) value;
            }
        }

        if (count == 0) {
            return;
        }

        final ByteBuffer received = ByteBuffer.wrap(Arrays.copyOf(output, count));
        terminal.putOutput(received.duplicate());
        method_5431();

        sendToRecipients(new TerminalOutputMessage(this, received, hasFrameError));
    }

    private void transmit() {
        int value;
        while (endpoint.canSend() && (value = terminal.readInput()) >= 0) {
            endpoint.send((byte) value);
        }
    }

    private long gameTime() {
        return field_11863 != null ? field_11863.method_75260() : 0;
    }

    private Iterable<class_1657> getTerminalUsers() {
        final long now = gameTime();
        users.entrySet().removeIf(entry -> now - entry.getValue() > CLIENT_EXPIRES_AFTER);

        return new ArrayList<>(users.keySet());
    }

    private void updateRecipients() {
        if (!(field_11863 instanceof final class_3218 serverLevel)) {
            return;
        }

        final class_243 center = class_243.method_24953(method_11016());
        final Set<class_3222> players = new LinkedHashSet<>();
        for (final class_3222 player : serverLevel.method_18456()) {
            if (!player.method_7325() && player.method_5707(center) <= VIEW_DISTANCE * VIEW_DISTANCE) {
                players.add(player);
            }
        }

        for (final class_1657 user : getTerminalUsers()) {
            if (user instanceof final class_3222 serverPlayer) {
                players.add(serverPlayer);
            }
        }

        final List<class_3222> previous = this.recipients;
        this.recipients = List.copyOf(players);

        for (final class_3222 recipient : this.recipients) {
            if (!previous.contains(recipient)) {
                recipient.field_13987.method_14364(class_2622.method_38585(this));
            }
        }
    }

    private void sendToRecipients(final AbstractMessage message) {
        for (final class_3222 recipient : recipients) {
            Network.sendToClient(message, recipient);
        }
    }
}
