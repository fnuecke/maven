/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.widget.Texture;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.common.item.Items;
import net.minecraft.class_10444;
import net.minecraft.class_11239;
import net.minecraft.class_11256;
import net.minecraft.class_11684;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_8030;
import net.minecraft.class_811;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;

public final class SideConfigurationBlockRenderer extends class_11239<SideConfigurationBlockRenderer.State> {
    public record State(Quaternionf rotation, int enabledSides, @Nullable class_2350 focusedSide,
                        int x0, int y0, int x1, int y1, float scale,
                        @Nullable class_8030 scissorArea,
                        @Nullable class_8030 bounds) implements class_11256 {
        public State(final Quaternionf rotation, final int enabledSides, @Nullable final class_2350 focusedSide,
                     final int x0, final int y0, final int x1, final int y1, final float scale) {
            this(rotation, enabledSides, focusedSide, x0, y0, x1, y1, scale, null, class_11256.method_71535(x0, y0, x1, y1, null));
        }
    }

    // --------------------------------------------------------------------- //

    private final class_1799 computerItemStack = new class_1799(Items.COMPUTER.get());
    private final class_10444 computerRenderState = new class_10444();

    // --------------------------------------------------------------------- //

    public SideConfigurationBlockRenderer(final class_4597.class_4598 bufferSource) {
        super(bufferSource);
    }

    // --------------------------------------------------------------------- //

    @Override
    public Class<State> method_70903() {
        return State.class;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void renderToTexture(final State state, final class_4587 poseStack) {
        poseStack.method_22905(1, 1, -1);
        poseStack.method_22907(state.rotation());
        poseStack.method_22905(1, -1, 1);

        renderBlock(poseStack);
        renderOverlays(state, poseStack);
    }

    @Override
    protected float method_70907(final int height, final int guiScale) {
        return height / 2f;
    }

    @Override
    protected String method_70906() {
        return "oc2 side configuration";
    }

    // --------------------------------------------------------------------- //

    private void renderBlock(final class_4587 poseStack) {
        final class_310 minecraft = class_310.method_1551();
        minecraft.field_1773.method_71114().method_71034(class_308.class_11274.field_60027);
        minecraft.method_65386().method_65598(computerRenderState, computerItemStack, class_811.field_4315, null, null, 0);

        final class_11684 featureRenderDispatcher = minecraft.field_1773.method_72911();
        computerRenderState.method_65604(poseStack, featureRenderDispatcher.method_73003(), 0xF000F0, class_4608.field_21444, 0);
        featureRenderDispatcher.method_73002();
    }

    private void renderOverlays(final State state, final class_4587 poseStack) {
        for (final class_2350 side : class_2350.values()) {
            if (side == class_2350.field_11035) {
                continue;
            }

            poseStack.method_22903();

            poseStack.method_22904(-side.method_10148() * 0.51, side.method_10164() * 0.51, -side.method_10165() * 0.51);

            final Vector3f sideRotation = switch (side) {
                case field_11033 -> new Vector3f(-90, 0, 0);
                case field_11036 -> new Vector3f(90, 0, 0);
                case field_11043 -> new Vector3f(0, 180, 0);
                case field_11039 -> new Vector3f(0, -90, 0);
                case field_11034 -> new Vector3f(0, 90, 0);
                default -> throw new IllegalStateException("Unexpected value: " + side);
            };
            poseStack.method_22907(new Quaternionf().rotationXYZ(
                (float) Math.toRadians(sideRotation.x()),
                (float) Math.toRadians(sideRotation.y()),
                (float) Math.toRadians(sideRotation.z())));

            poseStack.method_22904(-0.5, -0.5, 0);

            if ((state.enabledSides() & (1 << side.method_10146())) != 0) {
                renderOverlay(poseStack, Textures.BLOCK_FACE_ENABLED_TEXTURE);
            } else {
                renderOverlay(poseStack, Textures.BLOCK_FACE_DISABLED_TEXTURE);
            }

            if (side == state.focusedSide()) {
                renderOverlay(poseStack, Textures.BLOCK_FACE_FOCUSED_TEXTURE);
            }

            poseStack.method_22909();
        }
    }

    private void renderOverlay(final class_4587 poseStack, final Texture texture) {
        final class_4588 buffer = field_59933.method_73477(ModRenderType.getOverlay(texture.location));

        buffer.method_22918(poseStack.method_23760().method_23761(), 0, 0, 0).method_22913(0, 0);
        buffer.method_22918(poseStack.method_23760().method_23761(), 0, 1, 0).method_22913(0, 1);
        buffer.method_22918(poseStack.method_23760().method_23761(), 1, 1, 0).method_22913(1, 1);
        buffer.method_22918(poseStack.method_23760().method_23761(), 1, 0, 0).method_22913(1, 0);
    }
}
