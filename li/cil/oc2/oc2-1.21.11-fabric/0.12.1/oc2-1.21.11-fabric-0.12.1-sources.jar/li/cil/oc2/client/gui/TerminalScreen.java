/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.Ui;
import li.cil.oc2.client.gui.layout.WidgetNode;
import li.cil.oc2.client.gui.layout.Window;
import li.cil.oc2.client.gui.node.TerminalWidget;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.TerminalBlockEntity;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.TerminalInputMessage;
import li.cil.oc2.common.network.message.TerminalKeepAliveMessage;
import net.minecraft.class_11905;
import net.minecraft.class_11907;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class TerminalScreen extends AbstractBlockEntityScreen<TerminalBlockEntity> {
    private final TerminalWidget terminalWidget;

    private int keepAliveCountdown;

    // --------------------------------------------------------------------- //

    public static void open(final TerminalBlockEntity terminal) {
        class_310.method_1551().method_1507(new TerminalScreen(terminal));
    }

    // --------------------------------------------------------------------- //

    public TerminalScreen(final TerminalBlockEntity terminal) {
        super(Items.TERMINAL.get().method_63680(), terminal);
        this.terminalWidget = new TerminalWidget(terminal.getTerminal(), () -> true, () -> null,
            input -> Network.sendToServer(new TerminalInputMessage(blockEntity, input)));
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean method_25402(final class_11909 event, final boolean isDoubleClick) {
        return terminalWidget.method_25402(event, isDoubleClick) ||
            super.method_25402(event, isDoubleClick);
    }

    @Override
    public boolean method_25406(final class_11909 event) {
        return terminalWidget.method_25406(event) ||
            super.method_25406(event);
    }

    @Override
    public boolean method_25401(final double mouseX, final double mouseY, final double deltaX, final double deltaY) {
        return terminalWidget.method_25401(mouseX, mouseY, deltaX, deltaY) ||
            super.method_25401(mouseX, mouseY, deltaX, deltaY);
    }

    @Override
    public boolean method_25400(final class_11905 event) {
        return terminalWidget.method_25400(event) ||
            super.method_25400(event);
    }

    @Override
    public boolean method_25404(final class_11908 event) {
        return terminalWidget.method_25404(event) ||
            super.method_25404(event);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Window createWindow() {
        final ImageButton configButton = new ImageButton(0, 0, 12, 12,
            Sprites.CONFIG_BUTTON_INACTIVE,
            Sprites.CONFIG_BUTTON_ACTIVE
        ) {
            @Override
            public void method_25306(final class_11907 input) {
                field_22787.method_1507(new TerminalConfigurationScreen(blockEntity));
            }
        };
        configButton.withTooltip(class_2561.method_43471(Constants.OPEN_CONFIGURATION_CAPTION));

        return new Window(Ui.insetBlack(new WidgetNode(terminalWidget)),
            Ui.toolbar(new WidgetNode(InputCapture.button()), new WidgetNode(configButton)));
    }

    @Override
    protected void safeTick() {
        super.safeTick();

        sendKeepAlive();

        terminalWidget.tick();
    }

    // --------------------------------------------------------------------- //

    private void sendKeepAlive() {
        if (--keepAliveCountdown <= 0) {
            keepAliveCountdown = TerminalBlockEntity.CLIENT_KEEPALIVE_EVERY;
            Network.sendToServer(new TerminalKeepAliveMessage(blockEntity));
        }
    }
}
