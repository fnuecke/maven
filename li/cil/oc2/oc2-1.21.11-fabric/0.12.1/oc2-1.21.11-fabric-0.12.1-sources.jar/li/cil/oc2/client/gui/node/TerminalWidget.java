/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.node;

import li.cil.oc2.api.API;
import li.cil.oc2.client.gui.InputCapture;
import li.cil.oc2.client.gui.terminal.TerminalInput;
import li.cil.oc2.client.renderer.TerminalTextures;
import li.cil.oc2.common.vm.device.Terminal;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import org.lwjgl.glfw.GLFW;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public final class TerminalWidget extends class_339 {
    private static final int WIDTH = Terminal.WIDTH * Terminal.CHAR_WIDTH / 2;
    private static final int HEIGHT = Terminal.HEIGHT * Terminal.CHAR_HEIGHT / 2;

    private static final class_2960 FOCUSED = class_2960.method_60655(API.MOD_ID, "ui/inset_focused");

    private static final int WHEEL_UP_BUTTON = 64;
    private static final int WHEEL_DOWN_BUTTON = 65;
    private static final int WHEEL_SCROLL_LINES = 3;

    // --------------------------------------------------------------------- //

    private final Terminal terminal;
    private final BooleanSupplier isRunning;
    private final Supplier<class_2561> error;
    private final Consumer<ByteBuffer> inputSender;

    // --------------------------------------------------------------------- //

    public TerminalWidget(final Terminal terminal, final BooleanSupplier isRunning,
                          final Supplier<class_2561> error, final Consumer<ByteBuffer> inputSender) {
        super(0, 0, WIDTH, HEIGHT, class_5244.field_39003);
        this.terminal = terminal;
        this.isRunning = isRunning;
        this.error = error;
        this.inputSender = inputSender;
    }

    // --------------------------------------------------------------------- //


    public void tick() {
        final ByteBuffer input = terminal.getInput();
        if (input != null) {
            inputSender.accept(input);
        }
    }

    @Override
    public boolean method_25402(final class_11909 event, final boolean isDoubleClick) {
        return putMouseEvent(event.comp_4798(), event.comp_4799(), toReportedButton(event.method_74245()), true);
    }

    @Override
    public boolean method_25406(final class_11909 event) {
        return putMouseEvent(event.comp_4798(), event.comp_4799(), toReportedButton(event.method_74245()), false);
    }

    @Override
    public boolean method_25401(final double mouseX, final double mouseY, final double deltaX, final double deltaY) {
        if (deltaY == 0) {
            return false;
        }

        if (putMouseEvent(mouseX, mouseY, deltaY > 0 ? WHEEL_UP_BUTTON : WHEEL_DOWN_BUTTON, true)) {
            return true;
        }

        return shouldCaptureInput() && terminal.putScroll(deltaY > 0, WHEEL_SCROLL_LINES);
    }

    @Override
    public boolean method_25400(final class_11905 event) {
        final boolean isControlChord = (event.comp_4794() & GLFW.GLFW_MOD_CONTROL) != 0
            && (event.comp_4794() & GLFW.GLFW_MOD_ALT) == 0;
        if (!isControlChord) {
            putInput(event.method_74226());
        }
        return true;
    }

    @Override
    public boolean method_25404(final class_11908 event) {
        final int keyCode = event.comp_4795();
        final int modifiers = event.comp_4797();
        if (!shouldCaptureInput() && keyCode == GLFW.GLFW_KEY_ESCAPE) {
            return false;
        }

        if ((modifiers & GLFW.GLFW_MOD_CONTROL) != 0 && keyCode == GLFW.GLFW_KEY_V) {
            terminal.putPaste(class_310.method_1551().field_1774.method_1460());
        } else {
            final byte[] sequence = TerminalInput.getSequence(keyCode, modifiers, terminal.isCursorKeyApplicationMode(), terminal.isNewLineMode());
            if (sequence != null) {
                for (final byte b : sequence) {
                    terminal.putInput(b);
                }
            }
        }

        return true;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_48579(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        if (shouldCaptureInput()) {
            final int padding = 1;
            graphics.method_52706(class_10799.field_56883, FOCUSED, method_46426() - padding, method_46427() - padding, field_22758 + 2 * padding, field_22759 + 2 * padding);
        }

        if (isRunning.getAsBoolean()) {
            TerminalTextures.get(terminal).drawGui(graphics, method_46426(), method_46427(), WIDTH, HEIGHT);
        } else {
            final class_2561 message = error.get();
            if (message != null) {
                final class_327 font = class_310.method_1551().field_1772;
                graphics.method_27535(font, message,
                    method_46426() + (field_22758 - font.method_27525(message)) / 2,
                    method_46427() + (field_22759 - font.field_2000) / 2,
                    0xFFEE3322);
            }
        }
    }

    @Override
    protected void method_47399(final class_6382 output) {
    }

    // --------------------------------------------------------------------- //

    private boolean shouldCaptureInput() {
        return method_49606() && InputCapture.isEnabled() && isRunning.getAsBoolean();
    }

    private void putInput(final String value) {
        for (final byte b : value.getBytes(StandardCharsets.UTF_8)) {
            terminal.putInput(b);
        }
    }

    private static int toReportedButton(final int button) {
        return switch (button) {
            case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> 2;
            case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> 1;
            default -> button;
        };
    }

    private boolean putMouseEvent(final double mouseX, final double mouseY, final int button, final boolean isPressed) {
        if (!shouldCaptureInput() || !terminal.isMouseReportingEnabled()) {
            return false;
        }

        final int column = ((int) mouseX - method_46426()) * 2 / Terminal.CHAR_WIDTH;
        final int row = ((int) mouseY - method_46427()) * 2 / Terminal.CHAR_HEIGHT;
        terminal.putMouseEvent(button,
            Math.clamp(column, 0, Terminal.WIDTH - 1),
            Math.clamp(row, 0, Terminal.HEIGHT - 1),
            isPressed);

        return true;
    }
}
