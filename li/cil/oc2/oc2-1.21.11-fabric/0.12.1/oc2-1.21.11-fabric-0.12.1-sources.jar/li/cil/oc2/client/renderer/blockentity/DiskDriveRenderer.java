/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.common.block.DiskDriveBlock;
import li.cil.oc2.common.blockentity.DiskDriveBlockEntity;
import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import javax.annotation.Nullable;

public final class DiskDriveRenderer implements class_827<DiskDriveBlockEntity, MediaRenderState> {
    private final class_10442 itemModelResolver;

    // --------------------------------------------------------------------- //

    public DiskDriveRenderer(final class_5614.class_5615 context) {
        this.itemModelResolver = context.comp_4536();
    }

    // --------------------------------------------------------------------- //

    @Override
    public MediaRenderState method_74335() {
        return new MediaRenderState();
    }

    @Override
    public void extractRenderState(final DiskDriveBlockEntity diskDrive, final MediaRenderState state, final float partialTicks,
                                   final class_243 cameraPosition, @Nullable final class_11683.class_11792 crumbling) {
        class_827.super.method_74331(diskDrive, state, partialTicks, cameraPosition, crumbling);

        final class_2350 blockFacing = state.field_62674.method_11654(DiskDriveBlock.field_11177);
        state.neighborLight = diskDrive.method_10997() != null
            ? class_761.method_23794(diskDrive.method_10997(), diskDrive.method_11016().method_10093(blockFacing))
            : state.field_62676;
        itemModelResolver.method_65598(state.media, diskDrive.getMedia(), class_811.field_4319,
            diskDrive.method_10997(), null, (int) diskDrive.method_11016().method_10063());
    }

    @Override
    public void submit(final MediaRenderState state, final class_4587 stack, final class_11659 collector, final class_12075 camera) {
        if (state.media.method_65606()) {
            return;
        }

        final class_2350 blockFacing = state.field_62674.method_11654(DiskDriveBlock.field_11177);

        stack.method_22903();

        stack.method_46416(0.5f, 0.5f, 0.5f);
        stack.method_22907(class_7833.field_40715.rotationDegrees(blockFacing.method_10144()));
        stack.method_46416(0.0f, 0.0f, 0.5f);
        stack.method_22907(class_7833.field_40713.rotationDegrees(90));
        stack.method_46416(0.0f, 0.2375f, 2.5f / 16f);
        stack.method_22905(0.55f, 0.55f, 0.55f);

        state.media.method_65604(stack, collector, state.neighborLight, class_4608.field_21444, 0);

        stack.method_22909();
    }
}
