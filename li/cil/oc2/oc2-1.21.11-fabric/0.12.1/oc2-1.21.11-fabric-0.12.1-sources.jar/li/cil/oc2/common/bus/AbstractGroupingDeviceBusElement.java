/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus;

import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import li.cil.oc2.api.bus.DeviceBusController;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.common.util.SerializationUtils;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2487;
import net.minecraft.class_4844;
import net.minecraft.class_7225;
import net.minecraft.class_8942;
import java.util.*;

public abstract class AbstractGroupingDeviceBusElement<TEntry extends AbstractGroupingDeviceBusElement.Entry> extends AbstractDeviceBusElement {
    private static final String GROUPS_TAG_NAME = "groups";
    private static final String GROUP_ID_TAG_NAME = "groupId";
    private static final String GROUP_DATA_TAG_NAME = "groupData";

    protected interface Entry {
        Optional<String> getDeviceDataKey();

        OptionalInt getDeviceEnergyConsumption();

        Device getDevice();
    }

    // --------------------------------------------------------------------- //

    protected final int groupCount;
    protected final ArrayList<HashSet<TEntry>> groups;
    private final Object2IntOpenHashMap<Device> deviceGroups = new Object2IntOpenHashMap<>();

    // --------------------------------------------------------------------- //

    protected final UUID[] groupIds;
    protected final class_2487[] groupData;

    // --------------------------------------------------------------------- //

    protected AbstractGroupingDeviceBusElement(final int groupCount) {
        this.groupCount = groupCount;
        this.groups = new ArrayList<>(groupCount);
        this.groupIds = new UUID[groupCount];
        this.groupData = new class_2487[groupCount];

        deviceGroups.defaultReturnValue(-1);

        for (int i = 0; i < groupCount; i++) {
            groups.add(new HashSet<>());
            groupIds[i] = UUID.randomUUID();
            groupData[i] = new class_2487();
        }
    }

    // --------------------------------------------------------------------- //

    public void save(final class_11372 output) {
        if (groups.stream().anyMatch(group -> !group.isEmpty())) {
            onSaving();
        }

        final class_11372.class_11374 groupsOutput = output.method_71476(GROUPS_TAG_NAME);
        for (int i = 0; i < groupCount; i++) {
            final class_11372 groupOutput = groupsOutput.method_71480();
            groupOutput.method_71468(GROUP_ID_TAG_NAME, class_4844.field_25122, groupIds[i]);
            saveGroup(i, groupOutput.method_71461(GROUP_DATA_TAG_NAME));
        }
    }

    public void load(final class_11368 input) {
        int i = 0;
        for (final class_11368 groupInput : input.method_71438(GROUPS_TAG_NAME)) {
            if (i >= groupCount) {
                break;
            }

            groupIds[i] = groupInput.method_71426(GROUP_ID_TAG_NAME, class_4844.field_25122).orElse(groupIds[i]);
            groupData[i] = groupInput.method_71426(GROUP_DATA_TAG_NAME, class_2487.field_25128).orElse(groupData[i]);

            // Immediately load data into devices, if we already have some.
            final class_11368 devicesInput = groupInput.method_71434(GROUP_DATA_TAG_NAME);
            for (final TEntry entry : groups.get(i)) {
                entry.getDeviceDataKey()
                    .flatMap(devicesInput::method_71420)
                    .ifPresent(entry.getDevice()::deserialize);
            }

            i++;
        }
    }

    public void reset() {
        final boolean hadEntries = groups.stream().anyMatch(group -> !group.isEmpty());
        for (int i = 0; i < groupCount; i++) {
            for (final TEntry entry : groups.get(i)) {
                devices.removeInt(entry.getDevice());
                deviceGroups.removeInt(entry.getDevice());
                onEntryRemoved(entry);
            }
            groups.get(i).clear();
            groupData[i] = new class_2487();
        }

        if (hadEntries) {
            scanDevices();
        }
    }

    @Override
    public Optional<UUID> getDeviceIdentifier(final Device device) {
        final int index = deviceGroups.getInt(device);
        if (index >= 0) {
            return Optional.of(groupIds[index]);
        }
        return super.getDeviceIdentifier(device);
    }

    // --------------------------------------------------------------------- //

    protected final void setEntriesForGroupUnloaded(final int index) {
        final HashSet<TEntry> oldEntries = groups.get(index);
        if (oldEntries.isEmpty()) {
            return;
        }

        onSaving();
        final class_2487 devicesTag = groupData[index];
        for (final TEntry entry : oldEntries) {
            entry.getDeviceDataKey().ifPresent(key ->
                devicesTag.method_10566(key, SerializationUtils.saveToTag(new class_8942.class_11339(key), getRegistries(), entry.getDevice()::serialize)));
        }

        for (final TEntry entry : oldEntries) {
            devices.removeInt(entry.getDevice());
            deviceGroups.removeInt(entry.getDevice());
            onEntryRemoved(entry);
        }

        oldEntries.clear();

        scanDevices();
    }

    protected final void setEntriesForGroup(final int index, final Set<TEntry> newEntries) {
        final HashSet<TEntry> entries = groups.get(index);
        if (Objects.equals(newEntries, entries)) {
            if (entries.isEmpty()) {
                groupData[index].method_10541().clear();
            }

            return;
        }

        final boolean hadOldEntries = !entries.isEmpty();

        final HashSet<TEntry> removedEntries = new HashSet<>(entries);
        removedEntries.removeAll(newEntries);
        for (final TEntry entry : removedEntries) {
            devices.removeInt(entry.getDevice());
            deviceGroups.removeInt(entry.getDevice());
            onEntryRemoved(entry);
        }

        final HashSet<TEntry> addedEntries = new HashSet<>(newEntries);
        addedEntries.removeAll(entries);
        for (final TEntry entry : addedEntries) {
            devices.put(entry.getDevice(), entry.getDeviceEnergyConsumption().orElse(0));
            deviceGroups.put(entry.getDevice(), index);
            onEntryAdded(entry);
        }

        entries.removeAll(removedEntries);
        entries.addAll(newEntries);

        // Remove serialized data for devices that were present before, but are gone now.
        final class_2487 devicesTag = groupData[index];
        for (final TEntry entry : removedEntries) {
            entry.getDeviceDataKey().ifPresent(devicesTag::method_10551);
        }

        // Deserialize data for found devices, if we have existing data for them. Also collect
        // the list of serialized data we have for devices that have gone missing without being
        // explicitly removed. This can happen if a device is removed while the bus element is
        // unloaded.
        final HashSet<String> invalidDataKeys = new HashSet<>(devicesTag.method_10541());
        for (final TEntry entry : addedEntries) {
            entry.getDeviceDataKey().ifPresent(key -> {
                invalidDataKeys.remove(key);
                final Optional<class_2487> deviceTag = devicesTag.method_10562(key);
                if (deviceTag.isPresent()) {
                    SerializationUtils.loadFromTag(new class_8942.class_11339(key), getRegistries(), deviceTag.get(), entry.getDevice()::deserialize);
                } else {
                    devicesTag.method_10551(key);
                }
            });
        }

        invalidDataKeys.forEach(devicesTag::method_10551);

        // Assign a new ID to this side when the device configuration changes. Avoids confusion when
        // providing a different device to an interface when some running use programs in the VM may
        // still hold a reference to the old one. We consider "changing" anything that removes some
        // devices or adds new devices to an *existing* device set.
        if (hadOldEntries) {
            groupIds[index] = UUID.randomUUID();
        }

        // Trigger a device update on the controller, if we have one. This gives adapters a chance
        // to unmount old devices before we call dispose on them in the next step. If we don't
        // have a controller, devices must already be unmounted (either not mounted in this lifetime,
        // or controller unmounted them when it was removed).
        scanDevices();

        for (final TEntry entry : removedEntries) {
            entry.getDevice().dispose();
        }
    }

    protected abstract class_7225.class_7874 getRegistries();

    protected void onEntryAdded(final TEntry entry) {
    }

    protected void onEntryRemoved(final TEntry entry) {
    }

    // --------------------------------------------------------------------- //

    private void onSaving() {
        for (final DeviceBusController controller : controllers) {
            if (controller instanceof final CommonDeviceBusController commonController) {
                commonController.onSaving();
            }
        }
    }

    private void saveGroup(final int index, final class_11372 output) {
        // We keep data of devices that are not present (yet), because we might be saving before we
        // had a chance to do a full scan (something triggered a chunk save immediately after its load
        // for example). Otherwise, we might end up dropping saved data here, which would then be missing
        // on the next load+scan. Any stale data we accumulate this way will be cleaned up in the next
        // controller scan.
        final class_2487 devicesTag = groupData[index];
        final HashSet<String> savedKeys = new HashSet<>();
        for (final TEntry entry : groups.get(index)) {
            entry.getDeviceDataKey().ifPresent(key -> {
                // Always store, even if the data is empty, so we know a device by this provider existed.
                entry.getDevice().serialize(output.method_71461(key));
                savedKeys.add(key);
            });
        }
        for (final String key : devicesTag.method_10541()) {
            if (!savedKeys.contains(key)) {
                devicesTag.method_10562(key).ifPresent(tag -> output.method_71468(key, class_2487.field_25128, tag));
            }
        }
    }
}
