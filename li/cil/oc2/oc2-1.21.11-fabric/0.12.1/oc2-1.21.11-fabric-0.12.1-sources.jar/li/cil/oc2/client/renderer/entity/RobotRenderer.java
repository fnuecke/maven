/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.entity;

import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.client.renderer.Overlays;
import li.cil.oc2.client.renderer.entity.model.RobotModel;
import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import org.joml.Vector3f;

public final class RobotRenderer extends class_897<Robot, RobotRenderState> {
    private static final Vector3f GLOW_COLOR = new Vector3f(0.16f, 0.43f, 0.45f);
    private static final Vector3f GLOW_COLOR_BRIGHT = new Vector3f(0.35f, 0.95f, 1f);

    private static final class_238 GLOW_BOUNDS = new class_238(-6.25 / 16.0, 7 / 16.0, -6.25 / 16.0, 6.25 / 16.0, 8 / 16.0, 6.25 / 16.0);

    private static final float STATUS_INNER_X = 2 / 16f;
    private static final float STATUS_OUTER_X = 4 / 16f;
    private static final float STATUS_Y = 10 / 16f;
    private static final float STATUS_HEIGHT = 1 / 16f;
    private static final float STATUS_Z = 7 / 16f;

    private final RobotModel model;

    // --------------------------------------------------------------------- //

    public RobotRenderer(final class_5617.class_5618 context) {
        super(context);
        model = new RobotModel(context.method_32167(RobotModel.ROBOT_MODEL_LAYER));
    }

    // --------------------------------------------------------------------- //

    @Override
    public RobotRenderState method_55269() {
        return new RobotRenderState();
    }

    @Override
    public void extractRenderState(final Robot entity, final RobotRenderState renderState, final float partialTicks) {
        super.method_62354(entity, renderState, partialTicks);

        final Robot.AnimationState state = entity.getAnimationState();

        // NB: we don't entityYaw given to use because that uses a plain lerp which can lead to ugly
        //     jumps in case we get a wrapped rotationYaw synced from the server (leading to ~360
        //     degree delta to the last known previous rotation). Haven't figured out where to
        //     alternatively prevent this wrapping or patch the prev value instead.
        final float partialRotation = class_3532.method_15356(entity.field_5982, entity.method_36454()) * partialTicks;
        renderState.rotation = class_3532.method_15388(entity.field_5982, entity.method_36454(), partialRotation);
        renderState.baseY = state.getBaseRenderOffsetY(partialTicks);
        renderState.topY = state.getTopRenderOffsetY(partialTicks);
        renderState.topRotationY = state.getTopRenderRotationY(partialTicks);
        renderState.isRunning = entity.getVirtualMachine().isRunning();
        renderState.statusColor = entity.getStatusColor();
        renderState.statusValue = entity.getStatusValue();
        renderState.gameTime = entity.method_73183().method_75260();
        renderState.partialTicks = partialTicks;
    }

    @Override
    public void submit(final RobotRenderState state, final class_4587 stack, final class_11659 collector, final class_12075 camera) {
        stack.method_22903();
        stack.method_22907(class_7833.field_40715.rotationDegrees(state.rotation));

        model.submit(stack, collector, state.field_61820, state.baseY, state.topY, state.topRotationY);

        if (state.isRunning) {
            stack.method_22903();
            model.applyTopTransform(stack, state.topY, state.topRotationY);
            renderStatusLights(stack, collector, state.statusColor, state.statusValue);
            stack.method_22909();
        }

        if (state.topY > Robot.AnimationState.TOP_IDLE_Y) {
            stack.method_46416(0, state.baseY, 0);
            Overlays.renderBox(ModRenderType.getGlow(), stack, collector, GLOW_BOUNDS, GLOW_COLOR, GLOW_COLOR_BRIGHT, state.gameTime, state.partialTicks);
        }

        stack.method_22909();

        super.method_3936(state, stack, collector, camera);
    }

    // --------------------------------------------------------------------- //

    private static void renderStatusLights(final class_4587 stack, final class_11659 collector, final int color, final float value) {
        if (value <= 0) {
            return;
        }

        final float r = (color >>> 16) / 255f;
        final float g = ((color >>> 8) & 0xFF) / 255f;
        final float b = (color & 0xFF) / 255f;

        final float top = STATUS_Y + STATUS_HEIGHT * value;
        collector.method_73483(stack, ModRenderType.getIndicator(), (pose, consumer) -> {
            addQuad(pose, consumer, -STATUS_OUTER_X, -STATUS_INNER_X, top, r, g, b);
            addQuad(pose, consumer, STATUS_INNER_X, STATUS_OUTER_X, top, r, g, b);
        });
    }

    private static void addQuad(final class_4587.class_4665 matrix, final class_4588 consumer, final float x0, final float x1, final float y1, final float r, final float g, final float b) {
        addVertex(matrix, consumer, x0, STATUS_Y, r, g, b);
        addVertex(matrix, consumer, x1, STATUS_Y, r, g, b);
        addVertex(matrix, consumer, x1, y1, r, g, b);
        addVertex(matrix, consumer, x0, y1, r, g, b);
    }

    private static void addVertex(final class_4587.class_4665 matrix, final class_4588 consumer, final float x, final float y, final float r, final float g, final float b) {
        consumer.method_56824(matrix, x, y, STATUS_Z).method_22915(r, g, b, 1f);
    }
}
