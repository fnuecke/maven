/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.energy.FixedEnergyHandler;
import li.cil.oc2.common.entity.Robot;
import li.cil.oc2.common.fluid.FluidStack;
import li.cil.oc2.common.fluid.FluidTank;
import li.cil.oc2.common.inventory.ItemHandler;
import li.cil.oc2.common.vm.VMItemStackHandlers;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

public final class RobotInventoryContainer extends AbstractRobotContainer {
    private static final int FLUID_ID_INDEX = 0;
    private static final int FLUID_AMOUNT_INDEX = 1;
    private static final int FLUID_INFO_SIZE = 2;

    // --------------------------------------------------------------------- //

    private final IntPrecisionContainerData fluidInfo;

    // --------------------------------------------------------------------- //

    public static void createServer(final Robot robot, final FixedEnergyHandler energy, final CommonDeviceBusController busController, final class_3222 player) {
        MenuRegistry.openExtendedMenu(player, new ExtendedMenuProvider() {
            @Override
            public class_2561 method_5476() {
                return robot.method_5477();
            }

            @Override
            public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                return new RobotInventoryContainer(id, robot, player, createEnergyInfo(energy, busController), createFluidInfo(robot.getTank()));
            }

            @Override
            public void saveExtraData(final class_2540 buffer) {
                buffer.method_10804(robot.method_5628());
            }
        });
    }

    public static RobotInventoryContainer createClient(final int id, final class_1661 inventory, final class_2540 data) {
        final int entityId = data.method_10816();
        final class_1297 entity = inventory.field_7546.method_73183().method_8469(entityId);
        if (entity instanceof final Robot robot) {
            return new RobotInventoryContainer(id, robot, inventory.field_7546, createClientEnergyInfo(), new IntPrecisionContainerData.Client(FLUID_INFO_SIZE));
        }

        throw new IllegalArgumentException();
    }

    // --------------------------------------------------------------------- //

    private RobotInventoryContainer(final int id, final Robot robot, final class_1657 player, final IntPrecisionContainerData energyInfo, final IntPrecisionContainerData fluidInfo) {
        super(Containers.ROBOT.get(), id, player, robot, energyInfo);
        this.fluidInfo = fluidInfo;

        method_17361(fluidInfo, FLUID_INFO_SIZE);
        method_17360(fluidInfo);

        final VMItemStackHandlers handlers = robot.getItemStackHandlers();

        handlers.getItemHandler(DeviceTypes.CPU.get()).ifPresent(itemHandler -> {
            if (itemHandler.getSlots() > 0) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.CPU.get(), 0, 0, 0));
            }
        });

        handlers.getItemHandler(DeviceTypes.FLASH_MEMORY.get()).ifPresent(itemHandler -> {
            if (itemHandler.getSlots() > 0) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.FLASH_MEMORY.get(), 0, 0, 0));
            }
        });

        handlers.getItemHandler(DeviceTypes.MEMORY.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.MEMORY.get(), slot, 0, 0));
            }
        });

        handlers.getItemHandler(DeviceTypes.HARD_DRIVE.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.HARD_DRIVE.get(), slot, 0, 0));
            }
        });

        handlers.getItemHandler(DeviceTypes.FLOPPY.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.FLOPPY.get(), slot, 0, 0));
            }
        });

        handlers.getItemHandler(DeviceTypes.ROBOT_MODULE.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.ROBOT_MODULE.get(), slot, 0, 0));
            }
        });

        final ItemHandler inventory = robot.getInventory();
        for (int slot = 0; slot < inventory.getSlots(); slot++) {
            method_7621(new RobotSlot(inventory, slot, 0, 0));
        }

        createPlayerInventorySlots(player.method_31548());
    }

    // --------------------------------------------------------------------- //

    public FluidStack getFluid() {
        return new FluidStack(class_7923.field_41173.method_10200(fluidInfo.getInt(FLUID_ID_INDEX)), fluidInfo.getInt(FLUID_AMOUNT_INDEX));
    }

    public int getFluidCapacity() {
        return getRobot().getTank().getTankCapacity(0);
    }

    // --------------------------------------------------------------------- //

    private static IntPrecisionContainerData createFluidInfo(final FluidTank tank) {
        return new IntPrecisionContainerData.Server() {
            @Override
            public int getInt(final int index) {
                return switch (index) {
                    case FLUID_ID_INDEX -> class_7923.field_41173.method_10206(tank.getFluid().fluid());
                    case FLUID_AMOUNT_INDEX -> tank.getFluid().amount();
                    default -> 0;
                };
            }

            @Override
            public int getIntCount() {
                return FLUID_INFO_SIZE;
            }
        };
    }
}
