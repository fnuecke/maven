/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.client.gui.InternetGatewayConfigurationScreen;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.InternetGatewayBlockEntity;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3532;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import javax.annotation.Nullable;

public final class InternetGatewayBlock extends class_2383 implements class_2343 {
    public static final MapCodec<InternetGatewayBlock> CODEC = method_54094(InternetGatewayBlock::new);
    private static final double PARTICLES_MIN = 3 / 16.0;
    private static final double PARTICLES_MAX = 13 / 16.0;

    // --------------------------------------------------------------------- //

    public InternetGatewayBlock(final class_2251 properties) {
        super(properties
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override
    protected MapCodec<? extends InternetGatewayBlock> method_53969() {
        return field_46280;
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2680 method_9605(final class_1750 context) {
        return super.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    protected class_1269 method_55766(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final InternetGatewayBlockEntity gateway) {
            if (level.method_8608()) {
                InternetGatewayConfigurationScreen.open(gateway);
            }

            return class_1269.field_5812;
        }

        return super.method_55766(state, level, pos, player, hit);
    }

    @Override
    public void method_9496(final class_2680 state, final class_1937 level, final class_2338 pos, final class_5819 random) {
        if (!(level.method_8321(pos) instanceof final InternetGatewayBlockEntity gateway) || !gateway.isOperational()) {
            return;
        }

        level.method_8406(class_2398.field_23190,
            pos.method_10263() + class_3532.method_16436(random.method_43058(), PARTICLES_MIN, PARTICLES_MAX),
            pos.method_10264() + 1.0,
            pos.method_10260() + class_3532.method_16436(random.method_43058(), PARTICLES_MIN, PARTICLES_MAX),
            0.0, 0.03, 0.0);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.INTERNET_GATEWAY.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createServerTicker(level, type, BlockEntities.INTERNET_GATEWAY.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(field_11177);
    }
}
