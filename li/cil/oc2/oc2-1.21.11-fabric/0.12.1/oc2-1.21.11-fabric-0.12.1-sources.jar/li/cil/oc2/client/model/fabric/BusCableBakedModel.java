/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.model.fabric;

import li.cil.oc2.common.Constants;
import li.cil.oc2.common.block.BusCableBlock;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.util.ItemStackUtils;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBlockStateModel;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_10889;
import net.minecraft.class_11515;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_310;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Predicate;

public record BusCableBakedModel(
    class_1087 proxy,
    class_10889[] straightModelByAxis,
    class_10889[] supportModelByFace
) implements class_1087, FabricBlockStateModel {
    @Override
    public void emitQuads(final QuadEmitter emitter, final class_1920 level, final class_2338 pos,
                          final class_2680 state, final class_5819 random, final Predicate<class_2350> cullTest) {
        if (state.method_28498(BusCableBlock.HAS_FACADE) && state.method_11654(BusCableBlock.HAS_FACADE)) {
            emitFacadeQuads(emitter, level, pos, random, cullTest);
            return;
        }

        if (!state.method_11654(BusCableBlock.HAS_CABLE)) {
            return;
        }

        for (int i = 0; i < Constants.AXES.length; i++) {
            if (isStraightAlongAxis(state, Constants.AXES[i])) {
                straightModelByAxis[i].emitQuads(emitter, cullTest);
                return;
            }
        }

        proxy.emitQuads(emitter, level, pos, state, random, cullTest);

        final class_2350 supportSide = getSupportSide(level, pos, state);
        if (supportSide != null) {
            supportModelByFace[supportSide.method_10146()].emitQuads(emitter, cullTest);
        }
    }

    @Override
    public void method_68513(final class_5819 random, final List<class_10889> parts) {
        proxy.method_68513(random, parts);
    }

    @Override
    public class_1058 method_68511() {
        return proxy.method_68511();
    }

    // --------------------------------------------------------------------- //

    private static void emitFacadeQuads(final QuadEmitter emitter, final class_1920 level, final class_2338 pos,
                                        final class_5819 random, final Predicate<class_2350> cullTest) {
        final class_2586 blockEntity = level.method_8321(pos);

        class_2680 facadeState = null;
        if (blockEntity instanceof final BusCableBlockEntity busCable) {
            final class_1799 facadeItem = busCable.getFacade();
            facadeState = ItemStackUtils.getBlockState(facadeItem);
        }
        if (facadeState == null) {
            facadeState = class_2246.field_10085.method_9564();
        }

        final class_1087 model = class_310.method_1551().method_1541().method_3351().method_3335(facadeState);

        final class_11515 layer = class_4696.method_23679(facadeState);
        emitter.pushTransform(quad -> {
            quad.renderLayer(layer);
            return true;
        });

        try {
            model.emitQuads(emitter, level, pos, facadeState, random, cullTest);
        } finally {
            emitter.popTransform();
        }
    }

    @Nullable
    private static class_2350 getSupportSide(final class_1920 level, final class_2338 pos, final class_2680 state) {
        class_2350 supportSide = null;
        for (final class_2350 direction : Constants.DIRECTIONS) {
            if (isNeighborInDirectionSolid(level, pos, direction)) {
                final class_2754<BusCableBlock.ConnectionType> property = BusCableBlock.FACING_TO_CONNECTION_MAP.get(direction);
                if (state.method_28498(property) && state.method_11654(property) == BusCableBlock.ConnectionType.INTERFACE) {
                    return null; // Plug is already supporting us, bail.
                }

                if (supportSide == null) { // Prefer vertical supports.
                    supportSide = direction;
                }
            }
        }

        return supportSide;
    }

    private static boolean isNeighborInDirectionSolid(final class_1920 level, final class_2338 pos, final class_2350 direction) {
        final class_2338 neighborPos = pos.method_10093(direction);
        return level.method_8320(neighborPos).method_26206(level, neighborPos, direction.method_10153());
    }

    private static boolean isStraightAlongAxis(final class_2680 state, final class_2350.class_2351 axis) {
        for (final class_2350 direction : Constants.DIRECTIONS) {
            final class_2754<BusCableBlock.ConnectionType> property = BusCableBlock.FACING_TO_CONNECTION_MAP.get(direction);
            if (axis.method_10176(direction)) {
                if (state.method_11654(property) != BusCableBlock.ConnectionType.CABLE) {
                    return false;
                }
            } else {
                if (state.method_11654(property) != BusCableBlock.ConnectionType.NONE) {
                    return false;
                }
            }
        }

        return true;
    }
}
