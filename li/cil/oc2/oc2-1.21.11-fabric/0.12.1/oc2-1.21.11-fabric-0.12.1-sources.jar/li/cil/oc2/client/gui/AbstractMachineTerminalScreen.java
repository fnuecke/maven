/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.Node;
import li.cil.oc2.client.gui.layout.Ui;
import li.cil.oc2.client.gui.layout.UiContainerScreen;
import li.cil.oc2.client.gui.layout.WidgetNode;
import li.cil.oc2.client.gui.layout.Window;
import li.cil.oc2.client.gui.node.TerminalWidget;
import li.cil.oc2.common.container.AbstractMachineTerminalContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_5244;

@Environment(EnvType.CLIENT)
public abstract class AbstractMachineTerminalScreen<T extends AbstractMachineTerminalContainer> extends UiContainerScreen<T> {
    protected final TerminalWidget terminalWidget;

    // --------------------------------------------------------------------- //

    protected AbstractMachineTerminalScreen(final T container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title, Sprites.THEME);
        this.terminalWidget = new TerminalWidget(container.getTerminal(),
            () -> container.getVirtualMachine().isRunning(),
            () -> container.getVirtualMachine().getError(),
            container::sendTerminalInputToServer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_37432() {
        super.method_37432();

        terminalWidget.tick();
    }

    @Override
    public boolean method_25402(final class_11909 event, final boolean isDoubleClick) {
        return terminalWidget.method_25402(event, isDoubleClick) ||
            super.method_25402(event, isDoubleClick);
    }

    @Override
    public boolean method_25406(final class_11909 event) {
        return terminalWidget.method_25406(event) ||
            super.method_25406(event);
    }

    @Override
    public boolean method_25401(final double mouseX, final double mouseY, final double deltaX, final double deltaY) {
        return terminalWidget.method_25401(mouseX, mouseY, deltaX, deltaY) ||
            super.method_25401(mouseX, mouseY, deltaX, deltaY);
    }

    @Override
    public boolean method_25400(final class_11905 event) {
        return terminalWidget.method_25400(event) ||
            super.method_25400(event);
    }

    @Override
    public boolean method_25404(final class_11908 event) {
        if (terminalWidget.method_25404(event)) {
            return true;
        }

        // Don't close with inventory binding since we usually want to use that as terminal input
        // even without input capture enabled.
        if (field_22787.field_1690.field_1822.method_1417(event)) {
            return true;
        }

        return super.method_25404(event);
    }

    // --------------------------------------------------------------------- //

    protected Node createContent() {
        return Ui.insetBlack(new WidgetNode(terminalWidget));
    }

    @Override
    protected Window createWindow() {
        return new Window(createContent(), MachineScreens.toolbar(field_2797,
            InputCapture.button(),
            MachineScreens.openInventoryButton(field_2797)));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        final class_342 focusIndicatorEditBox = new class_342(field_22793, 0, 0, 0, 0, class_5244.field_39003);
        focusIndicatorEditBox.method_25365(true);
        setFocusIndicatorEditBox(focusIndicatorEditBox);
    }

    // We use this text box to indicate to Forge that we want all input, and event handlers should not be allowed
    // to steal input from us (e.g. via custom key bindings). Since Forge is lazy and just uses getDeclaredFields
    // to get private fields, which completely skips fields in base classes, we require subclasses to hold the field...
    protected abstract void setFocusIndicatorEditBox(final class_342 editBox);
}
