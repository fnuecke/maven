/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.block;

import li.cil.oc2.api.bus.device.vm.VMDevice;
import li.cil.oc2.api.bus.device.vm.VMDeviceLoadResult;
import li.cil.oc2.api.bus.device.vm.context.VMContext;
import li.cil.oc2.api.capabilities.TerminalUserProvider;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.bus.device.util.OptionalAddress;
import li.cil.oc2.common.bus.device.util.OptionalInterrupt;
import li.cil.oc2.common.serialization.NBTSerialization;
import li.cil.oc2.common.util.TickUtils;
import li.cil.sedna.device.virtio.VirtIOKeyboardDevice;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import javax.annotation.Nullable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

public final class KeyboardDevice<T> extends IdentityProxy<T> implements VMDevice, TerminalUserProvider {
    private static final String DEVICE_TAG_NAME = "device";
    private static final String ADDRESS_TAG_NAME = "address";
    private static final String INTERRUPT_TAG_NAME = "interrupt";
    private static final int USER_EXPIRES_AFTER = TickUtils.toTicks(Duration.ofSeconds(2));
    public static final int USER_KEEPALIVE_EVERY = TickUtils.toTicks(Duration.ofSeconds(1));

    // --------------------------------------------------------------------- //

    @Nullable
    private VirtIOKeyboardDevice device;

    // --------------------------------------------------------------------- //

    private final Map<class_1657, Long> users = new WeakHashMap<>();
    private final OptionalAddress address = new OptionalAddress();
    private final OptionalInterrupt interrupt = new OptionalInterrupt();
    private class_2487 deviceTag;

    // --------------------------------------------------------------------- //

    public KeyboardDevice(final T identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    public void sendKeyEvent(final int keycode, final boolean isDown) {
        if (device != null) {
            device.sendKeyEvent(keycode, isDown);
        }
    }

    public void handleUsedBy(final class_1657 player) {
        users.put(player, player.method_73183().method_75260());
    }

    @Override
    public Iterable<class_1657> getTerminalUsers() {
        users.entrySet().removeIf(entry -> entry.getKey().method_73183().method_75260() - entry.getValue() > USER_EXPIRES_AFTER);

        return new ArrayList<>(users.keySet());
    }

    @Override
    public VMDeviceLoadResult mount(final VMContext context) {
        if (!allocateDevice(context)) {
            return VMDeviceLoadResult.fail();
        }

        assert device != null;
        if (!address.claim(context.getDeviceRangeAllocator(), device)) {
            return VMDeviceLoadResult.fail()
                .withErrorMessage(class_2561.method_43471(Constants.COMPUTER_ERROR_DEVICE_DOES_NOT_FIT));
        }

        if (interrupt.claim(context)) {
            device.getInterrupt().set(interrupt.getAsInt(), context.getInterruptController());
        } else {
            return VMDeviceLoadResult.fail();
        }

        context.getEventBus().register(this);

        if (deviceTag != null) {
            NBTSerialization.deserialize(deviceTag, device);
        }

        return VMDeviceLoadResult.success();
    }

    @Override
    public void unmount() {
        if (device != null) {
            deviceTag = NBTSerialization.serialize(device);
        }

        device = null;
        users.clear();
    }

    @Override
    public void dispose() {
        deviceTag = null;
        address.clear();
        interrupt.clear();
    }

    @Override
    public void serialize(final class_11372 output) {
        if (device != null) {
            deviceTag = NBTSerialization.serialize(device);
        }
        if (deviceTag != null) {
            output.method_71468(DEVICE_TAG_NAME, class_2487.field_25128, deviceTag);
        }
        if (address.isPresent()) {
            output.method_71466(ADDRESS_TAG_NAME, address.getAsLong());
        }
        if (interrupt.isPresent()) {
            output.method_71465(INTERRUPT_TAG_NAME, interrupt.getAsInt());
        }
    }

    @Override
    public void deserialize(final class_11368 input) {
        input.method_71426(DEVICE_TAG_NAME, class_2487.field_25128).ifPresent(tag -> deviceTag = tag);
        input.method_71440(ADDRESS_TAG_NAME).ifPresent(address::set);
        input.method_71439(INTERRUPT_TAG_NAME).ifPresent(interrupt::set);
    }

    // --------------------------------------------------------------------- //

    private boolean allocateDevice(final VMContext context) {
        if (!context.getMemoryAllocator().claimMemory(Constants.PAGE_SIZE)) {
            return false;
        }

        device = new VirtIOKeyboardDevice(context.getMemoryMap(), Constants.VIRTIO_INPUT_QUEUE_SIZE);

        return true;
    }
}
