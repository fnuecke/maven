/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityType;
import li.cil.oc2.common.inventory.ItemHandler;
import li.cil.oc2.common.transaction.Transaction;
import li.cil.oc2.common.transaction.TransactionContext;
import net.minecraft.class_1799;
import java.util.function.BiFunction;
import java.util.function.Function;

final class ContainerItemAccess<T> {
    private final ItemHandler inventory;
    private final int slot;
    private final CapabilityType<T> type;

    // --------------------------------------------------------------------- //

    ContainerItemAccess(final ItemHandler inventory, final int slot, final CapabilityType<T> type) {
        this.inventory = inventory;
        this.slot = slot;
        this.type = type;
    }

    // --------------------------------------------------------------------- //

    boolean isPresent() {
        return Capabilities.get(getSingleCopy(), 0, type) != null;
    }

    <R> R read(final Function<T, R> operation, final R fallback) {
        final T capability = Capabilities.get(getSingleCopy(), 0, type);
        return capability != null ? operation.apply(capability) : fallback;
    }

    <R> R modify(final BiFunction<T, TransactionContext, R> operation, final R fallback, final TransactionContext transaction) {
        final class_1799 stack = inventory.getStackInSlot(slot);
        final ItemStackHandler copy = getSingleCopy();
        final T capability = Capabilities.get(copy, 0, type);
        if (capability == null) {
            return fallback;
        }

        try (Transaction nested = transaction.openNested()) {
            final R result = operation.apply(capability, nested);
            final class_1799 modified = copy.getStackInSlot(0);
            if (!class_1799.method_7973(modified, stack.method_46651(1))) {
                if (stack.method_7947() == 1) {
                    // Replace modified instance in-place.
                    if (inventory.extractItem(slot, 1, nested).method_7960()
                        || !inventory.insertItem(slot, modified, nested).method_7960()) {
                        return fallback;
                    }
                } else {
                    // Insert modified instance.
                    if (!insertStartingAtSlot(modified, nested).method_7960()
                        || inventory.extractItem(slot, 1, nested).method_7960()) {
                        return fallback;
                    }
                }
            }

            nested.commit();
            return result;
        }
    }

    // --------------------------------------------------------------------- //

    private class_1799 insertStartingAtSlot(class_1799 stack, final TransactionContext transaction) {
        for (int i = 0; i < inventory.getSlots() && !stack.method_7960(); i++) {
            stack = inventory.insertItem((slot + i) % inventory.getSlots(), stack, transaction);
        }
        return stack;
    }

    private ItemStackHandler getSingleCopy() {
        final ItemStackHandler copy = new ItemStackHandler(1);
        copy.setStackInSlot(0, inventory.getStackInSlot(slot).method_46651(1));
        return copy;
    }
}
