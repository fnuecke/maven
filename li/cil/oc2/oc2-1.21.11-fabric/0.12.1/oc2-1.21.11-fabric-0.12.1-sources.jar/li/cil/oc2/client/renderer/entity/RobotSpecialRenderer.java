/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.entity;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.client.renderer.entity.model.RobotModel;
import net.minecraft.class_10508;
import net.minecraft.class_10515;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_811;
import org.joml.Vector3fc;

import java.util.function.Consumer;

public final class RobotSpecialRenderer implements class_10508 {
    private final RobotModel model;

    // --------------------------------------------------------------------- //

    public RobotSpecialRenderer(final RobotModel model) {
        this.model = model;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_65699(final class_811 displayContext, final class_4587 poseStack, final class_11659 collector,
                       final int packedLight, final int packedOverlay, final boolean hasFoil, final int outlineColor) {
        poseStack.method_22903();
        poseStack.method_22904(0.5, 0, 0.5);
        model.submit(poseStack, collector, packedLight, 0, 0, 0);
        poseStack.method_22909();
    }

    @Override
    public void method_72175(final Consumer<Vector3fc> output) {
        final class_4587 poseStack = new class_4587();
        poseStack.method_22904(0.5, 0, 0.5);
        model.getExtents(poseStack, output);
    }

    // --------------------------------------------------------------------- //

    public record Unbaked() implements class_10515.class_10516 {
        public static final MapCodec<Unbaked> MAP_CODEC = MapCodec.unit(new Unbaked());

        @Override
        public MapCodec<Unbaked> method_65696() {
            return MAP_CODEC;
        }

        @Override
        public class_10515<?> method_65698(final class_10515.class_11695 context) {
            return new RobotSpecialRenderer(new RobotModel(context.comp_3391().method_32072(RobotModel.ROBOT_MODEL_LAYER)));
        }
    }
}
