/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.capabilities.NetworkInterface;
import li.cil.oc2.client.renderer.NetworkCableRenderer;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.block.NetworkConnectorBlock;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.NetworkConnectorConnectionsMessage;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.ServerScheduler;
import li.cil.oc2.common.util.TickUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;

public final class NetworkConnectorBlockEntity extends ModBlockEntity implements TickableBlockEntity {
    public enum ConnectionResult {
        SUCCESS,
        FAILURE,
        FAILURE_FULL,
        FAILURE_TOO_FAR,
        FAILURE_OBSTRUCTED,
        ALREADY_CONNECTED
    }

    private static final String CONNECTIONS_TAG_NAME = "connections";
    private static final String IS_OWNER_TAG_NAME = "is_owner";
    private static final String POSITION_TAG_NAME = "position";

    private static final int RETRY_UNLOADED_CHUNK_INTERVAL = TickUtils.toTicks(Duration.ofSeconds(5));
    private static final int MAX_CONNECTION_COUNT = 2;
    private static final int MAX_CONNECTION_DISTANCE = 16;
    private static final int BYTES_PER_TICK = 64 * 1024 / TickUtils.toTicks(Duration.ofSeconds(1)); // bytes / sec -> bytes / tick
    private static final int MIN_ETHERNET_FRAME_SIZE = 42;
    private static final int TTL_COST = 1;

    // --------------------------------------------------------------------- //

    private final NetworkConnectorNetworkInterface networkInterface = new NetworkConnectorNetworkInterface();

    @Nullable
    private NetworkInterface adjacentInterface;
    @Nullable
    private Capabilities.InvalidationHandle adjacentInterfaceHandle;
    private boolean isAdjacentInterfaceDirty = true;

    private final HashSet<class_2338> connectorPositions = new HashSet<>();
    private final HashSet<class_2338> ownedCables = new HashSet<>();
    private final HashSet<class_2338> dirtyConnectors = new HashSet<>();
    private final HashMap<class_2338, NetworkConnectorBlockEntity> connectors = new HashMap<>();

    // --------------------------------------------------------------------- //

    public NetworkConnectorBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.NETWORK_CONNECTOR.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    public static ConnectionResult connect(final NetworkConnectorBlockEntity connectorA, final NetworkConnectorBlockEntity connectorB) {
        if (connectorA == connectorB || !connectorA.isValid() || !connectorB.isValid()) {
            return ConnectionResult.FAILURE;
        }

        final class_1937 level = connectorA.field_11863;
        if (level == null || level.method_8608()) {
            return ConnectionResult.FAILURE;
        }

        if (connectorB.field_11863 != level) {
            return ConnectionResult.FAILURE;
        }

        if (!connectorA.canConnectMore() || !connectorB.canConnectMore()) {
            return ConnectionResult.FAILURE_FULL;
        }

        final class_2338 posA = connectorA.method_11016();
        final class_2338 posB = connectorB.method_11016();

        if (!posA.method_19771(posB, MAX_CONNECTION_DISTANCE)) {
            return ConnectionResult.FAILURE_TOO_FAR;
        }

        if (isObstructed(level, posA, posB)) {
            return ConnectionResult.FAILURE_OBSTRUCTED;
        }

        if (connectorA.connectorPositions.add(posB)) {
            connectorA.dirtyConnectors.add(posB);
            connectorA.onConnectedPositionsChanged();
        }

        if (connectorB.connectorPositions.add(posA)) {
            connectorB.dirtyConnectors.add(posA);
            connectorB.onConnectedPositionsChanged();
        }

        final ConnectionResult result;
        if (connectorA.ownedCables.contains(posB) || connectorB.ownedCables.contains(posA)) {
            connectorA.ownedCables.add(posB);
            connectorB.ownedCables.remove(posA);
            result = ConnectionResult.ALREADY_CONNECTED;
        } else {
            connectorA.ownedCables.add(posB);
            result = ConnectionResult.SUCCESS;
        }

        connectorA.method_5431();
        connectorB.method_5431();

        return result;
    }

    public void disconnectFrom(final class_2338 pos) {
        dirtyConnectors.remove(pos);
        connectors.remove(pos);

        if (ownedCables.remove(pos)) {
            if (field_11863 != null) {
                final class_243 dropPosition = pos.method_19771(method_11016(), MAX_CONNECTION_DISTANCE)
                    ? class_243.method_24953(method_11016().method_10081(pos)).method_1021(0.5f)
                    : class_243.method_24953(method_11016());
                ItemStackUtils.spawnAsEntity(field_11863, dropPosition, new class_1799(Items.NETWORK_CABLE.get()));
            }
        }

        if (isValid()) {
            if (connectorPositions.remove(pos)) {
                onConnectedPositionsChanged();
            }

            method_5431();
        }
    }

    public boolean canConnectMore() {
        return connectorPositions.size() < MAX_CONNECTION_COUNT;
    }

    public Collection<class_2338> getConnectedPositions() {
        return connectorPositions;
    }

    @Environment(EnvType.CLIENT)
    public void setConnectedPositionsClient(final ArrayList<class_2338> positions) {
        connectorPositions.clear();
        connectorPositions.addAll(positions);
        NetworkCableRenderer.invalidateConnections();
    }

    public void scheduleAdjacentInterfaceCheck() {
        isAdjacentInterfaceDirty = true;
    }

    @Override
    public void serverTick() {
        if (field_11863 == null) {
            return;
        }

        if (isAdjacentInterfaceDirty) {
            isAdjacentInterfaceDirty = false;
            resolveLocalInterface();
            setHasAdjacentInterface(adjacentInterface != null);
        }

        if (!dirtyConnectors.isEmpty()) {
            final ArrayList<class_2338> list = new ArrayList<>(dirtyConnectors);
            dirtyConnectors.clear();
            for (final class_2338 connectedPosition : list) {
                resolveConnectedInterface(connectedPosition);
            }
        }

        final NetworkInterface source = adjacentInterface != null ? adjacentInterface : NullNetworkInterface.INSTANCE;

        int byteBudget = BYTES_PER_TICK;
        byte[] frame;
        while (byteBudget > 0 && (frame = source.readEthernetFrame()) != null) {
            byteBudget -= Math.max(frame.length, MIN_ETHERNET_FRAME_SIZE); // Avoid bogus packets messing with us.
            networkInterface.writeEthernetFrame(source, frame, Config.ethernetFrameTimeToLive);
        }
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);

        final class_2499 connections = new class_2499();
        for (final class_2338 position : connectorPositions) {
            final class_2487 connectionTag = new class_2487();
            connectionTag.method_67494(POSITION_TAG_NAME, class_2338.field_25064, position);
            connections.add(connectionTag);
        }
        tag.method_10566(CONNECTIONS_TAG_NAME, connections);

        return tag;
    }

    @Override
    public void method_57569(final class_11372 output) {
        output.method_71478(CONNECTIONS_TAG_NAME);
    }

    @Override
    protected void method_11007(final class_11372 output) {
        super.method_11007(output);

        final class_11372.class_11374 connections = output.method_71476(CONNECTIONS_TAG_NAME);
        for (final class_2338 position : connectorPositions) {
            final class_11372 connection = connections.method_71480();
            connection.method_71468(POSITION_TAG_NAME, class_2338.field_25064, position);
            if (ownedCables.contains(position)) {
                connection.method_71472(IS_OWNER_TAG_NAME, true);
            }
        }
    }

    @Override
    protected void method_11014(final class_11368 input) {
        super.method_11014(input);

        input.method_71438(CONNECTIONS_TAG_NAME).method_71447().limit(MAX_CONNECTION_COUNT).forEach(connection -> {
            final class_2338 position = connection.method_71426(POSITION_TAG_NAME, class_2338.field_25064).orElse(null);
            if (position == null) {
                return;
            }

            connectorPositions.add(position);
            dirtyConnectors.add(position);
            if (connection.method_71433(IS_OWNER_TAG_NAME, false)) {
                ownedCables.add(position);
            }
        });
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        if (direction == NetworkConnectorBlock.getFacing(method_11010()).method_10153()) {
            collector.offer(Capabilities.NETWORK_INTERFACE, networkInterface);
        }
    }

    @Override
    protected void loadClient() {
        super.loadClient();

        NetworkCableRenderer.addNetworkConnector(this);
    }

    @Override
    protected void unloadServer(final boolean isDestroyed) {
        super.unloadServer(isDestroyed);

        if (isDestroyed) {
            // When we're being removed we want to break the actual link to any connected
            // connectors. This will also cause cables to be dropped.
            final ArrayList<NetworkConnectorBlockEntity> list = new ArrayList<>(connectors.values());
            connectors.clear();
            for (final NetworkConnectorBlockEntity connector : list) {
                disconnectFrom(connector.method_11016());
                connector.disconnectFrom(method_11016());
            }
        } else {
            // When unloading, we just want to remove the reference to this block entity
            // from connected connectors; we don't want to actually break the link.
            final class_2338 pos = method_11016();
            for (final NetworkConnectorBlockEntity connector : connectors.values()) {
                connector.connectors.remove(pos);
                if (connector.connectorPositions.contains(pos)) {
                    connector.dirtyConnectors.add(pos);
                }
            }
        }
    }

    // --------------------------------------------------------------------- //

    private void resolveLocalInterface() {
        assert field_11863 instanceof class_3218;

        adjacentInterface = null;
        if (adjacentInterfaceHandle != null) {
            adjacentInterfaceHandle.drop();
            adjacentInterfaceHandle = null;
        }

        if (!isValid()) {
            return;
        }

        final class_2350 facing = NetworkConnectorBlock.getFacing(method_11010());
        final class_2338 sourcePos = method_11016().method_10093(facing.method_10153());

        if (!field_11863.method_8477(sourcePos)) {
            ServerScheduler.schedule(field_11863, this::scheduleAdjacentInterfaceCheck, RETRY_UNLOADED_CHUNK_INTERVAL);
            return;
        }

        adjacentInterface = Capabilities.get(field_11863, sourcePos, Capabilities.NETWORK_INTERFACE, facing);
        adjacentInterfaceHandle = Capabilities.listen((class_3218) field_11863, sourcePos, this::scheduleAdjacentInterfaceCheck);
    }

    private void resolveConnectedInterface(final class_2338 connectedPosition) {
        connectors.remove(connectedPosition);

        if (!isValid()) {
            return;
        }

        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        if (!connectedPosition.method_19771(method_11016(), MAX_CONNECTION_DISTANCE)) {
            disconnectFrom(connectedPosition);
            return;
        }

        final class_1923 destinationChunk = new class_1923(connectedPosition);
        if (!field_11863.method_8393(destinationChunk.field_9181, destinationChunk.field_9180)) {
            ServerScheduler.schedule(field_11863, () -> dirtyConnectors.add(connectedPosition), RETRY_UNLOADED_CHUNK_INTERVAL);
            return;
        }

        final class_2586 blockEntity = field_11863.method_8321(connectedPosition);
        if (!(blockEntity instanceof final NetworkConnectorBlockEntity networkConnector)
            || !networkConnector.connectorPositions.contains(method_11016())) {
            disconnectFrom(connectedPosition);
            return;
        }

        if (isObstructed(field_11863, method_11016(), connectedPosition)) {
            disconnectFrom(connectedPosition);
            networkConnector.disconnectFrom(method_11016());
            return;
        }

        connectors.put(connectedPosition, networkConnector);
    }

    private static boolean isObstructed(final class_1937 level, final class_2338 a, final class_2338 b) {
        final class_243 va = class_243.method_24953(a);
        final class_243 vb = class_243.method_24953(b);
        final class_243 ab = vb.method_1020(va).method_1029().method_1021(0.5);

        // Because of floating point inaccuracies the raytrace is not necessarily
        // symmetric. In particular when grazing corners perfectly, e.g. two connectors
        // attached to the same block at a 90-degree angle. So we check both ways.
        final class_3965 hitAB = level.method_17742(new class_3959(
            va.method_1019(ab),
            vb.method_1020(ab),
            class_3959.class_3960.field_17558,
            class_3959.class_242.field_1348,
            class_3726.method_16194()
        ));
        final class_3965 hitBA = level.method_17742(new class_3959(
            vb.method_1020(ab),
            va.method_1019(ab),
            class_3959.class_3960.field_17558,
            class_3959.class_242.field_1348,
            class_3726.method_16194()
        ));

        return hitAB.method_17783() != class_239.class_240.field_1333 ||
            hitBA.method_17783() != class_239.class_240.field_1333;
    }

    private void setHasAdjacentInterface(final boolean value) {
        final class_2680 state = method_11010();
        if (state.method_11654(NetworkConnectorBlock.CONNECTED) == value) {
            return;
        }

        field_11863.method_8652(method_11016(), state.method_11657(NetworkConnectorBlock.CONNECTED, value), class_2248.field_31028);
    }

    private void onConnectedPositionsChanged() {
        if (field_11863 != null && !field_11863.method_8608()) {
            final NetworkConnectorConnectionsMessage message = new NetworkConnectorConnectionsMessage(this);
            Network.sendToClientsTrackingBlockEntity(message, this);
        }
    }

    // --------------------------------------------------------------------- //

    private static final class NullNetworkInterface implements NetworkInterface {
        public static final NetworkInterface INSTANCE = new NullNetworkInterface();

        @Override
        @Nullable
        public byte[] readEthernetFrame() {
            return null;
        }

        @Override
        public void writeEthernetFrame(final NetworkInterface source, final byte[] frame, final int timeToLive) {
        }
    }

    private final class NetworkConnectorNetworkInterface implements NetworkInterface {
        @Override
        @Nullable
        public byte[] readEthernetFrame() {
            return null;
        }

        @Override
        public void writeEthernetFrame(final NetworkInterface source, final byte[] frame, final int timeToLive) {
            if (timeToLive <= 0) {
                return;
            }

            final NetworkInterface local = adjacentInterface;
            if (local != null && local != source) {
                local.writeEthernetFrame(this, frame, timeToLive - TTL_COST);
            }

            for (final NetworkConnectorBlockEntity dst : connectors.values()) {
                if (!dst.isValid() || dst.networkInterface == source) {
                    continue;
                }
                dst.networkInterface.writeEthernetFrame(this, frame, timeToLive - TTL_COST);
            }
        }
    }
}
