/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import li.cil.oc2.api.API;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_290;
import net.minecraft.class_2960;

public final class ModShaders {
    public static final int MAX_PROJECTORS = 3;

    public static final RenderPipeline TERMINAL_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/terminal"))
        .withVertexShader(class_2960.method_60655(API.MOD_ID, "core/terminal"))
        .withFragmentShader(class_2960.method_60655(API.MOD_ID, "core/terminal"))
        .withSampler("Sampler0")
        .withBlend(BlendFunction.TRANSLUCENT)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .build();

    public static final RenderPipeline PROJECTORS_PIPELINE = RenderPipeline.builder(class_10799.field_56838)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/projectors"))
        .withVertexShader("core/screenquad")
        .withFragmentShader(class_2960.method_60655(API.MOD_ID, "core/projectors"))
        .withUniform("ProjectorsConfig", class_10789.field_60031)
        .withSampler("MainCameraDepth")
        .withSampler("ProjectorColor0")
        .withSampler("ProjectorDepth0")
        .withSampler("ProjectorColor1")
        .withSampler("ProjectorDepth1")
        .withSampler("ProjectorColor2")
        .withSampler("ProjectorDepth2")
        .withBlend(BlendFunction.ADDITIVE)
        .withColorWrite(true, false)
        .build();

    public static final RenderPipeline TERMINAL_DOWNSAMPLE_PIPELINE = RenderPipeline.builder()
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/terminal_downsample"))
        .withVertexShader("core/screenquad")
        .withFragmentShader("core/blit_screen")
        .withSampler("InSampler")
        .withDepthWrite(false)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379)
        .build();

    public static final RenderPipeline GUI_TERMINAL_CURSOR_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/gui_terminal_cursor"))
        .withVertexShader(class_2960.method_60655(API.MOD_ID, "core/terminal"))
        .withFragmentShader(class_2960.method_60655(API.MOD_ID, "core/terminal"))
        .withSampler("Sampler0")
        .withBlend(BlendFunction.TRANSLUCENT)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .build();

    public static final RenderPipeline GUI_TERMINAL_PIPELINE = RenderPipeline.builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/gui_terminal"))
        .withVertexShader("core/position_tex_color")
        .withFragmentShader(class_2960.method_60655(API.MOD_ID, "core/gui_terminal"))
        .withSampler("Sampler0")
        .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .build();

    // --------------------------------------------------------------------- //

    private ModShaders() {
    }
}
