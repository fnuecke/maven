/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.bus.device;

import li.cil.oc2.api.bus.DeviceBus;
import li.cil.oc2.api.bus.DeviceBusController;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_2586;

/**
 * Base interface for objects that can be registered as devices on a {@link DeviceBus}.
 * <p>
 * Which types are handled/supported by a bus depends on context of the {@link DeviceBusController}
 * managing the bus.
 * <p>
 * May be provided as a capability on {@link class_2586}s and {@link class_1799}s.
 * <p>
 * Note that it is strongly encouraged for implementations to provide an overloaded
 * {@link Object#equals(Object)} and {@link Object#hashCode()} so that identical
 * devices can be detected.
 */
public interface Device {
    /**
     * Called to dispose this device.
     * <p>
     * Called when the connected virtual machine stops or the device is removed from a {@link DeviceBus}.
     * <p>
     * This is not a terminal state: a device that is still on the bus when its virtual machine starts
     * again will be mounted again, so implementations must leave themselves usable. Releasing resources
     * here is fine as long as they can be re-acquired on the next mount.
     */
    default void dispose() {
    }

    /**
     * Called to serialize this device into its container's persistent storage.
     *
     * @param output the output to write the state of this device to.
     */
    default void serialize(final class_11372 output) {
    }

    /**
     * Called to deserialize this device from its container's persistent storage.
     * <p>
     * The passed input contains what was last written by {@link #serialize(class_11372)}.
     *
     * @param input the input to read the state of this device from.
     */
    default void deserialize(final class_11368 input) {
    }
}
