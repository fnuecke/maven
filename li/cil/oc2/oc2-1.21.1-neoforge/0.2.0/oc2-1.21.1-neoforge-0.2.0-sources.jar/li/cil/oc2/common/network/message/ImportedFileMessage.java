/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.bus.device.rpc.item.FileImportExportCardItemDevice;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;


public final class ImportedFileMessage extends AbstractMessage {
    private static final int MAX_NAME_LENGTH = 256;

    // --------------------------------------------------------------------- //

    private int id;
    private String name;
    private byte[] data;

    // --------------------------------------------------------------------- //

    public ImportedFileMessage(final int id, final String name, final byte[] data) {
        this.id = id;
        this.name = name;
        this.data = data;
    }

    public ImportedFileMessage(final RegistryFriendlyByteBuf buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final RegistryFriendlyByteBuf buffer) {
        id = buffer.readVarInt();
        name = buffer.readUtf(MAX_NAME_LENGTH);
        data = buffer.readByteArray(FileImportExportCardItemDevice.MAX_TRANSFERRED_FILE_SIZE);
    }

    @Override
    public void toBytes(final RegistryFriendlyByteBuf buffer) {
        buffer.writeVarInt(id);
        buffer.writeUtf(name, MAX_NAME_LENGTH);
        buffer.writeByteArray(data);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        if (context.getPlayer() instanceof final ServerPlayer sender) {
            FileImportExportCardItemDevice.setImportedFile(sender, id, name, data);
        }
    }
}
