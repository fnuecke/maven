/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.item;

import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.io.IODevice;
import li.cil.oc2.api.bus.device.io.IOMethod;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.rpc.RPCBusContext;
import li.cil.oc2.api.bus.device.rpc.RPCDevice;
import li.cil.oc2.api.bus.device.rpc.RPCMethodGroup;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import net.minecraft.world.item.ItemStack;

import java.util.List;

public abstract class AbstractItemRPCDevice extends IdentityProxy<ItemStack> implements RPCDevice, IODevice, ItemDevice {
    private final ObjectDevice device;

    // --------------------------------------------------------------------- //

    protected AbstractItemRPCDevice(final ItemStack identity) {
        super(identity);
        this.device = new ObjectDevice(this);
    }

    protected AbstractItemRPCDevice(final ItemStack identity, final Object target) {
        super(identity);
        this.device = new ObjectDevice(target);
    }

    // --------------------------------------------------------------------- //

    @Override
    public List<String> getTypeNames() {
        return device.getTypeNames();
    }

    @Override
    public List<RPCMethodGroup> getMethodGroups() {
        return device.getMethodGroups();
    }

    @Override
    public void mount(final RPCBusContext context) {
        device.mount(context);
    }

    @Override
    public void unmount(final RPCBusContext context) {
        device.unmount(context);
    }

    @Override
    public void dispose() {
        device.dispose();
    }

    // --------------------------------------------------------------------- //

    @Override
    public String getIOName() {
        return device.getIOName();
    }

    @Override
    public List<IOMethod> getIOMethods() {
        return device.getIOMethods();
    }
}
