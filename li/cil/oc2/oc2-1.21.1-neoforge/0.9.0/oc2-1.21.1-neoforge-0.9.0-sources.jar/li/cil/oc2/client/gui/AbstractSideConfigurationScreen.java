/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import li.cil.oc2.client.gui.widget.Texture;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.common.item.Items;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;

import static li.cil.oc2.common.util.TranslationUtils.key;
import static li.cil.oc2.common.util.TranslationUtils.text;

public abstract class AbstractSideConfigurationScreen extends Screen {
    private static final String SIDE_STATE_TEXT = key("gui.{mod}.sided_device.side_state");
    private static final Component CONNECTIVITY_ENABLED_TEXT = text("gui.{mod}.sided_device.connectivity.enabled");
    private static final Component CONNECTIVITY_DISABLED_TEXT = text("gui.{mod}.sided_device.connectivity.disabled");
    private static final Component HELP_TEXT = text("gui.{mod}.sided_device.help");
    private static final Component HELP_LABEL = Component.literal("?");

    public static final int UI_WIDTH = Sprites.SIDED_DEVICE_SCREEN.width;
    public static final int UI_HEIGHT = Sprites.SIDED_DEVICE_SCREEN.height;
    public static final int BLOCK_LEFT = UI_WIDTH / 2;
    public static final int BLOCK_TOP = 61;
    public static final int BLOCK_AREA_RIGHT = 139;
    public static final int BLOCK_AREA_TOP = 10;
    public static final int HELP_MARGIN = 2;
    public static final int HELP_SIZE = 9;
    public static final int HELP_COLOR = 0x555555;
    public static final int MAX_BLOCK_PITCH = 30;

    // --------------------------------------------------------------------- //

    protected final Player player;
    protected final InteractionHand hand;

    private final ComputerBlockItemRenderer computerBlockItemRenderer = new ComputerBlockItemRenderer();
    private final Item item;

    private Vector3f blockRotation = new Vector3f(-30, 45, 0);
    protected int left, top;
    @Nullable
    private Direction focusedSide;
    private boolean isDraggingBlock, hasDraggedBlock;
    private double dragStartX, dragStartY;

    // --------------------------------------------------------------------- //

    protected AbstractSideConfigurationScreen(final Player player, final InteractionHand hand, final Item item) {
        super(item.getDescription());
        this.player = player;
        this.hand = hand;
        this.item = item;
    }

    // --------------------------------------------------------------------- //

    protected abstract boolean getConfiguration(@Nullable final Direction side);

    protected abstract void sendConfiguration(final Direction side, final boolean value);

    // --------------------------------------------------------------------- //

    @Override
    protected void init() {
        super.init();

        left = (width - UI_WIDTH) / 2;
        top = (height - UI_HEIGHT) / 2;
    }

    @Override
    public void tick() {
        super.tick();

        final ItemStack heldItem = player.getItemInHand(hand);
        if (!heldItem.is(item)) {
            onClose();
        }
    }

    @Override
    public boolean mouseClicked(final double mouseX, final double mouseY, final int button) {
        final boolean result = super.mouseClicked(mouseX, mouseY, button);

        if (!result && isMouseInBlockArea(mouseX, mouseY) && button == 0) {
            isDraggingBlock = true;
            hasDraggedBlock = false;
            dragStartX = mouseX;
            dragStartY = mouseY;
        }

        return result;
    }

    @Override
    public boolean mouseReleased(final double mouseX, final double mouseY, final int button) {
        if (isDraggingBlock && button == 0) {
            isDraggingBlock = false;
            if (!hasDraggedBlock && focusedSide != null) {
                sendConfiguration(focusedSide, !getConfiguration(focusedSide));
                Minecraft.getInstance().getSoundManager()
                    .play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1));
            }
        }

        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(final double mouseX, final double mouseY, final int activeButton, final double deltaX, final double deltaY) {
        if (!isDraggingBlock) {
            return super.mouseDragged(mouseX, mouseY, activeButton, deltaX, deltaY);
        }

        if (activeButton == 0) {
            if (!hasDraggedBlock) {
                final double dx = mouseX - dragStartX;
                final double dy = mouseY - dragStartY;
                final double delta = Math.sqrt(dx * dx + dy * dy);
                hasDraggedBlock = delta > 3;
            }
            if (hasDraggedBlock) {
                blockRotation = new Vector3f(
                    Mth.clamp(blockRotation.x() - (float) deltaY, -MAX_BLOCK_PITCH, MAX_BLOCK_PITCH),
                    Mth.wrapDegrees(blockRotation.y() + (float) deltaX),
                    blockRotation.z()
                );
            }
        }

        return true;
    }

    @Override
    public void renderBackground(final GuiGraphics graphics, final int mouseX, final int mouseY, final float partialTicks) {
        renderTransparentBackground(graphics);
        Sprites.SIDED_DEVICE_SCREEN.draw(graphics, left, top);
    }

    @Override
    public void render(final GuiGraphics graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.render(graphics, mouseX, mouseY, partialTicks);

        final int blockX = left + BLOCK_LEFT;
        final int blockY = top + BLOCK_TOP;
        focusedSide = computerBlockItemRenderer.getFocusedSide(blockX - mouseX, blockY - mouseY, blockRotation);
        computerBlockItemRenderer.render(blockX, blockY, blockRotation);

        if (focusedSide != null) {
            final Component enabledComponent = getConfiguration(focusedSide) ? CONNECTIVITY_ENABLED_TEXT : CONNECTIVITY_DISABLED_TEXT;
            final MutableComponent tooltip = Component.translatable(SIDE_STATE_TEXT, enabledComponent);
            graphics.renderTooltip(font, tooltip, mouseX, mouseY);
        }

        graphics.drawString(font, HELP_LABEL, left + helpLeft(), top + BLOCK_AREA_TOP + HELP_MARGIN, HELP_COLOR, false);
        if (isMouseOverHelp(mouseX, mouseY)) {
            graphics.renderTooltip(font, font.split(HELP_TEXT, 160), mouseX, mouseY);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // --------------------------------------------------------------------- //

    private int helpLeft() {
        return BLOCK_AREA_RIGHT - HELP_MARGIN - font.width(HELP_LABEL);
    }

    private boolean isMouseOverHelp(final double mouseX, final double mouseY) {
        return mouseX >= left + helpLeft() && mouseX <= left + helpLeft() + font.width(HELP_LABEL) &&
            mouseY >= top + BLOCK_AREA_TOP + HELP_MARGIN && mouseY <= top + BLOCK_AREA_TOP + HELP_MARGIN + HELP_SIZE;
    }

    private boolean isMouseInBlockArea(final double mouseX, final double mouseY) {
        return mouseX >= left + 37 && mouseX <= left + 37 + 102 &&
            mouseY >= top + 10 && mouseY <= top + 10 + 102;
    }

    // --------------------------------------------------------------------- //

    private final class ComputerBlockItemRenderer {
        public static final int BLOCK_RENDER_SIZE = 48;

        private final ItemStack computerItemStack = new ItemStack(Items.COMPUTER.get());
        private final ItemRenderer itemRenderer = Minecraft.getInstance().getItemRenderer();
        private final BakedModel model = itemRenderer.getModel(computerItemStack, null, null, 0);

        @Nullable
        private Direction getFocusedSide(final float mouseX, final float mouseY, final Vector3f rotation) {
            // Rotate ray inversely around block to represent visual block rotation.
            final Quaternionf quaternion = fromXYZDegrees(toRenderRotation(rotation));
            quaternion.conjugate();

            // Move ray in screen space to mouse position.
            final float relMouseX = -mouseX / BLOCK_RENDER_SIZE;
            final float relMouseY = -mouseY / BLOCK_RENDER_SIZE;

            final Vector3f source = new Vector3f();
            source.add(relMouseX, relMouseY, 1);
            source.rotate(quaternion);

            final Vector3f target = new Vector3f();
            target.add(relMouseX, relMouseY, -1);
            target.rotate(quaternion);

            // Intersect rotated ray with bounding box representing block.
            final AABB aabb = new AABB(-0.5, -0.5, -0.5, 0.5, 0.5, 0.5);
            return aabb.clip(new Vec3(source), new Vec3(target))
                .map(hit -> Direction.getNearest(-hit.x, -hit.y(), -hit.z()))
                .filter(side -> side != Direction.SOUTH)
                .orElse(null);
        }

        public void render(final int x, final int y, final Vector3f rotation) {
            RenderSystem.setShaderTexture(0, InventoryMenu.BLOCK_ATLAS);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderColor(1, 1, 1, 1);

            final Vector3f renderRotation = toRenderRotation(rotation);

            final Matrix4fStack stack = RenderSystem.getModelViewStack();
            stack.pushMatrix();
            stack.translate(x, y, BLOCK_RENDER_SIZE);
            stack.rotate(fromXYZDegrees(renderRotation));
            stack.scale(BLOCK_RENDER_SIZE, -BLOCK_RENDER_SIZE, BLOCK_RENDER_SIZE);
            RenderSystem.applyModelViewMatrix();

            final MultiBufferSource.BufferSource bufferSource = Minecraft.getInstance().renderBuffers().bufferSource();
            renderBlock(bufferSource);
            renderOverlays(new PoseStack(), bufferSource);
            bufferSource.endBatch();

            stack.popMatrix();
            RenderSystem.applyModelViewMatrix();
        }

        private void renderBlock(final MultiBufferSource.BufferSource bufferSource) {
            itemRenderer.render(computerItemStack, ItemDisplayContext.NONE, false, new PoseStack(), bufferSource, 0xF000F0, OverlayTexture.NO_OVERLAY, model);
        }

        private void renderOverlays(final PoseStack poseStack, final MultiBufferSource.BufferSource bufferSource) {
            for (final Direction side : Direction.values()) {
                // South face of computers is the front face (screen) and there's no connectivity allowed there.
                if (side == Direction.SOUTH) {
                    continue;
                }

                poseStack.pushPose();
                poseStack.setIdentity();

                poseStack.translate(-side.getStepX() * 0.51, side.getStepY() * 0.51, -side.getStepZ() * 0.51);

                final Vector3f sideRotation = switch (side) {
                    case DOWN -> new Vector3f(-90, 0, 0);
                    case UP -> new Vector3f(90, 0, 0);
                    case NORTH -> new Vector3f(0, 180, 0);
                    case WEST -> new Vector3f(0, -90, 0);
                    case EAST -> new Vector3f(0, 90, 0);
                    default -> throw new IllegalStateException("Unexpected value: " + side);
                };
                poseStack.mulPose(fromXYZDegrees(sideRotation));

                poseStack.translate(-0.5, -0.5, 0);

                if (getConfiguration(side)) {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_ENABLED_TEXTURE);
                } else {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_DISABLED_TEXTURE);
                }

                if (side == focusedSide) {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_FOCUSED_TEXTURE);
                }

                poseStack.popPose();
            }
        }

        private void renderOverlay(final PoseStack poseStack, final MultiBufferSource.BufferSource bufferSource, final Texture texture) {
            final VertexConsumer buffer = bufferSource.getBuffer(ModRenderType.getOverlay(texture.location));

            buffer.addVertex(poseStack.last().pose(), 0, 0, 0).setUv(0, 0);
            buffer.addVertex(poseStack.last().pose(), 0, 1, 0).setUv(0, 1);
            buffer.addVertex(poseStack.last().pose(), 1, 1, 0).setUv(1, 1);
            buffer.addVertex(poseStack.last().pose(), 1, 0, 0).setUv(1, 0);
        }

        private static Vector3f toRenderRotation(final Vector3f rotation) {
            return new Vector3f(rotation).add(0, 180, 0);
        }

        private static Quaternionf fromXYZDegrees(final Vector3f degrees) {
            return new Quaternionf().rotationXYZ(
                (float) Math.toRadians(degrees.x()),
                (float) Math.toRadians(degrees.y()),
                (float) Math.toRadians(degrees.z()));
        }
    }
}
