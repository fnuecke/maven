/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.storage;

import net.minecraft.world.item.ItemStack;

public interface RemovableMediaContainer {
    ItemStack getMediaItemStack();

    void handleMediaChanged();

    default void handleDataAccess() {
    }
}
