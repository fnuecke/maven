/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.item;

import li.cil.oc2.common.bus.device.storage.AbstractBlockStorageItemDevice;
import li.cil.oc2.common.item.AbstractStorageItem;
import li.cil.oc2.common.util.BlockLocation;
import li.cil.oc2.common.util.ChunkUtils;
import li.cil.oc2.common.util.SoundEvents;
import li.cil.oc2.common.util.ThrottledSoundEmitter;
import li.cil.sedna.device.block.ByteBufferBlockDevice;
import net.minecraft.class_1799;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

public class HardDriveDevice extends AbstractBlockStorageItemDevice<ByteBufferBlockDevice, class_1799> {
    private final Supplier<Optional<BlockLocation>> location;
    private final ThrottledSoundEmitter soundEmitter;

    // --------------------------------------------------------------------- //

    public HardDriveDevice(final class_1799 identity, final boolean readonly, final Supplier<Optional<BlockLocation>> location) {
        super(identity, readonly);
        this.location = location;
        this.soundEmitter = new ThrottledSoundEmitter(location, SoundEvents.HDD_ACCESS.get())
            .withMinInterval(Duration.ofSeconds(1));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected int getMappedByteCount() {
        return ((AbstractStorageItem) identity.method_7909()).getCapacity(identity);
    }

    @Override
    protected CompletableFuture<ByteBufferBlockDevice> createBlockDevice() throws IOException {
        // Make sure we can access the data now, so base can handle missing/in use errors.
        final FileChannel channel = openBlob();
        final int size = getMappedByteCount();

        return CompletableFuture.supplyAsync(() -> {
            try {
                return ByteBufferBlockDevice.createFromFileChannel(channel, size, readonly);
            } catch (final IOException e) {
                throw new RuntimeException(e);
            }
        }, WORKERS);
    }

    @Override
    protected void handleDataAccess() {
        soundEmitter.play();
    }

    @Override
    protected class_1799 getStorageItem() {
        return identity;
    }

    @Override
    protected void handleStorageChanged() {
        location.get().ifPresent(blockLocation -> blockLocation.tryGetLevel().ifPresent(level ->
            ChunkUtils.setLazyUnsaved(level, blockLocation.blockPos())));
    }
}
