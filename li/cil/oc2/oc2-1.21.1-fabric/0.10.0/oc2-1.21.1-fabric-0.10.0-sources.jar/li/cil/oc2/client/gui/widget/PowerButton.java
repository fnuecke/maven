/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.widget;

import li.cil.oc2.client.gui.Sprites;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.container.AbstractMachineContainer;
import li.cil.oc2.common.vm.PowerAction;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import java.util.List;

import static li.cil.oc2.common.util.TextFormatUtils.withFormat;

public final class PowerButton extends ToggleImageButton {
    private static final class_2561 POWER_ON = class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_ON);
    private static final class_2561 SHUTDOWN = class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_SHUTDOWN);
    private static final class_2561 REBOOT = class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_REBOOT);
    private static final class_2561 POWER_OFF = class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_POWER_OFF);

    // --------------------------------------------------------------------- //

    private final AbstractMachineContainer menu;

    // --------------------------------------------------------------------- //

    public PowerButton(final int x, final int y, final AbstractMachineContainer menu) {
        super(x, y, 12, 12,
            Sprites.POWER_BUTTON_BASE,
            Sprites.POWER_BUTTON_PRESSED,
            Sprites.POWER_BUTTON_ACTIVE);
        this.menu = menu;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25306() {
        super.method_25306();
        menu.sendPowerActionToServer(getAction());
    }

    @Override
    public boolean isToggled() {
        return menu.getVirtualMachine().isRunning();
    }

    // --------------------------------------------------------------------- //

    @Override
    protected List<class_2561> getTooltipLines() {
        final PowerAction action = getAction();
        if (action == PowerAction.START) {
            return List.of(POWER_ON);
        }

        return List.of(
            highlightIf(SHUTDOWN, action == PowerAction.SHUTDOWN),
            highlightIf(REBOOT, action == PowerAction.REBOOT),
            highlightIf(POWER_OFF, action == PowerAction.POWER_OFF));
    }

    // --------------------------------------------------------------------- //

    private PowerAction getAction() {
        if (!isToggled()) {
            return PowerAction.START;
        }
        if (class_437.method_25441()) {
            return PowerAction.POWER_OFF;
        }
        if (class_437.method_25442()) {
            return PowerAction.REBOOT;
        }
        return PowerAction.SHUTDOWN;
    }

    private static class_2561 highlightIf(final class_2561 text, final boolean value) {
        return withFormat(text, value ? class_124.field_1068 : class_124.field_1080);
    }
}
