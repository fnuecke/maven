/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.block;

import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.oc2.api.bus.device.vm.ArchitectureType;
import li.cil.oc2.api.bus.device.vm.context.VMContext;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.bus.device.provider.item.FloppyItemDeviceProvider;
import li.cil.oc2.common.bus.device.storage.AbstractRemovableMediaDevice;
import li.cil.oc2.common.bus.device.storage.FloppyControllerStorage;
import li.cil.oc2.common.bus.device.storage.FloppyMedia;
import li.cil.oc2.common.bus.device.storage.MappedStorage;
import li.cil.oc2.common.bus.device.storage.RemovableMediaContainer;
import li.cil.oc2.common.item.FloppyItem;
import net.minecraft.class_1799;
import javax.annotation.Nullable;
import java.util.Objects;

public final class DiskDriveDevice extends AbstractRemovableMediaDevice {
    private final ArchitectureType architectureType;

    // --------------------------------------------------------------------- //

    public DiskDriveDevice(final RemovableMediaContainer container, final ArchitectureType architectureType) {
        super(container);
        this.architectureType = architectureType;
    }

    // --------------------------------------------------------------------- //

    public ArchitectureType getArchitectureType() {
        return architectureType;
    }

    @Override
    protected MappedStorage createStorage(final VMContext context) {
        return switch (architectureType) {
            case RISCV -> super.createStorage(context);
            case Z80 -> new FloppyControllerStorage();
        };
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean equals(@Nullable final Object o) {
        return super.equals(o) && architectureType == ((DiskDriveDevice) o).architectureType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), architectureType);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected int getMediumCapacity(final class_1799 stack) {
        if (!(stack.method_7909() instanceof final FloppyItem floppy)) {
            return Math.min(Config.floppySize, Config.maxBlobCapacity);
        }

        final BlockDeviceData data = floppy.getData(stack);
        if (data != null) {
            return (int) Math.max(data.getCapacity(), 0);
        }

        return Math.min(floppy.getCapacity(stack), Config.maxBlobCapacity);
    }

    @Override
    protected boolean isSupportedMedium(final class_1799 stack) {
        return stack.method_7909() instanceof FloppyItem;
    }

    @Override
    public String getDeviceDataKey() {
        return FloppyItemDeviceProvider.DEVICE_DATA_KEY;
    }

    @Override
    protected MediumInitializer createMediumInitializer(final class_1799 stack) {
        final BlockDeviceData data = ((FloppyItem) stack.method_7909()).getData(stack);
        if (data == null) {
            return FloppyMedia::format;
        }

        return medium -> FloppyMedia.image(medium, data.getBlockDevice());
    }
}
