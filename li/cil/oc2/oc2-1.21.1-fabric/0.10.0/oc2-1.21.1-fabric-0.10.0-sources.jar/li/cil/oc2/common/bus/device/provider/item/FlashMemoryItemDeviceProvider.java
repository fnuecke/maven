/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.item;

import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.common.bus.device.item.FlashStorageDevice;
import li.cil.oc2.common.bus.device.item.FlashStorageDeviceWithInitialData;
import li.cil.oc2.common.bus.device.provider.util.AbstractItemDeviceProvider;
import li.cil.oc2.common.item.FlashMemoryItem;
import net.minecraft.class_1799;
import java.util.Optional;

public final class FlashMemoryItemDeviceProvider extends AbstractItemDeviceProvider {
    public static final String DEVICE_DATA_KEY = API.MOD_ID + ":flash_memory";

    // --------------------------------------------------------------------- //

    public FlashMemoryItemDeviceProvider() {
        super(FlashMemoryItem.class);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Optional<ItemDevice> getItemDevice(final ItemDeviceQuery query) {
        final class_1799 stack = query.getItemStack();
        final FlashMemoryItem item = (FlashMemoryItem) stack.method_7909();

        final int capacity = Math.max(item.getCapacity(stack), 0);
        final BlockDeviceData data = item.getData(stack);
        return Optional.of(data != null
            ? new FlashStorageDeviceWithInitialData(stack, capacity, data)
            : new FlashStorageDevice(stack, capacity));
    }
}
