/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import net.minecraft.class_5558;
import javax.annotation.Nullable;

public final class CreativeEnergyBlock extends class_2248 implements class_2343 {
    public CreativeEnergyBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(-1, 3600000)
            .method_42327());
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.CREATIVE_ENERGY.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createServerTicker(level, type, BlockEntities.CREATIVE_ENERGY.get());
    }
}
