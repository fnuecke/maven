/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.bus.device.provider.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
