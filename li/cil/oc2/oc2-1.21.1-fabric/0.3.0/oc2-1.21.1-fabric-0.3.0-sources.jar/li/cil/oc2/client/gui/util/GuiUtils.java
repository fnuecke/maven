/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.util;

import li.cil.oc2.api.bus.device.DeviceType;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.client.gui.widget.Sprite;
import li.cil.oc2.common.container.DeviceTypeSlotItemHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import javax.annotation.Nullable;
import java.util.*;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class GuiUtils {
    @Nullable
    private static Map<DeviceType, class_2561> warningByDeviceType;

    private static Map<DeviceType, class_2561> getWarningByDeviceType() {
        // Lazy init to make sure init is done and the type keys are set.
        if (warningByDeviceType == null) {
            final HashMap<DeviceType, class_2561> map = new HashMap<>();

            map.put(DeviceTypes.FLASH_MEMORY.get(), text("tooltip.{mod}.flash_memory_missing"));
            map.put(DeviceTypes.MEMORY.get(), text("tooltip.{mod}.memory_missing"));
            map.put(DeviceTypes.HARD_DRIVE.get(), text("tooltip.{mod}.hard_drive_missing"));

            warningByDeviceType = map;
        }

        return warningByDeviceType;
    }

    private static final int SLOT_SIZE = 18;
    private static final int DEVICE_INFO_ICON_SIZE = 28;
    private static final int RELATIVE_ICON_POSITION = (SLOT_SIZE - DEVICE_INFO_ICON_SIZE) / 2;

    // --------------------------------------------------------------------- //

    public static <TContainer extends class_1703> void renderMissingDeviceInfoIcon(final class_332 graphics, final class_465<TContainer> screen, final DeviceType type, final Sprite icon) {
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0, 0, 100);
        findFirstSlotOfTypeIfAllSlotsOfTypeEmpty(screen.method_17577(), type).ifPresent(slot -> icon.draw(graphics,
            screen.field_2776 + slot.field_7873 - 1 + RELATIVE_ICON_POSITION,
            screen.field_2800 + slot.field_7872 - 1 + RELATIVE_ICON_POSITION));
        graphics.method_51448().method_22909();
    }

    public static <TContainer extends class_1703> void renderMissingDeviceInfoTooltip(final class_332 graphics, final class_465<TContainer> screen, final int mouseX, final int mouseY, final DeviceType type) {
        renderMissingDeviceInfoTooltip(graphics, screen, mouseX, mouseY, type, Objects.requireNonNull(getWarningByDeviceType().get(type)));
    }

    public static <TContainer extends class_1703> void renderMissingDeviceInfoTooltip(final class_332 graphics, final class_465<TContainer> screen, final int mouseX, final int mouseY, final DeviceType type, final class_2561 tooltip) {
        final class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null) {
            return;
        }

        final boolean isCursorHoldingStack = !minecraft.field_1724.field_7498.method_34255().method_7960();
        if (isCursorHoldingStack) {
            return;
        }

        final class_1735 hoveredSlot = screen.field_2787;
        if (hoveredSlot != null && hoveredSlot.method_7681()) {
            return;
        }

        findFirstSlotOfTypeIfAllSlotsOfTypeEmpty(screen.method_17577(), type).ifPresent(slot -> {
            if (slot == hoveredSlot) {
                TooltipRenderer.drawTooltip(graphics, Collections.singletonList(tooltip), mouseX, mouseY);
            }
        });
    }

    // --------------------------------------------------------------------- //

    private static Optional<DeviceTypeSlotItemHandler> findFirstSlotOfTypeIfAllSlotsOfTypeEmpty(final class_1703 container, final DeviceType type) {
        DeviceTypeSlotItemHandler firstSlot = null;
        for (final class_1735 slot : container.field_7761) {
            if (slot instanceof final DeviceTypeSlotItemHandler typedSlot) {
                final DeviceType slotType = typedSlot.getDeviceType();
                if (slotType == type) {
                    if (slot.method_7681()) {
                        return Optional.empty();
                    } else if (firstSlot == null) {
                        firstSlot = typedSlot;
                    }
                }
            }
        }
        return Optional.ofNullable(firstSlot);
    }
}
