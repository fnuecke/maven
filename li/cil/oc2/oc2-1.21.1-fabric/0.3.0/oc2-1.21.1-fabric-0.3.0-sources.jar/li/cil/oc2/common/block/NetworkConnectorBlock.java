/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.NetworkConnectorBlockEntity;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2341;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2738;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5431;
import net.minecraft.class_5558;
import net.minecraft.world.level.block.*;
import javax.annotation.Nullable;
import java.util.Objects;

public final class NetworkConnectorBlock extends class_2341 implements class_2343 {
    public static final MapCodec<NetworkConnectorBlock> field_46280 = MapCodec.unit(NetworkConnectorBlock::new);

    @Override
    protected MapCodec<? extends NetworkConnectorBlock> method_53969() {
        return field_46280;
    }

    private static final class_265 NEG_Z_SHAPE = class_2248.method_9541(5, 5, 7, 11, 11, 16);
    private static final class_265 POS_Z_SHAPE = class_2248.method_9541(5, 5, 0, 11, 11, 9);
    private static final class_265 NEG_X_SHAPE = class_2248.method_9541(7, 5, 5, 16, 11, 11);
    private static final class_265 POS_X_SHAPE = class_2248.method_9541(0, 5, 5, 9, 11, 11);
    private static final class_265 NEG_Y_SHAPE = class_2248.method_9541(5, 0, 5, 11, 9, 11);
    private static final class_265 POS_Y_SHAPE = class_2248.method_9541(5, 7, 5, 11, 16, 11);

    // --------------------------------------------------------------------- //

    public NetworkConnectorBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664()
            .method_11657(field_11177, class_2350.field_11043)
            .method_11657(field_11007, class_2738.field_12471));
    }

    // --------------------------------------------------------------------- //

    public static class_2350 getFacing(final class_2680 state) {
        return class_2341.method_10119(state);
    }

    @Override
    protected boolean method_9558(final class_2680 state, final class_4538 level, final class_2338 pos) {
        final class_2350 direction = getFacing(state).method_10153();
        final class_2338 neighborPos = pos.method_10093(direction);
        return level.method_8320(neighborPos)
            .method_30368(level, neighborPos, direction.method_10153(), class_5431.field_25823);
    }

    @Override
    public void method_9612(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2248 changedBlock, final class_2338 changedBlockPos, final boolean isMoving) {
        if (Objects.equals(changedBlockPos, pos.method_10093(getFacing(state).method_10153()))) {
            final class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof final NetworkConnectorBlockEntity networkConnector) {
                networkConnector.setNeighborChanged();
            }
        }
    }

    @Override
    public class_265 method_9530(final class_2680 state, final class_1922 level, final class_2338 pos, final class_3726 context) {
        return switch (state.method_11654(field_11007)) {
            case field_12471 -> switch (state.method_11654(field_11177)) {
                case field_11034 -> POS_X_SHAPE;
                case field_11039 -> NEG_X_SHAPE;
                case field_11035 -> POS_Z_SHAPE;
                default /* NORTH */ -> NEG_Z_SHAPE;
            };
            case field_12473 -> POS_Y_SHAPE;
            default /* FLOOR */ -> NEG_Y_SHAPE;
        };
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.NETWORK_CONNECTOR.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createServerTicker(level, type, BlockEntities.NETWORK_CONNECTOR.get());
    }

    // --------------------------------------------------------------------- //

    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11007, field_11177);
    }
}
