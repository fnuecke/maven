/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.api.inventory.ItemHandler;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class SlotItemHandler extends class_1735 {
    private static final class_1263 EMPTY_CONTAINER = new class_1277(0);

    private final ItemHandler itemHandler;
    private final int field_7874;

    // --------------------------------------------------------------------- //

    public SlotItemHandler(final ItemHandler itemHandler, final int index, final int xPosition, final int yPosition) {
        super(EMPTY_CONTAINER, index, xPosition, yPosition);
        this.itemHandler = itemHandler;
        this.field_7874 = index;
    }

    // --------------------------------------------------------------------- //

    public ItemHandler getItemHandler() {
        return itemHandler;
    }

    @Override
    public boolean method_7680(final class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }
        return itemHandler.insertItem(field_7874, stack, true).method_7947() < stack.method_7947();
    }

    @Override
    public class_1799 method_7677() {
        return itemHandler.getStackInSlot(field_7874);
    }

    @Override
    public void method_7673(final class_1799 stack) {
        if (itemHandler instanceof final ItemStackHandler handler) {
            handler.setStackInSlot(field_7874, stack);
        }
        method_7668();
    }

    @Override
    public void method_7670(final class_1799 oldStack, final class_1799 newStack) {
    }

    @Override
    public int method_7675() {
        return itemHandler instanceof final ItemStackHandler handler
            ? handler.getSlotLimit(field_7874)
            : super.method_7675();
    }

    @Override
    public int method_7676(final class_1799 stack) {
        final class_1799 remainder = itemHandler.insertItem(field_7874, stack.method_46651(stack.method_7914()), true);
        return stack.method_7914() - remainder.method_7947() + method_7677().method_7947();
    }

    @Override
    public boolean method_7674(final class_1657 player) {
        return !itemHandler.extractItem(field_7874, 1, true).method_7960();
    }

    @Override
    public class_1799 method_7671(final int amount) {
        return itemHandler.extractItem(field_7874, amount, false);
    }
}
