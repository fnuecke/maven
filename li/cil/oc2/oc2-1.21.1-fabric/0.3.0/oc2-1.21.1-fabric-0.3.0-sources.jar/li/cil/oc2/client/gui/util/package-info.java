/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.gui.util;

import javax.annotation.ParametersAreNonnullByDefault;
