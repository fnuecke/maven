/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.blockentity;

import javax.annotation.ParametersAreNonnullByDefault;
