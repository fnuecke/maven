/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockEntityCapabilityDeviceProvider;
import li.cil.oc2.common.capabilities.Capabilities;
import net.minecraft.class_2586;

public final class BlockEntityCapabilityDeviceProvider extends AbstractBlockEntityCapabilityDeviceProvider<Device, class_2586> {
    public BlockEntityCapabilityDeviceProvider() {
        super(Capabilities.DEVICE);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Invalidatable<Device> getBlockDevice(final BlockDeviceQuery query, final Device device) {
        return Invalidatable.of(device);
    }
}
