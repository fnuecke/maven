/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.gui;

import javax.annotation.ParametersAreNonnullByDefault;
