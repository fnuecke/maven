/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.common.item.NetworkTunnelItem;
import li.cil.oc2.common.tags.ItemTags;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.UUID;

public final class NetworkTunnelContainer extends AbstractContainer {
    public static void createServer(final class_3222 player, final class_1268 hand) {
        MenuRegistry.openExtendedMenu(player, new ExtendedMenuProvider() {
            @Override
            public class_2561 method_5476() {
                return player.method_5998(hand).method_7909().method_7848();
            }

            @Override
            public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                return new NetworkTunnelContainer(id, player, hand);
            }

            @Override
            public void saveExtraData(final class_2540 buffer) {
                buffer.method_10817(hand);
            }
        });
    }

    public static NetworkTunnelContainer createClient(final int id, final class_1661 inventory, final class_2540 data) {
        final class_1268 hand = data.method_10818(class_1268.class);
        final class_1657 player = inventory.field_7546;
        return new NetworkTunnelContainer(id, player, hand);
    }

    // --------------------------------------------------------------------- //

    private final class_1657 player;
    private final class_1268 hand;
    private final class_1263 linkSlot = new class_1277(1);

    // --------------------------------------------------------------------- //

    private NetworkTunnelContainer(final int id, final class_1657 player, final class_1268 hand) {
        super(Containers.NETWORK_TUNNEL.get(), id);
        this.player = player;
        this.hand = hand;

        createPlayerInventoryAndHotbarSlots(player.method_31548(), 8, 115);

        method_7621(new LockedSlot(player.method_31548(), getHandSlot(), 80, 25));
        method_7621(new DeviceTypeSlot(linkSlot, DeviceTypes.NETWORK_TUNNEL.get(), 0, 80, 51));
    }

    // --------------------------------------------------------------------- //

    public boolean hasLinkSlotItem() {
        return !linkSlot.method_5438(0).method_7960();
    }

    public void createTunnel() {
        final class_1799 tunnelA = player.method_5998(hand);
        final class_1799 tunnelB = linkSlot.method_5438(0);

        if (tunnelA.method_7960() ||
            tunnelB.method_7960() ||
            !tunnelA.method_31573(ItemTags.DEVICES_NETWORK_TUNNEL) ||
            !tunnelB.method_31573(ItemTags.DEVICES_NETWORK_TUNNEL)) {
            return;
        }

        final UUID id = UUID.randomUUID();
        NetworkTunnelItem.setTunnelId(tunnelA, id);
        NetworkTunnelItem.setTunnelId(tunnelB, id);
    }

    @Override
    public void method_7595(final class_1657 player) {
        super.method_7595(player);

        if (!player.method_37908().method_8608()) {
            method_7607(player, linkSlot);
        }
    }

    @Override
    public boolean method_7597(final class_1657 player) {
        return player.method_5998(hand).method_31573(ItemTags.DEVICES_NETWORK_TUNNEL);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected boolean isSlotLocked(final class_1661 inventory, final int slot) {
        return inventory.method_5438(slot) == player.method_5998(hand);
    }

    // --------------------------------------------------------------------- //

    private int getHandSlot() {
        final class_1661 inventory = player.method_31548();
        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            if (inventory.method_5438(slot) == player.method_5998(hand)) {
                return slot;
            }
        }

        return -1;
    }
}
