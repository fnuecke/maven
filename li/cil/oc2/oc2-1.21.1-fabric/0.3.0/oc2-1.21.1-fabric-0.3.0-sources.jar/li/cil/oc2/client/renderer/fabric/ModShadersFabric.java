/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.fabric;

import li.cil.oc2.client.renderer.ModShaders;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_290;

public final class ModShadersFabric {
    public static void initialize() {
        CoreShaderRegistrationCallback.EVENT.register(context -> {
            context.register(ModShaders.PROJECTORS_SHADER_LOCATION, class_290.field_1585,
                ModShaders::setProjectorsShader);
            context.register(ModShaders.TERMINAL_SHADER_LOCATION, class_290.field_1575,
                ModShaders::setTerminalShader);
        });
    }

    private ModShadersFabric() {
    }
}
