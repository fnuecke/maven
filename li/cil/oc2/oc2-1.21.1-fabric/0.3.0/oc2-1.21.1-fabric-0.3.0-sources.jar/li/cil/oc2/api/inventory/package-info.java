/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.api.inventory;

import javax.annotation.ParametersAreNonnullByDefault;
