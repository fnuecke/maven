/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_6862;

public class TypedItemStackHandler extends FixedSizeItemStackHandler {
    private final class_6862<class_1792> deviceType;

    // --------------------------------------------------------------------- //

    public TypedItemStackHandler(final int size, final class_6862<class_1792> deviceType) {
        super(size);
        this.deviceType = deviceType;
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean isItemValid(final int slot, final class_1799 stack) {
        return super.isItemValid(slot, stack) && !stack.method_7960() && stack.method_31573(deviceType);
    }
}
