/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.model.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
