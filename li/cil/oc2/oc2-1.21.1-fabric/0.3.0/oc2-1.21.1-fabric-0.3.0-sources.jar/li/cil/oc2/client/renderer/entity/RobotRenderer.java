/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.entity;

import li.cil.oc2.client.renderer.entity.model.RobotModel;
import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public final class RobotRenderer extends class_897<Robot> {
    private final RobotModel model;

    // --------------------------------------------------------------------- //

    public RobotRenderer(final class_5617.class_5618 context) {
        super(context);
        model = new RobotModel(context.method_32167(RobotModel.ROBOT_MODEL_LAYER));
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2960 getTextureLocation(final Robot entity) {
        return RobotModel.ROBOT_ENTITY_TEXTURE;
    }

    @Override
    public void render(final Robot entity, final float entityYaw, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int packedLight) {
        final Robot.AnimationState state = entity.getAnimationState();
        final float time = entity.method_37908().method_8510() + partialTicks;
        float deltaTime = class_310.method_1551().method_60646().method_60636();
        state.update(time, deltaTime, entity.method_37908().field_9229);

        stack.method_22903();
        // NB: we don't entityYaw given to use because that uses a plain lerp which can lead to ugly
        //     jumps in case we get a wrapped rotationYaw synced from the server (leading to ~360
        //     degree delta to the last known previous rotation). Haven't figured out where to
        //     alternatively prevent this wrapping or patch the prev value instead.
        final float partialRotation = class_3532.method_15356(entity.field_5982, entity.method_36454()) * partialTicks;
        final float rotation = class_3532.method_15388(entity.field_5982, entity.method_36454(), partialRotation);
        stack.method_22907(class_7833.field_40715.rotationDegrees(rotation));

        model.setupAnim(entity, 0, 0, 0, 0, 0);

        final class_4588 consumer = bufferSource.getBuffer(model.method_23500(getTextureLocation(entity)));
        model.method_2828(stack, consumer, packedLight, class_4608.field_21444, 0xFFFFFFFF);

        stack.method_22909();
    }
}
