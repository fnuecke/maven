/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import com.mojang.datafixers.util.Pair;
import li.cil.oc2.api.bus.device.DeviceType;
import li.cil.oc2.api.inventory.ItemHandler;
import net.minecraft.class_1723;
import net.minecraft.class_2960;
import javax.annotation.Nullable;

public final class DeviceTypeSlotItemHandler extends SlotItemHandler {
    private final DeviceType deviceType;

    public DeviceTypeSlotItemHandler(final ItemHandler itemHandler, final DeviceType deviceType, final int index, final int xPosition, final int yPosition) {
        super(itemHandler, index, xPosition, yPosition);
        this.deviceType = deviceType;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Nullable
    @Override
    public Pair<class_2960, class_2960> method_7679() {
        if (method_7681()) {
            return super.method_7679();
        } else {
            return Pair.of(class_1723.field_21668, deviceType.getBackgroundIcon());
        }
    }
}
