/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.common.container.ComputerTerminalContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_342;

@Environment(EnvType.CLIENT)
public final class ComputerTerminalScreen extends AbstractMachineTerminalScreen<ComputerTerminalContainer> {
    @SuppressWarnings("all")
    private class_342 focusIndicatorEditBox;

    // --------------------------------------------------------------------- //

    public ComputerTerminalScreen(final ComputerTerminalContainer container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void setFocusIndicatorEditBox(final class_342 editBox) {
        focusIndicatorEditBox = editBox;
    }
}
