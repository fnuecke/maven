/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus;

import dev.architectury.registry.registries.Registrar;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.provider.ItemDeviceProvider;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.common.bus.device.provider.Providers;
import li.cil.oc2.common.bus.device.rpc.TypeNameRPCDevice;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.bus.device.util.ItemDeviceInfo;
import li.cil.oc2.common.util.ItemDeviceUtils;
import li.cil.oc2.common.util.NBTTagIds;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import javax.annotation.Nullable;
import java.util.*;

import static li.cil.oc2.common.bus.device.provider.Providers.optionalKey;

public abstract class AbstractItemDeviceBusElement extends AbstractGroupingDeviceBusElement<AbstractItemDeviceBusElement.ItemEntry, ItemDeviceQuery> {
    public AbstractItemDeviceBusElement(final int groupCount) {
        super(groupCount);
    }

    // --------------------------------------------------------------------- //

    public boolean groupContains(final int groupIndex, final Device device) {
        for (final ItemEntry entry : groups.get(groupIndex)) {
            if (Objects.equals(entry.getDevice(), device)) {
                return true;
            }
        }

        return false;
    }

    public void handleSlotContentsChanged(final int slot, final class_1799 stack) {
        final ItemQueryResult queryResult = collectDevices(stack);

        setEntriesForGroup(slot, queryResult);
    }

    public void exportDeviceDataToItemStack(final int slot, final class_1799 stack) {
        if (stack.method_7960()) {
            return;
        }

        final class_2487 exportedTag = new class_2487();
        for (final ItemEntry entry : groups.get(slot)) {
            entry.getDeviceDataKey().ifPresent(key -> {
                final class_2487 deviceTag = new class_2487();
                entry.getDevice().exportToItemStack(deviceTag);
                if (!deviceTag.method_33133()) {
                    exportedTag.method_10566(key, deviceTag);
                }
            });
        }

        if (!exportedTag.method_33133()) {
            ItemDeviceUtils.setItemDeviceData(stack, exportedTag);
        }
    }

    // --------------------------------------------------------------------- //

    protected abstract ItemDeviceQuery makeQuery(final class_1799 stack);

    protected ItemQueryResult collectDevices(final class_1799 stack) {
        final ItemDeviceQuery query = makeQuery(stack);
        final HashSet<ItemEntry> entries = new HashSet<>();

        for (final ItemDeviceInfo deviceInfo : Devices.getDevices(query)) {
            entries.add(new ItemEntry(deviceInfo));
        }

        collectSyntheticDevices(query, entries);

        importDeviceDataFromItemStack(query, entries);

        return new ItemQueryResult(query, entries);
    }

    protected void collectSyntheticDevices(final ItemDeviceQuery query, final HashSet<ItemEntry> entries) {
        if (entries.isEmpty()) {
            return;
        }

        final class_2960 registryName = class_7923.field_41178.method_10221(query.getItemStack().method_7909());
        if (registryName != null) {
            final String itemName = registryName.toString();
            entries.add(new ItemEntry(new ItemDeviceInfo(null, new TypeNameRPCDevice(itemName), 0)));
        }
    }

    @Override
    protected void onEntryRemoved(final String dataKey, final class_2487 tag, @Nullable final ItemDeviceQuery query) {
        super.onEntryRemoved(dataKey, tag, query);
        final Registrar<ItemDeviceProvider> registry = Providers.itemDeviceProviderRegistry();
        final ItemDeviceProvider provider = registry.get(class_2960.method_60654(dataKey));
        if (provider != null) {
            provider.disposeMissing(query, tag);
        }
    }

    // --------------------------------------------------------------------- //

    private void importDeviceDataFromItemStack(final ItemDeviceQuery query, final HashSet<ItemEntry> entries) {
        final class_2487 exportedTag = ItemDeviceUtils.getItemDeviceData(query.getItemStack());
        if (!exportedTag.method_33133()) {
            for (final ItemEntry entry : entries) {
                entry.getDeviceDataKey().ifPresent(key -> {
                    if (exportedTag.method_10573(key, NBTTagIds.TAG_COMPOUND)) {
                        entry.deviceInfo.device.importFromItemStack(exportedTag.method_10562(key));
                    }
                });
            }
        }
    }

    // --------------------------------------------------------------------- //

    protected final class ItemQueryResult extends QueryResult {
        @Nullable
        private final ItemDeviceQuery query;
        private final Set<ItemEntry> entries;

        public ItemQueryResult(@Nullable final ItemDeviceQuery query, final Set<ItemEntry> entries) {
            this.query = query;
            this.entries = entries;
        }

        @Nullable
        @Override
        public ItemDeviceQuery getQuery() {
            return query;
        }

        @Override
        public Set<ItemEntry> getEntries() {
            return entries;
        }
    }

    protected record ItemEntry(ItemDeviceInfo deviceInfo) implements Entry {
        @Override
        public Optional<String> getDeviceDataKey() {
            return optionalKey(deviceInfo.provider);
        }

        @Override
        public OptionalInt getDeviceEnergyConsumption() {
            return OptionalInt.of(deviceInfo.getEnergyConsumption());
        }

        @Override
        public ItemDevice getDevice() {
            return deviceInfo.device;
        }
    }
}
