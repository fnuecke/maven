/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.vm.item;

import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.vm.VMDevice;
import li.cil.oc2.api.bus.device.vm.VMDeviceLoadResult;
import li.cil.oc2.api.bus.device.vm.context.VMContext;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.bus.device.util.OptionalAddress;
import li.cil.oc2.common.serialization.BlobStorage;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.sedna.api.device.PhysicalMemory;
import li.cil.sedna.device.memory.ByteBufferMemory;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.UUID;

public final class MemoryDevice extends IdentityProxy<class_1799> implements VMDevice, ItemDevice {
    private static final Logger LOGGER = LogManager.getLogger();

    private static final String BLOB_HANDLE_TAG_NAME = "blob";
    private static final String ADDRESS_TAG_NAME = "address";

    // --------------------------------------------------------------------- //

    private final int size;
    private PhysicalMemory device;

    // --------------------------------------------------------------------- //

    private final OptionalAddress address = new OptionalAddress();
    private UUID blobHandle;

    // --------------------------------------------------------------------- //

    public MemoryDevice(final class_1799 identity, final int capacity) {
        super(identity);
        size = capacity;
    }

    // --------------------------------------------------------------------- //

    @Override
    public VMDeviceLoadResult mount(final VMContext context) {
        if (allocateDevice(context) instanceof AllocationFailure(class_2561 message, boolean permanent)) {
            VMDeviceLoadResult result = VMDeviceLoadResult.fail();
            if (message != null) {
                result = result.withErrorMessage(message);
            }
            return permanent ? result.asPermanent() : result;
        }

        if (!address.claim(context.getMemoryRangeAllocator(), device)) {
            return VMDeviceLoadResult.fail().withErrorMessage(class_2561.method_43471(Constants.COMPUTER_ERROR_DEVICE_DOES_NOT_FIT)).asPermanent();
        }

        return VMDeviceLoadResult.success();
    }

    @Override
    public void unmount() {
        closeDevice();

        if (blobHandle != null) {
            BlobStorage.close(blobHandle);
        }
    }

    @Override
    public void dispose() {
        // Memory is volatile, so free up our persisted blob when device is disposed.
        if (blobHandle != null) {
            BlobStorage.delete(blobHandle);
            blobHandle = null;
        }

        address.clear();
    }

    @Override
    public class_2487 serializeNBT() {
        final class_2487 tag = new class_2487();

        if (blobHandle != null) {
            tag.method_25927(BLOB_HANDLE_TAG_NAME, blobHandle);
        }
        if (address.isPresent()) {
            tag.method_10544(ADDRESS_TAG_NAME, address.getAsLong());
        }

        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        if (tag.method_25928(BLOB_HANDLE_TAG_NAME)) {
            blobHandle = tag.method_25926(BLOB_HANDLE_TAG_NAME);
        }
        if (tag.method_10573(ADDRESS_TAG_NAME, NBTTagIds.TAG_LONG)) {
            address.set(tag.method_10537(ADDRESS_TAG_NAME));
        }
    }

    // --------------------------------------------------------------------- //

    private AllocationResult allocateDevice(final VMContext context) {
        if (!context.getMemoryAllocator().claimMemory(size)) {
            return new AllocationFailure(true);
        }

        if (BlobStorage.isStaleHandle(blobHandle)) {
            BlobStorage.delete(blobHandle);
            blobHandle = null;
            return new AllocationFailure(class_2561.method_43471(Constants.COMPUTER_ERROR_STATE_LOST), true);
        }

        try {
            final MappedByteBuffer buffer = openBlob().map(FileChannel.MapMode.READ_WRITE, 0, size);
            device = new ByteBufferMemory(size, buffer);
        } catch (final BlobStorage.BlobStorageFullException e) {
            LOGGER.error(e);
            return new AllocationFailure(class_2561.method_43471(Constants.COMPUTER_ERROR_STORAGE_FULL), false);
        } catch (final BlobStorage.BlobMissingException | BlobStorage.BlobInUseException e) {
            blobHandle = null;
            return new AllocationFailure(class_2561.method_43471(Constants.COMPUTER_ERROR_MEMORY_CORRUPTED), true);
        } catch (final IOException e) {
            LOGGER.error(e);
            return new AllocationFailure(false);
        }

        return new AllocationSuccess();
    }

    private void closeDevice() {
        if (device == null) {
            return;
        }

        try {
            device.close();
        } catch (final Exception e) {
            LOGGER.error(e);
        }

        device = null;
    }

    private FileChannel openBlob() throws IOException {
        final boolean isNew = !BlobStorage.isValidHandle(blobHandle);
        final UUID handle = isNew ? BlobStorage.allocateHandle() : blobHandle;

        final FileChannel channel = BlobStorage.open(handle, isNew);

        // Only set after we actually managed to open/create the storage. Will look
        // like a missing one if the open errors otherwise.
        blobHandle = handle;

        return channel;
    }

    private sealed interface AllocationResult permits AllocationSuccess, AllocationFailure {
    }

    private record AllocationSuccess() implements AllocationResult {
    }

    private record AllocationFailure(@Nullable class_2561 message, boolean permanent) implements AllocationResult {
        public AllocationFailure(final boolean permanent) {
            this(null, permanent);
        }
    }
}
