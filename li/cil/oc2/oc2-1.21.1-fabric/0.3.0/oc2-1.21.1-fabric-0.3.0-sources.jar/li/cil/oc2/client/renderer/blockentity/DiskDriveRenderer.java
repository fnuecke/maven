/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.common.block.DiskDriveBlock;
import li.cil.oc2.common.blockentity.DiskDriveBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.minecraft.class_918;

public final class DiskDriveRenderer implements class_827<DiskDriveBlockEntity> {
    private final class_824 renderer;

    // --------------------------------------------------------------------- //

    public DiskDriveRenderer(final class_5614.class_5615 context) {
        this.renderer = context.method_32139();
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final DiskDriveBlockEntity diskDrive, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        final class_1799 floppy = diskDrive.getFloppy();
        final class_2350 blockFacing = diskDrive.method_11010().method_11654(DiskDriveBlock.field_11177);
        final int neighborLight = class_761.method_23794(renderer.field_4348, diskDrive.method_11016().method_10093(blockFacing));
        final class_918 itemRenderer = class_310.method_1551().method_1480();

        stack.method_22903();

        stack.method_46416(0.5f, 0.5f, 0.5f);
        stack.method_22907(class_7833.field_40715.rotationDegrees(blockFacing.method_10144()));
        stack.method_46416(0.0f, 0.0f, 0.5f);
        stack.method_22907(class_7833.field_40713.rotationDegrees(90));
        stack.method_46416(0.0f, 0.2375f, 2.5f / 16f);
        stack.method_22905(0.55f, 0.55f, 0.55f);

        itemRenderer.method_23178(floppy, class_811.field_4319, neighborLight, overlay, stack, bufferSource,
            diskDrive.method_10997(), (int) diskDrive.method_11016().method_10063());

        stack.method_22909();
    }
}
