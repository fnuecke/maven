/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.model.fabric;

import li.cil.oc2.api.API;
import net.minecraft.class_1086;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_7775;
import javax.annotation.Nullable;

import static java.util.Objects.requireNonNull;

public final class BusCableModel {
    public static final class_2960 BUS_CABLE_BASE_MODEL = class_2960.method_60655(API.MOD_ID, "block/cable_base");
    public static final class_2960 BUS_CABLE_STRAIGHT_MODEL = class_2960.method_60655(API.MOD_ID, "block/cable_straight");
    public static final class_2960 BUS_CABLE_SUPPORT_MODEL = class_2960.method_60655(API.MOD_ID, "block/cable_support");

    // --------------------------------------------------------------------- //

    public static BusCableBakedModel bake(final class_1087 proxy, final class_7775 baker, final class_3665 modelState) {
        final class_1087[] straightModelByAxis = {
            bake(baker, BUS_CABLE_STRAIGHT_MODEL, modelState, class_1086.field_5366),
            bake(baker, BUS_CABLE_STRAIGHT_MODEL, modelState, class_1086.field_5351),
            bake(baker, BUS_CABLE_STRAIGHT_MODEL, modelState, null)
        };
        final class_1087[] supportModelByFace = {
            bake(baker, BUS_CABLE_SUPPORT_MODEL, modelState, class_1086.field_5353), // -y
            bake(baker, BUS_CABLE_SUPPORT_MODEL, modelState, class_1086.field_5351), // +y
            bake(baker, BUS_CABLE_SUPPORT_MODEL, modelState, class_1086.field_5355), // -z
            bake(baker, BUS_CABLE_SUPPORT_MODEL, modelState, null), // +z
            bake(baker, BUS_CABLE_SUPPORT_MODEL, modelState, class_1086.field_5366), // -x
            bake(baker, BUS_CABLE_SUPPORT_MODEL, modelState, class_1086.field_5347) // +x
        };

        return new BusCableBakedModel(proxy, straightModelByAxis, supportModelByFace);
    }

    // --------------------------------------------------------------------- //

    private static class_1087 bake(final class_7775 baker, final class_2960 model,
                                   final class_3665 modelState, @Nullable final class_1086 rotation) {
        final class_3665 state = rotation == null ? modelState : new ComposedModelState(
            modelState.method_3509().method_22933(rotation.method_3509()), modelState.method_3512());
        return requireNonNull(baker.method_45873(model, state));
    }

    private record ComposedModelState(class_4590 rotation, boolean uvLocked) implements class_3665 {
        @Override
        public class_4590 method_3509() {
            return rotation;
        }

        @Override
        public boolean method_3512() {
            return uvLocked;
        }
    }

    private BusCableModel() {
    }
}
