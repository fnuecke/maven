/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.Constants;
import li.cil.oc2.common.block.DiskDriveBlock;
import li.cil.oc2.common.bus.device.provider.item.FloppyItemDeviceProvider;
import li.cil.oc2.common.bus.device.vm.block.DiskDriveContainer;
import li.cil.oc2.common.bus.device.vm.block.DiskDriveDevice;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.container.TypedItemStackHandler;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.DiskDriveFloppyMessage;
import li.cil.oc2.common.tags.ItemTags;
import li.cil.oc2.common.util.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.time.Duration;

public final class DiskDriveBlockEntity extends ModBlockEntity implements DiskDriveContainer {
    private final DiskDriveItemStackHandler itemHandler = new DiskDriveItemStackHandler();
    @Nullable
    private DiskDriveDevice<DiskDriveBlockEntity> device;
    private final ThrottledSoundEmitter accessSoundEmitter;
    private final ThrottledSoundEmitter insertSoundEmitter;
    private final ThrottledSoundEmitter ejectSoundEmitter;

    // --------------------------------------------------------------------- //

    public DiskDriveBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.DISK_DRIVE.get(), pos, state);

        this.accessSoundEmitter = new ThrottledSoundEmitter(LocationSupplierUtils.of(this),
            SoundEvents.FLOPPY_ACCESS.get()).withMinInterval(Duration.ofSeconds(1));
        this.insertSoundEmitter = new ThrottledSoundEmitter(LocationSupplierUtils.of(this),
            SoundEvents.FLOPPY_INSERT.get()).withMinInterval(Duration.ofMillis(100));
        this.ejectSoundEmitter = new ThrottledSoundEmitter(LocationSupplierUtils.of(this),
            SoundEvents.FLOPPY_EJECT.get()).withMinInterval(Duration.ofMillis(100));
    }

    // --------------------------------------------------------------------- //

    public boolean canInsert(final class_1799 stack) {
        return !stack.method_7960() && stack.method_31573(ItemTags.DEVICES_FLOPPY);
    }

    public class_1799 insert(final class_1799 stack, @Nullable final class_1657 player) {
        if (!canInsert(stack)) {
            return stack;
        }

        eject(player);

        insertSoundEmitter.play();
        return itemHandler.insertItem(0, stack, false);
    }

    public boolean canEject() {
        return !itemHandler.extractItem(0, 1, true).method_7960();
    }

    public void eject(@Nullable final class_1657 player) {
        if (field_11863 == null) {
            return;
        }

        final class_1799 stack = itemHandler.extractItem(0, 1, false);
        if (!stack.method_7960()) {
            final class_2350 facing = method_11010().method_11654(DiskDriveBlock.field_11177);
            ejectSoundEmitter.play();
            ItemStackUtils.spawnAsEntity(field_11863, method_11016().method_10093(facing), stack, facing).ifPresent(entity -> {
                if (player != null) {
                    entity.method_6975();
                    entity.method_48349(player.method_5667());
                }
            });
        }
    }

    public void dropFloppy() {
        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        final class_1799 stack = itemHandler.extractItem(0, 1, false);
        if (!stack.method_7960()) {
            ItemStackUtils.spawnAsEntity(field_11863, method_11016(), stack);
        }
    }

    public class_1799 getFloppy() {
        return itemHandler.getStackInSlot(0);
    }

    @Environment(EnvType.CLIENT)
    public void setFloppyClient(final class_1799 stack) {
        itemHandler.setStackInSlot(0, stack);
    }

    @Nullable
    public DiskDriveDevice<DiskDriveBlockEntity> getDevice() {
        return device;
    }

    public void setDevice(final DiskDriveDevice<DiskDriveBlockEntity> value) {
        device = value;
    }

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.ITEM_HANDLER, itemHandler);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);
        tag.method_10566(Constants.ITEMS_TAG_NAME, itemHandler.serializeNBT(registries));
        return tag;
    }

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10566(Constants.ITEMS_TAG_NAME, itemHandler.serializeNBT(registries));
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        itemHandler.deserializeNBT(registries, tag.method_10562(Constants.ITEMS_TAG_NAME));
    }

    @Override
    public class_1799 getDiskItemStack() {
        return itemHandler.getStackInSlotRaw(0);
    }

    @Override
    public void handleDataAccess() {
        accessSoundEmitter.play();
    }

    // --------------------------------------------------------------------- //

    private final class DiskDriveItemStackHandler extends TypedItemStackHandler {
        public DiskDriveItemStackHandler() {
            super(1, ItemTags.DEVICES_FLOPPY);
        }

        public class_1799 getStackInSlotRaw(final int slot) {
            return super.getStackInSlot(slot);
        }

        @Override
        public class_1799 getStackInSlot(final int slot) {
            final class_1799 stack = getStackInSlotRaw(slot);
            exportDeviceDataToItemStack(stack);
            return stack;
        }

        @Override
        public class_1799 extractItem(final int slot, final int amount, final boolean simulate) {
            if (slot == 0 && !simulate && amount > 0) {
                exportDeviceDataToItemStack(getStackInSlotRaw(0));
            }

            return super.extractItem(slot, amount, simulate);
        }

        @Override
        public int getSlotLimit(final int slot) {
            return 1;
        }

        @Override
        public class_2487 serializeNBT(final class_7225.class_7874 provider) {
            exportDeviceDataToItemStack(getStackInSlotRaw(0));
            return super.serializeNBT(provider);
        }

        @Override
        protected void onContentsChanged(final int slot) {
            super.onContentsChanged(slot);

            if (field_11863 == null || field_11863.method_8608()) {
                return;
            }

            final class_1799 stack = getStackInSlotRaw(slot);
            if (device != null) {
                if (stack.method_7960()) {
                    device.removeBlockDevice();
                } else {
                    device.updateBlockDevice(ItemDeviceUtils.getDeviceData(stack, FloppyItemDeviceProvider.DEVICE_DATA_KEY));
                }
            }

            Network.sendToClientsTrackingBlockEntity(new DiskDriveFloppyMessage(DiskDriveBlockEntity.this), DiskDriveBlockEntity.this);

            method_5431();
        }

        private void exportDeviceDataToItemStack(final class_1799 stack) {
            if (stack.method_7960()) {
                return;
            }

            if (field_11863 == null || field_11863.method_8608()) {
                return;
            }

            if (device == null) {
                return;
            }

            final class_2487 tag = new class_2487();
            device.exportToItemStack(tag);

            if (tag.method_33133()) {
                return;
            }

            ItemDeviceUtils.setDeviceData(stack, FloppyItemDeviceProvider.DEVICE_DATA_KEY, tag);
        }
    }
}
