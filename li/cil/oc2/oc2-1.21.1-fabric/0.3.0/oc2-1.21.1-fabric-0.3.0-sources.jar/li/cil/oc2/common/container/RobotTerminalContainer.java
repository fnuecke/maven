/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import li.cil.oc2.api.inventory.ItemHandler;
import li.cil.oc2.client.gui.Sprites;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.energy.FixedEnergyStorage;
import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class RobotTerminalContainer extends AbstractRobotContainer {
    public static void createServer(final Robot robot, final FixedEnergyStorage energy, final CommonDeviceBusController busController, final class_3222 player) {
        MenuRegistry.openExtendedMenu(player, new ExtendedMenuProvider() {
            @Override
            public class_2561 method_5476() {
                return robot.method_5477();
            }

            @Override
            public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                return new RobotTerminalContainer(id, player, robot, createEnergyInfo(energy, busController));
            }

            @Override
            public void saveExtraData(final class_2540 buffer) {
                buffer.method_10804(robot.method_5628());
            }
        });
    }

    public static RobotTerminalContainer createClient(final int id, final class_1661 inventory, final class_2540 data) {
        final int entityId = data.method_10816();
        final class_1297 entity = inventory.field_7546.method_37908().method_8469(entityId);
        if (entity instanceof final Robot robot) {
            return new RobotTerminalContainer(id, inventory.field_7546, robot, createClientEnergyInfo());
        }

        throw new IllegalArgumentException();
    }

    // --------------------------------------------------------------------- //

    private RobotTerminalContainer(final int id, final class_1657 player, final Robot robot, final IntPrecisionContainerData energyInfo) {
        super(Containers.ROBOT_TERMINAL.get(), id, player, robot, energyInfo);

        // It's kinda dumb we need to access technically-client-side stuff here, but that's the nature of containers
        // needing to specify display positions for some reason.
        final int terminalScreenWidth = Sprites.TERMINAL_SCREEN.width;
        final int terminalScreenHeight = Sprites.TERMINAL_SCREEN.height;

        final ItemHandler inventory = robot.getInventory();
        for (int slot = 0; slot < inventory.getSlots(); slot++) {
            final int x = (terminalScreenWidth - inventory.getSlots() * SLOT_SIZE) / 2 + 1 + slot * SLOT_SIZE;
            method_7621(new RobotSlot(inventory, slot, x, terminalScreenHeight + 4));
        }
    }
}
