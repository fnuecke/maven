/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.util.BlockEntityUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5558;
import javax.annotation.Nullable;

/**
 * Convenience interface for enabling side-specific ticking of {@link class_2586}s using
 * {@link class_5558}s. Provides factory methods for all variants, working with
 * any block entity implementing this interface.
 */
public interface TickableBlockEntity {
    /**
     * Called on the client when this {@link class_2586} should tick.
     * <p>
     * Only called when registered using {@link #createTicker(class_1937, class_2591, class_2591)} or
     * {@link #createClientTicker(class_1937, class_2591, class_2591)}.
     */
    default void clientTick() {
    }

    /**
     * Called on the server when this {@link class_2586} should tick.
     * <p>
     * Only called when registered using {@link #createTicker(class_1937, class_2591, class_2591)} or
     * {@link #createServerTicker(class_1937, class_2591, class_2591)}.
     */
    default void serverTick() {
    }

    /**
     * Creates a ticker that will only run on the client.
     */
    @Nullable
    static <THave extends class_2586, TWant extends class_2586 & TickableBlockEntity> class_5558<THave> createClientTicker(final class_1937 level, final class_2591<THave> haveType, final class_2591<TWant> wantType) {
        if (level.method_8608()) {
            return BlockEntityUtils.createTicker(haveType, wantType, (ignoredLevel, blockPos, state, blockEntity) -> blockEntity.clientTick());
        } else {
            return null;
        }
    }

    /**
     * Creates a ticker that will only run on the server.
     */
    @Nullable
    static <THave extends class_2586, TWant extends class_2586 & TickableBlockEntity> class_5558<THave> createServerTicker(final class_1937 level, final class_2591<THave> haveType, final class_2591<TWant> wantType) {
        if (level.method_8608()) {
            return null;
        } else {
            return BlockEntityUtils.createTicker(haveType, wantType, (ignoredLevel, blockPos, state, blockEntity) -> blockEntity.serverTick());
        }
    }

    /**
     * Creates a ticker for either the client and the server.
     */
    @Nullable
    static <THave extends class_2586, TWant extends class_2586 & TickableBlockEntity> class_5558<THave> createTicker(final class_1937 level, final class_2591<THave> haveType, final class_2591<TWant> wantType) {
        if (level.method_8608()) {
            return BlockEntityUtils.createTicker(haveType, wantType, (ignoredLevel, blockPos, state, blockEntity) -> blockEntity.clientTick());
        } else {
            return BlockEntityUtils.createTicker(haveType, wantType, (ignoredLevel, blockPos, state, blockEntity) -> blockEntity.serverTick());
        }
    }
}
