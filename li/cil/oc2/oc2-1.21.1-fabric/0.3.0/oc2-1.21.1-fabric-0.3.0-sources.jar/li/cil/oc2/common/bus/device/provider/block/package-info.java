/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.bus.device.provider.block;

import javax.annotation.ParametersAreNonnullByDefault;
