/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.capabilities;

import javax.annotation.Nullable;
import net.minecraft.class_2350;

public interface CapabilityProvider {
    @Nullable
    <T> T getCapability(CapabilityType<T> capability, @Nullable class_2350 side);
}
