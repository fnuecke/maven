/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.common.container.RobotTerminalContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;

@Environment(EnvType.CLIENT)
public final class RobotTerminalScreen extends AbstractMachineTerminalScreen<RobotTerminalContainer> {
    private static final int SLOTS_X = (MachineTerminalWidget.WIDTH - Sprites.HOTBAR.width) / 2;
    private static final int SLOTS_Y = MachineTerminalWidget.HEIGHT - 1;

    // --------------------------------------------------------------------- //

    @SuppressWarnings("all")
    private class_342 focusIndicatorEditBox;

    // --------------------------------------------------------------------- //

    public RobotTerminalScreen(final RobotTerminalContainer container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        Sprites.HOTBAR.draw(graphics, field_2776 + SLOTS_X, field_2800 + SLOTS_Y);
        RobotContainerScreen.renderSelection(graphics, field_2797.getRobot().getSelectedSlot(), field_2776 + SLOTS_X + 4, field_2800 + SLOTS_Y + 4, 12);

        super.method_2389(graphics, partialTicks, mouseX, mouseY);
    }

    @Override
    protected void setFocusIndicatorEditBox(final class_342 editBox) {
        focusIndicatorEditBox = editBox;
    }
}
