/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.common.Config;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.oc2.common.util.TextFormatUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import java.util.List;

public abstract class AbstractStorageItem extends ModItem {
    private static final String CAPACITY_TAG_NAME = "capacity";

    // --------------------------------------------------------------------- //

    private final int defaultCapacity;

    // --------------------------------------------------------------------- //

    protected AbstractStorageItem(final class_1793 properties, final int defaultCapacity) {
        super(properties);
        this.defaultCapacity = defaultCapacity;
    }

    protected AbstractStorageItem(final int capacity) {
        this(createProperties(), capacity);
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.addDataCorrupted(stack, tooltip);
    }

    @Override
    public class_2561 method_7864(final class_1799 stack) {
        final int capacity = getCapacity(stack);
        return class_2561.method_43470("")
            .method_10852(super.method_7864(stack))
            .method_27693(" (")
            .method_27693(TextFormatUtils.formatSize(capacity))
            .method_27693(")");
    }

    // --------------------------------------------------------------------- //

    public int getCapacity(final class_1799 stack) {
        final class_2487 tag = ItemStackUtils.getModDataTag(stack);
        if (!tag.method_10573(CAPACITY_TAG_NAME, NBTTagIds.TAG_INT)) {
            return defaultCapacity;
        }

        final int capacity = tag.method_10550(CAPACITY_TAG_NAME);
        if (Config.maxBlobCapacity <= 0) {
            return Math.max(capacity, 0);
        }

        return class_3532.method_15340(capacity, 0, Config.maxBlobCapacity);
    }

    public class_1799 withCapacity(final class_1799 stack, final int capacity) {
        ItemStackUtils.modifyModDataTag(stack, tag -> tag.method_10569(CAPACITY_TAG_NAME, capacity));
        return stack;
    }

    public class_1799 withCapacity(final int capacity) {
        return withCapacity(new class_1799(this), capacity);
    }
}
