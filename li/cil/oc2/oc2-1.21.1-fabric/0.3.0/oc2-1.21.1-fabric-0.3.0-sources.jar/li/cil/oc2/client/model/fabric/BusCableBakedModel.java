/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.model.fabric;

import li.cil.oc2.common.Constants;
import li.cil.oc2.common.block.BusCableBlock;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.util.ItemStackUtils;
import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_310;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

public record BusCableBakedModel(
    class_1087 proxy,
    class_1087[] straightModelByAxis,
    class_1087[] supportModelByFace
) implements class_1087, FabricBakedModel {
    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(final class_1920 level, final class_2680 state, final class_2338 pos,
                               final Supplier<class_5819> randomSupplier, final RenderContext context) {
        if (state.method_28498(BusCableBlock.HAS_FACADE) && state.method_11654(BusCableBlock.HAS_FACADE)) {
            emitFacadeQuads(level, pos, randomSupplier, context);
            return;
        }

        if (!state.method_11654(BusCableBlock.HAS_CABLE)) {
            return;
        }

        for (int i = 0; i < Constants.AXES.length; i++) {
            if (isStraightAlongAxis(state, Constants.AXES[i])) {
                straightModelByAxis[i].emitBlockQuads(level, state, pos, randomSupplier, context);
                return;
            }
        }

        proxy.emitBlockQuads(level, state, pos, randomSupplier, context);

        final class_2350 supportSide = getSupportSide(level, pos, state);
        if (supportSide != null) {
            supportModelByFace[supportSide.method_10146()].emitBlockQuads(level, state, pos, randomSupplier, context);
        }
    }

    @Override
    public void emitItemQuads(final class_1799 stack, final Supplier<class_5819> randomSupplier, final RenderContext context) {
        proxy.emitItemQuads(stack, randomSupplier, context);
    }

    @Override
    public List<class_777> method_4707(@Nullable final class_2680 state, @Nullable final class_2350 side, final class_5819 random) {
        if (state == null || !state.method_11654(BusCableBlock.HAS_CABLE)) {
            return Collections.emptyList();
        }

        for (int i = 0; i < Constants.AXES.length; i++) {
            if (isStraightAlongAxis(state, Constants.AXES[i])) {
                return straightModelByAxis[i].method_4707(state, side, random);
            }
        }

        return proxy.method_4707(state, side, random);
    }

    @Override
    public boolean method_4708() {
        return proxy.method_4708();
    }

    @Override
    public boolean method_4712() {
        return proxy.method_4712();
    }

    @Override
    public boolean method_24304() {
        return proxy.method_24304();
    }

    @Override
    public boolean method_4713() {
        return proxy.method_4713();
    }

    @Override
    public class_1058 method_4711() {
        return proxy.method_4711();
    }

    @Override
    public class_809 method_4709() {
        return proxy.method_4709();
    }

    @Override
    public class_806 method_4710() {
        return proxy.method_4710();
    }

    // --------------------------------------------------------------------- //

    private static void emitFacadeQuads(final class_1920 level, final class_2338 pos,
                                        final Supplier<class_5819> randomSupplier, final RenderContext context) {
        final class_2586 blockEntity = level.method_8321(pos);

        class_2680 facadeState = null;
        if (blockEntity instanceof final BusCableBlockEntity busCable) {
            final class_1799 facadeItem = busCable.getFacade();
            facadeState = ItemStackUtils.getBlockState(facadeItem);
        }
        if (facadeState == null) {
            facadeState = class_2246.field_10085.method_9564();
        }

        final class_1087 model = class_310.method_1551().method_1541().method_3351().method_3335(facadeState);

        final RenderMaterial material = facadeMaterial(facadeState);
        if (material != null) {
            context.pushTransform(quad -> {
                quad.material(material);
                return true;
            });
        }

        try {
            model.emitBlockQuads(level, facadeState, pos, randomSupplier, context);
        } finally {
            if (material != null) {
                context.popTransform();
            }
        }
    }

    @Nullable
    private static RenderMaterial facadeMaterial(final class_2680 facadeState) {
        final Renderer renderer = RendererAccess.INSTANCE.getRenderer();
        if (renderer == null) {
            return null;
        }

        final BlendMode blendMode = BlendMode.fromRenderLayer(class_4696.method_23679(facadeState));
        return renderer.materialFinder().blendMode(blendMode).find();
    }

    @Nullable
    private static class_2350 getSupportSide(final class_1920 level, final class_2338 pos, final class_2680 state) {
        class_2350 supportSide = null;
        for (final class_2350 direction : Constants.DIRECTIONS) {
            if (isNeighborInDirectionSolid(level, pos, direction)) {
                final class_2754<BusCableBlock.ConnectionType> property = BusCableBlock.FACING_TO_CONNECTION_MAP.get(direction);
                if (state.method_28498(property) && state.method_11654(property) == BusCableBlock.ConnectionType.INTERFACE) {
                    return null; // Plug is already supporting us, bail.
                }

                if (supportSide == null) { // Prefer vertical supports.
                    supportSide = direction;
                }
            }
        }

        return supportSide;
    }

    private static boolean isNeighborInDirectionSolid(final class_1920 level, final class_2338 pos, final class_2350 direction) {
        final class_2338 neighborPos = pos.method_10093(direction);
        return level.method_8320(neighborPos).method_26206(level, neighborPos, direction.method_10153());
    }

    private static boolean isStraightAlongAxis(final class_2680 state, final class_2350.class_2351 axis) {
        for (final class_2350 direction : Constants.DIRECTIONS) {
            final class_2754<BusCableBlock.ConnectionType> property = BusCableBlock.FACING_TO_CONNECTION_MAP.get(direction);
            if (axis.method_10176(direction)) {
                if (state.method_11654(property) != BusCableBlock.ConnectionType.CABLE) {
                    return false;
                }
            } else {
                if (state.method_11654(property) != BusCableBlock.ConnectionType.NONE) {
                    return false;
                }
            }
        }

        return true;
    }
}
