/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.util;

import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.provider.ItemDeviceProvider;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import java.util.Optional;
import java.util.function.Predicate;

public abstract class AbstractItemDeviceProvider implements ItemDeviceProvider {
    private final Predicate<class_1792> predicate;

    // --------------------------------------------------------------------- //

    private AbstractItemDeviceProvider(final Predicate<class_1792> predicate) {
        this.predicate = predicate;
    }

    protected AbstractItemDeviceProvider(final RegistrySupplier<? extends class_1792> item) {
        this(i -> i == item.get());
    }

    protected AbstractItemDeviceProvider(final Class<? extends class_1792> type) {
        this(type::isInstance);
    }

    protected AbstractItemDeviceProvider() {
        this.predicate = i -> true;
    }

    // --------------------------------------------------------------------- //

    @Override
    public final Optional<ItemDevice> getDevice(final ItemDeviceQuery query) {
        return matches(query) ? getItemDevice(query) : Optional.empty();
    }

    @Override
    public final int getEnergyConsumption(final ItemDeviceQuery query) {
        return matches(query) ? getItemDeviceEnergyConsumption(query) : 0;
    }

    // --------------------------------------------------------------------- //

    protected boolean matches(final ItemDeviceQuery query) {
        final class_1799 stack = query.getItemStack();
        return !stack.method_7960() && predicate.test(stack.method_7909());
    }

    protected abstract Optional<ItemDevice> getItemDevice(final ItemDeviceQuery query);

    protected int getItemDeviceEnergyConsumption(final ItemDeviceQuery query) {
        return 0;
    }
}
