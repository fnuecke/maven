/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.capabilities.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
