/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.api.capabilities.RedstoneEmitter;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.integration.Wrenches;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.item.TooltipUtils;
import li.cil.oc2.common.util.VoxelShapeUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3222;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_8567;
import net.minecraft.class_9062;
import javax.annotation.Nullable;
import java.util.List;


public final class ComputerBlock extends class_2383 implements class_2343 {
    public static final MapCodec<ComputerBlock> CODEC = MapCodec.unit(ComputerBlock::new);

    @Override
    protected MapCodec<? extends ComputerBlock> method_53969() {
        return field_46280;
    }

    // We bake the "screen" indent on the front into the collision shape, to prevent stuff being
    // placeable on that side, such as network connectors, torches, etc.
    private static final class_265 NEG_Z_SHAPE = class_259.method_17786(
        class_2248.method_9541(0, 0, 1, 16, 16, 16), // main body
        class_2248.method_9541(0, 15, 0, 16, 16, 1), // across top
        class_2248.method_9541(0, 0, 0, 16, 6, 1), // across bottom
        class_2248.method_9541(0, 0, 0, 1, 16, 1), // up left
        class_2248.method_9541(15, 0, 0, 16, 16, 1) // up right
    );
    private static final class_265 NEG_X_SHAPE = VoxelShapeUtils.rotateHorizontalClockwise(NEG_Z_SHAPE);
    private static final class_265 POS_Z_SHAPE = VoxelShapeUtils.rotateHorizontalClockwise(NEG_X_SHAPE);
    private static final class_265 POS_X_SHAPE = VoxelShapeUtils.rotateHorizontalClockwise(POS_Z_SHAPE);

    // --------------------------------------------------------------------- //

    public ComputerBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f)
            .method_26236((state, level, pos) -> false));
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    @Override
    public void method_9568(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_9568(stack, context, tooltip, advanced);
        TooltipUtils.addBlockEntityInventoryInformation(stack, tooltip);
    }

    @Override
    protected boolean method_9506(final class_2680 state) {
        return true;
    }

    @Override
    protected int method_9524(final class_2680 state, final class_1922 level, final class_2338 pos, final class_2350 side) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity != null) {
            // Redstone requests info for faces with external perspective. Capabilities treat
            // the Direction from internal perspective, so flip it.
            final RedstoneEmitter emitter = Capabilities.get(blockEntity, Capabilities.REDSTONE_EMITTER, side.method_10153());
            if (emitter != null) {
                return emitter.getRedstoneOutput();
            }
        }

        return super.method_9524(state, level, pos, side);
    }

    @Override
    protected int method_9603(final class_2680 state, final class_1922 level, final class_2338 pos, final class_2350 side) {
        return method_9524(state, level, pos, side);
    }

    @Override
    protected void method_9612(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2248 changedBlock, final class_2338 changedBlockPos, final boolean isMoving) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final ComputerBlockEntity computer) {
            computer.handleNeighborChanged();
        }
    }

    @Override
    protected class_265 method_9530(final class_2680 state, final class_1922 level, final class_2338 pos, final class_3726 context) {
        return switch (state.method_11654(field_11177)) {
            case field_11043 -> NEG_Z_SHAPE;
            case field_11035 -> POS_Z_SHAPE;
            case field_11039 -> NEG_X_SHAPE;
            default -> POS_X_SHAPE;
        };
    }

    @Override
    protected class_9062 method_55765(final class_1799 stack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof final ComputerBlockEntity computer)) {
            return super.method_55765(stack, state, level, pos, player, hand, hit);
        }

        if (Wrenches.isWrench(stack)) {
            if (player.method_5715()) {
                // Let the wrench itself handle this (dismantle).
                return class_9062.field_47732;
            }

            if (!level.method_8608() && player instanceof final class_3222 serverPlayer) {
                computer.openInventoryScreen(serverPlayer);
            }
        } else if (!level.method_8608()) {
            if (player.method_5715()) {
                computer.start();
            } else if (player instanceof final class_3222 serverPlayer) {
                computer.openTerminalScreen(serverPlayer);
            }
        }

        return class_9062.method_55644(level.method_8608());
    }

    @Override
    protected class_1269 method_55766(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof final ComputerBlockEntity computer)) {
            return super.method_55766(state, level, pos, player, hit);
        }

        if (!level.method_8608()) {
            if (player.method_5715()) {
                computer.start();
            } else if (player instanceof final class_3222 serverPlayer) {
                computer.openTerminalScreen(serverPlayer);
            }
        }

        return class_1269.method_29236(level.method_8608());
    }

    @Override
    protected List<class_1799> method_9560(final class_2680 state, final class_8567.class_8568 builder) {
        // The old loot table copied the block entity's NBT into the item with CopyNbtFunction; under
        // data components there is no loot function that writes BLOCK_ENTITY_DATA, so do it here.
        final List<class_1799> drops = super.method_9560(state, builder);
        if (builder.method_51876(class_181.field_1228) instanceof final ComputerBlockEntity computer) {
            for (final class_1799 drop : drops) {
                if (drop.method_7909() == Items.COMPUTER.get()) {
                    computer.exportToItemStack(drop);
                }
            }
        }

        return drops;
    }

    @Override
    public class_2680 method_9576(final class_1937 level, final class_2338 pos, final class_2680 state, final class_1657 player) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (!level.method_8608() && blockEntity instanceof final ComputerBlockEntity computer) {
            if (!computer.getItemStackHandlers().isEmpty()) {
                computer.getItemStackHandlers().exportDeviceDataToItemStacks();

                if (player.method_7337()) {
                    final class_1799 stack = new class_1799(Items.COMPUTER.get());
                    computer.exportToItemStack(stack);
                    method_9577(level, pos, stack);
                }
            }
        }

        return super.method_9576(level, pos, state, player);
    }

    @Override
    public class_2680 method_9605(final class_1750 context) {
        return super.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.COMPUTER.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createTicker(level, type, BlockEntities.COMPUTER.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(field_11177);
    }
}
