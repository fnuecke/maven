/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity.robot;

import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_3532;

public final class RobotRotationActionType extends AbstractRobotActionType {
    public RobotRotationActionType(final int id) {
        super(id);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void initializeData(final Robot robot) {
        robot.method_5841().method_12778(Robot.TARGET_DIRECTION, robot.method_5735());
    }

    @Override
    public void performServer(final Robot robot, final AbstractRobotAction currentAction) {
        if (!(currentAction instanceof RobotRotationAction)) {
            robot.method_5841().method_12778(Robot.TARGET_DIRECTION, robot.method_5735());
        }
    }

    @Override
    public void performClient(final Robot robot) {
        final class_2350 target = robot.method_5841().method_12789(Robot.TARGET_DIRECTION);
        if (class_3532.method_15356(robot.method_36454(), target.method_10144()) > RobotRotationAction.TARGET_EPSILON) {
            RobotRotationAction.rotateTowards(robot, target);
        }
    }

    @Override
    public AbstractRobotAction deserialize(final class_2487 tag) {
        return new RobotRotationAction(tag);
    }
}
