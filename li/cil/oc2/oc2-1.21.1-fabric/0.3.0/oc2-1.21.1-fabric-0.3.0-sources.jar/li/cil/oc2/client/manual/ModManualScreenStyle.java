/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.manual;

import li.cil.manual.api.ManualScreenStyle;
import li.cil.oc2.api.API;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_768;

@Environment(EnvType.CLIENT)
public final class ModManualScreenStyle implements ManualScreenStyle {
    public static final ManualScreenStyle INSTANCE = new ModManualScreenStyle();

    @Override
    public class_2960 getWindowBackground() {
        return class_2960.method_60655(API.MOD_ID, "textures/gui/manual/manual.png");
    }

    @Override
    public class_2960 getScrollButtonTexture() {
        return class_2960.method_60655(API.MOD_ID, "textures/gui/manual/scroll_button.png");
    }

    @Override
    public class_2960 getTabButtonTexture() {
        return class_2960.method_60655(API.MOD_ID, "textures/gui/manual/tab_button.png");
    }

    @Override
    public class_768 getDocumentRect() {
        return new class_768(12, 12, 216, 232);
    }

    @Override
    public class_768 getScrollBarRect() {
        return new class_768(236, 8, 12, 240);
    }

    @Override
    public class_768 getScrollButtonRect() {
        return new class_768(0, 0, 12, 12);
    }

    @Override
    public class_768 getTabAreaRect() {
        return new class_768(-52, 12, 52, 232);
    }

    @Override
    public class_768 getTabRect() {
        return new class_768(0, 0, 64, 24);
    }

    @Override
    public int getTabOverlap() {
        return 0;
    }
}
