/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.util;

import java.util.List;
import net.minecraft.class_2477;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5225;
import net.minecraft.class_5348;

public final class TooltipRenderer {
    public static void drawTooltip(final class_332 graphics, final List<? extends class_5348> tooltip, final int x, final int y) {
        drawTooltip(graphics, tooltip, x, y, 200);
    }

    public static void drawTooltip(final class_332 graphics, final List<? extends class_5348> tooltip, final int x, final int y, final int widthHint) {
        final class_310 minecraft = class_310.method_1551();
        final class_437 screen = minecraft.field_1755;
        if (screen == null) {
            return;
        }

        final int availableWidth = Math.max(x, screen.field_22789 - x);
        final int targetWidth = Math.min(availableWidth, widthHint);
        final class_327 font = minecraft.field_1772;

        final class_5225 splitter = font.method_27527();
        final boolean needsWrapping = tooltip.stream().anyMatch(line -> font.method_27525(line) > targetWidth);
        final List<? extends class_5348> lines = needsWrapping
            ? tooltip.stream().flatMap(line -> splitter.method_27495(line, targetWidth, class_2583.field_24360).stream()).toList()
            : tooltip;
        graphics.method_51447(font, lines.stream().map(class_2477.method_10517()::method_30934).toList(), x, y);
    }

    // --------------------------------------------------------------------- //

    private TooltipRenderer() {
    }
}
