/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.util.NBTTagIds;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public class FixedSizeItemStackHandler extends ItemStackHandler {
    private static final String SIZE_TAG_NAME = "Size";

    // --------------------------------------------------------------------- //

    public FixedSizeItemStackHandler(final int size) {
        super(size);
    }

    public FixedSizeItemStackHandler(final class_2371<class_1799> stacks) {
        super(stacks);
    }

    // --------------------------------------------------------------------- //

    public boolean isEmpty() {
        for (int slot = 0; slot < getSlots(); slot++) {
            if (!getStackInSlot(slot).method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void deserializeNBT(final class_7225.class_7874 registries, final class_2487 tag) {
        // Our size is fixed, don't trust NBT data we're loading.
        if (tag.method_10573(SIZE_TAG_NAME, NBTTagIds.TAG_INT)) {
            final class_2487 safeTag = tag.method_10553();
            safeTag.method_10551(SIZE_TAG_NAME);
            super.deserializeNBT(registries, safeTag);
        } else {
            super.deserializeNBT(registries, tag);
        }
    }
}
