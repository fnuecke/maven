/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.entity;

import li.cil.oc2.client.renderer.entity.model.RobotModel;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5599;
import net.minecraft.class_756;
import net.minecraft.class_811;
import net.minecraft.class_824;

public final class RobotWithoutLevelRenderer extends class_756 {
    private final RobotModel model;

    // --------------------------------------------------------------------- //

    public RobotWithoutLevelRenderer(final class_824 dispatcher, final class_5599 modelSet) {
        super(dispatcher, modelSet);
        model = new RobotModel(modelSet.method_32072(RobotModel.ROBOT_MODEL_LAYER));
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_3166(final class_1799 itemStack, final class_811 transformType, final class_4587 poseStack, final class_4597 bufferSource, final int combinedLight, final int combinedOverlay) {
        poseStack.method_22903();

        poseStack.method_22904(0.5, 0, 0.5);

        final class_4588 consumer = bufferSource.getBuffer(model.method_23500(RobotModel.ROBOT_ENTITY_TEXTURE));
        model.method_2828(poseStack, consumer, combinedLight, class_4608.field_21444, 0xFFFFFFFF);

        poseStack.method_22909();
    }
}
