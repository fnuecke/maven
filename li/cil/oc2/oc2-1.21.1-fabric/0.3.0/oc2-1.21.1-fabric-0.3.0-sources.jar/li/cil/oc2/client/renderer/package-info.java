/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.renderer;

import javax.annotation.ParametersAreNonnullByDefault;
