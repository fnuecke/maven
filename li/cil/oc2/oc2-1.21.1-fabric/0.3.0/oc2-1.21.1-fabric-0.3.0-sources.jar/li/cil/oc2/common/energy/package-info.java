/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.energy;

import javax.annotation.ParametersAreNonnullByDefault;
