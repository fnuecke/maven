/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity.robot;

import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_243;
import net.minecraft.class_2487;

public final class RobotMovementActionType extends AbstractRobotActionType {
    public RobotMovementActionType(final int id) {
        super(id);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void initializeData(final Robot robot) {
        robot.method_5841().method_12778(Robot.TARGET_POSITION, robot.method_24515());
    }

    @Override
    public void performServer(final Robot robot, final AbstractRobotAction currentAction) {
        if (!(currentAction instanceof RobotMovementAction)) {
            robot.method_5841().method_12778(Robot.TARGET_POSITION, robot.method_24515());
        }
    }

    @Override
    public void performClient(final Robot robot) {
        final class_243 target = RobotMovementAction.getTargetPositionInBlock(robot.method_5841().method_12789(Robot.TARGET_POSITION));
        if (robot.method_19538().method_1025(target) > RobotMovementAction.TARGET_EPSILON) {
            RobotMovementAction.moveTowards(robot, target);
        }
    }

    @Override
    public AbstractRobotAction deserialize(final class_2487 tag) {
        return new RobotMovementAction(tag);
    }
}
