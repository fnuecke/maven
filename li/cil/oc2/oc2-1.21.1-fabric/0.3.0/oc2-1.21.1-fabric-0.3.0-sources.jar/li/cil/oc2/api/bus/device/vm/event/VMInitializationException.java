/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.bus.device.vm.event;

import java.util.Optional;
import net.minecraft.class_2561;

/**
 * May be fired by devices while handling {@link VMInitializingEvent} to indicate that initialization failed.
 */
public final class VMInitializationException extends RuntimeException {
    private final class_2561 message;

    // --------------------------------------------------------------------- //

    public VMInitializationException(final class_2561 message) {
        this.message = message;
    }

    public VMInitializationException() {
        this.message = null;
    }

    // --------------------------------------------------------------------- //

    /**
     * The error message indicating why initialization failed.
     * <p>
     * This should be a human-readable message, as it may be displayed to the user.
     *
     * @return the error message.
     */
    public Optional<class_2561> getErrorMessage() {
        return Optional.ofNullable(message);
    }
}
