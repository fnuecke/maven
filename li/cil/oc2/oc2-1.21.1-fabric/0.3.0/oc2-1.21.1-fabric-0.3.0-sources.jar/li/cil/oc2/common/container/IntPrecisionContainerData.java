/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import net.minecraft.class_3913;
import net.minecraft.class_3919;

/**
 * Utility class for synchronizing full-precision ints using {@link class_3913}.
 */
public abstract class IntPrecisionContainerData implements class_3913 {
    public abstract int getInt(final int index);

    public abstract int getIntCount();

    public static abstract class Server extends IntPrecisionContainerData {
        @Override
        public int method_17390(final int index) {
            final int intValue = getInt(index / 2);
            if ((index & 1) == 0) {
                return intValue & 0xFFFF; // Low half.
            } else {
                return (intValue >>> 16) & 0xFFFF; // High half.
            }
        }

        @Override
        public void method_17391(final int index, final int value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int method_17389() {
            return getIntCount() * 2;
        }
    }

    public static final class Client extends IntPrecisionContainerData {
        private final class_3919 data;

        public Client(final int size) {
            data = new class_3919(size * 2);
        }

        @Override
        public int getInt(final int index) {
            return (method_17390(index * 2 + 1) << 16) | method_17390(index * 2);
        }

        @Override
        public int getIntCount() {
            return method_17389() / 2;
        }

        @Override
        public int method_17390(final int index) {
            return data.method_17390(index);
        }

        @Override
        public void method_17391(final int index, final int value) {
            data.method_17391(index, value & 0xFFFF);
        }

        @Override
        public int method_17389() {
            return data.method_17389();
        }
    }
}
