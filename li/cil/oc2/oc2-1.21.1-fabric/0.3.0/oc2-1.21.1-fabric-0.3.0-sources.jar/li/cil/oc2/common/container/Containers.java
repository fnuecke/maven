/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import dev.architectury.registry.menu.MenuRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.common.util.RegistryUtils;
import net.minecraft.class_3917;
import net.minecraft.class_7924;

public final class Containers {
    private static final DeferredRegister<class_3917<?>> CONTAINERS = RegistryUtils.getInitializerFor(class_7924.field_41207);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_3917<ComputerInventoryContainer>> COMPUTER = CONTAINERS.register("computer", () -> MenuRegistry.ofExtended(ComputerInventoryContainer::createClient));
    public static final RegistrySupplier<class_3917<ComputerTerminalContainer>> COMPUTER_TERMINAL = CONTAINERS.register("computer_terminal", () -> MenuRegistry.ofExtended(ComputerTerminalContainer::createClient));
    public static final RegistrySupplier<class_3917<RobotInventoryContainer>> ROBOT = CONTAINERS.register("robot", () -> MenuRegistry.ofExtended(RobotInventoryContainer::createClient));
    public static final RegistrySupplier<class_3917<RobotTerminalContainer>> ROBOT_TERMINAL = CONTAINERS.register("robot_terminal", () -> MenuRegistry.ofExtended(RobotTerminalContainer::createClient));
    public static final RegistrySupplier<class_3917<NetworkTunnelContainer>> NETWORK_TUNNEL = CONTAINERS.register("network_tunnel", () -> MenuRegistry.ofExtended(NetworkTunnelContainer::createClient));

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }
}
