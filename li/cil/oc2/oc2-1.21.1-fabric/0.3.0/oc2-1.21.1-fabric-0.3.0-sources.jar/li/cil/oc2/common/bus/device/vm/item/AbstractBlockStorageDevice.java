/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.vm.item;

import com.google.common.eventbus.Subscribe;
import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.vm.VMDevice;
import li.cil.oc2.api.bus.device.vm.VMDeviceLoadResult;
import li.cil.oc2.api.bus.device.vm.context.VMContext;
import li.cil.oc2.api.bus.device.vm.context.VMRuntime;
import li.cil.oc2.api.bus.device.vm.event.VMResumedRunningEvent;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.bus.device.util.OptionalAddress;
import li.cil.oc2.common.bus.device.util.OptionalInterrupt;
import li.cil.oc2.common.serialization.BlobStorage;
import li.cil.oc2.common.serialization.NBTSerialization;
import li.cil.oc2.common.util.Event;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.sedna.api.device.BlockDevice;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class AbstractBlockStorageDevice<TBlock extends BlockDevice, TIdentity> extends IdentityProxy<TIdentity> implements VMDevice, ItemDevice {
    protected static final Logger LOGGER = LogManager.getLogger();

    private static final String DEVICE_TAG_NAME = "device";
    private static final String ADDRESS_TAG_NAME = "address";
    private static final String INTERRUPT_TAG_NAME = "interrupt";
    private static final String BLOB_HANDLE_TAG_NAME = "blob";

    protected static final ExecutorService WORKERS = Executors.newFixedThreadPool(
        Math.max(1, Runtime.getRuntime().availableProcessors()), r -> {
            final Thread thread = new Thread(r, "Block Device Initializer");
            thread.setDaemon(true);
            return thread;
        });

    // --------------------------------------------------------------------- //

    protected boolean readonly;
    protected MappedStorage storage;
    protected Invalidatable<VMRuntime> runtime = Invalidatable.empty();
    private volatile CompletableFuture<Void> openJob;

    // --------------------------------------------------------------------- //

    // Online persisted data.
    private final OptionalAddress address = new OptionalAddress();
    private final OptionalInterrupt interrupt = new OptionalInterrupt();
    private class_2487 deviceTag;

    // Offline persisted data.
    @Nullable
    protected UUID blobHandle;

    // --------------------------------------------------------------------- //

    protected AbstractBlockStorageDevice(final TIdentity identity, final boolean readonly) {
        super(identity);
        this.readonly = readonly;
    }

    // --------------------------------------------------------------------- //

    @Override
    public VMDeviceLoadResult mount(final VMContext context) {
        runtime = context.getRuntime();

        if (allocateDevice(context) instanceof AllocationFailure(class_2561 message, boolean permanent)) {
            var result = failMount();
            if (message != null) {
                result = result.withErrorMessage(message);
            }
            return permanent ? result.asPermanent() : result;
        }

        final VMDeviceLoadResult claim = storage.claim(context, address, interrupt);
        if (!claim.wasSuccessful()) {
            releaseOnFailure();
            return claim.asPermanent();
        }

        context.getEventBus().register(this);

        if (deviceTag != null) {
            NBTSerialization.deserialize(deviceTag, storage.getDevice());
        }

        return VMDeviceLoadResult.success();
    }

    @Override
    public void unmount() {
        closeDevice();

        if (blobHandle != null) {
            BlobStorage.close(blobHandle);
        }
    }

    @Override
    public void dispose() {
        deviceTag = null;
        address.clear();
        interrupt.clear();
    }

    @Override
    public void exportToItemStack(final class_2487 nbt) {
        if (blobHandle != null) {
            nbt.method_25927(BLOB_HANDLE_TAG_NAME, blobHandle);
        }
    }

    @Override
    public void importFromItemStack(final class_2487 nbt) {
        if (nbt.method_25928(BLOB_HANDLE_TAG_NAME)) {
            blobHandle = nbt.method_25926(BLOB_HANDLE_TAG_NAME);
        }
    }

    @Override
    public class_2487 serializeNBT() {
        joinOpenJob();

        final class_2487 tag = new class_2487();

        if (blobHandle != null) {
            tag.method_25927(BLOB_HANDLE_TAG_NAME, blobHandle);
        }

        if (storage != null) {
            deviceTag = NBTSerialization.serialize(storage.getDevice());
        }
        if (deviceTag != null) {
            tag.method_10566(DEVICE_TAG_NAME, deviceTag);
        }
        if (address.isPresent()) {
            tag.method_10544(ADDRESS_TAG_NAME, address.getAsLong());
        }
        if (interrupt.isPresent()) {
            tag.method_10569(INTERRUPT_TAG_NAME, interrupt.getAsInt());
        }

        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        if (tag.method_25928(BLOB_HANDLE_TAG_NAME)) {
            blobHandle = tag.method_25926(BLOB_HANDLE_TAG_NAME);
        }

        if (tag.method_10573(DEVICE_TAG_NAME, NBTTagIds.TAG_COMPOUND)) {
            deviceTag = tag.method_10562(DEVICE_TAG_NAME);
        }
        if (tag.method_10573(ADDRESS_TAG_NAME, NBTTagIds.TAG_LONG)) {
            address.set(tag.method_10537(ADDRESS_TAG_NAME));
        }
        if (tag.method_10573(INTERRUPT_TAG_NAME, NBTTagIds.TAG_INT)) {
            interrupt.set(tag.method_10550(INTERRUPT_TAG_NAME));
        }
    }

    public static void unmount(final class_2487 tag) {
        if (tag.method_25928(BLOB_HANDLE_TAG_NAME)) {
            final UUID blobHandle = tag.method_25926(BLOB_HANDLE_TAG_NAME);
            BlobStorage.close(blobHandle);
        }
    }

    @Subscribe
    public void handleResumedRunningEvent(final VMResumedRunningEvent event) {
        joinOpenJob();
    }

    // --------------------------------------------------------------------- //

    protected void setOpenJob(final CompletableFuture<Void> job) {
        joinOpenJob();
        openJob = job;
    }

    protected void joinOpenJob() {
        if (openJob != null) {
            try {
                openJob.join();
            } catch (final CompletionException e) {
                LOGGER.error(e);
            } finally {
                openJob = null;
            }
        }
    }

    protected abstract int getMappedByteCount();

    protected abstract CompletableFuture<TBlock> createBlockDevice() throws IOException;

    protected void setBlockDevice(final BlockDevice blockDevice) throws IOException {
        storage.setBlockDevice(withAccessListener(blockDevice));
    }

    protected MappedStorage createStorage(final VMContext context) {
        return new VirtIOStorage(context, readonly);
    }

    protected void handleDataAccess() {
    }

    protected void handleDataUnavailable() {
    }

    protected boolean handleDataStale() {
        return true;
    }

    protected final BlockDevice withAccessListener(final BlockDevice block) {
        final ListenableBlockDevice listenable = new ListenableBlockDevice(block);
        listenable.onAccess.add(this::handleDataAccess);
        return listenable;
    }

    // --------------------------------------------------------------------- //

    private AllocationResult allocateDevice(final VMContext context) {
        final long claim = (long) Constants.PAGE_SIZE + getMappedByteCount();
        if (!context.getMemoryAllocator().claimMemory((int) Math.min(Integer.MAX_VALUE, claim))) {
            return new AllocationFailure(true);
        }

        if (BlobStorage.isStaleHandle(blobHandle) && !handleDataStale()) {
            return new AllocationFailure(class_2561.method_43471(Constants.COMPUTER_ERROR_STORAGE_INCONSISTENT), true);
        }

        storage = createStorage(context);

        final CompletableFuture<TBlock> job;
        try {
            job = createBlockDevice();
        } catch (final BlobStorage.BlobStorageFullException e) {
            LOGGER.error(e);
            return new AllocationFailure(class_2561.method_43471(Constants.COMPUTER_ERROR_STORAGE_FULL), false);
        } catch (final BlobStorage.BlobMissingException | BlobStorage.BlobInUseException e) {
            handleDataUnavailable();
            return new AllocationFailure(class_2561.method_43471(Constants.COMPUTER_ERROR_STORAGE_CORRUPTED), true);
        } catch (final IOException e) {
            LOGGER.error(e);
            return new AllocationFailure(false);
        }

        setOpenJob(job.thenAcceptAsync(blockDevice -> {
            try {
                setBlockDevice(blockDevice);
            } catch (final IOException e) {
                throw new RuntimeException(e);
            }
        }, WORKERS));

        return new AllocationSuccess();
    }

    private void closeDevice() {
        // Join the init job before releasing the device to avoid writes from thread to closed device.
        // Since we use memory mapped memory, closing the device leads to it holding a dead pointer,
        // meaning further access to it will hard-crash the JVM.
        joinOpenJob();

        if (storage == null) {
            return;
        }

        try {
            storage.close();
        } catch (final IOException e) {
            LOGGER.error(e);
        }

        storage = null;
    }

    private VMDeviceLoadResult failMount() {
        releaseOnFailure();
        return VMDeviceLoadResult.fail();
    }

    private void releaseOnFailure() {
        closeDevice();

        if (blobHandle != null) {
            BlobStorage.close(blobHandle);
        }
    }

    // --------------------------------------------------------------------- //

    private sealed interface AllocationResult permits AllocationSuccess, AllocationFailure {
    }

    private record AllocationSuccess() implements AllocationResult {
    }

    private record AllocationFailure(@Nullable class_2561 message, boolean permanent) implements AllocationResult {
        public AllocationFailure(final boolean permanent) {
            this(null, permanent);
        }
    }

    private static final class ListenableBlockDevice implements BlockDevice {
        private final BlockDevice inner;

        public final Event onAccess = new Event();

        private ListenableBlockDevice(final BlockDevice inner) {
            this.inner = inner;
        }

        @Override
        public boolean isReadonly() {
            return inner.isReadonly();
        }

        @Override
        public long getCapacity() {
            return inner.getCapacity();
        }

        @Override
        public InputStream getInputStream(final long offset) {
            final ListenableInputStream stream = new ListenableInputStream(inner.getInputStream(offset));
            stream.onAccess.add(onAccess);
            return stream;
        }

        @Override
        public OutputStream getOutputStream(final long offset) {
            final ListenableOutputStream stream = new ListenableOutputStream(inner.getOutputStream(offset));
            stream.onAccess.add(onAccess);
            return stream;
        }

        @Override
        public void flush() {
            inner.flush();
        }

        @Override
        public void close() throws IOException {
            inner.close();
        }
    }

    private static final class ListenableInputStream extends InputStream {
        private final InputStream inner;

        public final Event onAccess = new Event();

        private ListenableInputStream(final InputStream inner) {
            this.inner = inner;
        }

        @Override
        public int read() throws IOException {
            onAccess();
            return inner.read();
        }

        @Override
        public int read(final byte[] b) throws IOException {
            onAccess();
            return inner.read(b);
        }

        @Override
        public int read(final byte[] b, final int off, final int len) throws IOException {
            onAccess();
            return inner.read(b, off, len);
        }

        @Override
        public long skip(final long n) throws IOException {
            onAccess();
            return inner.skip(n);
        }

        @Override
        public int available() throws IOException {
            return inner.available();
        }

        @Override
        public void close() throws IOException {
            inner.close();
        }

        @Override
        public synchronized void mark(final int limit) {
            inner.mark(limit);
        }

        @Override
        public synchronized void reset() throws IOException {
            onAccess();
            inner.reset();
        }

        @Override
        public boolean markSupported() {
            return inner.markSupported();
        }

        private void onAccess() {
            onAccess.run();
        }
    }

    private static final class ListenableOutputStream extends OutputStream {
        private final OutputStream inner;

        public final Event onAccess = new Event();

        private ListenableOutputStream(final OutputStream inner) {
            this.inner = inner;
        }

        @Override
        public void write(final int b) throws IOException {
            onAccess();
            inner.write(b);
        }

        @Override
        public void write(final byte[] b) throws IOException {
            onAccess();
            inner.write(b);
        }

        @Override
        public void write(final byte[] b, final int off, final int len) throws IOException {
            onAccess();
            inner.write(b, off, len);
        }

        @Override
        public void flush() throws IOException {
            inner.flush();
        }

        @Override
        public void close() throws IOException {
            inner.close();
        }

        private void onAccess() {
            onAccess.run();
        }
    }
}
