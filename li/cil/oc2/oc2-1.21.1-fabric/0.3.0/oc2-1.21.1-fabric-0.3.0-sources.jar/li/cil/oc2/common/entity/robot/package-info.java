/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.entity.robot;

import javax.annotation.ParametersAreNonnullByDefault;
