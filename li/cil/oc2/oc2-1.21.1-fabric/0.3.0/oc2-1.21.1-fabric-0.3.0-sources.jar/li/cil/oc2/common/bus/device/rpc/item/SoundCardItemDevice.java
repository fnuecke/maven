/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.item;

import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.Parameter;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.util.BlockLocation;
import li.cil.oc2.common.util.TickUtils;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import javax.annotation.Nullable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

public final class SoundCardItemDevice extends AbstractItemRPCDevice {
    private final int COOLDOWN_IN_TICKS = TickUtils.toTicks(Duration.ofSeconds(Config.soundCardCoolDownSeconds));
    private static final int MAX_FIND_RESULTS = 25;

    // --------------------------------------------------------------------- //

    private final Supplier<Optional<BlockLocation>> location;
    private long gameTimeCooldownExpiresAt;

    // --------------------------------------------------------------------- //

    public SoundCardItemDevice(final class_1799 identity, final Supplier<Optional<BlockLocation>> location) {
        super(identity, "sound");
        this.location = location;
    }

    // --------------------------------------------------------------------- //

    @Callback
    public void playSound(@Nullable @Parameter("name") final String name) {
        playSound(name, 1, 1);
    }

    @Callback
    public void playSound(@Nullable @Parameter("name") final String name, @Parameter("volume") final float volume) {
        playSound(name, volume, 1);
    }

    @Callback
    public void playSound(@Nullable @Parameter("name") final String name, @Parameter("volume") final float volume, @Parameter("pitch") final float pitch) {
        if (name == null) throw new IllegalArgumentException();
        if (volume < 0 || volume > 1.0f) throw new IllegalArgumentException("volume must be between >= 0 and <= 1");
        if (pitch < 0.5f || pitch > 2.0f) throw new IllegalArgumentException("pitch must be between >= 0.5 and <= 2");
        if (volume == 0) return;

        location.get().ifPresent(location -> location.tryGetLevel().ifPresent(level -> {
            if (!(level instanceof final class_3218 serverLevel)) {
                return;
            }

            final long gameTime = serverLevel.method_8510();
            if (gameTime < gameTimeCooldownExpiresAt) {
                return;
            }

            gameTimeCooldownExpiresAt = gameTime + COOLDOWN_IN_TICKS;

            final class_3414 soundEvent = class_7923.field_41172.method_10223(class_2960.method_60654(name));
            if (soundEvent == null) throw new IllegalArgumentException("Sound not found.");
            level.method_8396(null, location.blockPos(), soundEvent, class_3419.field_15245, volume, pitch);
        }));
    }

    @Callback
    public List<String> findSound(@Nullable @Parameter("name") final String name) {
        if (name == null || name.length() == 0) throw new IllegalArgumentException();

        final ArrayList<String> matches = new ArrayList<>();

        for (final class_2960 key : class_7923.field_41172.method_10235()) {
            final String keyName = key.toString();
            if (keyName.contains(name)) {
                matches.add(keyName);
                if (matches.size() >= MAX_FIND_RESULTS) {
                    break;
                }
            }
        }

        return matches;
    }
}
