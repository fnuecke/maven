/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.util;

import dev.architectury.registry.registries.Registrar;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.provider.BlockDeviceProvider;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.bus.device.provider.ItemDeviceProvider;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.api.bus.device.vm.ArchitectureType;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.bus.device.provider.Providers;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public final class Devices {
    public static BlockDeviceQuery makeQuery(@Nullable final ArchitectureType architectureType, final class_1936 level, final class_2338 pos, @Nullable final class_2350 side) {
        return new BlockQuery(architectureType, level, pos, side);
    }

    public static ItemDeviceQuery makeQuery(final class_1799 stack) {
        return new ItemQuery(null, null, null, stack);
    }

    public static ItemDeviceQuery makeQuery(@Nullable final ArchitectureType architectureType, final class_2586 blockEntity, final class_1799 stack) {
        return new ItemQuery(architectureType, blockEntity, null, stack);
    }

    public static ItemDeviceQuery makeQuery(@Nullable final ArchitectureType architectureType, final class_1297 entity, final class_1799 stack) {
        return new ItemQuery(architectureType, null, entity, stack);
    }

    public static Optional<List<Invalidatable<BlockDeviceInfo>>> getDevices(final BlockDeviceQuery query) {
        final class_1923 queryChunk = new class_1923(query.getQueryPosition());
        if (!query.getLevel().method_8393(queryChunk.field_9181, queryChunk.field_9180)) {
            return Optional.empty();
        }

        final Registrar<BlockDeviceProvider> registry = Providers.blockDeviceProviderRegistry();
        final ArrayList<Invalidatable<BlockDeviceInfo>> devices = new ArrayList<>();
        for (final BlockDeviceProvider provider : registry) {
            final Invalidatable<Device> device = provider.getDevice(query);
            if (device.isPresent()) {
                devices.add(device.mapWithDependency(d -> new BlockDeviceInfo(provider, d)));
            }
        }

        return Optional.of(devices);
    }

    public static List<ItemDeviceInfo> getDevices(final ItemDeviceQuery query) {
        if (query.getItemStack().method_7960()) {
            return Collections.emptyList();
        }

        final Registrar<ItemDeviceProvider> registry = Providers.itemDeviceProviderRegistry();
        final ArrayList<ItemDeviceInfo> devices = new ArrayList<>();
        for (final ItemDeviceProvider provider : registry) {
            final Optional<ItemDevice> device = provider.getDevice(query);
            device.ifPresent(d -> devices.add(new ItemDeviceInfo(provider, d, provider.getEnergyConsumption(query))));
        }
        return devices;
    }

    public static int getEnergyConsumption(final ItemDeviceQuery query) {
        if (query.getItemStack().method_7960()) {
            return 0;
        }

        final Registrar<ItemDeviceProvider> registry = Providers.itemDeviceProviderRegistry();
        long accumulator = 0;
        for (final ItemDeviceProvider provider : registry) {
            accumulator += Math.max(0, provider.getEnergyConsumption(query));
        }
        if (accumulator > Integer.MAX_VALUE) {
            return Integer.MAX_VALUE;
        } else {
            return (int) accumulator;
        }
    }

    // --------------------------------------------------------------------- //

    private record BlockQuery(
        @Nullable ArchitectureType architectureType,
        class_1936 level,
        class_2338 pos,
        @Nullable class_2350 side
    ) implements BlockDeviceQuery {
        @Override
        public Optional<ArchitectureType> getArchitectureType() {
            return Optional.ofNullable(architectureType);
        }

        @Override
        public class_1936 getLevel() {
            return level;
        }

        @Override
        public class_2338 getQueryPosition() {
            return pos;
        }

        @Nullable
        @Override
        public class_2350 getQuerySide() {
            return side;
        }
    }

    private record ItemQuery(
        @Nullable ArchitectureType architectureType,
        @Nullable class_2586 blockEntity,
        @Nullable class_1297 entity,
        class_1799 stack
    ) implements ItemDeviceQuery {
        @Override
        public Optional<ArchitectureType> getArchitectureType() {
            return Optional.ofNullable(architectureType);
        }

        @Override
        public Optional<class_2586> getContainerBlockEntity() {
            return Optional.ofNullable(blockEntity);
        }

        @Override
        public Optional<class_1297> getContainerEntity() {
            return Optional.ofNullable(entity);
        }

        @Override
        public class_1799 getItemStack() {
            return stack;
        }
    }
}
