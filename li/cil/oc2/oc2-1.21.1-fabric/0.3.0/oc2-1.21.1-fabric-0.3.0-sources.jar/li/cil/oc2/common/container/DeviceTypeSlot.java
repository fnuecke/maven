/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import com.mojang.datafixers.util.Pair;
import li.cil.oc2.api.bus.device.DeviceType;
import net.minecraft.class_1263;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;

public final class DeviceTypeSlot extends class_1735 {
    private final DeviceType deviceType;

    public DeviceTypeSlot(final class_1263 container, final DeviceType deviceType, final int index, final int x, final int y) {
        super(container, index, x, y);
        this.deviceType = deviceType;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Override
    public boolean method_7680(@NotNull final class_1799 stack) {
        return super.method_7680(stack) && stack.method_31573(deviceType.getTag());
    }

    @Nullable
    @Override
    public Pair<class_2960, class_2960> method_7679() {
        if (method_7681()) {
            return super.method_7679();
        } else {
            return Pair.of(class_1723.field_21668, deviceType.getBackgroundIcon());
        }
    }
}
