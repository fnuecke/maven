/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.util;

import li.cil.oc2.api.bus.device.DeviceType;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

public final class DeviceTypeImpl implements DeviceType {
    private final class_6862<class_1792> tag;
    private final class_2960 icon;
    private final class_2561 name;

    public DeviceTypeImpl(final class_6862<class_1792> tag, final class_2960 icon, final class_2561 name) {
        this.tag = tag;
        this.icon = icon;
        this.name = name;
    }

    @Override
    public class_6862<class_1792> getTag() {
        return tag;
    }

    @Override
    public class_2960 getBackgroundIcon() {
        return icon;
    }

    @Override
    public class_2561 getName() {
        return name;
    }
}
