/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.bus.AbstractItemDeviceBusElement;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public abstract class AbstractDeviceItemStackHandler extends FixedSizeItemStackHandler {
    public AbstractDeviceItemStackHandler(final int size) {
        this(class_2371.method_10213(size, class_1799.field_8037));
    }

    public AbstractDeviceItemStackHandler(final class_2371<class_1799> stacks) {
        super(stacks);
    }

    // --------------------------------------------------------------------- //

    public abstract AbstractItemDeviceBusElement getBusElement();

    public void exportDeviceDataToItemStacks() {
        for (int slot = 0; slot < getSlots(); slot++) {
            getBusElement().exportDeviceDataToItemStack(slot, getStackInSlot(slot));
        }
    }

    @Override
    public final class_2487 serializeNBT(final class_7225.class_7874 registries) {
        throw new UnsupportedOperationException("Use saveItems and saveDevices instead.");
    }

    @Override
    public final void deserializeNBT(final class_7225.class_7874 registries, final class_2487 tag) {
        throw new UnsupportedOperationException("Use loadItems and loadDevices instead.");
    }

    public class_2487 saveItems(final class_7225.class_7874 registries) {
        exportDeviceDataToItemStacks();

        return super.serializeNBT(registries);
    }

    public class_2487 saveDevices() {
        return getBusElement().save();
    }

    public void loadItems(final class_7225.class_7874 registries, final class_2487 tag) {
        super.deserializeNBT(registries, tag);
        updateDevices();
    }

    public void updateDevices() {
        for (int slot = 0; slot < getSlots(); slot++) {
            getBusElement().handleSlotContentsChanged(slot, getStackInSlot(slot));
        }
    }

    public void loadDevices(final class_2487 tag) {
        getBusElement().load(tag);
    }

    @Override
    public class_1799 getStackInSlot(final int slot) {
        final class_1799 stack = super.getStackInSlot(slot);
        getBusElement().exportDeviceDataToItemStack(slot, stack);
        return stack;
    }

    @Override
    public class_1799 extractItem(final int slot, final int amount, final boolean simulate) {
        if (!simulate && amount > 0) {
            getBusElement().exportDeviceDataToItemStack(slot, super.getStackInSlot(slot));
        }

        return super.extractItem(slot, amount, simulate);
    }

    @Override
    public int getSlotLimit(final int slot) {
        return 1;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void onContentsChanged(final int slot) {
        super.onContentsChanged(slot);
        getBusElement().handleSlotContentsChanged(slot, super.getStackInSlot(slot));
    }
}
