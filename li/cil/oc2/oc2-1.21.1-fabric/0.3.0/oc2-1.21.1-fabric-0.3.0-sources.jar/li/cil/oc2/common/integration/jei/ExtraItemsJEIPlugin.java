/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.integration.jei;

import com.google.common.base.Strings;
import li.cil.oc2.api.API;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.NBTUtils;
import li.cil.oc2.common.util.StorageItemUtils;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.ingredients.subtypes.IIngredientSubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import mezz.jei.api.registration.ISubtypeRegistration;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2514;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import javax.annotation.Nullable;

import static li.cil.oc2.common.Constants.ITEMS_TAG_NAME;

@JeiPlugin
public class ExtraItemsJEIPlugin implements IModPlugin {
    @Override
    public class_2960 getPluginUid() {
        return class_2960.method_60655(API.MOD_ID, "extra_items");
    }

    @Override
    public void registerItemSubtypes(final ISubtypeRegistration registration) {
        registration.registerSubtypeInterpreter(VanillaTypes.ITEM_STACK, Items.COMPUTER.get(), new ComputerSubtypeInterpreter());
        registration.registerSubtypeInterpreter(VanillaTypes.ITEM_STACK, Items.ROBOT.get(), new RobotSubtypeInterpreter());
        registration.registerSubtypeInterpreter(VanillaTypes.ITEM_STACK, Items.HARD_DRIVE_LARGE.get(), new ImageSubtypeInterpreter());
        registration.registerSubtypeInterpreter(VanillaTypes.ITEM_STACK, Items.FLASH_MEMORY.get(), new ImageSubtypeInterpreter());
        registration.registerSubtypeInterpreter(VanillaTypes.ITEM_STACK, Items.FLOPPY.get(), new ImageSubtypeInterpreter());
    }

    private static final class ComputerSubtypeInterpreter implements IIngredientSubtypeInterpreter<class_1799> {
        @Override
        public String apply(final class_1799 ingredient, final UidContext context) {
            final class_2487 itemsTag = NBTUtils.getChildTag(ItemStackUtils.getBlockEntityDataTag(ingredient), ITEMS_TAG_NAME);
            return itemsTag.method_33133() ? NONE : stableTagToString(itemsTag);
        }
    }

    private static final class RobotSubtypeInterpreter implements IIngredientSubtypeInterpreter<class_1799> {
        @Override
        public String apply(final class_1799 ingredient, final UidContext context) {
            final class_2487 itemsTag = NBTUtils.getChildTag(ItemStackUtils.getModDataTag(ingredient), ITEMS_TAG_NAME);
            return itemsTag.method_33133() ? NONE : stableTagToString(itemsTag);
        }
    }

    private static final class ImageSubtypeInterpreter implements IIngredientSubtypeInterpreter<class_1799> {
        @Override
        public String apply(final class_1799 ingredient, final UidContext context) {
            final String registryName = ItemStackUtils.getModDataTag(ingredient).method_10558(StorageItemUtils.IMAGE_TAG_NAME);
            return Strings.isNullOrEmpty(registryName) ? NONE : registryName;
        }
    }

    private static String stableTagToString(@Nullable final class_2520 tag) {
        final StringBuilder stringBuilder = new StringBuilder();
        stableTagToString(tag, stringBuilder);
        return stringBuilder.toString();
    }

    private static void stableTagToString(@Nullable final class_2520 tag, final StringBuilder stringBuilder) {
        if (tag == null) {
            stringBuilder.append("null");
        }
        if (tag instanceof class_2487 compoundTag) {
            stringBuilder.append("{");
            compoundTag.method_10541().stream().sorted().forEach(key -> {
                stringBuilder.append(key).append(":");
                stableTagToString(compoundTag.method_10580(key), stringBuilder);
                stringBuilder.append(",");
            });
            stringBuilder.setLength(stringBuilder.length() - 1); // remove last comma
            stringBuilder.append("}");
        } else if (tag instanceof class_2499 listTag) {
            stringBuilder.append("[");
            for (final class_2520 childTag : listTag) {
                stableTagToString(childTag, stringBuilder);
                stringBuilder.append(",");
            }
            stringBuilder.setLength(stringBuilder.length() - 1); // remove last comma
            stringBuilder.append("]");
        } else if (tag instanceof class_2514 numericTag) {
            stringBuilder.append(numericTag.method_10702());
        } else {
            stringBuilder.append(tag);
        }
    }
}
