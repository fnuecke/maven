/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
