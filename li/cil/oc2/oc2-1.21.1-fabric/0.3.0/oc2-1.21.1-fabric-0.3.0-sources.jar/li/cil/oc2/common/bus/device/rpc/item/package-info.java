/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.bus.device.rpc.item;

import javax.annotation.ParametersAreNonnullByDefault;
