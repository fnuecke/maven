/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.audio;

import li.cil.oc2.common.util.TickUtils;
import net.minecraft.class_1101;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import java.time.Duration;

public final class LoopingBlockEntitySound extends class_1101 {
    private static final float FADE_IN_DURATION_IN_TICKS = TickUtils.toTicks(Duration.ofSeconds(2));
    private static final float FADE_IN_PER_TICK = 1f / FADE_IN_DURATION_IN_TICKS;

    // --------------------------------------------------------------------- //

    private final class_2586 blockEntity;
    private boolean isCanceled;

    // --------------------------------------------------------------------- //

    public LoopingBlockEntitySound(final class_2586 blockEntity, final class_3414 sound) {
        super(sound, class_3419.field_15245, class_5819.method_43047());
        this.blockEntity = blockEntity;
        this.field_5442 = 0;

        final class_243 position = class_243.method_24953(blockEntity.method_11016());
        field_5439 = position.field_1352;
        field_5450 = position.field_1351;
        field_5449 = position.field_1350;

        field_5446 = true;
    }

    // --------------------------------------------------------------------- //

    public void cancel() {
        isCanceled = true;
    }

    @Override
    public void method_16896() {
        field_5442 = class_3532.method_15363(field_5442 + FADE_IN_PER_TICK, 0, 1);
        final class_1923 chunkPos = new class_1923(blockEntity.method_11016());
        if (blockEntity.method_11015() || blockEntity.method_10997() == null || !blockEntity.method_10997().method_8393(chunkPos.field_9181, chunkPos.field_9180)) {
            method_24876();
        }
    }

    @Override
    public boolean method_26273() {
        return !isCanceled;
    }
}
