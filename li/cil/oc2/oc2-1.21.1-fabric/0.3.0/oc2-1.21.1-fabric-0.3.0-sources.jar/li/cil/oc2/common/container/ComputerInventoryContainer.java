/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.energy.EnergyStorage;
import li.cil.oc2.common.vm.VMItemStackHandlers;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3222;

public final class ComputerInventoryContainer extends AbstractComputerContainer {
    public static void createServer(final ComputerBlockEntity computer, final EnergyStorage energy, final CommonDeviceBusController busController, final class_3222 player) {
        MenuRegistry.openExtendedMenu(player, new ExtendedMenuProvider() {
            @Override
            public class_2561 method_5476() {
                return class_2561.method_43471(computer.method_11010().method_26204().method_9539());
            }

            @Override
            public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                return new ComputerInventoryContainer(id, computer, player, createEnergyInfo(energy, busController));
            }

            @Override
            public void saveExtraData(final class_2540 buffer) {
                buffer.method_10807(computer.method_11016());
            }
        });
    }

    public static ComputerInventoryContainer createClient(final int id, final class_1661 playerInventory, final class_2540 data) {
        final class_2338 pos = data.method_10811();
        final class_2586 blockEntity = playerInventory.field_7546.method_37908().method_8321(pos);
        if (blockEntity instanceof final ComputerBlockEntity computer) {
            return new ComputerInventoryContainer(id, computer, playerInventory.field_7546, createClientEnergyInfo());
        }

        throw new IllegalArgumentException();
    }

    // --------------------------------------------------------------------- //

    private ComputerInventoryContainer(final int id, final ComputerBlockEntity computer, final class_1657 player, final IntPrecisionContainerData energyInfo) {
        super(Containers.COMPUTER.get(), id, player, computer, energyInfo);

        final VMItemStackHandlers handlers = computer.getItemStackHandlers();

        handlers.getItemHandler(DeviceTypes.CPU.get()).ifPresent(itemHandler -> {
            if (itemHandler.getSlots() > 0) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.CPU.get(), 0, 64, 52));
            }
        });

        handlers.getItemHandler(DeviceTypes.FLASH_MEMORY.get()).ifPresent(itemHandler -> {
            if (itemHandler.getSlots() > 0) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.FLASH_MEMORY.get(), 0, 64, 78));
            }
        });

        handlers.getItemHandler(DeviceTypes.MEMORY.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.MEMORY.get(), slot, 64 + slot * SLOT_SIZE, 24));
            }
        });

        handlers.getItemHandler(DeviceTypes.HARD_DRIVE.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.HARD_DRIVE.get(), slot, 100 + slot % 2 * SLOT_SIZE, 60 + slot / 2 * SLOT_SIZE));
            }
        });

        handlers.getItemHandler(DeviceTypes.CARD.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.CARD.get(), slot, 38, 24 + slot * SLOT_SIZE));
            }
        });

        createPlayerInventoryAndHotbarSlots(player.method_31548(), 8, 115);
    }
}
