/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import li.cil.oc2.client.gui.BusInterfaceScreen;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.integration.Wrenches;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.LevelUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1928;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_310;
import net.minecraft.class_3542;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_8567;
import net.minecraft.class_9062;
import net.minecraft.world.level.*;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class BusCableBlock extends class_2237 {
    public static final MapCodec<BusCableBlock> field_46280 = MapCodec.unit(BusCableBlock::new);

    @Override
    protected MapCodec<? extends BusCableBlock> method_53969() {
        return field_46280;
    }

    public enum ConnectionType implements class_3542 {
        NONE,
        CABLE,
        INTERFACE;

        @Override
        public String method_15434() {
            return switch (this) {
                case NONE -> "none";
                case CABLE -> "cable";
                case INTERFACE -> "interface";
            };
        }
    }

    // --------------------------------------------------------------------- //

    public static final class_2746 HAS_CABLE = class_2746.method_11825("has_cable");
    public static final class_2746 HAS_FACADE = class_2746.method_11825("has_facade");
    public static final class_2754<ConnectionType> CONNECTION_NORTH = class_2754.method_11850("connection_north", ConnectionType.class);
    public static final class_2754<ConnectionType> CONNECTION_EAST = class_2754.method_11850("connection_east", ConnectionType.class);
    public static final class_2754<ConnectionType> CONNECTION_SOUTH = class_2754.method_11850("connection_south", ConnectionType.class);
    public static final class_2754<ConnectionType> CONNECTION_WEST = class_2754.method_11850("connection_west", ConnectionType.class);
    public static final class_2754<ConnectionType> CONNECTION_UP = class_2754.method_11850("connection_up", ConnectionType.class);
    public static final class_2754<ConnectionType> CONNECTION_DOWN = class_2754.method_11850("connection_down", ConnectionType.class);

    public static final Map<class_2350, class_2754<ConnectionType>> FACING_TO_CONNECTION_MAP = class_156.method_654(Maps.newEnumMap(class_2350.class), directions -> {
        directions.put(class_2350.field_11043, CONNECTION_NORTH);
        directions.put(class_2350.field_11034, CONNECTION_EAST);
        directions.put(class_2350.field_11035, CONNECTION_SOUTH);
        directions.put(class_2350.field_11039, CONNECTION_WEST);
        directions.put(class_2350.field_11036, CONNECTION_UP);
        directions.put(class_2350.field_11033, CONNECTION_DOWN);
    });

    public static ConnectionType getConnectionType(final class_2680 state, @Nullable final class_2350 direction) {
        if (direction != null) {
            return state.method_11654(BusCableBlock.FACING_TO_CONNECTION_MAP.get(direction));
        } else {
            return ConnectionType.NONE;
        }
    }

    public static int getInterfaceCount(final class_2680 state) {
        int partCount = 0;
        for (final class_2754<ConnectionType> connectionType : FACING_TO_CONNECTION_MAP.values()) {
            if (state.method_11654(connectionType) == ConnectionType.INTERFACE) {
                partCount++;
            }
        }
        return partCount;
    }

    public static class_2350 getHitSide(final class_2338 pos, final class_3965 hit) {
        final class_243 localHitPos = hit.method_17784().method_1020(class_243.method_24953(pos));
        return class_2350.method_10142(localHitPos.field_1352, localHitPos.field_1351, localHitPos.field_1350);
    }

    // --------------------------------------------------------------------- //

    private final class_265[] shapes;

    // --------------------------------------------------------------------- //

    public BusCableBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));

        class_2680 defaultState = method_9595().method_11664();
        for (final class_2754<ConnectionType> property : FACING_TO_CONNECTION_MAP.values()) {
            defaultState = defaultState.method_11657(property, ConnectionType.NONE);
        }
        defaultState = defaultState.method_11657(HAS_CABLE, true);
        defaultState = defaultState.method_11657(HAS_FACADE, false);
        method_9590(defaultState);

        shapes = makeShapes();
    }

    // --------------------------------------------------------------------- //

    public static boolean addInterface(final class_1937 level, final class_2338 pos, final class_2680 state, final class_2350 side) {
        if (state.method_26204() != Blocks.BUS_CABLE.get()) {
            return false;
        }

        if (state.method_11654(HAS_FACADE)) {
            return false;
        }

        final class_2754<BusCableBlock.ConnectionType> property = FACING_TO_CONNECTION_MAP.get(side);
        if (state.method_11654(property) != ConnectionType.NONE) {
            return false;
        }

        level.method_8652(pos, state.method_11657(property, ConnectionType.INTERFACE), class_2248.field_31022);

        onConnectionTypeChanged(level, pos, side, false);

        return true;
    }

    public static boolean addCable(final class_1937 level, final class_2338 pos, final class_2680 state) {
        if (state.method_26204() != Blocks.BUS_CABLE.get()) {
            return false;
        }

        if (state.method_11654(HAS_CABLE)) {
            return false;
        }

        level.method_8652(pos, state.method_11657(HAS_CABLE, true), class_2248.field_31022);

        onConnectionTypeChanged(level, pos, null, false);

        return true;
    }

    public static void setHasFacade(final class_1937 level, final class_2338 pos, final class_2680 state, @Nullable final class_2680 facadeState, final boolean value) {
        if (state.method_11654(HAS_FACADE) == value) {
            return;
        }

        level.method_8652(pos, state.method_11657(HAS_FACADE, value), class_2248.field_31022);

        if (!level.method_8608()) {
            final class_2680 soundsSource = facadeState != null ? facadeState : state;
            LevelUtils.playSound(level, pos, soundsSource.method_26231(), value ? class_2498::method_10598 : class_2498::method_10595);
        }
    }

    @Override
    public void method_9612(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2248 changedBlock, final class_2338 changedBlockPos, final boolean isMoving) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final BusCableBlockEntity busCable) {
            busCable.handleNeighborChanged(changedBlockPos);
        }
    }

    @Override
    protected class_9062 method_55765(final class_1799 heldItem, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        if (heldItem.method_7909() == Items.BUS_CABLE.get() ||
            heldItem.method_7909() == Items.BUS_INTERFACE.get()) {
            return class_9062.field_47732;
        }

        final class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof final BusCableBlockEntity busCableBlockEntity)) {
            return super.method_55765(heldItem, state, level, pos, player, hand, hit);
        }

        if (Wrenches.isWrench(heldItem)) {
            if (player.method_5715()) {
                final class_1799 facadeItem = busCableBlockEntity.getFacade();
                if (!facadeItem.method_7960()) {
                    if (!level.method_8608()) {
                        busCableBlockEntity.removeFacade();
                        if (!player.method_7337() && level.method_8450().method_8355(class_1928.field_19392)) {
                            ItemStackUtils.spawnAsEntity(level, pos, facadeItem, hit.method_17780()).ifPresent(entity -> {
                                entity.method_6975();
                                entity.method_5694(player);
                            });
                        }
                    }
                    return class_9062.method_55644(level.method_8608());
                } else {
                    // NB: leave wrenching logic up to wrench when the to-be-removed interface is the last
                    //     part of this bus. This ensures we properly remove the block itself without having
                    //     to duplicate the logic needed for that.
                    if (getPartCount(state) > 1 && (tryRemoveInterface(state, level, pos, player, hit) || tryRemoveCable(state, level, pos, player))) {
                        return class_9062.method_55644(level.method_8608());
                    }
                }
            } else if (level.method_8608()) {
                final class_2350 side = getHitSide(pos, hit);
                if (getConnectionType(state, side) == ConnectionType.INTERFACE) {
                    openBusInterfaceScreen(busCableBlockEntity, side);
                    return class_9062.method_55644(level.method_8608());
                }
            }
        } else if (!player.method_5715() && !state.method_11654(HAS_FACADE) && getInterfaceCount(state) == 0) {
            switch (busCableBlockEntity.getFacadeType(heldItem)) {
                case INVALID_BLOCK -> {
                    if (!level.method_8608()) {
                        player.method_7353(text("message.{mod}.invalid_facade_block"), true);
                    }

                    // Always return success (even on failure) to avoid accidentally placing blocks.
                    return class_9062.method_55644(level.method_8608());
                }
                case VALID_BLOCK -> {
                    if (!level.method_8608()) {
                        busCableBlockEntity.setFacade(heldItem);
                        if (!player.method_31549().field_7477) {
                            heldItem.method_7934(1);
                        }
                    }
                    return class_9062.method_55644(level.method_8608());
                }
            }
        }

        return super.method_55765(heldItem, state, level, pos, player, hand, hit);
    }

    @Override
    protected List<class_1799> method_9560(final class_2680 state, final class_8567.class_8568 builder) {
        final List<class_1799> drops = new ArrayList<>(super.method_9560(state, builder));

        if (state.method_11654(HAS_FACADE)) {
            final class_2586 blockEntity = builder.method_51876(class_181.field_1228);
            if (blockEntity instanceof final BusCableBlockEntity busCable) {
                final class_1799 stack = busCable.getFacade();
                if (!stack.method_7960()) {
                    drops.add(stack);
                }
            }
        }

        if (state.method_11654(HAS_CABLE)) {
            drops.add(new class_1799(Items.BUS_CABLE.get()));
        }

        int interfaceCount = 0;
        for (final class_2350 side : Constants.DIRECTIONS) {
            final ConnectionType connectionType = state.method_11654(FACING_TO_CONNECTION_MAP.get(side));
            if (connectionType == ConnectionType.INTERFACE) {
                interfaceCount++;
            }
        }

        if (interfaceCount > 0) {
            drops.add(new class_1799(Items.BUS_INTERFACE.get(), interfaceCount));
        }

        return drops;
    }

    @Override
    public class_2680 method_9605(final class_1750 context) {
        class_2680 state = method_9564();

        final class_1937 level = context.method_8045();
        final class_2338 position = context.method_8037();
        for (final Map.Entry<class_2350, class_2754<ConnectionType>> entry : FACING_TO_CONNECTION_MAP.entrySet()) {
            final class_2350 facing = entry.getKey();
            final class_2338 facingPos = position.method_10093(facing);
            if (context.method_8041().method_7909() == Items.BUS_CABLE.get() &&
                canHaveCableTo(level.method_8320(facingPos), facing.method_10153())) {
                state = state.method_11657(entry.getValue(), ConnectionType.CABLE);
            }
        }

        return state;
    }

    @Override
    public class_2680 method_9559(class_2680 state, final class_2350 facing, final class_2680 facingState, final class_1936 level, final class_2338 currentPos, final class_2338 facingPos) {
        final class_2754<ConnectionType> property = FACING_TO_CONNECTION_MAP.get(facing);
        if (state.method_11654(property) == ConnectionType.INTERFACE) {
            return state;
        }

        final boolean neighborConnectionChanged;
        if (state.method_11654(HAS_CABLE) && canHaveCableTo(facingState, facing.method_10153())) {
            neighborConnectionChanged = state.method_11654(property) != ConnectionType.CABLE;
            state = state.method_11657(property, ConnectionType.CABLE);
        } else {
            neighborConnectionChanged = state.method_11654(property) != ConnectionType.NONE;
            state = state.method_11657(property, ConnectionType.NONE);
        }

        onConnectionTypeChanged(level, currentPos, facing, neighborConnectionChanged);

        return state;
    }

    @Override
    public class_265 method_9530(final class_2680 state, final class_1922 level, final class_2338 pos, final class_3726 context) {
        if (state.method_11654(HAS_FACADE)) {
            return class_259.method_1077();
        }

        return shapes[getShapeIndex(state)];
    }

    public static class_1799 getPickedStack(final class_1922 level, final class_2338 pos, final class_1657 player) {
        if (!(level.method_8321(pos) instanceof final BusCableBlockEntity busCable)) {
            return class_1799.field_8037;
        }

        final class_1799 facadeItem = busCable.getFacade();
        if (!facadeItem.method_7960()) {
            return facadeItem.method_7972();
        }

        final class_243 from = player.method_33571();
        final class_243 to = from.method_1019(player.method_5828(1).method_1021(player.method_55754() + 1));
        final class_3965 hit = level.method_17742(new class_3959(from, to, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, player));
        if (hit.method_17783() != class_239.class_240.field_1332 || !hit.method_17777().equals(pos)) {
            return class_1799.field_8037;
        }

        final class_2680 state = level.method_8320(pos);
        if (getConnectionType(state, getHitSide(pos, hit)) == ConnectionType.INTERFACE) {
            return new class_1799(Items.BUS_INTERFACE.get());
        }

        return class_1799.field_8037;
    }

    // --------------------------------------------------------------------- //
    // BaseEntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.BUS_CABLE.get().method_11032(pos, state);
    }

    @Override
    public class_2464 method_9604(final class_2680 state) {
        return class_2464.field_11458;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        FACING_TO_CONNECTION_MAP.values().forEach(builder::method_11667);
        builder.method_11667(HAS_CABLE);
        builder.method_11667(HAS_FACADE);
    }

    // --------------------------------------------------------------------- //

    private static boolean canHaveCableTo(final class_2680 state, final class_2350 side) {
        return state.method_26204() == Blocks.BUS_CABLE.get() &&
            state.method_11654(HAS_CABLE) &&
            state.method_11654(FACING_TO_CONNECTION_MAP.get(side)) != ConnectionType.INTERFACE;
    }

    private static int getPartCount(final class_2680 state) {
        int partCount = getInterfaceCount(state);
        if (state.method_11654(HAS_CABLE)) {
            partCount++;
        }
        return partCount;
    }

    private static boolean tryRemoveInterface(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2350 side = getHitSide(pos, hit);
        final class_2754<ConnectionType> property = FACING_TO_CONNECTION_MAP.get(side);

        if (state.method_11654(property) != ConnectionType.INTERFACE) {
            return false;
        }

        final class_2338 neighborPos = pos.method_10093(side);
        final boolean isReplacedByCable = state.method_11654(HAS_CABLE) && canHaveCableTo(level.method_8320(neighborPos), side.method_10153());
        if (isReplacedByCable) {
            level.method_8501(pos, state.method_11657(property, ConnectionType.CABLE));
        } else {
            level.method_8501(pos, state.method_11657(property, ConnectionType.NONE));
        }

        handlePartRemoved(state, level, pos, side, player, new class_1799(Items.BUS_INTERFACE.get()), isReplacedByCable);

        return true;
    }

    private static boolean tryRemoveCable(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player) {
        if (!state.method_11654(HAS_CABLE)) {
            return false;
        }

        level.method_8501(pos, state.method_11657(HAS_CABLE, false));

        handlePartRemoved(state, level, pos, null, player, new class_1799(Items.BUS_CABLE.get()), true);

        return true;
    }

    private static void handlePartRemoved(final class_2680 state, final class_1937 level, final class_2338 pos, @Nullable final class_2350 side, final class_1657 player, final class_1799 drop, final boolean neighborConnectionChanged) {
        onConnectionTypeChanged(level, pos, side, neighborConnectionChanged);

        if (!player.method_7337() && level.method_8450().method_8355(class_1928.field_19392)) {
            ItemStackUtils.spawnAsEntity(level, pos, drop, side).ifPresent(entity -> {
                entity.method_6975();
                entity.method_5694(player);
            });
        }

        LevelUtils.playSound(level, pos, state.method_26231(), class_2498::method_10595);
    }

    private static void onConnectionTypeChanged(final class_1936 level, final class_2338 pos, @Nullable final class_2350 face, final boolean neighborConnectionChanged) {
        if (level.method_8608()) {
            return;
        }

        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final BusCableBlockEntity busCable) {
            busCable.handleConfigurationChanged(face, neighborConnectionChanged);
        }
    }

    @Environment(EnvType.CLIENT)
    private static void openBusInterfaceScreen(final BusCableBlockEntity blockEntity, final class_2350 side) {
        final BusInterfaceScreen screen = new BusInterfaceScreen(blockEntity, side);
        class_310.method_1551().method_1507(screen);
    }

    private static class_265[] makeShapes() {
        final class_265 ownCableBounds = class_2248.method_9541(5, 5, 5, 11, 11, 11);
        final class_265[] cableShapes = new class_265[Constants.BLOCK_FACE_COUNT];
        final class_265[] interfaceShapes = new class_265[Constants.BLOCK_FACE_COUNT];
        for (int i = 0; i < Constants.BLOCK_FACE_COUNT; i++) {
            cableShapes[i] = getCableShape(Constants.DIRECTIONS[i]);
            interfaceShapes[i] = getInterfaceShape(Constants.DIRECTIONS[i]);
        }

        // We pack info as such:
        // [has interface on side] [has cable on side] [has own cable]
        // Which is a total of 13 bits (6 + 6 + 1), so 8k combinations.
        // It's a lot, but not so much that it's not ok to still cache
        // it and avoid recomputing the bounds all the time.

        final int configurations = 1 << (6 + 6 + 1);
        final class_265[] result = new class_265[configurations];
        Arrays.fill(result, class_259.method_1073());

        for (int i = 0; i < result.length; i++) {
            final int mask = i >> 1;
            for (int sideIndex = 0; sideIndex < Constants.BLOCK_FACE_COUNT; sideIndex++) {
                final int cableBit = 1 << sideIndex;
                if ((mask & cableBit) != 0) {
                    result[i] = class_259.method_1084(result[i], cableShapes[sideIndex]);
                }

                final int interfaceBit = cableBit << 6;
                if ((mask & interfaceBit) != 0) {
                    result[i] = class_259.method_1084(result[i], interfaceShapes[sideIndex]);
                }
            }

            if ((i & 1) != 0) {
                result[i] = class_259.method_1084(result[i], ownCableBounds);
            }
        }

        return result;
    }


    private static class_265 getCableShape(final class_2350 zDirection) {
        final int xSize = 6;
        final int ySize = 6;
        final int zSize = 5;

        final class_2350 yDirection = zDirection.method_10166() == class_2350.class_2351.field_11052 ? class_2350.field_11043 : class_2350.field_11036;
        final class_2350 xDirection = zDirection.method_10166() == class_2350.class_2351.field_11052 ? class_2350.field_11039 : zDirection.method_10170();

        final class_2382 min = new class_2382(8, 8, 8)
            .method_23226(xDirection, -xSize / 2)
            .method_23226(yDirection, -ySize / 2)
            .method_23226(zDirection, 8 - zSize);
        final class_2382 max = new class_2382(8, 8, 8)
            .method_23226(xDirection, xSize / 2)
            .method_23226(yDirection, ySize / 2)
            .method_23226(zDirection, 8);

        final class_238 bounds = new class_238(
            class_243.method_24954(min).method_1021(1 / 16.0),
            class_243.method_24954(max).method_1021(1 / 16.0)
        );

        return class_259.method_1078(bounds);
    }

    private static class_265 getInterfaceShape(final class_2350 zDirection) {
        final int xSize = 8;
        final int ySize = 8;
        final int zSize = 1;

        final class_2350 yDirection = zDirection.method_10166() == class_2350.class_2351.field_11052 ? class_2350.field_11043 : class_2350.field_11036;
        final class_2350 xDirection = zDirection.method_10166() == class_2350.class_2351.field_11052 ? class_2350.field_11039 : zDirection.method_10170();

        final class_2382 min = new class_2382(8, 8, 8)
            .method_23226(xDirection, -xSize / 2)
            .method_23226(yDirection, -ySize / 2)
            .method_23226(zDirection, 8 - zSize);
        final class_2382 max = new class_2382(8, 8, 8)
            .method_23226(xDirection, xSize / 2)
            .method_23226(yDirection, ySize / 2)
            .method_23226(zDirection, 8);

        final class_238 bounds = new class_238(
            class_243.method_24954(min).method_1021(1 / 16.0),
            class_243.method_24954(max).method_1021(1 / 16.0)
        );

        return class_259.method_1084(getCableShape(zDirection), class_259.method_1078(bounds));
    }

    private static int getShapeIndex(final class_2680 state) {
        int index = 0;

        for (int sideIndex = 0; sideIndex < Constants.BLOCK_FACE_COUNT; sideIndex++) {
            final int cableBit = 1 << sideIndex;
            final int interfaceBit = cableBit << 6;
            switch (state.method_11654(FACING_TO_CONNECTION_MAP.get(Constants.DIRECTIONS[sideIndex]))) {
                case CABLE -> index |= cableBit;
                case INTERFACE -> index |= interfaceBit;
            }
        }

        index = index << 1;

        if (state.method_11654(HAS_CABLE)) {
            index |= 1;
        }

        return index;
    }
}
