/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1792;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_6395;

public final class ClientPlatform {
    @ExpectPlatform
    public static void setHotbarVisible(final boolean value) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isStencilEnabled(final class_276 target) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void enableStencil(final class_276 target) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerItemProperty(final class_1792 item, final class_2960 name, final class_6395 property) {
        throw new AssertionError();
    }

    private ClientPlatform() {
    }
}
