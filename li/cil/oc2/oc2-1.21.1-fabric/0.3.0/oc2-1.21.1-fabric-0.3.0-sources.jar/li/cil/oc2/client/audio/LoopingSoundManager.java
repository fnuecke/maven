/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.audio;

import java.util.WeakHashMap;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3414;

public final class LoopingSoundManager {
    private static final WeakHashMap<class_2586, LoopingBlockEntitySound> BLOCK_ENTITY_SOUNDS = new WeakHashMap<>();

    // --------------------------------------------------------------------- //

    public static void play(final class_2586 blockEntity, final class_3414 sound, final int delay) {
        stop(blockEntity);

        final LoopingBlockEntitySound instance = new LoopingBlockEntitySound(blockEntity, sound);
        BLOCK_ENTITY_SOUNDS.put(blockEntity, instance);
        class_310.method_1551().method_1483().method_4872(instance, delay);
    }

    public static void stop(final class_2586 blockEntity) {
        final LoopingBlockEntitySound instance = BLOCK_ENTITY_SOUNDS.remove(blockEntity);
        if (instance != null) {
            instance.cancel();
            class_310.method_1551().method_1483().method_4870(instance);
        }
    }

    public static boolean isPlaying(final class_2586 blockEntity) {
        final LoopingBlockEntitySound instance = BLOCK_ENTITY_SOUNDS.get(blockEntity);
        return instance != null && !instance.method_4793();
    }
}
