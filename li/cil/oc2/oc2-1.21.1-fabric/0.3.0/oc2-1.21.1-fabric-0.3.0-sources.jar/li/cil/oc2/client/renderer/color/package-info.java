/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.renderer.color;

import javax.annotation.ParametersAreNonnullByDefault;
