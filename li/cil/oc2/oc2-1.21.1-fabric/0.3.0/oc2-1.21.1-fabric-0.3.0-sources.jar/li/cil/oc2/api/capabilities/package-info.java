/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.api.capabilities;

import javax.annotation.ParametersAreNonnullByDefault;
