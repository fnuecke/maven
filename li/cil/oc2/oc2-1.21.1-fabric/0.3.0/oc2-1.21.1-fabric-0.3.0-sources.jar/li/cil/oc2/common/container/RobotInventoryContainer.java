/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.api.inventory.ItemHandler;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.energy.FixedEnergyStorage;
import li.cil.oc2.common.entity.Robot;
import li.cil.oc2.common.vm.VMItemStackHandlers;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class RobotInventoryContainer extends AbstractRobotContainer {
    public static void createServer(final Robot robot, final FixedEnergyStorage energy, final CommonDeviceBusController busController, final class_3222 player) {
        MenuRegistry.openExtendedMenu(player, new ExtendedMenuProvider() {
            @Override
            public class_2561 method_5476() {
                return robot.method_5477();
            }

            @Override
            public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                return new RobotInventoryContainer(id, robot, player, createEnergyInfo(energy, busController));
            }

            @Override
            public void saveExtraData(final class_2540 buffer) {
                buffer.method_10804(robot.method_5628());
            }
        });
    }

    public static RobotInventoryContainer createClient(final int id, final class_1661 inventory, final class_2540 data) {
        final int entityId = data.method_10816();
        final class_1297 entity = inventory.field_7546.method_37908().method_8469(entityId);
        if (entity instanceof final Robot robot) {
            return new RobotInventoryContainer(id, robot, inventory.field_7546, createClientEnergyInfo());
        }

        throw new IllegalArgumentException();
    }

    // --------------------------------------------------------------------- //

    private RobotInventoryContainer(final int id, final Robot robot, final class_1657 player, final IntPrecisionContainerData energyInfo) {
        super(Containers.ROBOT.get(), id, player, robot, energyInfo);

        final VMItemStackHandlers handlers = robot.getItemStackHandlers();

        handlers.getItemHandler(DeviceTypes.CPU.get()).ifPresent(itemHandler -> {
            if (itemHandler.getSlots() > 0) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.CPU.get(), 0, 34, 52));
            }
        });

        handlers.getItemHandler(DeviceTypes.FLASH_MEMORY.get()).ifPresent(itemHandler -> {
            if (itemHandler.getSlots() > 0) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.FLASH_MEMORY.get(), 0, 34, 78));
            }
        });

        handlers.getItemHandler(DeviceTypes.MEMORY.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.MEMORY.get(), slot, 34 + slot * SLOT_SIZE, 24));
            }
        });

        handlers.getItemHandler(DeviceTypes.HARD_DRIVE.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.HARD_DRIVE.get(), slot, 70, 60 + slot * SLOT_SIZE));
            }
        });

        handlers.getItemHandler(DeviceTypes.FLOPPY.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.FLOPPY.get(), slot, 70 + SLOT_SIZE, 60 + slot * SLOT_SIZE));
            }
        });

        handlers.getItemHandler(DeviceTypes.ROBOT_MODULE.get()).ifPresent(itemHandler -> {
            for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
                method_7621(new DeviceTypeSlotItemHandler(itemHandler, DeviceTypes.ROBOT_MODULE.get(), slot, 8, 24 + slot * SLOT_SIZE));
            }
        });

        final ItemHandler inventory = robot.getInventory();
        for (int slot = 0; slot < inventory.getSlots(); slot++) {
            final int x = 116 + slot % 3 * SLOT_SIZE;
            final int y = 24 + slot / 3 * SLOT_SIZE;
            method_7621(new RobotSlot(inventory, slot, x, y));
        }

        createPlayerInventoryAndHotbarSlots(player.method_31548(), 8, 115);
    }
}
