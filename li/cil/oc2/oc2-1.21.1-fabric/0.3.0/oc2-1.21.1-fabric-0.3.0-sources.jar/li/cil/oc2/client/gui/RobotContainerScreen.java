/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.common.container.RobotInventoryContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_757;

@Environment(EnvType.CLIENT)
public final class RobotContainerScreen extends AbstractMachineInventoryScreen<RobotInventoryContainer> {
    private static final int SLOT_SIZE = 18;

    // --------------------------------------------------------------------- //

    public static void renderSelection(final class_332 graphics, final int selectedSlot, final int x, final int y, final int columns) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1, 1, 1, 1);

        final int slotX = selectedSlot % columns * SLOT_SIZE;
        final int slotY = selectedSlot / columns * SLOT_SIZE;
        final int offset = SLOT_SIZE * (int) (15 * (System.currentTimeMillis() % 1000) / 1000);
        Sprites.SLOT_SELECTION.draw(graphics, x + slotX, y + slotY, 0, offset);
    }

    // --------------------------------------------------------------------- //

    public RobotContainerScreen(final RobotInventoryContainer container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title);
        field_2792 = Sprites.ROBOT_CONTAINER.width;
        field_2779 = Sprites.ROBOT_CONTAINER.height;
        field_25270 = field_2779 - 94;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        super.method_2389(graphics, partialTicks, mouseX, mouseY);

        Sprites.ROBOT_CONTAINER.draw(graphics, field_2776, field_2800);
        renderSelection(graphics, field_2797.getRobot().getSelectedSlot(), field_2776 + 115, field_2800 + 23, 3);
    }
}
