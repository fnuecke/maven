/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.common.block.Blocks;
import li.cil.oc2.common.util.RegistryUtils;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.List;

public final class BlockEntities {
    private static final DeferredRegister<class_2591<?>> BLOCK_ENTITIES = RegistryUtils.getInitializerFor(class_7924.field_41255);

    private static final List<RegistrySupplier<? extends class_2591<?>>> ALL = new ArrayList<>();

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_2591<BusCableBlockEntity>> BUS_CABLE = register(Blocks.BUS_CABLE, BusCableBlockEntity::new);
    public static final RegistrySupplier<class_2591<ChargerBlockEntity>> CHARGER = register(Blocks.CHARGER, ChargerBlockEntity::new);
    public static final RegistrySupplier<class_2591<ComputerBlockEntity>> COMPUTER = register(Blocks.COMPUTER, ComputerBlockEntity::new);
    public static final RegistrySupplier<class_2591<CreativeEnergyBlockEntity>> CREATIVE_ENERGY = register(Blocks.CREATIVE_ENERGY, CreativeEnergyBlockEntity::new);
    public static final RegistrySupplier<class_2591<DiskDriveBlockEntity>> DISK_DRIVE = register(Blocks.DISK_DRIVE, DiskDriveBlockEntity::new);
    public static final RegistrySupplier<class_2591<KeyboardBlockEntity>> KEYBOARD = register(Blocks.KEYBOARD, KeyboardBlockEntity::new);
    public static final RegistrySupplier<class_2591<NetworkConnectorBlockEntity>> NETWORK_CONNECTOR = register(Blocks.NETWORK_CONNECTOR, NetworkConnectorBlockEntity::new);
    public static final RegistrySupplier<class_2591<NetworkHubBlockEntity>> NETWORK_HUB = register(Blocks.NETWORK_HUB, NetworkHubBlockEntity::new);
    public static final RegistrySupplier<class_2591<ProjectorBlockEntity>> PROJECTOR = register(Blocks.PROJECTOR, ProjectorBlockEntity::new);
    public static final RegistrySupplier<class_2591<RedstoneInterfaceBlockEntity>> REDSTONE_INTERFACE = register(Blocks.REDSTONE_INTERFACE, RedstoneInterfaceBlockEntity::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    public static List<class_2591<?>> getAll() {
        return ALL.stream().<class_2591<?>>map(RegistrySupplier::get).toList();
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("ConstantConditions") // .build(null) is fine
    private static <B extends class_2248, T extends class_2586> RegistrySupplier<class_2591<T>> register(final RegistrySupplier<B> block, final class_2591.class_5559<T> factory) {
        final RegistrySupplier<class_2591<T>> type = BLOCK_ENTITIES.register(
            block.getId().method_12832(), () -> class_2591.class_2592.method_20528(factory, block.get()).method_11034(null));
        ALL.add(type);
        return type;
    }
}
