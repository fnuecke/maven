/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.bus.device.vm.item;

import javax.annotation.ParametersAreNonnullByDefault;
