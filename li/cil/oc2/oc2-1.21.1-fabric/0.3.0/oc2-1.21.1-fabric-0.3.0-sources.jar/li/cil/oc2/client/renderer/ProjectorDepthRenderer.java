/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalNotification;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.architectury.event.events.client.ClientTickEvent;
import li.cil.oc2.client.ClientPlatform;
import li.cil.oc2.common.block.ProjectorBlock;
import li.cil.oc2.common.blockentity.ProjectorBlockEntity;
import li.cil.oc2.common.bus.device.vm.block.ProjectorDevice;
import li.cil.oc2.common.ext.MinecraftExt;
import li.cil.oc2.common.mixin.LevelRendererMixin;
import li.cil.oc2.common.util.FakePlayerUtils;
import li.cil.oc2.jcodec.common.model.Picture;
import li.cil.oc2.jcodec.scale.Yuv420jToRgb;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_6364;
import net.minecraft.class_6367;
import net.minecraft.class_638;
import net.minecraft.class_6854;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_758;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_8251;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

import java.lang.ref.WeakReference;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.lwjgl.opengl.GL11.GL_NONE;
import static org.lwjgl.opengl.GL11.glDrawBuffer;
import static org.lwjgl.opengl.GL30.GL_FRAMEBUFFER;
import static org.lwjgl.opengl.GL30.glBindFramebuffer;

// No @Mod.EventBusSubscriber: we need to register this manually, because static init throws errors when running data generation.
public final class ProjectorDepthRenderer {
    private static final int DEPTH_CAPTURE_SIZE = 256;

    private static final List<ProjectorBlockEntity> VISIBLE_PROJECTORS = new ArrayList<>();
    private static final LazyDepthOnlyRenderBuffer[] PROJECTOR_DEPTH_BUFFER_LEDGER = new LazyDepthOnlyRenderBuffer[ModShaders.MAX_PROJECTORS];
    private static final DepthOnlyRenderTarget[] PROJECTOR_DEPTH_BUFFERS = new DepthOnlyRenderTarget[ModShaders.MAX_PROJECTORS];
    private static final class_1043[] PROJECTOR_COLOR_BUFFERS = new class_1043[ModShaders.MAX_PROJECTORS];
    private static final Matrix4f[] PROJECTOR_CAMERA_MATRICES = new Matrix4f[ModShaders.MAX_PROJECTORS];
    private static final class_4184 PROJECTOR_DEPTH_CAMERA = new class_4184();
    private static DepthOnlyRenderTarget mainCameraDepth;
    private static final float PROJECTOR_FORWARD_SHIFT = 7 / 16f; // From center of projector block.
    private static final float PROJECTOR_NEAR = 0.5f - PROJECTOR_FORWARD_SHIFT;
    private static final float PROJECTOR_FAR = ProjectorBlockEntity.MAX_RENDER_DISTANCE;
    private static final int HALF_FRUSTUM_WIDTH = (ProjectorBlockEntity.MAX_WIDTH - 1) / 2;
    private static final int FRUSTUM_HEIGHT = ProjectorBlockEntity.MAX_HEIGHT - 1;
    private static final Matrix4f DEPTH_CAMERA_PROJECTION_MATRIX = getFrustumMatrix(
        PROJECTOR_NEAR, PROJECTOR_FAR,
        ProjectorBlockEntity.MAX_GOOD_RENDER_DISTANCE,
        -HALF_FRUSTUM_WIDTH, HALF_FRUSTUM_WIDTH,
        FRUSTUM_HEIGHT, 0);

    private static final Cache<ProjectorBlockEntity, RenderInfo> RENDER_INFO = CacheBuilder.newBuilder()
        .expireAfterAccess(Duration.ofSeconds(5))
        .removalListener(ProjectorDepthRenderer::handleProjectorNoLongerRendering)
        .build();

    private static int refreshSlot;
    private static boolean isRenderingProjectorDepth;
    private static class_239 hitResultBak;
    private static boolean entityShadowsBak;
    private static class_1297 minecraftCameraEntityBak;
    private static class_4184 gameRendererMainCameraBak;
    private static float shaderFogStartBak;
    private static float shaderFogEndBak;
    private static final float[] SHADER_FOG_COLOR_BAK = new float[4];
    private static class_6854 shaderFogShapeBak;

    private static void handleProjectorNoLongerRendering(final RemovalNotification<ProjectorBlockEntity, RenderInfo> notification) {
        final ProjectorBlockEntity projector = notification.getKey();
        if (projector != null) {
            projector.setFrameConsumer(null);
        }
        final RenderInfo renderInfo = notification.getValue();
        if (renderInfo != null) {
            renderInfo.close();
        }
    }

    static {
        for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
            PROJECTOR_CAMERA_MATRICES[i] = new Matrix4f();
        }
    }

    private static LazyDepthOnlyRenderBuffer[] projectorDepthBuffers() {
        if (PROJECTOR_DEPTH_BUFFER_LEDGER[0] == null) {
            for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
                PROJECTOR_DEPTH_BUFFER_LEDGER[i] = new LazyDepthOnlyRenderBuffer();
            }
        }
        return PROJECTOR_DEPTH_BUFFER_LEDGER;
    }

    private static DepthOnlyRenderTarget mainCameraDepth() {
        if (mainCameraDepth == null) {
            mainCameraDepth = new DepthOnlyRenderTarget(class_6364.field_33724, class_6364.field_33725);
        }
        return mainCameraDepth;
    }

    // --------------------------------------------------------------------- //

    /**
     * Adds a projector that is being rendered this frame. This is called every frame a projector is rendering,
     * the list of rendering projectors is cleared at the end of every frame.
     */
    public static void addProjector(final ProjectorBlockEntity projector) {
        VISIBLE_PROJECTORS.add(projector);
    }

    /**
     * Whether we will be rendering projector depth this frame.
     * <p>
     * Checked in our {@link LevelRendererMixin} to avoid unnecessary flushing and copying
     * when we're not rendering projections.
     */
    public static boolean willRenderProjectorDepth() {
        return !VISIBLE_PROJECTORS.isEmpty();
    }

    /**
     * Whether we're currently rendering projector depth maps.
     * <p>
     * This is used in a couple of events and mixins, used to suppress regular rendering of things not needed in the
     * depth buffer.
     */
    public static boolean isIsRenderingProjectorDepth() {
        return isRenderingProjectorDepth;
    }

    /**
     * Called from a mixin in the {@link class_761#method_22710(class_9779, boolean, class_4184, class_757, class_765, Matrix4f, Matrix4f)}
     * method to grab the current depth buffer. This is necessary, because the depth buffer may be messed up by other
     * render passes when using the "Fabulous!" graphics mode.
     * <p>
     * Called before {@link #renderProjectors(Matrix4f, Matrix4f, class_9779)} every frame.
     */
    public static void captureMainCameraDepth() {
        final class_276 mainRenderTarget = class_310.method_1551().method_1522();
        if (mainRenderTarget.field_1482 != mainCameraDepth().field_1482 || mainRenderTarget.field_1481 != mainCameraDepth().field_1481) {
            mainCameraDepth().method_1234(mainRenderTarget.field_1482, mainRenderTarget.field_1481, class_310.field_1703);
        }
        if (ClientPlatform.isStencilEnabled(mainRenderTarget)) {
            ClientPlatform.enableStencil(mainCameraDepth());
        } else if (ClientPlatform.isStencilEnabled(mainCameraDepth())) {
            mainCameraDepth().method_1238();
            mainCameraDepth = new DepthOnlyRenderTarget(mainRenderTarget.field_1482, mainRenderTarget.field_1481);
        }
        mainCameraDepth().method_29329(mainRenderTarget);
        mainRenderTarget.method_1235(false);
    }

    /**
     * Renders the projected images of {@link ProjectorBlockEntity} instances that were registered via
     * {@link #addProjector(ProjectorBlockEntity)} this frame.
     */
    public static void renderProjectors(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix, final class_9779 deltaTracker) {
        if (isIsRenderingProjectorDepth()) {
            return;
        }

        if (VISIBLE_PROJECTORS.isEmpty()) {
            return;
        }
        try {
            final class_310 minecraft = class_310.method_1551();
            final class_638 level = minecraft.field_1687;
            final class_746 player = minecraft.field_1724;
            if (level == null || player == null) {
                return;
            }

            VISIBLE_PROJECTORS.sort((projector1, projector2) -> {
                final double distance1 = player.method_5707(class_243.method_24953(projector1.method_11016()));
                final double distance2 = player.method_5707(class_243.method_24953(projector2.method_11016()));
                return Double.compare(distance1, distance2);
            });

            final int projectorCount = Math.min(VISIBLE_PROJECTORS.size(), ModShaders.MAX_PROJECTORS);

            for (int i = 0; i < projectorCount; i++) {
                VISIBLE_PROJECTORS.get(i).onRendering();
            }

            final int renderCount = updateProjectorDepths(minecraft, level, deltaTracker, projectorCount);
            if (renderCount > 0) {
                renderProjectorColors(minecraft, modelViewMatrix, projectionMatrix, renderCount);
            }
        } finally {
            VISIBLE_PROJECTORS.clear();
            Arrays.fill(PROJECTOR_COLOR_BUFFERS, null);
        }
    }

    /**
     * Suppresses fog rendering while rendering depth buffer for projectors.
     */
    public static void handleFog() {
        if (isRenderingProjectorDepth) {
            class_758.method_23792();
        }
    }

    /**
     * Suppresses nameplate rendering while rendering depth buffer for projectors.
     */
    public static boolean shouldSuppressNameplates() {
        return isRenderingProjectorDepth;
    }

    /**
     * Updates cached rendering info, such as textures holding image data for projectors, to allow expiration.
     */
    public static void initialize() {
        ClientTickEvent.CLIENT_POST.register(minecraft -> RENDER_INFO.cleanUp());
    }

    // --------------------------------------------------------------------- //

    /**
     * Stage one of projector rendering, render scene depths from the perspective of all projectors that should
     * bre rendered. The output is the list of depth buffers, MVP matrices that were used to render them, and the
     * associated color texture for the projector.
     */
    private static int updateProjectorDepths(final class_310 minecraft, final class_638 level,
                                             final class_9779 deltaTracker, final int projectorCount) {
        final class_243 mainCameraPosition = minecraft.field_1773.method_19418().method_19326();
        final class_4587 viewModelStack = new class_4587();

        matchDepthTargetsToOwningProjectors(projectorCount);

        renderDepthBuffer(minecraft, level, deltaTracker, projectorCount, viewModelStack);

        final int validDepthTargetCount = sortByDepthBufferValidity(projectorCount);

        for (int i = 0; i < validDepthTargetCount; i++) {
            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(i);
            final class_2350 facing = projector.method_11010().method_11654(ProjectorBlock.field_11177);
            final class_243 projectorPos = class_243
                .method_24953(projector.method_11016())
                .method_1019(new class_243(facing.method_23955()).method_1021(PROJECTOR_FORWARD_SHIFT));

            configureProjectorDepthCamera(level, projectorPos, facing.method_10144());

            setupViewModelMatrix(viewModelStack);

            storeProjectorMatrix(i, projectorPos, mainCameraPosition, viewModelStack);

            storeProjectorBuffers(i, projector);
        }

        return validDepthTargetCount;
    }

    private static void matchDepthTargetsToOwningProjectors(final int projectorCount) {
        for (int i = 0; i < projectorCount; i++) {
            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(i);
            for (int j = i; j < ModShaders.MAX_PROJECTORS; j++) {
                if (projectorDepthBuffers()[j].isOwnedBy(projector)) {
                    swapDepthTargets(i, j);
                    break;
                }
            }
        }

        for (int i = 0; i < projectorCount; i++) {
            projectorDepthBuffers()[i].setOwner(VISIBLE_PROJECTORS.get(i));
        }
    }

    private static int sortByDepthBufferValidity(final int projectorCount) {
        int validDepthTargetCount = 0;

        for (int i = 0; i < projectorCount; i++) {
            if (!projectorDepthBuffers()[i].isValid) {
                continue;
            }

            Collections.swap(VISIBLE_PROJECTORS, i, validDepthTargetCount);
            swapDepthTargets(i, validDepthTargetCount);

            validDepthTargetCount++;
        }

        return validDepthTargetCount;
    }

    private static void swapDepthTargets(final int a, final int b) {
        if (a == b) {
            return;
        }

        final var target = PROJECTOR_DEPTH_BUFFER_LEDGER[a];
        PROJECTOR_DEPTH_BUFFER_LEDGER[a] = PROJECTOR_DEPTH_BUFFER_LEDGER[b];
        PROJECTOR_DEPTH_BUFFER_LEDGER[b] = target;
    }

    private static void renderDepthBuffer(final class_310 minecraft, final class_638 level,
                                          final class_9779 deltaTracker, final int projectorCount,
                                          final class_4587 viewModelStack) {
        int projectorIndex = getNextDepthTargetSlotToRender(projectorCount);
        if (projectorIndex < 0) {
            return;
        }

        final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(projectorIndex);
        final class_2350 facing = projector.method_11010().method_11654(ProjectorBlock.field_11177);
        final class_243 projectorPos = class_243
            .method_24953(projector.method_11016())
            .method_1019(new class_243(facing.method_23955()).method_1021(PROJECTOR_FORWARD_SHIFT));

        prepareDepthBufferRendering(minecraft, level, deltaTracker.method_60637(false));
        try {
            configureProjectorDepthCamera(level, projectorPos, facing.method_10144());

            RenderSystem.setProjectionMatrix(DEPTH_CAMERA_PROJECTION_MATRIX, class_8251.field_43360);
            setupViewModelMatrix(viewModelStack);

            bindProjectorDepthRenderTarget(projectorIndex, minecraft);

            renderProjectorDepthBuffer(minecraft, deltaTracker, viewModelStack);
        } finally {
            finishDepthBufferRendering(minecraft);
        }
    }

    private static int getNextDepthTargetSlotToRender(final int projectorCount) {
        for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
            refreshSlot = (refreshSlot + 1) % ModShaders.MAX_PROJECTORS;
            if (refreshSlot < projectorCount) {
                return refreshSlot;
            }
        }
        return -1;
    }

    private static void prepareDepthBufferRendering(final class_310 minecraft, final class_638 level, final float partialTicks) {
        isRenderingProjectorDepth = true;

        // Suppresses hit outlines being rendered.
        hitResultBak = minecraft.field_1765;
        minecraft.field_1765 = null;

        // Skip shadow rendering for perf.
        entityShadowsBak = minecraft.field_1690.method_42435().method_41753();
        minecraft.field_1690.method_42435().method_41748(false);

        minecraftCameraEntityBak = minecraft.method_1560();
        minecraft.method_1504(ProjectorCameraEntity.get(level, class_243.field_1353, partialTicks));
        gameRendererMainCameraBak = minecraft.field_1773.field_18765;
        minecraft.field_1773.field_18765 = PROJECTOR_DEPTH_CAMERA;

        RenderSystem.backupProjectionMatrix();
        RenderSystem.getModelViewStack().pushMatrix().identity();
        RenderSystem.applyModelViewMatrix();

        backupFog();
    }

    private static void finishDepthBufferRendering(final class_310 minecraft) {
        minecraft.field_1765 = hitResultBak;
        minecraft.field_1690.method_42435().method_41748(entityShadowsBak);

        ((MinecraftExt) minecraft).setMainRenderTargetOverride(null);
        minecraft.method_1522().method_1235(true);

        minecraft.method_1504(minecraftCameraEntityBak);
        minecraft.field_1773.field_18765 = gameRendererMainCameraBak;

        RenderSystem.restoreProjectionMatrix();
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();

        isRenderingProjectorDepth = false;

        restoreFog();
    }

    private static void backupFog() {
        shaderFogStartBak = RenderSystem.getShaderFogStart();
        shaderFogEndBak = RenderSystem.getShaderFogEnd();
        System.arraycopy(RenderSystem.getShaderFogColor(), 0, SHADER_FOG_COLOR_BAK, 0, SHADER_FOG_COLOR_BAK.length);
        shaderFogShapeBak = RenderSystem.getShaderFogShape();
    }

    private static void restoreFog() {
        RenderSystem.setShaderFogStart(shaderFogStartBak);
        RenderSystem.setShaderFogEnd(shaderFogEndBak);
        RenderSystem.setShaderFogColor(SHADER_FOG_COLOR_BAK[0], SHADER_FOG_COLOR_BAK[1], SHADER_FOG_COLOR_BAK[2], SHADER_FOG_COLOR_BAK[3]);
        RenderSystem.setShaderFogShape(shaderFogShapeBak);
    }

    private static void configureProjectorDepthCamera(final class_638 level, final class_243 pos, final float rotationY) {
        PROJECTOR_DEPTH_CAMERA.method_19321(level, ProjectorCameraEntity.get(level, pos, rotationY), false, false, 0);
    }

    private static void setupViewModelMatrix(final class_4587 viewModelStack) {
        viewModelStack.method_34426();
        viewModelStack.method_22907(class_7833.field_40716.rotationDegrees(PROJECTOR_DEPTH_CAMERA.method_19330() + 180));
    }

    private static void storeProjectorMatrix(final int projectorIndex, final class_243 projectorPos, final class_243 mainCameraPosition, final class_4587 viewModelStack) {
        // Save model-view-projection matrix for mapping in compositing shader. We use the position relative to the
        // main camera here, so that the main camera can sit at the origin. This avoids loss of precision.
        PROJECTOR_CAMERA_MATRICES[projectorIndex].set(DEPTH_CAMERA_PROJECTION_MATRIX);
        viewModelStack.method_22903();
        viewModelStack.method_22904(
            mainCameraPosition.method_10216() - projectorPos.method_10216(),
            mainCameraPosition.method_10214() - projectorPos.method_10214(),
            mainCameraPosition.method_10215() - projectorPos.method_10215()
        );
        PROJECTOR_CAMERA_MATRICES[projectorIndex].mul(viewModelStack.method_23760().method_23761());
        viewModelStack.method_22909();
    }

    private static void bindProjectorDepthRenderTarget(final int projectorIndex, final class_310 minecraft) {
        final var projectorDepthTarget = projectorDepthBuffers()[projectorIndex];
        projectorDepthTarget.target.method_1235(true);
        ((MinecraftExt) minecraft).setMainRenderTargetOverride(projectorDepthTarget.target);
        projectorDepthTarget.isValid = true; // I mean, it *will* be...
    }

    private static void renderProjectorDepthBuffer(final class_310 minecraft, final class_9779 deltaTracker, final class_4587 viewModelStack) {
        final class_761 levelRenderer = minecraft.field_1769;
        final Matrix4f frustumMatrix = viewModelStack.method_23760().method_23761();
        levelRenderer.method_32133(
            PROJECTOR_DEPTH_CAMERA.method_19326(),
            frustumMatrix,
            DEPTH_CAMERA_PROJECTION_MATRIX
        );
        levelRenderer.method_22710(
            deltaTracker,
            /* shouldRenderBlockOutline: */ false,
            PROJECTOR_DEPTH_CAMERA,
            minecraft.field_1773,
            minecraft.field_1773.method_22974(),
            frustumMatrix,
            DEPTH_CAMERA_PROJECTION_MATRIX
        );
    }

    private static void storeProjectorBuffers(final int projectorIndex, final ProjectorBlockEntity projector) {
        PROJECTOR_COLOR_BUFFERS[projectorIndex] = getColorBuffer(projector);
        PROJECTOR_DEPTH_BUFFERS[projectorIndex] = projectorDepthBuffers()[projectorIndex].target;
    }

    /**
     * Stage two or projector rendering, this composes the projections of the projectors being rendered into the
     * main render target, using the camera matrices and depth information to determine where to render. This is
     * essentially a post-processing pass, i.e. it renders a screen-filling rectangle blending the projector light
     * into the existing main render target output.
     */
    private static void renderProjectorColors(final class_310 minecraft, final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix, final int renderCount) {
        prepareColorBufferRendering();
        try {
            prepareOrthographicRendering(minecraft);

            RenderSystem.setShader(ModShaders::getProjectorsShader);
            ModShaders.configureProjectorsShader(
                mainCameraDepth(),
                constructInverseMainCameraMatrix(modelViewMatrix, projectionMatrix),
                PROJECTOR_COLOR_BUFFERS,
                PROJECTOR_DEPTH_BUFFERS,
                PROJECTOR_CAMERA_MATRICES,
                renderCount
            );

            renderIntoScreenRect();
        } finally {
            finishColorBufferRendering();
        }
    }

    private static void prepareColorBufferRendering() {
        RenderSystem.backupProjectionMatrix();
        RenderSystem.getModelViewStack().pushMatrix();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE);

        RenderSystem.colorMask(true, true, true, false);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
    }

    private static void finishColorBufferRendering() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.disableBlend();

        RenderSystem.restoreProjectionMatrix();
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();
    }

    private static void prepareOrthographicRendering(final class_310 minecraft) {
        final Matrix4f screenProjectionMatrix = new Matrix4f().setOrtho(
            0, minecraft.method_22683().method_4489(),
            minecraft.method_22683().method_4506(), 0,
            1000, 3000
        );
        RenderSystem.setProjectionMatrix(screenProjectionMatrix, class_8251.field_43361);

        final Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.identity();
        modelViewStack.translate(0, 0, -2000);
        RenderSystem.applyModelViewMatrix();
    }

    private static Matrix4f constructInverseMainCameraMatrix(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
        final Matrix4f inverseModelViewMatrix = new Matrix4f(projectionMatrix);
        inverseModelViewMatrix.mul(modelViewMatrix);
        inverseModelViewMatrix.invert();
        return inverseModelViewMatrix;
    }

    private static void renderIntoScreenRect() {
        final class_287 builder = class_289.method_1348()
            .method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        builder.method_22912(0, 0, 0).method_22913(0, 1);
        builder.method_22912(0, mainCameraDepth().field_1481, 0).method_22913(0, 0);
        builder.method_22912(mainCameraDepth().field_1482, mainCameraDepth().field_1481, 0).method_22913(1, 0);
        builder.method_22912(mainCameraDepth().field_1482, 0, 0).method_22913(1, 1);
        class_286.method_43433(builder.method_60800());
    }

    private static Matrix4f getFrustumMatrix(final float near, final float far, final float dist,
                                             final float left, final float right,
                                             final float top, final float bottom) {
        return new Matrix4f().set(new float[]{
            2 * dist / (right - left), 0, 0, 0,
            0, 2 * dist / (top - bottom), 0, 0,
            (right + left) / (right - left), (top + bottom) / (top - bottom), -(far + near) / (far - near), -1,
            0, 0, -(2 * far * near) / (far - near), 0,
        });
    }

    private static class_1043 getColorBuffer(final ProjectorBlockEntity projector) {
        try {
            final RenderInfo renderInfo = RENDER_INFO.get(projector, () -> {
                final class_1043 texture = new class_1043(ProjectorDevice.WIDTH, ProjectorDevice.HEIGHT, false);
                final RenderInfo info = new RenderInfo(texture);
                info.upload();
                projector.setFrameConsumer(info);
                return info;
            });

            renderInfo.uploadIfDirty();

            return renderInfo.texture();
        } catch (final ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    // --------------------------------------------------------------------- //

    /**
     * Tracks a depth buffer for a projector.
     * <p>
     * Since we only update one depth buffer per frame (to spread render cost things out), we may
     * be left with a depth buffer that has not yet been updated after being reassigned to a
     * different projector. So we have to track validity.
     */
    private static class LazyDepthOnlyRenderBuffer {
        public DepthOnlyRenderTarget target = new DepthOnlyRenderTarget(DEPTH_CAPTURE_SIZE, DEPTH_CAPTURE_SIZE);
        public WeakReference<?> owner;
        public boolean isValid;

        public boolean isOwnedBy(ProjectorBlockEntity projector) {
            return isValid && owner.get() == projector;
        }

        public void setOwner(ProjectorBlockEntity projector) {
            if (owner == null || owner.get() != projector) {
                owner = new WeakReference<>(projector);
                isValid = false;
            }
        }
    }

    /**
     * Tracks a render texture holding color info for rendering projectors.
     * <p>
     * Automatically updated by projectors when new data arrives (from a worker thread).
     */
    private static final class RenderInfo implements ProjectorBlockEntity.FrameConsumer {
        private static final ThreadLocal<byte[]> RGB = ThreadLocal.withInitial(() -> new byte[3]);

        private final class_1043 texture;
        private boolean hasNewFrame;

        RenderInfo(final class_1043 texture) {
            this.texture = texture;
        }

        public class_1043 texture() {
            return texture;
        }

        public synchronized void close() {
            texture.close();
        }

        public synchronized void uploadIfDirty() {
            if (hasNewFrame) {
                hasNewFrame = false;
                upload();
            }
        }

        public void upload() {
            final class_1011 pixels = texture.method_4525();
            if (pixels == null) {
                return;
            }

            texture.method_23207();
            pixels.method_22619(0, 0, 0, 0, 0, pixels.method_4307(), pixels.method_4323(),
                /* blur: */ true, /* clamp: */ true, /* mipmap: */ false, /* autoClose: */ false);
        }

        @Override
        public synchronized void processFrame(final Picture picture) {
            final class_1011 image = texture.method_4525();
            if (image == null) {
                return;
            }

            final byte[] y = picture.getPlaneData(0);
            final byte[] u = picture.getPlaneData(1);
            final byte[] v = picture.getPlaneData(2);

            // Convert in quads, based on the half resolution of UV. As such, skip every other row, since
            // we're setting the current and the next.
            int lumaIndex = 0, chromaIndex = 0;
            for (int halfRow = 0; halfRow < ProjectorDevice.HEIGHT / 2; halfRow++, lumaIndex += ProjectorDevice.WIDTH * 2) {
                final int row = halfRow * 2;
                for (int halfCol = 0; halfCol < ProjectorDevice.WIDTH / 2; halfCol++, chromaIndex++) {
                    final int col = halfCol * 2;
                    final int yIndex = lumaIndex + col;
                    final byte cb = u[chromaIndex];
                    final byte cr = v[chromaIndex];
                    setFromYUV420(image, col, row, y[yIndex], cb, cr);
                    setFromYUV420(image, col + 1, row, y[yIndex + 1], cb, cr);
                    setFromYUV420(image, col, row + 1, y[yIndex + ProjectorDevice.WIDTH], cb, cr);
                    setFromYUV420(image, col + 1, row + 1, y[yIndex + ProjectorDevice.WIDTH + 1], cb, cr);
                }
            }

            hasNewFrame = true;
        }

        private static void setFromYUV420(final class_1011 image, final int col, final int row, final byte y, final byte cb, final byte cr) {
            final byte[] bytes = RGB.get();
            Yuv420jToRgb.YUVJtoRGB(y, cb, cr, bytes, 0);
            final int r = bytes[0] + 128;
            final int g = bytes[1] + 128;
            final int b = bytes[2] + 128;
            image.method_4305(col, row, r | (g << 8) | (b << 16) | (0xFF << 24));
        }
    }

    /**
     * Optimized texture target that doesn't have a color texture, so we can completely skip that when rendering
     * projector depth buffers.
     */
    private static final class DepthOnlyRenderTarget extends class_6367 {
        public DepthOnlyRenderTarget(final int width, final int height) {
            super(width, height, true, class_310.field_1703);
        }

        @Override
        public void method_1231(final int width, final int height, final boolean isOnOSX) {
            super.method_1231(width, height, isOnOSX);
            if (field_1475 > -1) {
                if (field_1476 > -1) {
                    glBindFramebuffer(GL_FRAMEBUFFER, field_1476);
                    glDrawBuffer(GL_NONE);
                    glBindFramebuffer(GL_FRAMEBUFFER, 0);
                }
                TextureUtil.releaseTextureId(this.field_1475);
                this.field_1475 = -1;
            }
        }
    }

    /**
     * Fake entity used as rendering context when rendering projector depth buffers.
     */
    private static final class ProjectorCameraEntity extends class_1657 {
        private static ProjectorCameraEntity instance;

        /**
         * Singleton getter for the fake render entity, to avoid unnecessary allocations.
         */
        public static ProjectorCameraEntity get(final class_1937 level, final class_243 pos, final float rotationY) {
            if (instance == null) {
                instance = new ProjectorCameraEntity(level, class_2338.field_10980, rotationY);
            }

            instance.method_51502(level);
            instance.method_5808(pos.method_10216(), pos.method_10214(), pos.method_10215(), rotationY, 0);

            return instance;
        }

        private ProjectorCameraEntity(final class_1937 level, final class_2338 blockPos, final float rotationY) {
            super(level, blockPos, rotationY, FakePlayerUtils.getFakePlayerProfile());
        }

        @Override
        public float method_5705(final float partialTicks) {
            return field_5982;
        }

        @Override
        public float method_5695(final float partialTicks) {
            return field_6004;
        }

        @Override
        public boolean method_7325() {
            return false;
        }

        @Override
        public boolean method_7337() {
            return true;
        }
    }
}
