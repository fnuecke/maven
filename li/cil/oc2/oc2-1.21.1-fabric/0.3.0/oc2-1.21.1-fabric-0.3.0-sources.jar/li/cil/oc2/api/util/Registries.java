/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.util;

import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.device.DeviceType;
import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.oc2.api.bus.device.provider.BlockDeviceProvider;
import li.cil.oc2.api.bus.device.provider.ItemDeviceProvider;
import li.cil.oc2.api.bus.device.rpc.RPCTypeAdapter;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

/**
 * {@link class_5321}s for registries created by the mod.
 */
public final class Registries {
    /**
     * The registry name of the registry holding block device providers.
     */
    public static final class_5321<class_2378<BlockDeviceProvider>> BLOCK_DEVICE_PROVIDER = key("block_device_provider");

    /**
     * The registry name of the registry holding item device providers.
     */
    public static final class_5321<class_2378<ItemDeviceProvider>> ITEM_DEVICE_PROVIDER = key("item_device_provider");

    /**
     * The registry name of the registry holding block device bases.
     */
    public static final class_5321<class_2378<BlockDeviceData>> BLOCK_DEVICE_DATA = key("block_device_data");

    /**
     * The registry name of the registry holding device types.
     */
    public static final class_5321<class_2378<DeviceType>> DEVICE_TYPE = key("device_type");

    /**
     * The registry name of the registry holding RPC method parameter type adapters.
     */
    public static final class_5321<class_2378<RPCTypeAdapter>> RPC_TYPE_ADAPTER = key("rpc_type_adapter");

    // --------------------------------------------------------------------- //

    private static <T> class_5321<class_2378<T>> key(final String name) {
        return class_5321.method_29180(class_2960.method_60655(API.MOD_ID, name));
    }
}
