/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.capabilities.NetworkInterface;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.capabilities.Capabilities;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Stream;

public final class NetworkHubBlockEntity extends ModBlockEntity implements NetworkInterface {
    private static final int TTL_COST = 1;

    private int frameCount;
    private long lastGameTime;

    // --------------------------------------------------------------------- //

    private final Invalidatable<?>[] adjacentBlockInterfaces = new Invalidatable<?>[Constants.BLOCK_FACE_COUNT];
    private boolean haveAdjacentBlocksChanged = true;

    // --------------------------------------------------------------------- //

    public NetworkHubBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.NETWORK_HUB.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    public void handleNeighborChanged() {
        haveAdjacentBlocksChanged = true;
    }

    @Override
    public byte[] readEthernetFrame() {
        return null;
    }

    @Override
    public void writeEthernetFrame(final NetworkInterface source, final byte[] frame, final int timeToLive) {
        if (field_11863 == null) {
            return;
        }

        // Give a cap on top of the TLL, just in case trolls intentionally build
        // loops that exponentially multiply ethernet frames after people crank up
        // the default TTL.
        final long gameTime = field_11863.method_8510();
        if (gameTime > lastGameTime) {
            lastGameTime = gameTime;
            frameCount = 1;
        } else if (frameCount > Config.hubEthernetFramesPerTick) {
            return;
        } else {
            frameCount++;
        }

        getAdjacentInterfaces().forEach(adjacentInterface -> {
            if (adjacentInterface != source) {
                adjacentInterface.writeEthernetFrame(this, frame, timeToLive - TTL_COST);
            }
        });
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.NETWORK_INTERFACE, this);
    }

    // --------------------------------------------------------------------- //

    private Stream<NetworkInterface> getAdjacentInterfaces() {
        validateAdjacentBlocks();
        return Arrays.stream(adjacentBlockInterfaces)
            .filter(Objects::nonNull)
            .filter(Invalidatable::isPresent)
            .map(adjacent -> (NetworkInterface) adjacent.get());
    }

    private void validateAdjacentBlocks() {
        if (!isValid() || !haveAdjacentBlocksChanged) {
            return;
        }

        for (final class_2350 side : Constants.DIRECTIONS) {
            adjacentBlockInterfaces[side.method_10146()] = null;
        }

        haveAdjacentBlocksChanged = false;

        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        final class_2338 pos = method_11016();
        for (final class_2350 side : Constants.DIRECTIONS) {
            final class_2338 neighborPos = pos.method_10093(side);
            if (!field_11863.method_8477(neighborPos)) {
                continue;
            }

            final Invalidatable<NetworkInterface> neighborInterface = Capabilities.watch(
                field_11863, neighborPos, side.method_10153(), Capabilities.NETWORK_INTERFACE);
            if (neighborInterface.isPresent()) {
                adjacentBlockInterfaces[side.method_10146()] = neighborInterface;
                neighborInterface.addListener(unused -> haveAdjacentBlocksChanged = true);
            }
        }
    }
}
