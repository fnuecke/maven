/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nullable;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5251;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class FileChooserScreen extends class_437 {
    private static final Logger LOGGER = LogManager.getLogger();

    // --------------------------------------------------------------------- //

    private static final int MARGIN = 30;
    private static final int WIDGET_SPACING = 8;

    private static final int TEXT_FIELD_HEIGHT = 20;
    private static final int BUTTON_HEIGHT = 20;
    private static final int LIST_ENTRY_HEIGHT = 12;

    private static final class_2561 OPEN_TITLE_TEXT = text("gui.{mod}.file_chooser.title.load");
    private static final class_2561 SAVE_TITLE_TEXT = text("gui.{mod}.file_chooser.title.save");
    private static final class_2561 FILE_NAME_TEXT = text("gui.{mod}.file_chooser.text_field.filename");
    private static final class_2561 LOAD_TEXT = text("gui.{mod}.file_chooser.confirm_button.load");
    private static final class_2561 SAVE_TEXT = text("gui.{mod}.file_chooser.confirm_button.save");
    private static final class_2561 OVERWRITE_TEXT = text("gui.{mod}.file_chooser.confirm_button.overwrite");
    private static final class_2561 CANCEL_TEXT = text("gui.{mod}.file_chooser.cancel_button");

    // --------------------------------------------------------------------- //

    private static Path directory = Paths.get("").toAbsolutePath();

    // --------------------------------------------------------------------- //

    private final FileChooserCallback callback;
    private final boolean isLoad;

    private final class_437 previousScreen;

    private FileList fileList;
    private class_342 fileNameTextField;
    private class_4185 okButton;

    private boolean isComplete;

    // --------------------------------------------------------------------- //

    @FunctionalInterface
    public
    interface FileChooserCallback {
        void onFileSelected(Path path);

        default void onCanceled() {
        }
    }

    // --------------------------------------------------------------------- //

    public static void openFileChooserForSave(final String name, final FileChooserCallback callback) {
        final class_437 currentScreen = class_310.method_1551().field_1755;
        if (currentScreen instanceof FileChooserScreen) {
            currentScreen.method_25419();
        }

        final FileChooserScreen screen = new FileChooserScreen(callback, false);
        class_310.method_1551().method_1507(screen);
        screen.fileNameTextField.method_1852(toFileName(name));
    }

    public static void openFileChooserForLoad(final FileChooserCallback callback) {
        final class_437 currentScreen = class_310.method_1551().field_1755;
        if (currentScreen instanceof FileChooserScreen) {
            currentScreen.method_25419();
        }

        final FileChooserScreen screen = new FileChooserScreen(callback, true);
        class_310.method_1551().method_1507(screen);
    }

    // --------------------------------------------------------------------- //

    public FileChooserScreen(final FileChooserCallback callback, final boolean isLoad) {
        super(isLoad ? OPEN_TITLE_TEXT : SAVE_TITLE_TEXT);

        this.callback = callback;
        this.isLoad = isLoad;

        this.previousScreen = class_310.method_1551().field_1755;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25419() {
        if (!isComplete) {
            callback.onCanceled();
        }

        if (previousScreen != null) {
            field_22787.method_18858(() -> field_22787.method_1507(previousScreen));
        }
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        method_52752(graphics);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        final int widgetsWidth = field_22789 - MARGIN * 2;
        final int listHeight = field_22790 - MARGIN - WIDGET_SPACING - TEXT_FIELD_HEIGHT - WIDGET_SPACING - BUTTON_HEIGHT - MARGIN;
        fileList = new FileList(MARGIN, listHeight, LIST_ENTRY_HEIGHT);
        method_37063(fileList);

        final int fileNameTop = MARGIN + listHeight + WIDGET_SPACING;
        fileNameTextField = new class_342(field_22793, MARGIN, fileNameTop, widgetsWidth, TEXT_FIELD_HEIGHT, FILE_NAME_TEXT);
        fileNameTextField.method_1863(s -> {
            fileList.setSelected(null);
            updateButtons();
        });
        fileNameTextField.method_1880(1024);
        method_37063(fileNameTextField);

        final int buttonTop = fileNameTop + TEXT_FIELD_HEIGHT + WIDGET_SPACING;
        final int buttonCount = 2;
        final int buttonWidth = widgetsWidth / buttonCount - (buttonCount - 1) * WIDGET_SPACING;
        okButton = method_37063(class_4185.method_46430(class_5244.field_39003, this::handleOkPressed)
            .method_46434(MARGIN, buttonTop, buttonWidth, BUTTON_HEIGHT).method_46431());
        method_37063(class_4185.method_46430(CANCEL_TEXT, this::handleCancelPressed)
            .method_46434(MARGIN + buttonWidth + WIDGET_SPACING, buttonTop, buttonWidth, BUTTON_HEIGHT).method_46431());

        fileList.refreshFiles(directory);

        updateButtons();
    }

    @Override
    public void method_29638(final List<Path> files) {
        files.stream().filter(file -> {
            try {
                return Files.exists(file) && !Files.isHidden(file);
            } catch (final IOException | SecurityException ignored) {
                return false;
            }
        }).findFirst().ifPresent(fileList::selectPath);
    }

    // --------------------------------------------------------------------- //

    private boolean isParentPath() {
        if (directory == null) {
            return false;
        }

        final FileList.FileEntry selected = fileList.method_25334();
        if (selected != null) {
            return Objects.equals(selected.file, directory.getParent());
        }

        final String selectedFileEntry = fileNameTextField.method_1882();
        return "..".equals(selectedFileEntry);
    }

    private Optional<Path> getPath() {
        final FileList.FileEntry selected = fileList.method_25334();
        if (selected != null) {
            return Optional.ofNullable(selected.file);
        }

        if (directory == null) {
            return Optional.empty();
        }

        final String selectedFileEntry = fileNameTextField.method_1882();
        if ("".equals(selectedFileEntry) || ".".equals(selectedFileEntry)) {
            return Optional.empty();
        }

        try {
            return Optional.of(directory.resolve(selectedFileEntry));
        } catch (final InvalidPathException e) {
            return Optional.empty();
        }
    }

    private void confirm() {
        if (isParentPath()) {
            fileList.refreshFiles(getPath().orElse(null));
            return;
        }

        getPath().ifPresent(path -> {
            if (Files.isDirectory(path)) {
                fileList.refreshFiles(path);
                return;
            }
            if (Files.isRegularFile(path)) {
                isComplete = true;
                callback.onFileSelected(path);
                method_25419();
            } else if (!isLoad) {
                isComplete = true;
                callback.onFileSelected(path);
                method_25419();
            } // else: cannot load non-existing file
        });
    }

    private void cancel() {
        isComplete = true;
        callback.onCanceled();
        method_25419();
    }

    private void updateButtons() {
        okButton.field_22763 = false;
        okButton.method_25355(isLoad ? LOAD_TEXT : SAVE_TEXT);

        if (isParentPath()) {
            okButton.field_22763 = true;
            return;
        }

        getPath().ifPresent(path -> {
            if (isLoad) {
                okButton.field_22763 = Files.exists(path);
            } else {
                okButton.field_22763 = true;
                if (Files.isRegularFile(path)) {
                    // setFGColor is a loader extension; style the message instead.
                    okButton.method_25355(OVERWRITE_TEXT.method_27661().method_27692(class_124.field_1061));
                }
            }
        });
    }

    private void handleOkPressed(final class_4185 button) { //NOPMD - required by Button.OnPress
        confirm();
    }

    private void handleCancelPressed(final class_4185 button) { //NOPMD - required by Button.OnPress
        cancel();
    }

    private static String toFileName(final String name) {
        try {
            final Path fileName = Paths.get(name).getFileName();
            return fileName != null ? fileName.toString() : "";
        } catch (final InvalidPathException e) {
            return "";
        }
    }

    // --------------------------------------------------------------------- //

    private final class FileList extends class_4280<FileList.FileEntry> {
        public FileList(final int y, final int height, final int slotHeight) {
            super(FileChooserScreen.this.field_22787, FileChooserScreen.this.field_22789, height, y, slotHeight);
        }

        public void refreshFiles(@Nullable final Path directory) {
            FileChooserScreen.directory = directory;

            method_25307(0);
            method_25339();

            if (directory != null && Files.isDirectory(directory)) {
                method_25321(createDirectoryEntry(directory.getParent(), ".."));

                try {
                    final List<Path> files = Files.list(directory)
                        .sorted((p1, p2) -> {
                            if (Files.isDirectory(p1) && !Files.isDirectory(p2)) {
                                return -1;
                            }
                            if (!Files.isDirectory(p1) && Files.isDirectory(p2)) {
                                return 1;
                            }
                            return p1.getFileName().compareTo(p2.getFileName());
                        }).toList();
                    for (final Path path : files) {
                        try {
                            if (Files.isHidden(path)) {
                                continue;
                            }

                            if (Files.isDirectory(path)) {
                                method_25321(createDirectoryEntry(path));
                            } else {
                                method_25321(createFileEntry(path));
                            }
                        } catch (final IOException | SecurityException ignored) {
                        }
                    }
                } catch (final IOException | SecurityException e) {
                    LOGGER.error(e);
                }
            } else {
                for (final Path path : FileSystems.getDefault().getRootDirectories()) {
                    method_25321(createDirectoryEntry(path, path.toString()));
                }
            }

            fileNameTextField.method_1852("");
        }

        public void selectPath(final Path path) {
            if (Files.isDirectory(path)) {
                refreshFiles(path);
            } else {
                refreshFiles(path.getParent());
                method_25396().stream().filter(entry -> path.equals(entry.file))
                    .findFirst().ifPresent(entry -> {
                        entry.select();
                        method_25324(entry);
                    });
            }
        }

        @Override
        public void setSelected(@Nullable final FileChooserScreen.FileList.FileEntry entry) {
            super.method_25313(entry);
            updateButtons();
        }

        private FileList.FileEntry createFileEntry(final Path file) {
            return new FileList.FileEntry(file, class_2561.method_43470(file.getFileName().toString()));
        }

        private FileList.FileEntry createDirectoryEntry(final Path path) {
            return createDirectoryEntry(path, path.getFileName().toString() + path.getFileSystem().getSeparator());
        }

        private FileList.FileEntry createDirectoryEntry(@Nullable final Path path, final String displayName) {
            final class_5251 color = path != null && Files.exists(path)
                ? class_5251.method_27717(0xA0A0FF)
                : class_5251.method_27718(class_124.field_1080);
            return new FileList.FileEntry(path, class_2561.method_43470(displayName)
                .method_27694(s -> s.method_27703(color)));
        }

        private final class FileEntry extends class_4280.class_4281<FileEntry> {
            @Nullable
            private final Path file;
            private final class_2561 displayName;

            private long lastEntryClickTime;

            public FileEntry(@Nullable final Path file, final class_2561 displayName) {
                this.file = file;
                this.displayName = displayName;
            }

            @Override
            public void method_25343(final class_332 graphics, final int index, final int top, final int left, final int width, final int height,
                               final int mouseX, final int mouseY, final boolean isHovered, final float deltaTime) {
                graphics.method_51439(field_22793, displayName, left, top, 0xFFFFFFFF, true);
            }

            @Override
            public boolean method_25402(final double mouseX, final double mouseY, final int button) {
                final boolean isLeftClick = button == 0;
                if (isLeftClick) {
                    select();

                    final boolean isDoubleClick = System.currentTimeMillis() - lastEntryClickTime < 250;
                    if (isDoubleClick && okButton.field_22763) {
                        confirm();
                    }

                    lastEntryClickTime = System.currentTimeMillis();
                }

                return false;
            }

            public void select() {
                if (directory != null && Objects.equals(directory.getParent(), file)) {
                    fileNameTextField.method_1852("..");
                } else if (file != null) {
                    final Path fileName = file.getFileName();
                    fileNameTextField.method_1852(fileName != null ? fileName.toString() : file.toString());
                } else {
                    return;
                }
                fileNameTextField.method_1870(false);
                fileNameTextField.method_1884(0);
                setSelected(this);
            }

            @Override
            public class_2561 method_37006() {
                return class_2561.method_43469("narrator.select", displayName);
            }
        }
    }
}
