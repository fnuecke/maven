/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.renderer.entity;

import javax.annotation.ParametersAreNonnullByDefault;
