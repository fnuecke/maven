/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.BusInterfaceNameMessage;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class BusInterfaceScreen extends class_437 {
    private static final int TEXT_LEFT = 9;
    private static final int TEXT_TOP = 11;
    private static final int CONFIRM_LEFT = 206;
    private static final int CONFIRM_TOP = 9;
    private static final int CANCEL_LEFT = 219;
    private static final int CANCEL_TOP = 9;

    private final BusCableBlockEntity busCable;
    private final class_2350 side;

    private class_342 nameField;

    private int left, top;

    // --------------------------------------------------------------------- //

    public BusInterfaceScreen(final BusCableBlockEntity busCable, final class_2350 side) {
        super(Items.BUS_INTERFACE.get().method_7848());
        this.busCable = busCable;
        this.side = side;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        left = (field_22789 - Sprites.BUS_INTERFACE_SCREEN.width) / 2;
        top = (field_22790 - Sprites.BUS_INTERFACE_SCREEN.height) / 2;

        nameField = new class_342(field_22793, left + TEXT_LEFT, top + TEXT_TOP, 192, 12, text("{mod}.gui.bus_interface_name"));
        nameField.method_1856(false);
        nameField.method_1868(0xFFFFFFFF);
        nameField.method_1858(false);
        nameField.method_1880(32);
        nameField.method_1852(busCable.getInterfaceName(side));
        method_25429(nameField);
        method_48265(nameField);

        method_37063(new ImageButton(
            left + CONFIRM_LEFT, top + CONFIRM_TOP,
            Sprites.CONFIRM_BASE.width, Sprites.CONFIRM_BASE.height,
            Sprites.CONFIRM_BASE,
            Sprites.CONFIRM_PRESSED
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                setInterfaceName(nameField.method_1882());
                method_25419();
            }
        }).withTooltip(class_2561.method_43471(Constants.TOOLTIP_CONFIRM));

        method_37063(new ImageButton(
            left + CANCEL_LEFT, top + CANCEL_TOP,
            Sprites.CANCEL_BASE.width, Sprites.CANCEL_BASE.height,
            Sprites.CANCEL_BASE,
            Sprites.CANCEL_PRESSED
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                method_25419();
            }
        }).withTooltip(class_2561.method_43471(Constants.TOOLTIP_CANCEL));
    }

    @Override
    public void method_25393() {
        super.method_25393();

        final class_243 busCableCenter = class_243.method_24953(busCable.method_11016());
        if (!busCable.isValid() ||
            field_22787.field_1724 == null ||
            field_22787.field_1724.method_5707(busCableCenter) > 8 * 8) {
            method_25419();
        }
    }

    @Override
    public boolean method_25404(final int keyCode, final int scanCode, final int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER ||
            keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            setInterfaceName(nameField.method_1882());
            method_25419();
            return true;
        }

        return nameField.method_25404(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        method_52752(graphics);
        Sprites.BUS_INTERFACE_SCREEN.draw(graphics, left, top);
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        RenderSystem.disableBlend();
        nameField.method_25394(graphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --------------------------------------------------------------------- //

    private void setInterfaceName(final String name) {
        Network.sendToServer(new BusInterfaceNameMessage.ToServer(busCable, side, name));
    }
}
