/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.util;

import javax.annotation.Nullable;
import net.minecraft.class_1297;
import net.minecraft.class_2350;

/**
 * A more restrictive version of {@link Side}, intended for robot operation APIs.
 */
public enum RobotOperationSide {
    FRONT(class_2350.field_11035),
    front(FRONT),
    f(FRONT),

    UP(class_2350.field_11036),
    up(UP),
    u(UP),

    DOWN(class_2350.field_11033),
    down(DOWN),
    d(DOWN),
    ;

    private final class_2350 direction;

    RobotOperationSide(final class_2350 direction) {
        this.direction = direction;
    }

    RobotOperationSide(final RobotOperationSide parent) {
        this(parent.direction);
    }

    /**
     * Gets the world-space direction for the specified side relative to the specified entity.
     *
     * @param entity the entity to which the side is relative.
     * @param side   the side to convert to a world-space direction.
     * @return a world-space direction.
     */
    public static class_2350 toGlobal(final class_1297 entity, @Nullable final RobotOperationSide side) {
        class_2350 direction = side == null
            ? RobotOperationSide.FRONT.direction
            : side.direction;
        if (direction.method_10166().method_10179()) {
            final int horizontalIndex = entity.method_5735().method_10161();
            for (int i = 0; i < horizontalIndex; i++) {
                direction = direction.method_10170();
            }
        }
        return direction;
    }
}
