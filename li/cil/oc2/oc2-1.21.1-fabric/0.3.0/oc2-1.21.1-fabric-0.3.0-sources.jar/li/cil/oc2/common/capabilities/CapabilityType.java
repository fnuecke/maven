/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.capabilities;

import net.minecraft.class_2960;

public final class CapabilityType<T> {
    private final class_2960 id;
    private final Class<T> type;

    public CapabilityType(final class_2960 id, final Class<T> type) {
        this.id = id;
        this.type = type;
    }

    public class_2960 id() {
        return id;
    }

    public Class<T> type() {
        return type;
    }

    @Override
    public String toString() {
        return "CapabilityType[" + id + "]";
    }
}
