/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;

public class ImmutableHorizontalBlock extends class_2383 {
    public static final MapCodec<ImmutableHorizontalBlock> CODEC = method_54094(ImmutableHorizontalBlock::new);

    @Override
    protected MapCodec<? extends ImmutableHorizontalBlock> method_53969() {
        return field_46280;
    }

    public ImmutableHorizontalBlock(final class_2251 properties) {
        super(properties);
    }

    @Override
    public class_2680 method_9598(final class_2680 state, final class_2470 rotation) {
        return state;
    }

    @Override
    public class_2680 method_9569(final class_2680 state, final class_2415 mirror) {
        return state;
    }
}
