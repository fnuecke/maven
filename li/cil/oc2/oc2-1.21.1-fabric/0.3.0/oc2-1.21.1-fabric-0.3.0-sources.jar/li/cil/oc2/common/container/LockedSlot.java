/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public final class LockedSlot extends class_1735 {
    public LockedSlot(final class_1263 container, final int slot, final int x, final int y) {
        super(container, slot, x, y);
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean method_7680(final class_1799 p_40231_) {
        return false;
    }

    @Override
    public boolean method_7674(final class_1657 p_40228_) {
        return false;
    }
}
