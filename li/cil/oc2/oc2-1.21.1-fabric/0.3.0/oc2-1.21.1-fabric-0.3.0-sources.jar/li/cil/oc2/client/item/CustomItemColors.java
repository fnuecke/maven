/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.item;

import dev.architectury.registry.client.rendering.ColorHandlerRegistry;
import li.cil.oc2.common.item.ColoredItem;
import li.cil.oc2.common.item.Items;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9282;
import net.minecraft.class_9334;

public final class CustomItemColors {
    public static final int BLACK = 0xFF404040;
    public static final int GREY = 0xFF555555;
    public static final int LIGHT_GREY = 0xFF898989;
    public static final int WHITE = 0xFFCACACA;

    public static final int LIME = 0xFF65DA2B;
    public static final int GREEN = 0xFF1C9C31;
    public static final int CYAN = 0xFF11C5BD;
    public static final int BLUE = 0xFF4F66E8;
    public static final int LIGHT_BLUE = 0xFF1192C5;
    public static final int PURPLE = 0xFF8F02CA;
    public static final int MAGENTA = 0xFFC61087;
    public static final int PINK = 0xFFDB51BD;
    public static final int ORANGE = 0xFFDD803D;
    public static final int RED = 0xFFDD3D3D;
    public static final int BROWN = 0xFF745C42;
    public static final int YELLOW = 0xFFFFFC49;

    // --------------------------------------------------------------------- //

    private static final int NO_TINT = 0xFFFFFFFF;

    // --------------------------------------------------------------------- //

    public static void initialize() {
        ColorHandlerRegistry.registerItemColors((stack, layer) -> layer == 1 ? getColor(stack) : NO_TINT,
            Items.HARD_DRIVE_SMALL,
            Items.HARD_DRIVE_MEDIUM,
            Items.HARD_DRIVE_LARGE,
            Items.FLASH_MEMORY,
            Items.FLOPPY);
    }

    public static int getColorByDye(final class_1767 dye) {
        return switch (dye) {
            case field_7952 -> WHITE;
            case field_7946 -> ORANGE;
            case field_7958 -> MAGENTA;
            case field_7951 -> LIGHT_BLUE;
            case field_7947 -> YELLOW;
            case field_7961 -> LIME;
            case field_7954 -> PINK;
            case field_7944 -> GREY;
            case field_7967 -> LIGHT_GREY;
            case field_7955 -> CYAN;
            case field_7945 -> PURPLE;
            case field_7966 -> BLUE;
            case field_7957 -> BROWN;
            case field_7942 -> GREEN;
            case field_7964 -> RED;
            case field_7963 -> BLACK;
        };
    }

    public static int getColor(final class_1799 stack) {
        final class_1792 item = stack.method_7909();
        if (item instanceof final ColoredItem coloredItem) {
            return coloredItem.getColor(stack);
        }
        return GREY;
    }

    public static class_1799 withColor(final class_1799 stack, final class_1767 color) {
        return withColor(stack, getColorByDye(color));
    }

    public static class_1799 withColor(final class_1799 stack, final int color) {
        final class_1792 item = stack.method_7909();
        if (item instanceof ColoredItem) {
            stack.method_57379(class_9334.field_49644, new class_9282(color, true));
        }
        return stack;
    }
}
