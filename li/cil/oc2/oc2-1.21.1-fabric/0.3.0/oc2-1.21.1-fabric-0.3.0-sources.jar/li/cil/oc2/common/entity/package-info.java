/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.entity;

import javax.annotation.ParametersAreNonnullByDefault;
