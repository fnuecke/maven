/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.bus.device.io.IOCallback;
import li.cil.oc2.api.bus.device.io.IOName;
import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.DocumentedDevice;
import li.cil.oc2.api.bus.device.object.NamedDevice;
import li.cil.oc2.api.bus.device.object.Parameter;
import li.cil.oc2.api.util.Side;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.util.HorizontalBlockUtils;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;

import static java.util.Collections.singletonList;

@IOName("REDSTN")
public final class RedstoneInterfaceBlockEntity extends ModBlockEntity implements NamedDevice, DocumentedDevice {
    private static final String OUTPUT_TAG_NAME = "output";

    private static final String GET_REDSTONE_INPUT = "getRedstoneInput";
    private static final String GET_REDSTONE_OUTPUT = "getRedstoneOutput";
    private static final String SET_REDSTONE_OUTPUT = "setRedstoneOutput";
    private static final String SIDE = "side";
    private static final String VALUE = "value";
    private static final int GET_REDSTONE_INPUT_CODE = 1;
    private static final int GET_REDSTONE_OUTPUT_CODE = 2;
    private static final int SET_REDSTONE_OUTPUT_CODE = 3;

    // --------------------------------------------------------------------- //

    private final byte[] output = new byte[Constants.BLOCK_FACE_COUNT];

    // --------------------------------------------------------------------- //

    public RedstoneInterfaceBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.REDSTONE_INTERFACE.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10570(OUTPUT_TAG_NAME, output);
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        final byte[] serializedOutput = tag.method_10547(OUTPUT_TAG_NAME);
        System.arraycopy(serializedOutput, 0, output, 0, Math.min(serializedOutput.length, output.length));
    }

    public int getOutputForDirection(final class_2350 direction) {
        final class_2350 localDirection = HorizontalBlockUtils.toLocal(method_11010(), direction);
        assert localDirection != null;

        return output[localDirection.method_10146()];
    }

    @Callback(name = GET_REDSTONE_INPUT)
    public int getRedstoneInput(@Parameter(SIDE) @Nullable final Side side) {
        if (side == null) throw new IllegalArgumentException();

        if (field_11863 == null) {
            return 0;
        }

        final class_2338 pos = method_11016();
        final class_2350 direction = HorizontalBlockUtils.toGlobal(method_11010(), side);
        assert direction != null;

        final class_2338 neighborPos = pos.method_10093(direction);
        final class_1923 chunkPos = new class_1923(neighborPos);
        if (!field_11863.method_8393(chunkPos.field_9181, chunkPos.field_9180)) {
            return 0;
        }

        return field_11863.method_49808(neighborPos, direction);
    }

    @Callback(name = GET_REDSTONE_OUTPUT, synchronize = false)
    public int getRedstoneOutput(@Parameter(SIDE) @Nullable final Side side) {
        if (side == null) throw new IllegalArgumentException();
        final int index = toLocalIndex(side);

        return output[index];
    }

    @Callback(name = SET_REDSTONE_OUTPUT)
    public void setRedstoneOutput(@Parameter(SIDE) @Nullable final Side side, @Parameter(VALUE) final int value) {
        if (side == null) throw new IllegalArgumentException();
        final int index = toLocalIndex(side);

        final byte clampedValue = (byte) class_3532.method_15340(value, 0, 15);
        if (clampedValue == output[index]) {
            return;
        }

        output[index] = clampedValue;

        final class_2350 direction = HorizontalBlockUtils.toGlobal(method_11010(), side);
        if (direction != null) {
            notifyNeighbor(direction);
        }

        method_5431();
    }

    @Override
    public Collection<String> getDeviceTypeNames() {
        return singletonList("redstone");
    }

    @Override
    public void getDeviceDocumentation(final DeviceVisitor visitor) {
        visitor.visitCallback(GET_REDSTONE_INPUT)
            .description("Get the current redstone level received on the specified side. " +
                "Note that if the current output level on the specified side is not " +
                "zero, this will affect the measured level.\n" +
                "Sides may be specified by name or zero-based index. Relative sides " +
                "(front, back, left, right) and indices depend on the orientation of the " +
                "device; absolute sides (north, south, west, east) do not.")
            .returnValueDescription("the current received level on the specified side.")
            .parameterDescription(SIDE, "the side to read the input level from.");

        visitor.visitCallback(GET_REDSTONE_OUTPUT)
            .description("Get the current redstone level transmitted on the specified side. " +
                "This will return the value last set via setRedstoneOutput().\n" +
                "Sides may be specified by name or zero-based index. Relative sides " +
                "(front, back, left, right) and indices depend on the orientation of the " +
                "device; absolute sides (north, south, west, east) do not.")
            .returnValueDescription("the current transmitted level on the specified side.")
            .parameterDescription(SIDE, "the side to read the output level from.");
        visitor.visitCallback(SET_REDSTONE_OUTPUT)
            .description("Set the new redstone level transmitted on the specified side.\n" +
                "Sides may be specified by name or zero-based index. Relative sides " +
                "(front, back, left, right) and indices depend on the orientation of the " +
                "device; absolute sides (north, south, west, east) do not.")
            .parameterDescription(SIDE, "the side to write the output level to.")
            .parameterDescription(VALUE, "the output level to set, will be clamped to [0, 15].");
    }

    // --------------------------------------------------------------------- //

    @IOCallback(GET_REDSTONE_INPUT_CODE)
    public void getRedstoneInputIO(final InputStream arguments, final OutputStream results) throws IOException {
        results.write(getRedstoneInput(Side.byIndex(arguments.read())));
    }

    @IOCallback(value = GET_REDSTONE_OUTPUT_CODE, synchronize = false)
    public void getRedstoneOutputIO(final InputStream arguments, final OutputStream results) throws IOException {
        results.write(getRedstoneOutput(Side.byIndex(arguments.read())));
    }

    @IOCallback(SET_REDSTONE_OUTPUT_CODE)
    public void setRedstoneOutputIO(final InputStream arguments) throws IOException {
        final Side side = Side.byIndex(arguments.read());
        final int value = arguments.read();
        if (value < 0) {
            throw new IllegalArgumentException("Missing output level.");
        }
        setRedstoneOutput(side, value);
    }

    // --------------------------------------------------------------------- //

    private int toLocalIndex(final Side side) {
        return HorizontalBlockUtils.toLocal(method_11010(), side).method_10146();
    }

    private void notifyNeighbor(final class_2350 direction) {
        if (field_11863 == null) {
            return;
        }

        field_11863.method_8452(method_11016(), method_11010().method_26204());
        field_11863.method_8452(method_11016().method_10093(direction), method_11010().method_26204());
    }
}
