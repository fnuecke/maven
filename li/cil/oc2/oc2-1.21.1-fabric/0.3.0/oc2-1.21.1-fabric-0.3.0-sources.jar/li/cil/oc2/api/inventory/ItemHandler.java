/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.inventory;

import net.minecraft.class_1799;

/**
 * A slotted item container supporting simulated insertion and extraction.
 */
public interface ItemHandler {
    /**
     * The number of slots in this container.
     *
     * @return the slot count.
     */
    int getSlots();

    /**
     * The stack in the specified slot.
     * <p>
     * The returned stack must not be modified; copy it first.
     *
     * @param slot the slot to read.
     * @return the stack in the slot, or {@link class_1799#field_8037}.
     */
    class_1799 getStackInSlot(int slot);

    /**
     * Inserts a stack into the specified slot.
     *
     * @param slot     the slot to insert into.
     * @param stack    the stack to insert; not modified by this call.
     * @param simulate whether to only test the operation instead of performing it.
     * @return the remainder that could not be inserted; {@link class_1799#field_8037} if all of it was.
     */
    class_1799 insertItem(int slot, class_1799 stack, boolean simulate);

    /**
     * Extracts up to {@code amount} items from the specified slot.
     *
     * @param slot     the slot to extract from.
     * @param amount   the maximum number of items to extract.
     * @param simulate whether to only test the operation instead of performing it.
     * @return the extracted stack; {@link class_1799#field_8037} if nothing was extracted.
     */
    class_1799 extractItem(int slot, int amount, boolean simulate);

    /**
     * The maximum number of items the specified slot can hold.
     *
     * @param slot the slot to get the limit for.
     * @return the slot's capacity.
     */
    default int getSlotLimit(final int slot) {
        return 64;
    }
}
