/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.api.inventory.ItemHandler;
import net.minecraft.class_1262;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

/**
 * oc2's own slotted item container, replacing Forge's {@code ItemStackHandler}.
 * <p>
 * Kept deliberately close to the original's shape so the many subclasses did not have to change,
 * but the NBT methods now take a {@link class_7225.class_7874}: from 1.20.5 on, item stacks cannot
 * be serialized without registry access.
 */
public class ItemStackHandler implements ItemHandler {
    private static final String SIZE_TAG_NAME = "Size";

    protected class_2371<class_1799> stacks;

    // --------------------------------------------------------------------- //

    public ItemStackHandler(final int size) {
        this(class_2371.method_10213(size, class_1799.field_8037));
    }

    public ItemStackHandler(final class_2371<class_1799> stacks) {
        this.stacks = stacks;
    }

    // --------------------------------------------------------------------- //

    @Override
    public int getSlots() {
        return stacks.size();
    }

    @Override
    public class_1799 getStackInSlot(final int slot) {
        validateSlot(slot);
        return stacks.get(slot);
    }

    public void setStackInSlot(final int slot, final class_1799 stack) {
        validateSlot(slot);
        stacks.set(slot, stack);
        onContentsChanged(slot);
    }

    @Override
    public class_1799 insertItem(final int slot, final class_1799 stack, final boolean simulate) {
        if (stack.method_7960()) {
            return class_1799.field_8037;
        }

        if (!isItemValid(slot, stack)) {
            return stack;
        }

        validateSlot(slot);

        final class_1799 existing = stacks.get(slot);

        int limit = getStackLimit(slot, stack);
        if (!existing.method_7960()) {
            if (!class_1799.method_31577(stack, existing)) {
                return stack;
            }
            limit -= existing.method_7947();
        }

        if (limit <= 0) {
            return stack;
        }

        final boolean reachedLimit = stack.method_7947() > limit;
        if (!simulate) {
            if (existing.method_7960()) {
                stacks.set(slot, reachedLimit ? stack.method_46651(limit) : stack);
            } else {
                existing.method_7933(reachedLimit ? limit : stack.method_7947());
            }
            onContentsChanged(slot);
        }

        return reachedLimit ? stack.method_46651(stack.method_7947() - limit) : class_1799.field_8037;
    }

    @Override
    public class_1799 extractItem(final int slot, final int amount, final boolean simulate) {
        if (amount == 0) {
            return class_1799.field_8037;
        }

        validateSlot(slot);

        final class_1799 existing = stacks.get(slot);
        if (existing.method_7960()) {
            return class_1799.field_8037;
        }

        final int toExtract = Math.min(amount, existing.method_7914());
        if (existing.method_7947() <= toExtract) {
            if (!simulate) {
                stacks.set(slot, class_1799.field_8037);
                onContentsChanged(slot);
                return existing;
            }
            return existing.method_7972();
        }

        if (!simulate) {
            stacks.set(slot, existing.method_46651(existing.method_7947() - toExtract));
            onContentsChanged(slot);
        }

        return existing.method_46651(toExtract);
    }

    public int getSlotLimit(final int slot) {
        return class_1792.field_30887;
    }

    public boolean isItemValid(final int slot, final class_1799 stack) {
        return true;
    }

    // --------------------------------------------------------------------- //

    public class_2487 serializeNBT(final class_7225.class_7874 provider) {
        final class_2487 tag = new class_2487();
        tag.method_10569(SIZE_TAG_NAME, stacks.size());
        class_1262.method_5426(tag, stacks, provider);
        return tag;
    }

    public void deserializeNBT(final class_7225.class_7874 provider, final class_2487 tag) {
        setSize(tag.method_10545(SIZE_TAG_NAME) ? tag.method_10550(SIZE_TAG_NAME) : stacks.size());
        class_1262.method_5429(tag, stacks, provider);
        onLoad();
    }

    // --------------------------------------------------------------------- //

    protected void setSize(final int size) {
        stacks = class_2371.method_10213(size, class_1799.field_8037);
    }

    protected int getStackLimit(final int slot, final class_1799 stack) {
        return Math.min(getSlotLimit(slot), stack.method_7914());
    }

    protected void onContentsChanged(final int slot) {
    }

    protected void onLoad() {
    }

    private void validateSlot(final int slot) {
        if (slot < 0 || slot >= stacks.size()) {
            throw new IndexOutOfBoundsException("Slot " + slot + " not in range [0," + stacks.size() + ")");
        }
    }
}
