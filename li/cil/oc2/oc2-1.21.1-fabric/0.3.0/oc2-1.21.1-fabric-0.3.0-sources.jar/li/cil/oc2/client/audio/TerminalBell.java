/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.audio;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_2766;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class TerminalBell {
    public static void play() {
        final class_310 client = class_310.method_1551();
        client.execute(() -> client.method_1483().method_4873(
            class_1109.method_47978(class_2766.field_18289.method_11886(), 1)));
    }

    private TerminalBell() {
    }
}
