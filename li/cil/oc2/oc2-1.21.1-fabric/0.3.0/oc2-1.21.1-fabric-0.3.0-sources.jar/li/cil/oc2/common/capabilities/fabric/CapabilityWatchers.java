/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.capabilities.fabric;

import li.cil.oc2.api.util.Invalidatable;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerBlockEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

final class CapabilityWatchers {
    private static final Map<class_1936, Map<class_2338, List<Invalidatable<?>>>> WATCHERS = new WeakHashMap<>();
    private static final Set<InvalidationKey> INVALIDATING = new HashSet<>();

    // --------------------------------------------------------------------- //

    static void initialize() {
        ServerBlockEntityEvents.BLOCK_ENTITY_UNLOAD.register((blockEntity, level) ->
            invalidate(level, blockEntity.method_11016()));

        ServerChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> invalidate(level, chunk.method_12004()));
    }

    static <T> Invalidatable<T> watch(final class_1936 level, final class_2338 pos, final T value) {
        final Invalidatable<T> result = Invalidatable.of(value);

        final class_2338 key = pos.method_10062();
        final List<Invalidatable<?>> watchers = WATCHERS
            .computeIfAbsent(level, ignored -> new HashMap<>())
            .computeIfAbsent(key, ignored -> new ArrayList<>());
        watchers.add(result);

        result.addListener(ignored -> remove(level, key, result));

        return result;
    }

    static void invalidate(final class_1936 level, final class_2338 pos) {
        final Map<class_2338, List<Invalidatable<?>>> byPosition = WATCHERS.get(level);
        if (byPosition == null) {
            return;
        }

        final List<Invalidatable<?>> watchers = byPosition.remove(pos);
        if (watchers == null) {
            return;
        }

        final InvalidationKey key = new InvalidationKey(level, pos.method_10062());
        if (!INVALIDATING.add(key)) {
            return;
        }

        try {
            // Copy: invalidating fires the listener that removes the entry we are iterating.
            for (final Invalidatable<?> watcher : new ArrayList<>(watchers)) {
                watcher.invalidate();
            }
        } finally {
            INVALIDATING.remove(key);
        }

        if (byPosition.isEmpty()) {
            WATCHERS.remove(level);
        }
    }

    private record InvalidationKey(class_1936 level, class_2338 pos) {
    }

    // --------------------------------------------------------------------- //

    private static void invalidate(final class_1936 level, final class_1923 chunkPos) {
        final Map<class_2338, List<Invalidatable<?>>> byPosition = WATCHERS.get(level);
        if (byPosition == null) {
            return;
        }

        final List<class_2338> positions = byPosition.keySet().stream()
            .filter(pos -> new class_1923(pos).equals(chunkPos))
            .toList();
        for (final class_2338 pos : positions) {
            invalidate(level, pos);
        }
    }

    private static void remove(final class_1936 level, final class_2338 pos, final Invalidatable<?> watcher) {
        final Map<class_2338, List<Invalidatable<?>>> byPosition = WATCHERS.get(level);
        if (byPosition == null) {
            return;
        }

        final List<Invalidatable<?>> watchers = byPosition.get(pos);
        if (watchers == null) {
            return;
        }

        watchers.remove(watcher);
        if (watchers.isEmpty()) {
            byPosition.remove(pos);
            if (byPosition.isEmpty()) {
                WATCHERS.remove(level);
            }
        }
    }

    private CapabilityWatchers() {
    }
}
