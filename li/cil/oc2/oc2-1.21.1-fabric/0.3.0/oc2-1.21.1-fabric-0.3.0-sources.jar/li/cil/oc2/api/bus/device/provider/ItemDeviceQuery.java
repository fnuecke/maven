/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.bus.device.provider;

import li.cil.oc2.api.bus.device.vm.ArchitectureType;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import java.util.Optional;

/**
 * Device query for an item stack.
 *
 * @see ItemDeviceProvider
 */
public interface ItemDeviceQuery {
    /**
     * The architecture of the machine this query is for.
     * <p>
     * Allows providers to select a different device implementation based on the architecture.
     * This can be useful when different architectures are just so fundamentally different that
     * the same device simply cannot work on both as-is, but from a gameplay perspective we still
     * want to provide a seamless experience that "just works".
     * <p>
     * In some cases, e.g. for tooltip queries, this is left empty.
     *
     * @return the architecture the device would be built for, if any.
     */
    Optional<ArchitectureType> getArchitectureType();

    /**
     * The {@link class_2586} that holds the item this query is for.
     *
     * @return the {@link class_2586} hosting the device, if any.
     */
    Optional<class_2586> getContainerBlockEntity();

    /**
     * The {@link class_1297} that holds the item this query is for.
     *
     * @return the {@link class_1297} hosting the device, if any.
     */
    Optional<class_1297> getContainerEntity();

    /**
     * The item stack this query is performed for.
     *
     * @return the item stack to get a device for.
     */
    class_1799 getItemStack();
}
