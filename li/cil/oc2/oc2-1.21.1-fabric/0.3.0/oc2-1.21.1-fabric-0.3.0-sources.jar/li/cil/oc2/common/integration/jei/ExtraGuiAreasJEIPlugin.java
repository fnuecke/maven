/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.integration.jei;

import li.cil.oc2.api.API;
import li.cil.oc2.client.gui.AbstractMachineInventoryScreen;
import li.cil.oc2.client.gui.AbstractMachineTerminalScreen;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.gui.handlers.IGuiContainerHandler;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import net.minecraft.class_2960;
import net.minecraft.class_768;
import java.util.List;

@JeiPlugin
public class ExtraGuiAreasJEIPlugin implements IModPlugin {
    @Override
    public class_2960 getPluginUid() {
        return class_2960.method_60655(API.MOD_ID, "extra_gui_areas");
    }

    @Override
    public void registerGuiHandlers(final IGuiHandlerRegistration registration) {
        registration.addGenericGuiContainerHandler(AbstractMachineInventoryScreen.class, new AbstractMachineInventoryScreenGuiContainerHandler());
        registration.addGenericGuiContainerHandler(AbstractMachineTerminalScreen.class, new AbstractMachineTerminalScreenGuiContainerHandler());
    }

    private static final class AbstractMachineInventoryScreenGuiContainerHandler implements IGuiContainerHandler<AbstractMachineInventoryScreen<?>> {
        @Override
        public List<class_768> getGuiExtraAreas(final AbstractMachineInventoryScreen<?> screen) {
            return screen.getExtraAreas();
        }
    }

    private static final class AbstractMachineTerminalScreenGuiContainerHandler implements IGuiContainerHandler<AbstractMachineTerminalScreen<?>> {
        @Override
        public List<class_768> getGuiExtraAreas(final AbstractMachineTerminalScreen<?> screen) {
            return screen.getExtraAreas();
        }
    }
}
