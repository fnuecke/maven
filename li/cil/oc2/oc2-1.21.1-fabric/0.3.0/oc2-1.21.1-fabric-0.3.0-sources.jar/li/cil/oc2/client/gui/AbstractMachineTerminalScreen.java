/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.util.TooltipRenderer;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.client.gui.widget.ToggleImageButton;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.container.AbstractMachineTerminalContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_5244;
import net.minecraft.class_5348;
import net.minecraft.class_768;
import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;
import static li.cil.oc2.common.util.TextFormatUtils.withFormat;

@Environment(EnvType.CLIENT)
public abstract class AbstractMachineTerminalScreen<T extends AbstractMachineTerminalContainer> extends AbstractModContainerScreen<T> {
    private static final int CONTROLS_TOP = 8;
    private static final int ENERGY_TOP = CONTROLS_TOP + Sprites.SIDEBAR_3.height + 4;

    private static boolean isInputCaptureEnabled;

    private final MachineTerminalWidget terminalWidget;

    // --------------------------------------------------------------------- //

    protected AbstractMachineTerminalScreen(final T container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title);
        this.terminalWidget = new MachineTerminalWidget(this);
        field_2792 = Sprites.TERMINAL_SCREEN.width;
        field_2779 = Sprites.TERMINAL_SCREEN.height;
    }

    // --------------------------------------------------------------------- //

    public static boolean isInputCaptureEnabled() {
        return isInputCaptureEnabled;
    }

    public List<class_768> getExtraAreas() {
        final List<class_768> list = new ArrayList<>();
        list.add(new class_768(
            field_2776 - Sprites.SIDEBAR_3.width, field_2800 + CONTROLS_TOP,
            Sprites.SIDEBAR_3.width, Sprites.SIDEBAR_3.height
        ));

        if (shouldRenderEnergyBar()) {
            list.add(new class_768(
                field_2776 - Sprites.SIDEBAR_2.width, field_2800 + ENERGY_TOP,
                Sprites.SIDEBAR_2.width, Sprites.SIDEBAR_2.height
            ));
        }

        return list;
    }

    @Override
    public void method_37432() {
        super.method_37432();

        terminalWidget.tick();
    }

    @Override
    public boolean method_25400(final char ch, final int modifiers) {
        return terminalWidget.charTyped(ch, modifiers) ||
            super.method_25400(ch, modifiers);
    }

    @Override
    public boolean method_25404(final int keyCode, final int scanCode, final int modifiers) {
        if (terminalWidget.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }

        // Don't close with inventory binding since we usually want to use that as terminal input
        // even without input capture enabled.
        if (field_22787.field_1690.field_1822.method_1417(keyCode, scanCode)) {
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25426() {
        super.method_25426();
        terminalWidget.init();

        final class_342 focusIndicatorEditBox = new class_342(field_22793, 0, 0, 0, 0, class_5244.field_39003);
        focusIndicatorEditBox.method_25365(true);
        setFocusIndicatorEditBox(focusIndicatorEditBox);

        method_37063(new ToggleImageButton(
            field_2776 - Sprites.SIDEBAR_3.width + 4, field_2800 + CONTROLS_TOP + 4,
            12, 12,
            Sprites.POWER_BUTTON_BASE,
            Sprites.POWER_BUTTON_PRESSED,
            Sprites.POWER_BUTTON_ACTIVE
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                field_2797.sendPowerStateToServer(!field_2797.getVirtualMachine().isRunning());
            }

            @Override
            public boolean isToggled() {
                return field_2797.getVirtualMachine().isRunning();
            }
        }).withTooltip(
            class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_CAPTION),
            class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_DESCRIPTION)
        );

        method_37063(new ToggleImageButton(
            field_2776 - Sprites.SIDEBAR_3.width + 4, field_2800 + CONTROLS_TOP + 4 + 14,
            12, 12,
            Sprites.INPUT_BUTTON_BASE,
            Sprites.INPUT_BUTTON_PRESSED,
            Sprites.INPUT_BUTTON_ACTIVE
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                isInputCaptureEnabled = !isInputCaptureEnabled;
            }

            @Override
            public boolean isToggled() {
                return isInputCaptureEnabled;
            }
        }).withTooltip(
            class_2561.method_43471(Constants.TERMINAL_CAPTURE_INPUT_CAPTION),
            class_2561.method_43471(Constants.TERMINAL_CAPTURE_INPUT_DESCRIPTION)
        );

        method_37063(new ImageButton(
            field_2776 - Sprites.SIDEBAR_3.width + 4, field_2800 + CONTROLS_TOP + 4 + 14 + 14,
            12, 12,
            Sprites.INVENTORY_BUTTON_INACTIVE,
            Sprites.INVENTORY_BUTTON_ACTIVE
        ) {
            @Override
            public void method_25306() {
                field_2797.switchToInventory();
            }
        }).withTooltip(class_2561.method_43471(Constants.MACHINE_OPEN_INVENTORY_CAPTION));
    }

    @Override
    public void method_25432() {
        super.method_25432();
        terminalWidget.onClose();
    }

    // --------------------------------------------------------------------- //

    // We use this text box to indicate to Forge that we want all input, and event handlers should not be allowed
    // to steal input from us (e.g. via custom key bindings). Since Forge is lazy and just uses getDeclaredFields
    // to get private fields, which completely skips fields in base classes, we require subclasses to hold the field...
    protected abstract void setFocusIndicatorEditBox(final class_342 editBox);

    @Override
    protected void renderFg(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        super.renderFg(graphics, partialTicks, mouseX, mouseY);

        if (shouldRenderEnergyBar()) {
            final int x = field_2776 - Sprites.SIDEBAR_2.width + 4;
            final int y = field_2800 + ENERGY_TOP + 4;
            Sprites.ENERGY_BAR.drawFillY(graphics, x, y, field_2797.getEnergy() / (float) field_2797.getEnergyCapacity());
        }

        terminalWidget.render(graphics, mouseX, mouseY, field_2797.getVirtualMachine().getError());
    }

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        Sprites.SIDEBAR_3.draw(graphics, field_2776 - Sprites.SIDEBAR_3.width, field_2800 + CONTROLS_TOP);

        if (shouldRenderEnergyBar()) {
            final int x = field_2776 - Sprites.SIDEBAR_2.width;
            final int y = field_2800 + ENERGY_TOP;
            Sprites.SIDEBAR_2.draw(graphics, x, y);
            Sprites.ENERGY_BASE.draw(graphics, x + 4, y + 4);
        }

        terminalWidget.renderBackground(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2380(final class_332 graphics, final int mouseX, final int mouseY) {
        super.method_2380(graphics, mouseX, mouseY);

        if (shouldRenderEnergyBar()) {
            if (isMouseOver(mouseX, mouseY, -Sprites.SIDEBAR_2.width + 4, ENERGY_TOP + 4, Sprites.ENERGY_BAR.width, Sprites.ENERGY_BAR.height)) {
                final List<? extends class_5348> tooltip = asList(
                    class_2561.method_43469(Constants.TOOLTIP_ENERGY,
                        withFormat(field_2797.getEnergy() + "/" + field_2797.getEnergyCapacity(), class_124.field_1060)),
                    class_2561.method_43469(Constants.TOOLTIP_ENERGY_CONSUMPTION,
                        withFormat(String.valueOf(field_2797.getEnergyConsumption()), class_124.field_1060))
                );
                TooltipRenderer.drawTooltip(graphics, tooltip, mouseX, mouseY, 200);
            }
        }
    }

    @Override
    protected void method_2388(final class_332 graphics, final int mouseX, final int mouseY) {
        // This is required to prevent the labels from being rendered
    }

    // --------------------------------------------------------------------- //

    private boolean shouldRenderEnergyBar() {
        return field_2797.getEnergyCapacity() > 0;
    }
}
