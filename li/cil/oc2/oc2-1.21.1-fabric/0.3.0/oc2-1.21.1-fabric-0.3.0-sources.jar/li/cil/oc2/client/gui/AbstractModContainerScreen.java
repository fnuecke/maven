/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;

@Environment(EnvType.CLIENT)
public abstract class AbstractModContainerScreen<T extends class_1703> extends class_465<T> {
    public AbstractModContainerScreen(final T container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title);
    }

    // --------------------------------------------------------------------- //

    public boolean isMouseOver(final int mouseX, final int mouseY, final int x, final int y, final int width, final int height) {
        final int localMouseX = mouseX - field_2776;
        final int localMouseY = mouseY - field_2800;
        return localMouseX >= x &&
            localMouseX < x + width &&
            localMouseY >= y &&
            localMouseY < y + height;
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        renderFg(graphics, partialTicks, mouseX, mouseY);

        method_2380(graphics, mouseX, mouseY);
    }

    // --------------------------------------------------------------------- //


    protected void renderFg(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
    }
}
