/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity.robot;

import li.cil.oc2.common.entity.Entities;
import li.cil.oc2.common.entity.Robot;
import li.cil.oc2.common.util.NBTUtils;
import li.cil.oc2.common.util.TickUtils;
import net.minecraft.class_1313;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import javax.annotation.Nullable;
import java.time.Duration;
import java.util.Objects;

public final class RobotMovementAction extends AbstractRobotAction {
    public static final double TARGET_EPSILON = 0.0001;

    // --------------------------------------------------------------------- //

    private static final float MOVEMENT_SPEED = 1f / TickUtils.toTicks(Duration.ofSeconds(1)); // blocks per tick

    private static final String DIRECTION_TAG_NAME = "direction";
    private static final String ORIGIN_TAG_NAME = "origin";
    private static final String START_TAG_NAME = "start";
    private static final String TARGET_TAG_NAME = "target";

    // --------------------------------------------------------------------- //

    @Nullable
    private MovementDirection direction;
    @Nullable
    private class_2338 origin;
    @Nullable
    private class_2338 start;
    @Nullable
    private class_2338 target;
    @Nullable
    private class_243 targetPos;

    // --------------------------------------------------------------------- //

    public RobotMovementAction(final MovementDirection direction) {
        super(RobotActions.MOVEMENT);
        this.direction = direction.resolve();
    }

    RobotMovementAction(final class_2487 tag) {
        super(RobotActions.MOVEMENT, tag);
    }

    // --------------------------------------------------------------------- //

    public static class_243 getTargetPositionInBlock(final class_2338 position) {
        return class_243.method_24955(position).method_1031(0, 0.5f * (1 - Entities.ROBOT.get().method_17686()), 0);
    }

    public static void moveTowards(final Robot robot, final class_243 targetPosition) {
        class_243 delta = targetPosition.method_1020(robot.method_19538());
        if (delta.method_1027() > MOVEMENT_SPEED * MOVEMENT_SPEED) {
            delta = delta.method_1029().method_1021(MOVEMENT_SPEED);
        }

        robot.method_5784(class_1313.field_6308, delta);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void initialize(final Robot robot) {
        if (origin == null || start == null || target == null) {
            origin = robot.method_24515();
            start = origin;
            target = start;
            if (direction != null) {
                switch (direction) {
                    case UPWARD -> target = target.method_10093(class_2350.field_11036);
                    case DOWNWARD -> target = target.method_10093(class_2350.field_11033);
                    case FORWARD -> target = target.method_10093(robot.method_5735());
                    case BACKWARD -> target = target.method_10093(robot.method_5735().method_10153());
                }
            }
        }

        targetPos = getTargetPositionInBlock(target);
        robot.method_5841().method_12778(Robot.TARGET_POSITION, target);
    }

    @Override
    public RobotActionResult perform(final Robot robot) {
        if (targetPos == null) {
            throw new IllegalStateException();
        }

        validateTarget(robot);

        moveAndResolveCollisions(robot);

        if (robot.method_19538().method_1025(targetPos) < TARGET_EPSILON) {
            if (Objects.equals(target, origin)) {
                return RobotActionResult.FAILURE; // Collided and returned.
            } else {
                return RobotActionResult.SUCCESS; // Made it to new location.
            }
        }

        return RobotActionResult.INCOMPLETE;
    }

    @Override
    public class_2487 serialize() {
        final class_2487 tag = super.serialize();

        NBTUtils.putEnum(tag, DIRECTION_TAG_NAME, direction);
        if (origin != null) {
            tag.method_10566(ORIGIN_TAG_NAME, class_2512.method_10692(origin));
        }
        if (start != null) {
            tag.method_10566(START_TAG_NAME, class_2512.method_10692(start));
        }
        if (target != null) {
            tag.method_10566(TARGET_TAG_NAME, class_2512.method_10692(target));
        }

        return tag;
    }

    @Override
    public void deserialize(final class_2487 tag) {
        super.deserialize(tag);

        direction = NBTUtils.getEnum(tag, DIRECTION_TAG_NAME, MovementDirection.class);
        if (direction == null) direction = MovementDirection.FORWARD;
        direction = direction.resolve();
        origin = class_2512.method_10691(tag, ORIGIN_TAG_NAME).orElse(null);
        start = class_2512.method_10691(tag, START_TAG_NAME).orElse(null);
        target = class_2512.method_10691(tag, TARGET_TAG_NAME).orElse(null);
        if (target != null) {
            targetPos = getTargetPositionInBlock(target);
        }
    }

    private void moveAndResolveCollisions(final Robot robot) {
        if (start == null || target == null || targetPos == null) {
            return;
        }

        moveTowards(robot, targetPos);

        final boolean didCollide = robot.field_5976 || robot.field_5992;
        final long gameTime = robot.method_37908().method_8510();
        if (didCollide && !robot.method_37908().method_8608()
            && robot.getLastPistonMovement() < gameTime - 1) {
            final class_2338 newStart = target;
            target = start;
            start = newStart;
            targetPos = getTargetPositionInBlock(target);
            robot.method_5841().method_12778(Robot.TARGET_POSITION, target);
        }
    }

    private void validateTarget(final Robot robot) {
        final class_2338 currentPosition = robot.method_24515();
        if (start == null || Objects.equals(currentPosition, start) ||
            target == null || Objects.equals(currentPosition, target)) {
            return;
        }

        // Got pushed out of our original path. Adjust start and target by the least offset.
        final class_2338 fromStart = currentPosition.method_10059(start);
        final class_2338 fromTarget = currentPosition.method_10059(target);

        final int deltaStart = fromStart.method_10263() + fromStart.method_10264() + fromStart.method_10260();
        final int deltaTarget = fromTarget.method_10263() + fromTarget.method_10264() + fromTarget.method_10260();

        if (deltaStart < deltaTarget) {
            start = currentPosition;
            target = target.method_10081(fromStart);
        } else {
            start = start.method_10081(fromTarget);
            target = currentPosition;
        }

        targetPos = getTargetPositionInBlock(target);
        robot.method_5841().method_12778(Robot.TARGET_POSITION, target);
    }
}
