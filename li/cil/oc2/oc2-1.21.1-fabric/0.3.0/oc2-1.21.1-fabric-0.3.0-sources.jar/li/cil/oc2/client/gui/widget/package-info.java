/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.gui.widget;

import javax.annotation.ParametersAreNonnullByDefault;
