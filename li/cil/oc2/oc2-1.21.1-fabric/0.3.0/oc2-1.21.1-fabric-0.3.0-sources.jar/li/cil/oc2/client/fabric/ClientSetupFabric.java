/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.fabric;

import dev.architectury.registry.client.level.entity.EntityModelLayerRegistry;
import dev.architectury.registry.client.level.entity.EntityRendererRegistry;
import dev.architectury.registry.client.rendering.BlockEntityRendererRegistry;
import dev.architectury.registry.client.rendering.ColorHandlerRegistry;
import dev.architectury.registry.menu.MenuRegistry;
import li.cil.oc2.client.gui.*;
import li.cil.oc2.client.item.CustomItemColors;
import li.cil.oc2.client.item.CustomItemModelProperties;
import li.cil.oc2.client.model.fabric.BusCableModelLoader;
import li.cil.oc2.client.renderer.ProjectorDepthRenderer;
import li.cil.oc2.client.renderer.blockentity.ChargerRenderer;
import li.cil.oc2.client.renderer.blockentity.ComputerRenderer;
import li.cil.oc2.client.renderer.blockentity.DiskDriveRenderer;
import li.cil.oc2.client.renderer.blockentity.ProjectorRenderer;
import li.cil.oc2.client.renderer.color.BusCableBlockColor;
import li.cil.oc2.client.renderer.entity.RobotRenderer;
import li.cil.oc2.client.renderer.entity.RobotWithoutLevelRenderer;
import li.cil.oc2.client.renderer.entity.model.RobotModel;
import li.cil.oc2.client.renderer.fabric.ModShadersFabric;
import li.cil.oc2.common.block.Blocks;
import li.cil.oc2.common.block.BusCableBlock;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.container.Containers;
import li.cil.oc2.common.entity.Entities;
import li.cil.oc2.common.item.Items;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockGatherCallback;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class ClientSetupFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ComputerRenderer.initialize();
        ProjectorDepthRenderer.initialize();
        ModShadersFabric.initialize();
        ClientLevelEventsFabric.initialize();
        ClientRenderEventsFabric.initialize();

        CustomItemModelProperties.initialize();
        CustomItemColors.initialize();

        BusCableModelLoader.initialize();
        ColorHandlerRegistry.registerBlockColors(new BusCableBlockColor(), Blocks.BUS_CABLE);

        BlockEntityRendererRegistry.register(BlockEntities.COMPUTER.get(), ComputerRenderer::new);
        BlockEntityRendererRegistry.register(BlockEntities.DISK_DRIVE.get(), DiskDriveRenderer::new);
        BlockEntityRendererRegistry.register(BlockEntities.CHARGER.get(), ChargerRenderer::new);
        BlockEntityRendererRegistry.register(BlockEntities.PROJECTOR.get(), ProjectorRenderer::new);

        EntityRendererRegistry.register(Entities.ROBOT, RobotRenderer::new);
        EntityModelLayerRegistry.register(RobotModel.ROBOT_MODEL_LAYER, RobotModel::createRobotLayer);

        MenuRegistry.registerScreenFactory(Containers.COMPUTER.get(), ComputerContainerScreen::new);
        MenuRegistry.registerScreenFactory(Containers.COMPUTER_TERMINAL.get(), ComputerTerminalScreen::new);
        MenuRegistry.registerScreenFactory(Containers.ROBOT.get(), RobotContainerScreen::new);
        MenuRegistry.registerScreenFactory(Containers.ROBOT_TERMINAL.get(), RobotTerminalScreen::new);
        MenuRegistry.registerScreenFactory(Containers.NETWORK_TUNNEL.get(), NetworkTunnelScreen::new);

        BuiltinItemRendererRegistry.INSTANCE.register(Items.ROBOT.get(), new RobotItemRenderer());

        registerBusCablePickBlock();
    }

    // --------------------------------------------------------------------- //

    /**
     * Matches NeoForge's {@code Block#getCloneItemStack}.
     */
    private static void registerBusCablePickBlock() {
        ClientPickBlockGatherCallback.EVENT.register((player, result) -> {
            if (!(result instanceof final class_3965 hit) || result.method_17783() != class_239.class_240.field_1332) {
                return class_1799.field_8037;
            }

            if (player.method_37908().method_8321(hit.method_17777()) instanceof BusCableBlockEntity) {
                return BusCableBlock.getPickedStack(player.method_37908(), hit.method_17777(), player);
            }

            return class_1799.field_8037;
        });
    }

    private static final class RobotItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {
        private RobotWithoutLevelRenderer renderer;

        @Override
        public void render(final class_1799 stack, final net.minecraft.class_811 context,
                           final net.minecraft.class_4587 poseStack,
                           final net.minecraft.class_4597 bufferSource,
                           final int light, final int overlay) {
            if (renderer == null) {
                final class_310 minecraft = class_310.method_1551();
                renderer = new RobotWithoutLevelRenderer(
                    minecraft.method_31975(), minecraft.method_31974());
            }
            renderer.method_3166(stack, context, poseStack, bufferSource, light, overlay);
        }
    }
}
