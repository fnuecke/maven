/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.integration;

import javax.annotation.ParametersAreNonnullByDefault;
