/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.api.inventory.ItemHandler;
import net.minecraft.class_1799;

public final class ItemHandlerUtils {
    public static class_1799 insertItemStack(final ItemHandler handler, class_1799 stack, final boolean simulate) {
        if (stack.method_7960()) {
            return class_1799.field_8037;
        }

        if (stack.method_7946()) {
            for (int slot = 0; slot < handler.getSlots() && !stack.method_7960(); slot++) {
                final class_1799 existing = handler.getStackInSlot(slot);
                if (!existing.method_7960() && class_1799.method_31577(existing, stack)) {
                    stack = handler.insertItem(slot, stack, simulate);
                }
            }

            if (stack.method_7960()) {
                return class_1799.field_8037;
            }
        }

        for (int slot = 0; slot < handler.getSlots() && !stack.method_7960(); slot++) {
            if (handler.getStackInSlot(slot).method_7960()) {
                stack = handler.insertItem(slot, stack, simulate);
            }
        }

        return stack;
    }

    private ItemHandlerUtils() {
    }
}
