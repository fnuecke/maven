/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
