/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.client.gui.util.GuiUtils;
import li.cil.oc2.client.gui.util.TooltipRenderer;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.client.gui.widget.ToggleImageButton;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.container.AbstractMachineTerminalContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_5348;
import net.minecraft.class_757;
import net.minecraft.class_768;
import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;
import static li.cil.oc2.common.util.TextFormatUtils.withFormat;

@Environment(EnvType.CLIENT)
public abstract class AbstractMachineInventoryScreen<T extends AbstractMachineTerminalContainer> extends AbstractModContainerScreen<T> {
    private static final int CONTROLS_TOP = 8;
    private static final int ENERGY_TOP = CONTROLS_TOP + Sprites.SIDEBAR_2.height + 4;

    // --------------------------------------------------------------------- //

    public AbstractMachineInventoryScreen(final T container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title);
    }

    // --------------------------------------------------------------------- //

    public List<class_768> getExtraAreas() {
        final List<class_768> list = new ArrayList<>();
        list.add(new class_768(
            field_2776 - Sprites.SIDEBAR_2.width, field_2800 + CONTROLS_TOP,
            Sprites.SIDEBAR_2.width, Sprites.SIDEBAR_2.height
        ));

        if (shouldRenderEnergyBar()) {
            list.add(new class_768(
                field_2776 - Sprites.SIDEBAR_2.width, field_2800 + ENERGY_TOP,
                Sprites.SIDEBAR_2.width, Sprites.SIDEBAR_2.height
            ));
        }

        return list;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        method_37063(new ToggleImageButton(
            field_2776 - Sprites.SIDEBAR_3.width + 4, field_2800 + CONTROLS_TOP + 4,
            12, 12,
            Sprites.POWER_BUTTON_BASE,
            Sprites.POWER_BUTTON_PRESSED,
            Sprites.POWER_BUTTON_ACTIVE
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                field_2797.sendPowerStateToServer(!field_2797.getVirtualMachine().isRunning());
            }

            @Override
            public boolean isToggled() {
                return field_2797.getVirtualMachine().isRunning();
            }
        }).withTooltip(
            class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_CAPTION),
            class_2561.method_43471(Constants.COMPUTER_SCREEN_POWER_DESCRIPTION)
        );

        method_37063(new ImageButton(
            field_2776 - Sprites.SIDEBAR_3.width + 4, field_2800 + CONTROLS_TOP + 4 + 14,
            12, 12,
            Sprites.INVENTORY_BUTTON_ACTIVE,
            Sprites.INVENTORY_BUTTON_INACTIVE
        ) {
            @Override
            public void method_25306() {
                field_2797.switchToTerminal();
            }
        }.withTooltip(class_2561.method_43471(Constants.MACHINE_OPEN_TERMINAL_CAPTION)));
    }

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1, 1, 1, 1);

        Sprites.SIDEBAR_2.draw(graphics, field_2776 - Sprites.SIDEBAR_2.width, field_2800 + CONTROLS_TOP);

        if (shouldRenderEnergyBar()) {
            final int x = field_2776 - Sprites.SIDEBAR_2.width;
            final int y = field_2800 + ENERGY_TOP;
            Sprites.SIDEBAR_2.draw(graphics, x, y);
            Sprites.ENERGY_BASE.draw(graphics, x + 4, y + 4);
        }
    }

    @Override
    protected void renderFg(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        super.renderFg(graphics, partialTicks, mouseX, mouseY);

        GuiUtils.renderMissingDeviceInfoIcon(graphics, this, DeviceTypes.FLASH_MEMORY.get(), Sprites.WARN_ICON);
        GuiUtils.renderMissingDeviceInfoIcon(graphics, this, DeviceTypes.MEMORY.get(), Sprites.WARN_ICON);
        GuiUtils.renderMissingDeviceInfoIcon(graphics, this, DeviceTypes.HARD_DRIVE.get(), Sprites.INFO_ICON);

        if (shouldRenderEnergyBar()) {
            final int x = field_2776 - Sprites.SIDEBAR_2.width + 4;
            final int y = field_2800 + ENERGY_TOP + 4;
            Sprites.ENERGY_BAR.drawFillY(graphics, x, y, field_2797.getEnergy() / (float) field_2797.getEnergyCapacity());
        }
    }

    @Override
    protected void method_2380(final class_332 graphics, final int mouseX, final int mouseY) {
        super.method_2380(graphics, mouseX, mouseY);

        GuiUtils.renderMissingDeviceInfoTooltip(graphics, this, mouseX, mouseY, DeviceTypes.FLASH_MEMORY.get());
        GuiUtils.renderMissingDeviceInfoTooltip(graphics, this, mouseX, mouseY, DeviceTypes.MEMORY.get());
        GuiUtils.renderMissingDeviceInfoTooltip(graphics, this, mouseX, mouseY, DeviceTypes.HARD_DRIVE.get());

        if (shouldRenderEnergyBar()) {
            if (isMouseOver(mouseX, mouseY, -Sprites.SIDEBAR_2.width + 4, ENERGY_TOP + 4, Sprites.ENERGY_BAR.width, Sprites.ENERGY_BAR.height)) {
                final List<? extends class_5348> tooltip = asList(
                    class_2561.method_43469(Constants.TOOLTIP_ENERGY,
                        withFormat(field_2797.getEnergy() + "/" + field_2797.getEnergyCapacity(), class_124.field_1060)),
                    class_2561.method_43469(Constants.TOOLTIP_ENERGY_CONSUMPTION,
                        withFormat(String.valueOf(field_2797.getEnergyConsumption()), class_124.field_1060))
                );
                TooltipRenderer.drawTooltip(graphics, tooltip, mouseX, mouseY, 200);
            }
        }
    }

    // --------------------------------------------------------------------- //

    private boolean shouldRenderEnergyBar() {
        return field_2797.getEnergyCapacity() > 0;
    }
}
