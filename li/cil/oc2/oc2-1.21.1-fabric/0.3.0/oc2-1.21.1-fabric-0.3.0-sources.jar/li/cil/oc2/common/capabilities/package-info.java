/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.capabilities;

import javax.annotation.ParametersAreNonnullByDefault;
