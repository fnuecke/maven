/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.ext;

import javax.annotation.Nullable;
import net.minecraft.class_276;

public interface MinecraftExt {
    void setMainRenderTargetOverride(@Nullable class_276 renderTarget);
}
