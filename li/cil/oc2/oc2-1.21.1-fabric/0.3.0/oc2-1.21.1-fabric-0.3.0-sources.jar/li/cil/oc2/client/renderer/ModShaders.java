/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.api.API;
import net.minecraft.class_1043;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import org.joml.Matrix4f;

import javax.annotation.Nullable;

public final class ModShaders {
    public static final int MAX_PROJECTORS = 3;

    public static final class_2960 PROJECTORS_SHADER_LOCATION = class_2960.method_60655(API.MOD_ID, "projectors");
    public static final class_2960 TERMINAL_SHADER_LOCATION = class_2960.method_60655(API.MOD_ID, "terminal");
    private static final String[] PROJECTOR_COLOR_NAMES = {"ProjectorColor0", "ProjectorColor1", "ProjectorColor2"};
    private static final String[] PROJECTOR_DEPTH_NAMES = {"ProjectorDepth0", "ProjectorDepth1", "ProjectorDepth2"};
    private static final String[] PROJECTOR_CAMERA_NAMES = {"ProjectorCamera0", "ProjectorCamera1", "ProjectorCamera2"};

    // --------------------------------------------------------------------- //

    private static class_5944 projectorsShader;
    private static class_5944 terminalShader;

    // --------------------------------------------------------------------- //

    @Nullable
    public static class_5944 getProjectorsShader() {
        return projectorsShader;
    }

    @Nullable
    public static class_5944 getTerminalShader() {
        return terminalShader;
    }

    @SuppressWarnings("ConstantConditions") // Setting samples to null to clear them is fine.
    public static void configureProjectorsShader(
        final class_276 target,
        final Matrix4f inverseCameraMatrix,
        final class_1043[] colors,
        final class_276[] depths,
        final Matrix4f[] projectorCameraMatrices,
        final int count
    ) {
        final int projectorCount = Math.min(count, MAX_PROJECTORS);
        projectorsShader.method_35785("Count").method_35649(projectorCount);

        projectorsShader.method_34583("MainCameraDepth", target.method_30278());
        projectorsShader.method_35785("InverseMainCamera").method_1250(inverseCameraMatrix);

        for (int i = 0; i < MAX_PROJECTORS; i++) {
            if (i < projectorCount) {
                projectorsShader.method_34583(PROJECTOR_COLOR_NAMES[i], colors[i].method_4624());
                projectorsShader.method_34583(PROJECTOR_DEPTH_NAMES[i], depths[i].method_30278());
                projectorsShader.method_35785(PROJECTOR_CAMERA_NAMES[i]).method_1250(projectorCameraMatrices[i]);
            } else {
                projectorsShader.method_34583(PROJECTOR_COLOR_NAMES[i], null);
                projectorsShader.method_34583(PROJECTOR_DEPTH_NAMES[i], null);
            }
        }
    }

    public static void setProjectorsShader(@Nullable final class_5944 shader) {
        projectorsShader = shader;
    }

    public static void setTerminalShader(@Nullable final class_5944 shader) {
        terminalShader = shader;
    }
}
