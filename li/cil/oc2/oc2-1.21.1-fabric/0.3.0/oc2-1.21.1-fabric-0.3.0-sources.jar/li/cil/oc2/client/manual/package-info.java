/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.manual;

import javax.annotation.ParametersAreNonnullByDefault;
