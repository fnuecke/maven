/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.object.Callbacks;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockDeviceProvider;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class BlockStateObjectDeviceProvider extends AbstractBlockDeviceProvider {
    @Override
    public Invalidatable<Device> getDevice(final BlockDeviceQuery query) {
        final class_1936 level = query.getLevel();
        final class_2338 position = query.getQueryPosition();

        final class_2680 blockState = level.method_8320(position);

        if (blockState.method_26215()) {
            return Invalidatable.empty();
        }

        final class_2248 block = blockState.method_26204();
        if (!Callbacks.hasMethods(block)) {
            return Invalidatable.empty();
        }

        return Invalidatable.of(new ObjectDevice(block));
    }
}
