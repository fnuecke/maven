/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity.robot;

import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_2487;

public abstract class AbstractRobotAction {
    private static final String ID_TAG_NAME = "id";

    // --------------------------------------------------------------------- //

    private final AbstractRobotActionType type;
    private int id;

    // --------------------------------------------------------------------- //

    public AbstractRobotAction(final AbstractRobotActionType type) {
        this.type = type;
    }

    public AbstractRobotAction(final AbstractRobotActionType type, final class_2487 tag) {
        this(type);
        deserialize(tag);
    }

    // --------------------------------------------------------------------- //

    public AbstractRobotActionType getType() {
        return type;
    }

    public int getId() {
        return id;
    }

    public void setId(final int value) {
        id = value;
    }

    public void initialize(final Robot robot) {
    }

    public abstract RobotActionResult perform(Robot robot);

    public class_2487 serialize() {
        final class_2487 tag = new class_2487();

        tag.method_10569(ID_TAG_NAME, id);

        return tag;
    }

    public void deserialize(final class_2487 tag) {
        id = tag.method_10550(ID_TAG_NAME);
    }
}
