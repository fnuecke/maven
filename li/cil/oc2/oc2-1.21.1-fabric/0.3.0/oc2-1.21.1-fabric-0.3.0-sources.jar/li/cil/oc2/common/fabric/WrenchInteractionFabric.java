/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.fabric;

import li.cil.oc2.common.item.WrenchItem;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;

/**
 * Matches NeoForge's {@code IItemExtension#onItemUseFirst}.
 */
public final class WrenchInteractionFabric {
    public static void initialize() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            final class_1799 stack = player.method_5998(hand);
            if (!(stack.method_7909() instanceof final WrenchItem wrench)) {
                return class_1269.field_5811;
            }

            return wrench.tryRotate(new class_1838(player, hand, hit));
        });
    }

    public static boolean isHoldingWrench(final class_1657 player) {
        for (final class_1268 hand : class_1268.values()) {
            if (player.method_5998(hand).method_7909() instanceof WrenchItem) {
                return true;
            }
        }
        return false;
    }

    private WrenchInteractionFabric() {
    }
}
