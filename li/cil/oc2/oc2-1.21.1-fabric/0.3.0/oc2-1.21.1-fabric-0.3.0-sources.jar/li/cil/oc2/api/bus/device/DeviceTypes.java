/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.bus.device;

import li.cil.oc2.api.API;
import li.cil.oc2.api.util.Registries;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.function.Supplier;

/**
 * Lists built-in device types for convenience.
 */
public final class DeviceTypes {
    public static final Supplier<DeviceType> CPU = of("cpu");
    public static final Supplier<DeviceType> MEMORY = of("memory");
    public static final Supplier<DeviceType> HARD_DRIVE = of("hard_drive");
    public static final Supplier<DeviceType> FLASH_MEMORY = of("flash_memory");
    public static final Supplier<DeviceType> CARD = of("card");
    public static final Supplier<DeviceType> ROBOT_MODULE = of("robot_module");
    public static final Supplier<DeviceType> FLOPPY = of("floppy");
    public static final Supplier<DeviceType> NETWORK_TUNNEL = of("network_tunnel");

    // --------------------------------------------------------------------- //

    private static Supplier<DeviceType> of(final String name) {
        final class_2960 id = class_2960.method_60655(API.MOD_ID, name);
        return new Supplier<>() {
            private DeviceType value;

            @Override
            public DeviceType get() {
                if (value == null) {
                    value = registry().method_10223(id);
                    if (value == null) {
                        throw new IllegalStateException("Device type [" + id + "] is not registered yet.");
                    }
                }
                return value;
            }
        };
    }

    @SuppressWarnings("unchecked")
    private static class_2378<DeviceType> registry() {
        final class_2378<?> registry = class_7923.field_41167.method_10223(Registries.DEVICE_TYPE.method_29177());
        if (registry == null) {
            throw new IllegalStateException("Registry [" + Registries.DEVICE_TYPE.method_29177() + "] does not exist yet.");
        }
        return (class_2378<DeviceType>) registry;
    }

    private DeviceTypes() {
    }
}
