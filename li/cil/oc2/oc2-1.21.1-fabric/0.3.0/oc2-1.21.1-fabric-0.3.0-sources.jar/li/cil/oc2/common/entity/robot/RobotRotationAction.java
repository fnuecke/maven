/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity.robot;

import li.cil.oc2.common.entity.Robot;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.oc2.common.util.NBTUtils;
import li.cil.oc2.common.util.TickUtils;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_3532;
import javax.annotation.Nullable;
import java.time.Duration;

public final class RobotRotationAction extends AbstractRobotAction {
    public static final float TARGET_EPSILON = 0.0001f;

    // --------------------------------------------------------------------- //

    private static final float ROTATION_SPEED = 90f / TickUtils.toTicks(Duration.ofSeconds(1)); // degrees per tick

    private static final String DIRECTION_TAG_NAME = "direction";
    private static final String TARGET_TAG_NAME = "start";

    // --------------------------------------------------------------------- //

    @Nullable
    private RotationDirection direction;
    @Nullable
    private class_2350 target;

    // --------------------------------------------------------------------- //

    public RobotRotationAction(final RotationDirection direction) {
        super(RobotActions.ROTATION);
        this.direction = direction.resolve();
    }

    RobotRotationAction(final class_2487 tag) {
        super(RobotActions.ROTATION, tag);
    }

    // --------------------------------------------------------------------- //

    public static void rotateTowards(final Robot robot, final class_2350 targetRotation) {
        robot.method_36456(class_3532.method_15388(robot.method_36454(), targetRotation.method_10144(), ROTATION_SPEED));
    }

    // --------------------------------------------------------------------- //

    @Override
    public void initialize(final Robot robot) {
        if (target == null) {
            target = robot.method_5735();
            if (direction != null) {
                switch (direction) {
                    case LEFT -> target = target.method_10160();
                    case RIGHT -> target = target.method_10170();
                }
            }
        }

        robot.method_5841().method_12778(Robot.TARGET_DIRECTION, target);
    }

    @Override
    public RobotActionResult perform(final Robot robot) {
        if (target == null) {
            throw new IllegalStateException();
        }

        rotateTowards(robot, target);

        if (class_3532.method_15356(robot.method_36454(), target.method_10144()) < TARGET_EPSILON) {
            return RobotActionResult.SUCCESS;
        }

        return RobotActionResult.INCOMPLETE;
    }

    @Override
    public class_2487 serialize() {
        final class_2487 tag = super.serialize();

        NBTUtils.putEnum(tag, DIRECTION_TAG_NAME, direction);
        if (target != null) {
            NBTUtils.putEnum(tag, TARGET_TAG_NAME, target);
        }

        return tag;
    }

    @Override
    public void deserialize(final class_2487 tag) {
        super.deserialize(tag);

        direction = NBTUtils.getEnum(tag, DIRECTION_TAG_NAME, RotationDirection.class);
        if (direction == null) direction = RotationDirection.LEFT;
        direction = direction.resolve();
        if (tag.method_10573(TARGET_TAG_NAME, NBTTagIds.TAG_INT)) {
            target = NBTUtils.getEnum(tag, TARGET_TAG_NAME, class_2350.class);
        }
    }
}
