/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common;

import li.cil.oc2.api.bus.device.vm.ArchitectureType;
import li.cil.oc2.common.config.*;

import javax.annotation.Nullable;
import java.util.UUID;

@WorldRestart
@Type(ConfigType.SERVER)
public final class Config {
    @Path("vm")
    public static long maxAllocatedMemory = 2L * 1024 * Constants.MEGABYTE;

    @Path("energy.blocks")
    public static double busCableEnergyPerTick = 0.1;
    @Path("energy.blocks")
    public static double busInterfaceEnergyPerTick = 0.5;
    @Path("energy.blocks")
    public static int computerEnergyStorage = 2000;
    @Path("energy.blocks")
    public static int chargerEnergyPerTick = 2500;
    @Path("energy.blocks")
    public static int chargerEnergyStorage = 10000;
    @Path("energy.blocks")
    public static int projectorEnergyPerTick = 20;
    @Path("energy.blocks")
    public static int projectorEnergyStorage = 2000;

    @Path("energy.entities")
    public static double robotCpuEnergyMultiplier = 0.5;
    @Path("energy.entities")
    public static int robotEnergyStorage = 750000;

    @Path("energy.items")
    public static int riscvCpuEnergyPerTick = 10;
    @Path("energy.items")
    public static int z80CpuEnergyPerTick = 2;
    @Path("energy.items")
    public static double memoryEnergyPerMegabytePerTick = 0.5;
    @Path("energy.items")
    public static double hardDriveEnergyPerMegabytePerTick = 1;
    @Path("energy.items")
    public static int redstoneInterfaceCardEnergyPerTick = 1;
    @Path("energy.items")
    public static int networkInterfaceEnergyPerTick = 1;
    @Path("energy.items")
    public static int fileImportExportCardEnergyPerTick = 1;
    @Path("energy.items")
    public static int soundCardEnergyPerTick = 1;
    @Path("energy.items")
    public static int blockOperationsModuleEnergyPerTick = 2;
    @Path("energy.items")
    public static int inventoryOperationsModuleEnergyPerTick = 1;
    @Path("energy.items")
    public static int networkTunnelEnergyPerTick = 2;

    @Path("gameplay")
    public static long soundCardCoolDownSeconds = 2;

    @Path("admin")
    public static UUID fakePlayerUUID = UUID.fromString("e39dd9a7-514f-4a2d-aa5e-b6030621416d");

    @Path("admin.storage")
    @Min(0)
    public static int maxBlobCount = 1024;
    @Path("admin.storage")
    @Min(0)
    public static int maxTrashedBlobCount = 64;
    @Path("admin.storage")
    @Min(0)
    public static int blobEvictionGraceHours = 24 * 7;
    @Path("admin.storage")
    @Min(0)
    public static int maxBlobCapacity = 16 * Constants.MEGABYTE;

    @Path("admin.network")
    public static int projectorAverageMaxBytesPerSecond = 160 * 1024;
    @Path("admin.virtual_network")
    public static int ethernetFrameTimeToLive = 12;
    @Path("admin.virtual_network")
    public static int hubEthernetFramesPerTick = 32;

    public static int cpuEnergyPerTick(@Nullable final ArchitectureType architecture) {
        if (architecture == null) {
            return 0;
        }
        return switch (architecture) {
            case RISCV -> riscvCpuEnergyPerTick;
            case Z80 -> z80CpuEnergyPerTick;
        };
    }

    public static int robotCpuEnergyPerTick(@Nullable final ArchitectureType architecture) {
        return (int) Math.round(cpuEnergyPerTick(architecture) * robotCpuEnergyMultiplier);
    }

    public static boolean computersUseEnergy() {
        return computerEnergyStorage > 0;
    }

    public static boolean chargerUseEnergy() {
        return chargerEnergyPerTick > 0 && chargerEnergyStorage > 0;
    }

    public static boolean projectorsUseEnergy() {
        return projectorEnergyStorage > 0 && projectorEnergyPerTick > 0;
    }

    public static boolean robotsUseEnergy() {
        return robotEnergyStorage > 0;
    }
}
