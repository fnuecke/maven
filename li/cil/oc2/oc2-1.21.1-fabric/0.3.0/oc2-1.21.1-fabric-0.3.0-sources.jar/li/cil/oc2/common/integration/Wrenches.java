/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.integration;

import li.cil.oc2.common.tags.ItemTags;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import javax.annotation.Nullable;

public final class Wrenches {
    public static boolean isWrench(@Nullable final class_1799 stack) {
        return stack != null && !stack.method_7960() && stack.method_31573(ItemTags.WRENCHES);
    }

    public static boolean isHoldingWrench(final class_1297 entity) {
        if (!(entity instanceof final class_1309 livingEntity)) {
            return false;
        }

        for (final class_1799 stack : livingEntity.method_5877()) {
            if (isWrench(stack)) {
                return true;
            }
        }

        return false;
    }
}
