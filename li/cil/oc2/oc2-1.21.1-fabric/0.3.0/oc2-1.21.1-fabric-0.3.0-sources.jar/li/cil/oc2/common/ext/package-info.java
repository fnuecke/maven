/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.ext;

import javax.annotation.ParametersAreNonnullByDefault;
