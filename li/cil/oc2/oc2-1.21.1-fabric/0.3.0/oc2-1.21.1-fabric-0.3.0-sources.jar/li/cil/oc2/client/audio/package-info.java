/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.audio;

import javax.annotation.ParametersAreNonnullByDefault;
