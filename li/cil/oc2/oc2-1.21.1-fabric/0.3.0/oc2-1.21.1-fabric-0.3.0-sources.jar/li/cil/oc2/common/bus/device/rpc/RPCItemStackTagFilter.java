/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc;

import li.cil.oc2.common.util.NBTTagIds;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3544;
import net.minecraft.class_7923;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Objects;

public final class RPCItemStackTagFilter {
    public class_2960 item;
    public String[] tags;

    private String[][] paths; // Cache of resolved paths specified in tags.

    // --------------------------------------------------------------------- //

    @Nullable
    public class_2487 apply(final class_1799 stack, final class_2487 tag) {
        if (stack.method_7960() || tags == null) {
            return null;
        }

        if (item != null && !Objects.equals(class_7923.field_41178.method_10221(stack.method_7909()), item)) {
            return null;
        }

        validatePaths();

        final class_2487 filtered = new class_2487();
        for (final String[] path : paths) {
            final class_2487 filteredByPath = filterPath(path, tag);
            if (filteredByPath != null) {
                filtered.method_10543(filteredByPath);
            }
        }

        return filtered;
    }

    // --------------------------------------------------------------------- //

    @Nullable
    private class_2487 filterPath(final String[] path, final class_2487 source) {
        if (path.length == 0) {
            return null;
        }

        final class_2487 result = new class_2487();

        class_2487 currentSource = source;
        class_2487 currentTarget = result;
        for (int j = 0; j < path.length - 1; j++) {
            final String segment = path[j];
            if (currentSource.method_10573(segment, NBTTagIds.TAG_COMPOUND)) {
                currentSource = currentSource.method_10562(segment);
                currentTarget.method_10566(segment, new class_2487());
                currentTarget = currentTarget.method_10562(segment);
            } else {
                return null; // Path mismatch, inner element is not a compound tag.
            }
        }

        final class_2520 tag = currentSource.method_10580(path[path.length - 1]);
        if (tag == null) {
            return null; // Cannot find tag at path.
        }

        currentTarget.method_10566(path[path.length - 1], tag);

        return result;
    }

    private void validatePaths() {
        if (paths != null) {
            return;
        }

        // Strip out blank (null) entries entirely to avoid NREs later.
        final ArrayList<String[]> resolved = new ArrayList<>(tags.length);
        for (final String tag : tags) {
            if (!class_3544.method_15438(tag)) {
                resolved.add(tag.split("\\."));
            }
        }

        paths = resolved.toArray(new String[0][]);
    }
}
