/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.api.bus.device.vm.event;

import javax.annotation.ParametersAreNonnullByDefault;
