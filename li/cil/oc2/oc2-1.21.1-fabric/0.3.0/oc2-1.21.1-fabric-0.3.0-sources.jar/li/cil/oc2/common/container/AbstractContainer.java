/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import javax.annotation.Nullable;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

public abstract class AbstractContainer extends class_1703 {
    protected static final int HOTBAR_SIZE = 9;
    protected static final int SLOT_SIZE = 18;
    protected static final int PLAYER_INVENTORY_ROWS = 3;
    protected static final int PLAYER_INVENTORY_COLUMNS = 9;
    protected static final int PLAYER_INVENTORY_HOTBAR_SPACING = 4;

    public AbstractContainer(@Nullable final class_3917<?> type, final int id) {
        super(type, id);
    }

    @Override
    public class_1799 method_7601(final class_1657 player, final int index) {
        final class_1735 from = field_7761.get(index);
        final class_1799 stack = from.method_7677().method_7972();
        if (stack.method_7960()) {
            return class_1799.field_8037;
        }

        final boolean intoPlayerInventory = from.field_7871 != player.method_31548();
        final class_1799 fromStack = from.method_7677();

        final int step, begin;
        if (intoPlayerInventory) {
            step = -1;
            begin = field_7761.size() - 1;
        } else {
            step = 1;
            begin = 0;
        }

        if (fromStack.method_7914() > 1) {
            for (int i = begin; i >= 0 && i < field_7761.size(); i += step) {
                final class_1735 into = field_7761.get(i);
                if (into.field_7871 == from.field_7871) {
                    continue;
                }

                if (!into.method_7680(fromStack)) {
                    continue;
                }

                if (!into.method_7681()) {
                    continue;
                }

                final class_1799 intoStack = into.method_7677();
                final boolean itemsAreEqual = class_1799.method_31577(fromStack, intoStack);
                if (!itemsAreEqual) {
                    continue;
                }

                final int maxSizeInSlot = Math.min(fromStack.method_7914(), into.method_7676(stack));
                final int spaceInSlot = maxSizeInSlot - intoStack.method_7947();
                if (spaceInSlot <= 0) {
                    continue;
                }

                final int itemsMoved = Math.min(spaceInSlot, fromStack.method_7947());
                if (itemsMoved <= 0) {
                    continue;
                }

                intoStack.method_7933(from.method_7671(itemsMoved).method_7947());
                into.method_7668();

                if (from.method_7677().method_7960()) {
                    break;
                }
            }
        }

        for (int i = begin; i >= 0 && i < field_7761.size(); i += step) {
            if (from.method_7677().method_7960()) {
                break;
            }

            final class_1735 into = field_7761.get(i);
            if (into.field_7871 == from.field_7871) {
                continue;
            }

            if (!into.method_7680(fromStack)) {
                continue;
            }

            if (into.method_7681()) {
                continue;
            }

            final int maxSizeInSlot = Math.min(fromStack.method_7914(), into.method_7676(fromStack));
            final int itemsMoved = Math.min(maxSizeInSlot, fromStack.method_7947());
            into.method_7673(from.method_7671(itemsMoved));
        }

        return from.method_7677().method_7947() < stack.method_7947() ? from.method_7677() : class_1799.field_8037;
    }

    protected int createPlayerInventoryAndHotbarSlots(final class_1661 inventory, final int startX, final int startY) {
        final int nextIndex = createHotbarSlots(inventory, 0, startX, startY + PLAYER_INVENTORY_ROWS * SLOT_SIZE + PLAYER_INVENTORY_HOTBAR_SPACING);
        return createPlayerInventorySlots(inventory, nextIndex, startX, startY);
    }

    protected int createPlayerInventorySlots(final class_1661 inventory, final int startIndex, final int startX, final int startY) {
        for (int row = 0; row < PLAYER_INVENTORY_ROWS; ++row) {
            for (int column = 0; column < PLAYER_INVENTORY_COLUMNS; ++column) {
                final int index = startIndex + row * PLAYER_INVENTORY_COLUMNS + column;
                final int x = startX + column * SLOT_SIZE;
                final int y = startY + row * SLOT_SIZE;

                final class_1735 slot;
                if (isSlotLocked(inventory, index)) {
                    slot = new LockedSlot(inventory, index, x, y);
                } else {
                    slot = new class_1735(inventory, index, x, y);
                }

                this.method_7621(slot);
            }
        }

        return startIndex + PLAYER_INVENTORY_ROWS * PLAYER_INVENTORY_COLUMNS;
    }

    protected int createHotbarSlots(final class_1661 inventory, final int startIndex, final int startX, final int startY) {
        for (int i = 0; i < HOTBAR_SIZE; ++i) {
            final int index = startIndex + i;
            final int x = startX + i * SLOT_SIZE;

            final class_1735 slot;
            if (isSlotLocked(inventory, index)) {
                slot = new LockedSlot(inventory, index, x, startY);
            } else {
                slot = new class_1735(inventory, index, x, startY);
            }

            this.method_7621(slot);
        }

        return startIndex + HOTBAR_SIZE;
    }

    protected boolean isSlotLocked(final class_1661 inventory, final int slot) {
        return false;
    }
}
