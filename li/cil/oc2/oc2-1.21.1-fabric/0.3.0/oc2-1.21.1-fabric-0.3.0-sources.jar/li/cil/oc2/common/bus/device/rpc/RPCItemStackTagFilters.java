/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import dev.architectury.registry.ReloadListenerRegistry;
import li.cil.oc2.api.API;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Map;

public final class RPCItemStackTagFilters {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final ArrayList<RPCItemStackTagFilter> FILTERS = new ArrayList<>();

    // --------------------------------------------------------------------- //

    public static class_2487 getFilteredTag(final class_1799 stack, final class_2487 tag) {
        final class_2487 result = new class_2487();
        for (final RPCItemStackTagFilter filter : FILTERS) {
            final class_2487 filtered = filter.apply(stack, tag);
            if (filtered != null) {
                result.method_10543(filtered);
            }
        }

        return result;
    }

    // --------------------------------------------------------------------- //

    public static void initialize() {
        ReloadListenerRegistry.register(class_3264.field_14190, ReloadListener.INSTANCE,
            class_2960.method_60655(API.MOD_ID, "item_stack_tag_filters"));
    }

    // --------------------------------------------------------------------- //

    private static final class ReloadListener extends class_4309 {
        private static final Gson GSON = new GsonBuilder()
            .registerTypeAdapter(class_2960.class, new class_2960.class_2961())
            .create();

        public static final ReloadListener INSTANCE = new ReloadListener();

        public ReloadListener() {
            super(GSON, "item_tag_filters");
        }

        @Override
        protected void apply(final Map<class_2960, JsonElement> objects, final class_3300 resourceManager, final class_3695 profiler) {
            FILTERS.clear();

            objects.forEach((location, element) -> {
                try {
                    final RPCItemStackTagFilter filter = GSON.fromJson(element, RPCItemStackTagFilter.class);
                    if (filter != null) {
                        FILTERS.add(filter);
                    }
                } catch (final Exception e) {
                    LOGGER.error("Failed loading item tag filter [{}].", location, e);
                }
            });
        }
    }
}
