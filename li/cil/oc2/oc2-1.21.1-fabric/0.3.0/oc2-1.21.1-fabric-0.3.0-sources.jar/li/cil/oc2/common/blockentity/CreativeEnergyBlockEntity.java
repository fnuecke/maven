/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.energy.EnergyStorage;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public final class CreativeEnergyBlockEntity extends ModBlockEntity implements TickableBlockEntity {
    private final class_2350[] SIDES = class_2350.values();

    // --------------------------------------------------------------------- //

    public CreativeEnergyBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.CREATIVE_ENERGY.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void serverTick() {
        assert field_11863 != null;

        for (final class_2350 side : SIDES) {
            final class_2338 neighborPos = method_11016().method_10093(side);
            final class_1923 neighborChunkPos = new class_1923(neighborPos);
            if (field_11863.method_8393(neighborChunkPos.field_9181, neighborChunkPos.field_9180)) {
                final class_2586 blockEntity = field_11863.method_8321(neighborPos);
                if (blockEntity != null) {
                    final EnergyStorage energy = Capabilities.get(blockEntity, Capabilities.ENERGY_STORAGE, side.method_10153());
                    if (energy != null) {
                        energy.receiveEnergy(Integer.MAX_VALUE, false);
                    }
                }
            }
        }
    }
}
