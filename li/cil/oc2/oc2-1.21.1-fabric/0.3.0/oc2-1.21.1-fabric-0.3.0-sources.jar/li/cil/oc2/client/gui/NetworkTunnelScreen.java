/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.common.container.NetworkTunnelContainer;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.NetworkTunnelLinkMessage;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_757;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class NetworkTunnelScreen extends AbstractModContainerScreen<NetworkTunnelContainer> {
    private static final int LINK_BUTTON_LEFT = 48;
    private static final int LINK_BUTTON_TOP = 78;

    private static final class_2561 LINK_BUTTON_CAPTION = text("gui.{mod}.network_tunnel.link");

    private ImageButton linkButton;

    // --------------------------------------------------------------------- //

    public NetworkTunnelScreen(final NetworkTunnelContainer container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title);

        field_2792 = Sprites.NETWORK_TUNNEL_SCREEN.width;
        field_2779 = Sprites.NETWORK_TUNNEL_SCREEN.height;
        field_25270 = field_2779 - 94;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        linkButton.field_22763 = method_17577().hasLinkSlotItem();

        super.method_25394(graphics, mouseX, mouseY, partialTicks);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        linkButton = method_37063(new ImageButton(
            field_2776 + LINK_BUTTON_LEFT, field_2800 + LINK_BUTTON_TOP,
            Sprites.NETWORK_TUNNEL_LINK_BUTTON_INACTIVE.width, Sprites.NETWORK_TUNNEL_LINK_BUTTON_INACTIVE.height,
            Sprites.NETWORK_TUNNEL_LINK_BUTTON_INACTIVE,
            Sprites.NETWORK_TUNNEL_LINK_BUTTON_ACTIVE) {
            @Override
            public void method_25306() {
                super.method_25306();
                createTunnel();
            }
        }).withMessage(LINK_BUTTON_CAPTION);
    }

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1, 1, 1, 1);

        Sprites.NETWORK_TUNNEL_SCREEN.draw(graphics, field_2776, field_2800);
    }

    // --------------------------------------------------------------------- //

    private void createTunnel() {
        final NetworkTunnelLinkMessage message = new NetworkTunnelLinkMessage(method_17577().field_7763);
        Network.sendToServer(message);
    }
}
