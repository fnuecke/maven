/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.color;

import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.util.ItemStackUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_322;
import javax.annotation.Nullable;

@Environment(EnvType.CLIENT)
public final class BusCableBlockColor implements class_322 {
    @Override
    public int getColor(final class_2680 state, @Nullable final class_1920 level, @Nullable final class_2338 pos, final int tintIndex) {
        if (level == null || pos == null) {
            return 0;
        }

        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final BusCableBlockEntity busCable) {
            final class_2680 facade = ItemStackUtils.getBlockState(busCable.getFacade());
            if (facade != null) {
                return class_310.method_1551().method_1505().method_1697(facade, level, pos, tintIndex);
            }
        }

        return 0;
    }
}
