/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.vm.block;

import li.cil.oc2.api.bus.device.vm.VMDevice;
import li.cil.oc2.api.bus.device.vm.VMDeviceLoadResult;
import li.cil.oc2.api.bus.device.vm.context.VMContext;
import li.cil.oc2.api.capabilities.TerminalUserProvider;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.bus.device.util.OptionalAddress;
import li.cil.oc2.common.bus.device.util.OptionalInterrupt;
import li.cil.oc2.common.serialization.NBTSerialization;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.sedna.device.virtio.VirtIOKeyboardDevice;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

public final class KeyboardDevice<T> extends IdentityProxy<T> implements VMDevice, TerminalUserProvider {
    private static final String DEVICE_TAG_NAME = "device";
    private static final String ADDRESS_TAG_NAME = "address";
    private static final String INTERRUPT_TAG_NAME = "interrupt";
    private static final long USER_EXPIRES_AFTER = 2000; // milliseconds
    public static final long USER_KEEPALIVE_EVERY = 1000; // milliseconds

    // --------------------------------------------------------------------- //

    @Nullable
    private VirtIOKeyboardDevice device;

    // --------------------------------------------------------------------- //

    private final Map<class_1657, Long> users = new WeakHashMap<>();
    private final OptionalAddress address = new OptionalAddress();
    private final OptionalInterrupt interrupt = new OptionalInterrupt();
    private class_2487 deviceTag;

    // --------------------------------------------------------------------- //

    public KeyboardDevice(final T identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    public void sendKeyEvent(final int keycode, final boolean isDown) {
        if (device != null) {
            device.sendKeyEvent(keycode, isDown);
        }
    }

    public void handleUsedBy(final class_1657 player) {
        users.put(player, System.currentTimeMillis());
    }

    @Override
    public Iterable<class_1657> getTerminalUsers() {
        final long now = System.currentTimeMillis();
        users.entrySet().removeIf(entry -> now - entry.getValue() > USER_EXPIRES_AFTER);

        return new ArrayList<>(users.keySet());
    }

    @Override
    public VMDeviceLoadResult mount(final VMContext context) {
        if (!allocateDevice(context)) {
            return VMDeviceLoadResult.fail();
        }

        assert device != null;
        if (!address.claim(context.getDeviceRangeAllocator(), device)) {
            return VMDeviceLoadResult.fail()
                .withErrorMessage(class_2561.method_43471(Constants.COMPUTER_ERROR_DEVICE_DOES_NOT_FIT));
        }

        if (interrupt.claim(context)) {
            device.getInterrupt().set(interrupt.getAsInt(), context.getInterruptController());
        } else {
            return VMDeviceLoadResult.fail();
        }

        context.getEventBus().register(this);

        if (deviceTag != null) {
            NBTSerialization.deserialize(deviceTag, device);
        }

        return VMDeviceLoadResult.success();
    }

    @Override
    public void unmount() {
        device = null;
        users.clear();
    }

    @Override
    public void dispose() {
        deviceTag = null;
        address.clear();
        interrupt.clear();
    }

    @Override
    public class_2487 serializeNBT() {
        final class_2487 tag = new class_2487();

        if (device != null) {
            deviceTag = NBTSerialization.serialize(device);
        }
        if (deviceTag != null) {
            tag.method_10566(DEVICE_TAG_NAME, deviceTag);
        }
        if (address.isPresent()) {
            tag.method_10544(ADDRESS_TAG_NAME, address.getAsLong());
        }
        if (interrupt.isPresent()) {
            tag.method_10569(INTERRUPT_TAG_NAME, interrupt.getAsInt());
        }

        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        if (tag.method_10573(DEVICE_TAG_NAME, NBTTagIds.TAG_COMPOUND)) {
            deviceTag = tag.method_10562(DEVICE_TAG_NAME);
        }
        if (tag.method_10573(ADDRESS_TAG_NAME, NBTTagIds.TAG_LONG)) {
            address.set(tag.method_10537(ADDRESS_TAG_NAME));
        }
        if (tag.method_10573(INTERRUPT_TAG_NAME, NBTTagIds.TAG_INT)) {
            interrupt.set(tag.method_10550(INTERRUPT_TAG_NAME));
        }
    }

    // --------------------------------------------------------------------- //

    private boolean allocateDevice(final VMContext context) {
        if (!context.getMemoryAllocator().claimMemory(Constants.PAGE_SIZE)) {
            return false;
        }

        device = new VirtIOKeyboardDevice(context.getMemoryMap(), Constants.VIRTIO_INPUT_QUEUE_SIZE);

        return true;
    }
}
