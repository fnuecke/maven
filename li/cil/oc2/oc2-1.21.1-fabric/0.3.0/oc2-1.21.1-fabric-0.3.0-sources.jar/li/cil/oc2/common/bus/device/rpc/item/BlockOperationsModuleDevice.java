/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.item;

import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.DocumentedDevice;
import li.cil.oc2.api.bus.device.object.Parameter;
import li.cil.oc2.api.capabilities.Robot;
import li.cil.oc2.api.inventory.ItemHandler;
import li.cil.oc2.api.util.RobotOperationSide;
import li.cil.oc2.common.util.FakePlayerUtils;
import li.cil.oc2.common.util.LevelUtils;
import li.cil.oc2.common.util.TickUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2288;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2515;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3748;
import net.minecraft.class_3965;
import javax.annotation.Nullable;
import java.time.Duration;
import java.util.List;

public final class BlockOperationsModuleDevice extends AbstractItemRPCDevice implements DocumentedDevice {
    private static final String LAST_OPERATION_TAG_NAME = "cooldown";
    private static final String COOLDOWN_TAG_NAME = "cooldown_ticks";

    private static final int MIN_COOLDOWN = TickUtils.toTicks(Duration.ofSeconds(1));
    private static final int MAX_COOLDOWN = TickUtils.toTicks(Duration.ofSeconds(15));

    private static final String EXCAVATE = "excavate";
    private static final String PLACE = "place";
    private static final String DURABILITY = "durability";
    private static final String SIDE = "side";

    // --------------------------------------------------------------------- //

    private final class_1297 entity;
    private final Robot robot;
    private long lastOperation;
    private int cooldown = MIN_COOLDOWN;

    // --------------------------------------------------------------------- //

    public BlockOperationsModuleDevice(final class_1799 identity, final class_1297 entity, final Robot robot) {
        super(identity, "block_operations");
        this.entity = entity;
        this.robot = robot;
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2487 serializeNBT() {
        final class_2487 tag = new class_2487();
        tag.method_10544(LAST_OPERATION_TAG_NAME, lastOperation);
        tag.method_10569(COOLDOWN_TAG_NAME, cooldown);
        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        lastOperation = class_3532.method_53062(tag.method_10537(LAST_OPERATION_TAG_NAME), 0, entity.method_37908().method_8510());
        cooldown = class_3532.method_15340(tag.method_10550(COOLDOWN_TAG_NAME), MIN_COOLDOWN, MAX_COOLDOWN);
    }

    @Callback(name = EXCAVATE)
    public boolean excavate() {
        return excavate(null);
    }

    @Callback(name = EXCAVATE)
    public boolean excavate(@Parameter("side") @Nullable final RobotOperationSide side) {
        if (isOnCooldown()) {
            return false;
        }

        beginCooldown(MIN_COOLDOWN);

        final class_1937 level = entity.method_37908();
        if (!(level instanceof final class_3218 serverLevel)) {
            return false;
        }

        final int selectedSlot = robot.getSelectedSlot(); // Get once to avoid change due to threading.
        final ItemHandler inventory = robot.getInventory();

        final class_2350 direction = RobotOperationSide.toGlobal(entity, side);
        final class_2338 blockPos = entity.method_24515().method_10093(direction);

        final List<class_1542> oldItems = getItemsInRange();

        final class_1799 tool = inventory.getStackInSlot(selectedSlot);
        final class_3222 player = FakePlayerUtils.getFakePlayer(serverLevel, entity);

        final int breakTicks;
        player.method_6122(class_1268.field_5808, tool);
        player.method_24830(true); // Avoid the robot hovering slowing it down.
        try {
            breakTicks = tryHarvestBlock(serverLevel, player, blockPos, tool);
        } finally {
            player.method_6122(class_1268.field_5808, class_1799.field_8037);
        }

        if (breakTicks < 0) {
            return false;
        }

        beginCooldown(Math.max(MIN_COOLDOWN, breakTicks));

        final List<class_1542> droppedItems = getItemsInRange();
        droppedItems.removeAll(oldItems);

        for (final class_1542 itemEntity : droppedItems) {
            class_1799 stack = itemEntity.method_6983();
            stack = insertStartingAt(inventory, stack, selectedSlot + 1, false);
            itemEntity.method_6979(stack);
        }

        return true;
    }

    @Callback(name = PLACE)
    public boolean place() {
        return place(null);
    }

    @Callback(name = PLACE)
    public boolean place(@Parameter("side") @Nullable final RobotOperationSide side) {
        if (isOnCooldown()) {
            return false;
        }

        beginCooldown(MIN_COOLDOWN);

        final class_1937 level = entity.method_37908();
        if (!(level instanceof final class_3218 serverLevel)) {
            return false;
        }

        final int selectedSlot = robot.getSelectedSlot(); // Get once to avoid change due to threading.
        final ItemHandler inventory = robot.getInventory();

        final class_1799 extracted = inventory.extractItem(selectedSlot, 1, true);
        if (extracted.method_7960() || !(extracted.method_7909() instanceof class_1747)) {
            return false;
        }

        final class_2350 direction = RobotOperationSide.toGlobal(entity, side);
        final class_2338 blockPos = entity.method_24515().method_10093(direction);
        final class_2350 oppositeDirection = direction.method_10153();
        final class_3965 hit = new class_3965(
            class_243.method_24953(blockPos).method_1019(class_243.method_24953(oppositeDirection.method_10163()).method_1021(0.5)),
            oppositeDirection,
            blockPos,
            false);

        final class_1799 itemStack = extracted.method_7972();
        final class_3222 player = FakePlayerUtils.getFakePlayer(serverLevel, entity);

        // Full useOn dance for permission checks.
        player.method_6122(class_1268.field_5808, itemStack);
        try {
            final class_1269 result = itemStack.method_7981(new class_1838(player, class_1268.field_5808, hit));
            if (!result.method_23665()) {
                return false;
            }
        } finally {
            player.method_6122(class_1268.field_5808, class_1799.field_8037);
        }

        if (itemStack.method_7960()) {
            inventory.extractItem(selectedSlot, 1, false);
        }

        return true;
    }

    @Callback(name = DURABILITY)
    public int durability() {
        final class_1799 tool = robot.getInventory().getStackInSlot(robot.getSelectedSlot());
        if (!tool.method_7963()) {
            return 0;
        }

        return tool.method_7936() - tool.method_7919();
    }

    @Override
    public void getDeviceDocumentation(final DocumentedDevice.DeviceVisitor visitor) {
        visitor.visitCallback(EXCAVATE)
            .description("Try to break a block in the specified direction, using the tool in the " +
                "currently selected inventory slot. Collected blocks will be inserted starting after " +
                "the currently selected inventory slot. If a slot is full, the next slot will be used. " +
                "If the inventory has no space for the dropped block, it will drop into the world.\n" +
                "Blocks the held tool would not collect anything from, blocks nothing can break and " +
                "blocks that would take longer than fifteen seconds are refused.")
            .returnValueDescription("whether the operation was successful.")
            .parameterDescription(SIDE, "the relative direction to break a block in. " +
                "Optional, defaults to front. Valid values are front, up and down.");

        visitor.visitCallback(PLACE)
            .description("Try to place a block in the specified direction. Blocks will be placed from " +
                "the currently selected inventory slot. If the slot is empty, no block will be placed.")
            .returnValueDescription("whether the operation was successful.")
            .parameterDescription(SIDE, "the relative direction to place the block in. " +
                "Optional, defaults to front. Valid values are front, up and down.");

        visitor.visitCallback(DURABILITY)
            .description("Get the remaining durability of the tool in the currently selected " +
                "inventory slot.")
            .returnValueDescription("the remaining durability, or zero if the slot is empty or holds " +
                "something that cannot take damage.");
    }

    // --------------------------------------------------------------------- //

    private void beginCooldown(final int ticks) {
        lastOperation = entity.method_37908().method_8510();
        cooldown = ticks;
    }

    private boolean isOnCooldown() {
        return entity.method_37908().method_8510() - lastOperation < cooldown;
    }

    private List<class_1542> getItemsInRange() {
        return entity.method_37908().method_18467(class_1542.class, entity.method_5829().method_1014(2));
    }

    private int tryHarvestBlock(final class_3218 level, final class_3222 player, final class_2338 blockPos, final class_1799 tool) {
        // This method is based on ServerPlayerGameMode::destroyBlock. Simplified for our needs.
        final class_2680 blockState = level.method_8320(blockPos);
        if (blockState.method_26215()) {
            return -1;
        }

        final class_2248 block = blockState.method_26204();
        final boolean isCommandBlock = block instanceof class_2288 || block instanceof class_2515 || block instanceof class_3748;
        if (isCommandBlock && !player.method_7338()) {
            return -1;
        }

        if (!LevelUtils.hasCorrectToolForDrops(level, player, blockPos, blockState)) {
            return -1;
        }

        final int breakTicks = breakDurationInTicks(blockState, player, level, blockPos);
        if (breakTicks < 0 || breakTicks > MAX_COOLDOWN) {
            return -1;
        }

        if (!LevelUtils.fireBlockBreak(level, player, blockPos, blockState)) {
            return -1;
        }

        final class_2586 blockEntity = level.method_8321(blockPos);
        final class_1799 toolBeforeMining = tool.method_7972();

        block.method_9576(level, blockPos, blockState, player);
        if (!level.method_8650(blockPos, false)) {
            return -1;
        }

        block.method_9585(level, blockPos, blockState);
        tool.method_7952(level, blockState, blockPos, player);
        block.method_9556(level, player, blockPos, blockState, blockEntity, toolBeforeMining);

        return breakTicks;
    }

    private static int breakDurationInTicks(final class_2680 blockState, final class_3222 player, final class_3218 level, final class_2338 blockPos) {
        final float progressPerTick = blockState.method_26165(player, level, blockPos);
        if (progressPerTick <= 0) {
            return -1;
        }

        return class_3532.method_15386(1 / progressPerTick);
    }

    private class_1799 insertStartingAt(final ItemHandler handler, class_1799 stack, final int startSlot, final boolean simulate) {
        for (int i = 0; i < handler.getSlots(); i++) {
            final int slot = (startSlot + i) % handler.getSlots();
            stack = handler.insertItem(slot, stack, simulate);
            if (stack.method_7960()) {
                return class_1799.field_8037;
            }
        }

        return stack;
    }
}
