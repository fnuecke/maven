/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceProvider;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.bus.device.vm.ArchitectureType;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.block.DiskDriveBlock;
import li.cil.oc2.common.blockentity.DiskDriveBlockEntity;
import li.cil.oc2.common.bus.device.vm.block.DiskDriveDevice;
import net.minecraft.class_2586;
import java.util.Optional;

public final class DiskDriveDeviceProvider implements BlockDeviceProvider {
    @Override
    public Invalidatable<Device> getDevice(final BlockDeviceQuery query) {
        final Optional<ArchitectureType> architectureType = query.getArchitectureType();
        if (architectureType.isEmpty()) {
            return Invalidatable.empty();
        }

        final class_2586 blockEntity = query.getLevel().method_8321(query.getQueryPosition());
        if (!(blockEntity instanceof final DiskDriveBlockEntity drive)) {
            return Invalidatable.empty();
        }

        final boolean isBackSide = query.getQuerySide() == drive.method_11010().method_11654(DiskDriveBlock.field_11177).method_10153();
        if (!isBackSide) {
            return Invalidatable.empty();
        }

        DiskDriveDevice<DiskDriveBlockEntity> device = drive.getDevice();
        if (device == null || device.getArchitectureType() != architectureType.get()) {
            device = new DiskDriveDevice<>(drive, architectureType.get());
            drive.setDevice(device);
        }

        return Invalidatable.of(device);
    }
}
