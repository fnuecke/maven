/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.api.platform;

import javax.annotation.ParametersAreNonnullByDefault;
