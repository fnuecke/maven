/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.common.container.ComputerInventoryContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class ComputerContainerScreen extends AbstractMachineInventoryScreen<ComputerInventoryContainer> {
    public ComputerContainerScreen(final ComputerInventoryContainer container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title);
        field_2792 = Sprites.COMPUTER_CONTAINER.width;
        field_2779 = Sprites.COMPUTER_CONTAINER.height;
        field_25270 = field_2779 - 94;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        super.method_2389(graphics, partialTicks, mouseX, mouseY);
        Sprites.COMPUTER_CONTAINER.draw(graphics, field_2776, field_2800);
    }
}
