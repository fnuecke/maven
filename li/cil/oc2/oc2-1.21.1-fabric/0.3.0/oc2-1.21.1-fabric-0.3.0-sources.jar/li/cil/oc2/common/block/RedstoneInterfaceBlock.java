/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.RedstoneInterfaceBlockEntity;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3620;
import javax.annotation.Nullable;

public final class RedstoneInterfaceBlock extends class_2383 implements class_2343 {
    public static final MapCodec<RedstoneInterfaceBlock> CODEC = MapCodec.unit(RedstoneInterfaceBlock::new);

    @Override
    protected MapCodec<? extends RedstoneInterfaceBlock> method_53969() {
        return field_46280;
    }

    public RedstoneInterfaceBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2680 method_9605(final class_1750 context) {
        return super.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    protected boolean method_9506(final class_2680 state) {
        return true;
    }

    @Override
    protected int method_9524(final class_2680 state, final class_1922 level, final class_2338 pos, final class_2350 side) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final RedstoneInterfaceBlockEntity redstoneInterface) {
            // Redstone requests info for faces with external perspective. We treat
            // the Direction from internal perspective, so flip it.
            return redstoneInterface.getOutputForDirection(side.method_10153());
        }

        return super.method_9524(state, level, pos, side);
    }

    @Override
    protected int method_9603(final class_2680 state, final class_1922 level, final class_2338 pos, final class_2350 side) {
        return method_9524(state, level, pos, side);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.REDSTONE_INTERFACE.get().method_11032(pos, state);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(field_11177);
    }
}
