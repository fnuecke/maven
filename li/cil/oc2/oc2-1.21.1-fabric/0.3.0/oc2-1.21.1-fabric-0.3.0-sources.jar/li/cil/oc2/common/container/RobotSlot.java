/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.api.inventory.ItemHandler;
import net.minecraft.class_1799;

public final class RobotSlot extends SlotItemHandler {
    public RobotSlot(final ItemHandler itemHandler, final int index, final int xPosition, final int yPosition) {
        super(itemHandler, index, xPosition, yPosition);
    }

    @Override
    public boolean method_7680(final class_1799 stack) {
        return super.method_7680(stack) && stack.method_7909().method_31568();
    }
}
