/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.bus.device.rpc;

import javax.annotation.ParametersAreNonnullByDefault;
