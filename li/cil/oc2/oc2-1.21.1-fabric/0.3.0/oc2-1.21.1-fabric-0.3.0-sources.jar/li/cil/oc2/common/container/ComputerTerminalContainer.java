/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.energy.EnergyStorage;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3222;

public final class ComputerTerminalContainer extends AbstractComputerContainer {
    public static void createServer(final ComputerBlockEntity computer, final EnergyStorage energy, final CommonDeviceBusController busController, final class_3222 player) {
        MenuRegistry.openExtendedMenu(player, new ExtendedMenuProvider() {
            @Override
            public class_2561 method_5476() {
                return class_2561.method_43471(computer.method_11010().method_26204().method_9539());
            }

            @Override
            public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                return new ComputerTerminalContainer(id, player, computer, createEnergyInfo(energy, busController));
            }

            @Override
            public void saveExtraData(final class_2540 buffer) {
                buffer.method_10807(computer.method_11016());
            }
        });
    }

    public static ComputerTerminalContainer createClient(final int id, final class_1661 inventory, final class_2540 data) {
        final class_2338 pos = data.method_10811();
        final class_2586 blockEntity = inventory.field_7546.method_37908().method_8321(pos);
        if (blockEntity instanceof final ComputerBlockEntity computer) {
            return new ComputerTerminalContainer(id, inventory.field_7546, computer, createClientEnergyInfo());
        }

        throw new IllegalArgumentException();
    }

    // --------------------------------------------------------------------- //

    private ComputerTerminalContainer(final int id, final class_1657 player, final ComputerBlockEntity computer, final IntPrecisionContainerData energyInfo) {
        super(Containers.COMPUTER_TERMINAL.get(), id, player, computer, energyInfo);
    }
}
