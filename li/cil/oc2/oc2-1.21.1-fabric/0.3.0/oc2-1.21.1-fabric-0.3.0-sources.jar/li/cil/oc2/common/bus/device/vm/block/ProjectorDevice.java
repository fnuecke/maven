/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.vm.block;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import li.cil.oc2.api.bus.device.vm.VMDevice;
import li.cil.oc2.api.bus.device.vm.VMDeviceLoadResult;
import li.cil.oc2.api.bus.device.vm.context.VMContext;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.bus.device.util.OptionalAddress;
import li.cil.oc2.common.serialization.BlobStorage;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.oc2.common.vm.device.SimpleFramebufferDevice;
import li.cil.oc2.jcodec.common.model.Picture;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.UUID;

public final class ProjectorDevice extends IdentityProxy<class_2586> implements VMDevice {
    private static final Logger LOGGER = LogManager.getLogger();

    private static final String ADDRESS_TAG_NAME = "address";
    private static final String BLOB_HANDLE_TAG_NAME = "blob";

    public static final int WIDTH = 640;
    public static final int HEIGHT = 480;

    private static final int FRAMEBUFFER_SIZE = WIDTH * HEIGHT * SimpleFramebufferDevice.STRIDE;

    // --------------------------------------------------------------------- //

    private final BooleanConsumer onMountedChanged;

    @Nullable
    private SimpleFramebufferDevice device;

    // --------------------------------------------------------------------- //

    private final OptionalAddress address = new OptionalAddress();
    @Nullable
    private UUID blobHandle;

    // --------------------------------------------------------------------- //

    public ProjectorDevice(final class_2586 identity, final BooleanConsumer onMountedChanged) {
        super(identity);
        this.onMountedChanged = onMountedChanged;
    }

    // --------------------------------------------------------------------- //

    public boolean hasChanges() {
        final SimpleFramebufferDevice framebufferDevice = device;
        return framebufferDevice != null && framebufferDevice.hasChanges();
    }

    public boolean applyChanges(final Picture picture) {
        final SimpleFramebufferDevice framebufferDevice = device;
        return framebufferDevice != null && framebufferDevice.applyChanges(picture);
    }

    @Override
    public VMDeviceLoadResult mount(final VMContext context) {
        if (!allocateDevice(context)) {
            return VMDeviceLoadResult.fail();
        }

        assert device != null;
        if (!address.claim(context.getDeviceRangeAllocator(), device)) {
            return VMDeviceLoadResult.fail()
                .withErrorMessage(class_2561.method_43471(Constants.COMPUTER_ERROR_DEVICE_DOES_NOT_FIT));
        }

        onMountedChanged.accept(true);

        return VMDeviceLoadResult.success();
    }

    @Override
    public void unmount() {
        final SimpleFramebufferDevice framebufferDevice = device;
        device = null;
        if (framebufferDevice != null) {
            framebufferDevice.close();
        }

        if (blobHandle != null) {
            BlobStorage.close(blobHandle);
        }

        onMountedChanged.accept(false);
    }

    @Override
    public void dispose() {
        if (blobHandle != null) {
            BlobStorage.delete(blobHandle);
            blobHandle = null;
        }

        address.clear();
    }

    @Override
    public class_2487 serializeNBT() {
        final class_2487 tag = new class_2487();

        if (blobHandle != null) {
            tag.method_25927(BLOB_HANDLE_TAG_NAME, blobHandle);
        }
        if (address.isPresent()) {
            tag.method_10544(ADDRESS_TAG_NAME, address.getAsLong());
        }

        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        if (tag.method_25928(BLOB_HANDLE_TAG_NAME)) {
            blobHandle = tag.method_25926(BLOB_HANDLE_TAG_NAME);
        }
        if (tag.method_10573(ADDRESS_TAG_NAME, NBTTagIds.TAG_LONG)) {
            address.set(tag.method_10537(ADDRESS_TAG_NAME));
        }
    }

    // --------------------------------------------------------------------- //

    private boolean allocateDevice(final VMContext context) {
        if (!context.getMemoryAllocator().claimMemory(Constants.PAGE_SIZE + FRAMEBUFFER_SIZE)) {
            return false;
        }

        try {
            device = createFrameBufferDevice();
        } catch (final IOException e) {
            return false;
        }

        return true;
    }

    private SimpleFramebufferDevice createFrameBufferDevice() throws IOException {
        if (BlobStorage.isStaleHandle(blobHandle)) {
            LOGGER.error("Discarding stale projector framebuffer data [{}].", blobHandle);
            BlobStorage.delete(blobHandle);
            blobHandle = null;
        }

        if (!BlobStorage.isValidHandle(blobHandle)) {
            blobHandle = BlobStorage.allocateHandle();
        }

        FileChannel channel;
        try {
            channel = BlobStorage.open(blobHandle, true);
        } catch (final BlobStorage.BlobInUseException e) {
            blobHandle = BlobStorage.allocateHandle();
            channel = BlobStorage.open(blobHandle, true);
        }

        final MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, FRAMEBUFFER_SIZE);
        return new SimpleFramebufferDevice(WIDTH, HEIGHT, buffer);
    }
}
