/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import dev.architectury.event.events.common.LifecycleEvent;
import dev.architectury.registry.ReloadListenerRegistry;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import li.cil.oc2.api.API;
import li.cil.oc2.common.vm.fs.LayeredFileSystem;
import li.cil.sedna.fs.FileSystem;
import li.cil.sedna.fs.ZipStreamFileSystem;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public final class FileSystems {
    private static final Logger LOGGER = LogManager.getLogger();

    private static final String DIRECTORY = "file_systems";
    private static final String ARCHIVE_EXTENSION = ".zip";
    private static final String DESCRIPTOR_EXTENSION = ".json";

    private static final LayeredFileSystem LAYERED_FILE_SYSTEM = new LayeredFileSystem();

    // --------------------------------------------------------------------- //

    public static FileSystem getLayeredFileSystem() {
        return LAYERED_FILE_SYSTEM;
    }

    public static void initialize() {
        ReloadListenerRegistry.register(class_3264.field_14190, ReloadListener.INSTANCE,
            class_2960.method_60655(API.MOD_ID, DIRECTORY));
        LifecycleEvent.SERVER_STOPPED.register(server -> LAYERED_FILE_SYSTEM.clear());
    }

    // --------------------------------------------------------------------- //

    private static void reload(final class_3300 resourceManager) {
        LAYERED_FILE_SYSTEM.clear();

        LOGGER.info("Searching for datapack file systems...");
        final Map<class_2960, class_3298> descriptors = resourceManager
            .method_14488(DIRECTORY, location -> location.method_12832().endsWith(DESCRIPTOR_EXTENSION));

        final ArrayList<ZipStreamFileSystem> fileSystems = new ArrayList<>();
        final Object2IntArrayMap<ZipStreamFileSystem> fileSystemOrder = new Object2IntArrayMap<>();

        for (final Map.Entry<class_2960, class_3298> entry : descriptors.entrySet()) {
            LOGGER.info("Found [{}]", entry.getKey());
            try {
                final JsonObject json;
                try (Reader reader = entry.getValue().method_43039()) {
                    json = JsonParser.parseReader(reader).getAsJsonObject();
                }

                final ZipStreamFileSystem fileSystem;
                try (InputStream stream = resourceManager.getResourceOrThrow(getArchiveLocation(entry.getKey())).method_14482()) {
                    fileSystem = new ZipStreamFileSystem(stream);
                }

                final long fileCount = fileSystem.statfs().fileCount;
                if (fileCount > 0) {
                    LOGGER.info("  Adding layer with [{}] file(s).", fileCount);
                    fileSystems.add(fileSystem);
                } else {
                    LOGGER.info("  Skipping empty layer.");
                }

                if (json.has("order")) {
                    final JsonPrimitive order = json.getAsJsonPrimitive("order");
                    fileSystemOrder.put(fileSystem, order.getAsInt());
                } else {
                    fileSystemOrder.put(fileSystem, 0);
                }
            } catch (final Throwable e) {
                LOGGER.error(e);
            }
        }

        fileSystems.sort(Comparator.comparingInt(fileSystemOrder::getInt));
        fileSystems.forEach(LAYERED_FILE_SYSTEM::addLayer);
    }

    private static class_2960 getArchiveLocation(final class_2960 descriptorLocation) {
        final String path = descriptorLocation.method_12832();
        return descriptorLocation.method_45136(path.substring(0, path.length() - DESCRIPTOR_EXTENSION.length()) + ARCHIVE_EXTENSION);
    }

    // --------------------------------------------------------------------- //

    private static final class ReloadListener implements class_3302 {
        public static final ReloadListener INSTANCE = new ReloadListener();

        @Override
        public CompletableFuture<Void> method_25931(final class_3302.class_4045 stage, final class_3300 resourceManager, final class_3695 preparationsProfiler, final class_3695 reloadProfiler, final Executor backgroundExecutor, final Executor gameExecutor) {
            return CompletableFuture
                .runAsync(() -> FileSystems.reload(resourceManager), backgroundExecutor)
                .thenCompose(stage::method_18352);
        }
    }

    private FileSystems() {
    }
}
