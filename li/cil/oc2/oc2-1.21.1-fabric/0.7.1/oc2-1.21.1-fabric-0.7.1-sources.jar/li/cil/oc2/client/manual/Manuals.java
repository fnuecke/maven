/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.manual;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.manual.api.ManualModel;
import li.cil.manual.api.Tab;
import li.cil.manual.api.prefab.Manual;
import li.cil.manual.api.prefab.provider.NamespaceDocumentProvider;
import li.cil.manual.api.prefab.provider.NamespacePathProvider;
import li.cil.manual.api.prefab.tab.ItemStackTab;
import li.cil.manual.api.prefab.tab.TextureTab;
import li.cil.manual.api.provider.DocumentProvider;
import li.cil.manual.api.provider.PathProvider;
import li.cil.manual.api.util.Constants;
import li.cil.oc2.api.API;
import li.cil.oc2.common.block.Blocks;
import li.cil.oc2.common.integration.ModIntegration;
import li.cil.oc2.common.integration.tis3d.SerialProtocolDocumentProvider;
import li.cil.oc2.common.item.Items;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

@Environment(EnvType.CLIENT)
public final class Manuals {
    private static final DeferredRegister<ManualModel> MANUALS = DeferredRegister.create(API.MOD_ID, Constants.MANUAL_REGISTRY);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<ManualModel> MANUAL = MANUALS.register("manual", Manual::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        final DeferredRegister<PathProvider> pathProviders = DeferredRegister.create(API.MOD_ID, Constants.PATH_PROVIDER_REGISTRY);
        final DeferredRegister<DocumentProvider> contentProviders = DeferredRegister.create(API.MOD_ID, Constants.DOCUMENT_PROVIDER_REGISTRY);
        final DeferredRegister<Tab> tabs = DeferredRegister.create(API.MOD_ID, Constants.TAB_REGISTRY);

        pathProviders.register("path_provider", () -> new NamespacePathProvider(API.MOD_ID));
        contentProviders.register("content_provider", () -> new NamespaceDocumentProvider(API.MOD_ID, "doc"));
        ModIntegration.TIS3D.run(() -> contentProviders.register("tis3d_serial_protocol_provider", SerialProtocolDocumentProvider::new));

        tabs.register("home", () -> new TextureTab(
            ManualModel.LANGUAGE_KEY + "/index.md",
            class_2561.method_43471("manual." + API.MOD_ID + ".home"),
            class_2960.method_60655(API.MOD_ID, "textures/gui/manual/home.png")));
        tabs.register("blocks", () -> new ItemStackTab(
            ManualModel.LANGUAGE_KEY + "/block/index.md",
            class_2561.method_43471("manual." + API.MOD_ID + ".blocks"),
            new class_1799(Blocks.COMPUTER.get())));
        tabs.register("modules", () -> new ItemStackTab(
            ManualModel.LANGUAGE_KEY + "/item/index.md",
            class_2561.method_43471("manual." + API.MOD_ID + ".items"),
            new class_1799(Items.TRANSISTOR.get())));
        tabs.register("api", () -> new TextureTab(
            ManualModel.LANGUAGE_KEY + "/device/index.md",
            class_2561.method_43471("manual." + API.MOD_ID + ".api"),
            class_2960.method_60655(API.MOD_ID, "textures/gui/manual/api.png")));

        MANUALS.register();
        pathProviders.register();
        contentProviders.register();
        tabs.register();
    }
}
