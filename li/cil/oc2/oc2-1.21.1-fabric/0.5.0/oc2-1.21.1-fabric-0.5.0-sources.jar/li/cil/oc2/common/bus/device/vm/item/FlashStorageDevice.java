/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.vm.item;

import com.google.common.eventbus.Subscribe;
import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.vm.FirmwareLoader;
import li.cil.oc2.api.bus.device.vm.VMDevice;
import li.cil.oc2.api.bus.device.vm.VMDeviceLoadResult;
import li.cil.oc2.api.bus.device.vm.context.VMContext;
import li.cil.oc2.api.bus.device.vm.event.VMInitializationException;
import li.cil.oc2.api.bus.device.vm.event.VMInitializingEvent;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.serialization.BlobStorage;
import li.cil.oc2.common.util.StorageItemUtils;
import li.cil.oc2.common.util.StorageItemUtils.State;
import li.cil.sedna.api.memory.MemoryAccessException;
import li.cil.sedna.memory.MemoryMaps;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.UUID;

public class FlashStorageDevice extends IdentityProxy<class_1799> implements VMDevice, ItemDevice, FirmwareLoader {
    private static final Logger LOGGER = LogManager.getLogger(FlashStorageDevice.class);

    private static final String BLOB_HANDLE_TAG_NAME = "blob";

    // --------------------------------------------------------------------- //

    protected final int size;

    @Nullable
    private ByteBuffer data;

    // Offline persisted data.
    @Nullable
    protected UUID blobHandle;

    // --------------------------------------------------------------------- //

    public FlashStorageDevice(final class_1799 identity, final int size) {
        super(identity);
        this.size = size;
    }

    // --------------------------------------------------------------------- //

    @Override
    public VMDeviceLoadResult mount(final VMContext context) {
        if (!context.getMemoryAllocator().claimMemory(size)) {
            return VMDeviceLoadResult.fail();
        }

        if (BlobStorage.isStaleHandle(blobHandle) && !StorageItemUtils.acceptStaleData(identity)) {
            return VMDeviceLoadResult.fail()
                .withErrorMessage(class_2561.method_43471(Constants.COMPUTER_ERROR_STORAGE_INCONSISTENT))
                .asPermanent();
        }

        try {
            data = readData();
        } catch (final BlobStorage.BlobStorageFullException e) {
            LOGGER.error(e);
            return VMDeviceLoadResult.fail()
                .withErrorMessage(class_2561.method_43471(Constants.COMPUTER_ERROR_STORAGE_FULL));
        } catch (final BlobStorage.BlobMissingException | BlobStorage.BlobInUseException e) {
            flag(State.CORRUPTED);
            return VMDeviceLoadResult.fail()
                .withErrorMessage(class_2561.method_43471(Constants.COMPUTER_ERROR_STORAGE_CORRUPTED))
                .asPermanent();
        } catch (final IOException e) {
            LOGGER.error(e);
            return VMDeviceLoadResult.fail();
        }

        context.getEventBus().register(this);

        return VMDeviceLoadResult.success();
    }

    @Override
    public void unmount() {
        data = null;

        if (blobHandle != null) {
            BlobStorage.close(blobHandle);
        }
    }

    @Override
    public void exportToItemStack(final class_2487 nbt) {
        if (blobHandle != null) {
            nbt.method_25927(BLOB_HANDLE_TAG_NAME, blobHandle);
        }
    }

    @Override
    public void importFromItemStack(final class_2487 nbt) {
        if (nbt.method_25928(BLOB_HANDLE_TAG_NAME)) {
            blobHandle = nbt.method_25926(BLOB_HANDLE_TAG_NAME);
        }
    }

    @Override
    public class_2487 serializeNBT() {
        final class_2487 tag = new class_2487();

        if (blobHandle != null) {
            tag.method_25927(BLOB_HANDLE_TAG_NAME, blobHandle);
        }

        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        if (tag.method_25928(BLOB_HANDLE_TAG_NAME)) {
            blobHandle = tag.method_25926(BLOB_HANDLE_TAG_NAME);
        }
    }

    @Subscribe
    public void handleInitializingEvent(final VMInitializingEvent event) {
        if (data == null) {
            return; // Never programmed; the machine starts on zeroes and goes nowhere, as before.
        }

        data.clear();

        try {
            MemoryMaps.store(event.memory(), event.programStartAddress(), data);
        } catch (final MemoryAccessException e) {
            throw new VMInitializationException(class_2561.method_43471(Constants.COMPUTER_ERROR_INSUFFICIENT_MEMORY));
        }
    }

    // --------------------------------------------------------------------- //

    @Nullable
    protected ByteBuffer readData() throws IOException {
        if (!BlobStorage.isValidHandle(blobHandle)) {
            return null;
        }

        return read(blobHandle, false);
    }

    protected final ByteBuffer read(final UUID handle, final boolean createIfMissing) throws IOException {
        final FileChannel channel = BlobStorage.open(handle, createIfMissing);
        try {
            final ByteBuffer buffer = ByteBuffer.allocate(size);
            while (buffer.hasRemaining()) {
                if (channel.read(buffer) < 0) {
                    break;
                }
            }
            return buffer;
        } catch (final IOException e) {
            BlobStorage.close(handle);
            throw e;
        }
    }

    public static void unmount(final class_2487 tag) {
        if (tag.method_25928(BLOB_HANDLE_TAG_NAME)) {
            BlobStorage.close(tag.method_25926(BLOB_HANDLE_TAG_NAME));
        }
    }

    private void flag(final State state) {
        StorageItemUtils.setState(identity, state);
    }
}
