/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalNotification;
import dev.architectury.event.events.client.ClientTickEvent;
import li.cil.oc2.api.API;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.client.renderer.TerminalTexture;
import li.cil.oc2.common.block.ComputerBlock;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.vm.Terminal;
import net.minecraft.class_1723;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_5348;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_824;
import net.minecraft.class_827;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutionException;

public final class ComputerRenderer implements class_827<ComputerBlockEntity> {
    public static final class_2960 OVERLAY_POWER_LOCATION = class_2960.method_60655(API.MOD_ID, "block/computer/computer_overlay_power");
    public static final class_2960 OVERLAY_STATUS_LOCATION = class_2960.method_60655(API.MOD_ID, "block/computer/computer_overlay_status");
    public static final class_2960 OVERLAY_TERMINAL_LOCATION = class_2960.method_60655(API.MOD_ID, "block/computer/computer_overlay_terminal");

    private static final class_4730 TEXTURE_POWER = new class_4730(class_1723.field_21668, OVERLAY_POWER_LOCATION);
    private static final class_4730 TEXTURE_STATUS = new class_4730(class_1723.field_21668, OVERLAY_STATUS_LOCATION);
    private static final class_4730 TEXTURE_TERMINAL = new class_4730(class_1723.field_21668, OVERLAY_TERMINAL_LOCATION);

    private static final Cache<Terminal, TerminalTexture> terminalTextures = CacheBuilder.newBuilder()
        .expireAfterAccess(Duration.ofSeconds(5))
        .removalListener(ComputerRenderer::handleNoLongerRendering)
        .build();

    // --------------------------------------------------------------------- //

    public static void initialize() {
        ClientTickEvent.CLIENT_POST.register(minecraft -> {
            terminalTextures.cleanUp();
            terminalTextures.asMap().values().forEach(TerminalTexture::refresh);
        });
    }

    // --------------------------------------------------------------------- //

    private final class_824 renderer;

    // --------------------------------------------------------------------- //

    public ComputerRenderer(final class_5614.class_5615 context) {
        this.renderer = context.method_32139();
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final ComputerBlockEntity computer, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        final class_2350 blockFacing = computer.method_11010().method_11654(ComputerBlock.field_11177);
        final class_243 cameraPosition = renderer.field_4344.method_19331().method_5836(partialTicks);

        // If viewer is not in front of the block we can skip the rest, it cannot be visible.
        // We check against the center of the block instead of the actual relevant face for simplicity.
        final class_243 relativeCameraPosition = cameraPosition.method_1020(class_243.method_24953(computer.method_11016()));
        final double projectedCameraPosition = relativeCameraPosition.method_1026(class_243.method_24954(blockFacing.method_10163()));
        if (projectedCameraPosition <= 0) {
            return;
        }

        stack.method_22903();

        // Align with front face of block.
        final Quaternionf rotation = class_7833.field_40715.rotationDegrees(blockFacing.method_10144() + 180);
        stack.method_46416(0.5f, 0, 0.5f);
        stack.method_22907(rotation);
        stack.method_46416(-0.5f, 0, -0.5f);

        // Flip and align with top left corner.
        stack.method_46416(1, 1, 0);
        stack.method_22905(-1, -1, -1);

        // Scale to make 1/16th of the block one unit and align with top left of terminal area.
        final float pixelScale = 1 / 16f;
        stack.method_22905(pixelScale, pixelScale, pixelScale);

        if (computer.getVirtualMachine().isRunning()) {
            renderTerminal(computer, stack, bufferSource, cameraPosition);
        } else {
            renderStatusText(computer, stack, bufferSource, cameraPosition);
        }

        stack.method_46416(0, 0, -0.1f);
        final Matrix4f matrix = stack.method_23760().method_23761();

        switch (computer.getVirtualMachine().getBusState()) {
            case SCAN_PENDING:
            case INCOMPLETE:
                renderStatus(matrix, bufferSource);
                break;
            case TOO_COMPLEX:
                renderStatus(matrix, bufferSource, 1000);
                break;
            case MULTIPLE_CONTROLLERS:
                renderStatus(matrix, bufferSource, 250);
                break;
            case READY:
                switch (computer.getVirtualMachine().getRunState()) {
                    case STOPPED:
                        break;
                    case LOADING_DEVICES:
                        renderStatus(matrix, bufferSource);
                        break;
                    case RUNNING:
                        renderPower(matrix, bufferSource);
                        break;
                }
                break;
        }

        stack.method_22909();
    }

    // --------------------------------------------------------------------- //

    private void renderTerminal(final ComputerBlockEntity computer, final class_4587 stack, final class_4597 bufferSource, final class_243 cameraPosition) {
        // Render terminal content if close enough.
        if (class_243.method_24953(computer.method_11016()).method_24802(cameraPosition, 6f)) {
            stack.method_22903();
            stack.method_46416(2, 2, -0.9f);

            // Scale to make terminal fit fully.
            final Terminal terminal = computer.getTerminal();
            final float textScaleX = 12f / terminal.getWidth();
            final float textScaleY = 7f / terminal.getHeight();
            final float scale = Math.min(textScaleX, textScaleY) * 0.95f;

            // Center it on both axes.
            final float scaleDeltaX = textScaleX - scale;
            final float scaleDeltaY = textScaleY - scale;
            stack.method_46416(
                terminal.getWidth() * scaleDeltaX * 0.5f,
                terminal.getHeight() * scaleDeltaY * 0.5f,
                0f);

            stack.method_22905(scale, scale, 1f);

            try {
                final TerminalTexture texture = terminalTextures.get(terminal, () -> new TerminalTexture(terminal));
                texture.draw(stack);
            } catch (final ExecutionException e) {
                throw new RuntimeException(e);
            }

            stack.method_22909();
        } else {
            stack.method_22903();
            stack.method_46416(0, 0, -0.9f);

            final Matrix4f matrix = stack.method_23760().method_23761();
            renderQuad(matrix, TEXTURE_TERMINAL.method_24145(bufferSource, ModRenderType::getUnlitBlock));

            stack.method_22909();
        }
    }

    private void renderStatusText(final ComputerBlockEntity computer, final class_4587 stack, final class_4597 bufferSource, final class_243 cameraPosition) {
        if (!class_243.method_24953(computer.method_11016()).method_24802(cameraPosition, 12f)) {
            return;
        }

        final class_2561 bootError = computer.getVirtualMachine().getError();
        if (bootError == null) {
            return;
        }

        stack.method_22903();
        stack.method_46416(3, 3, -0.9f);

        drawText(stack, bufferSource, bootError);

        stack.method_22909();
    }

    private void drawText(final class_4587 stack, final class_4597 bufferSource, final class_2561 text) {
        final int maxWidth = 100;

        stack.method_22903();
        stack.method_22905(10f / maxWidth, 10f / maxWidth, 10f / maxWidth);

        final class_327 fontRenderer = class_310.method_1551().field_1772;
        final Matrix4f matrix = stack.method_23760().method_23761();
        final List<class_5348> wrappedText = fontRenderer.method_27527().method_27495(text, maxWidth, class_2583.field_24360);
        if (wrappedText.size() == 1) {
            final int textWidth = fontRenderer.method_27525(text);
            drawTextLine(fontRenderer, text.getString(), (maxWidth - textWidth) * 0.5f, 0, matrix, bufferSource);
        } else {
            for (int i = 0; i < wrappedText.size(); i++) {
                drawTextLine(fontRenderer, wrappedText.get(i).getString(), 0, i * fontRenderer.field_2000, matrix, bufferSource);
            }
        }

        stack.method_22909();
    }

    private static void drawTextLine(final class_327 font, final String text, final float x, final float y,
                                     final Matrix4f matrix, final class_4597 bufferSource) {
        font.method_27521(text, x, y, 0xFFEE3322, false, matrix, bufferSource,
            class_327.class_6415.field_33993, 0, class_765.method_23687(15, 15));
    }

    private void renderStatus(final Matrix4f matrix, final class_4597 bufferSource) {
        renderStatus(matrix, bufferSource, 0);
    }

    private void renderStatus(final Matrix4f matrix, final class_4597 bufferSource, final int frequency) {
        if (frequency <= 0 || (System.currentTimeMillis() + hashCode()) / frequency % 2 == 1) {
            renderQuad(matrix, TEXTURE_STATUS.method_24145(bufferSource, ModRenderType::getUnlitBlock));
        }
    }

    private void renderPower(final Matrix4f matrix, final class_4597 bufferSource) {
        renderQuad(matrix, TEXTURE_POWER.method_24145(bufferSource, ModRenderType::getUnlitBlock));
    }

    private static void renderQuad(final Matrix4f matrix, final class_4588 consumer) {
        // Not chained: vanilla's SpriteCoordinateExpander.addVertex returns the delegate, so a
        // chained setUv would bypass the sprite remap (NeoForge patches this, Fabric does not).
        consumer.method_22918(matrix, 0, 0, 0);
        consumer.method_22913(0, 0);

        consumer.method_22918(matrix, 0, 16, 0);
        consumer.method_22913(0, 1);

        consumer.method_22918(matrix, 16, 16, 0);
        consumer.method_22913(1, 1);

        consumer.method_22918(matrix, 16, 0, 0);
        consumer.method_22913(1, 0);
    }

    private static void handleNoLongerRendering(final RemovalNotification<Terminal, TerminalTexture> notification) {
        final TerminalTexture value = notification.getValue();
        if (value != null) {
            value.close();
        }
    }
}
