/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.client.renderer.ProjectorDepthRenderer;
import li.cil.oc2.common.block.ProjectorBlock;
import li.cil.oc2.common.blockentity.ProjectorBlockEntity;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

public class ProjectorRenderer implements class_827<ProjectorBlockEntity> {
    private static final int LIGHT_COLOR_NEAR = 0x22FFFFFF;
    private static final int LIGHT_COLOR_FAR = 0x00FFFFFF;
    private static final int LENS_COLOR = 0xDDFFFFFF;
    private static final int MISSING_ENERGY_COLOR = 0xEEFF6666;
    private static final int LED_COLOR = 0xCC6688DD;

    private static final float LENS_RIGHT = 0 + 4 / 16f;
    private static final float LENS_LEFT = 1 - 4 / 16f;
    private static final float LENS_BOTTOM = 0 + 4 / 16f;
    private static final float LENS_TOP = 1 - 4 / 16f;

    // --------------------------------------------------------------------- //

    public ProjectorRenderer(final class_5614.class_5615 ignored) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean shouldRender(final ProjectorBlockEntity projector, final class_243 position) {
        return !ProjectorDepthRenderer.isRenderingProjectorDepth() &&
            class_827.super.method_33892(projector, position);
    }

    @Override
    public boolean shouldRenderOffScreen(final ProjectorBlockEntity projector) {
        // Render bounding box of projectors (vastly) exceeds their block position, so they need
        // to be treated as global renderers, and cannot be culled with their chunk.
        return true;
    }

    @Override
    public void render(final ProjectorBlockEntity projector, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        if (projector.isProjecting()) {
            stack.method_22903();

            alignToFrontFace(projector, stack);

            if (projector.hasEnergy()) {
                if (canSeeProjectedImage(stack)) {
                    ProjectorDepthRenderer.addProjector(projector);
                }

                renderProjectorLight(stack, bufferSource);
            } else {
                renderMissingEnergyIndicator(stack, bufferSource);
            }

            stack.method_22909();
        }
    }

    // --------------------------------------------------------------------- //

    private static boolean canSeeProjectedImage(final class_4587 stack) {
        final Matrix4f matrix = stack.method_23760().method_23761();

        final Vector4f lookDirection = new Vector4f(0, 0, -1, 0);
        lookDirection.mul(matrix);

        final Vector4f relativePosition = new Vector4f(0, 0, 1, 1);
        relativePosition.mul(matrix);

        return relativePosition.dot(lookDirection) < ProjectorBlockEntity.MAX_RENDER_DISTANCE;
    }

    private void alignToFrontFace(final ProjectorBlockEntity projector, final class_4587 stack) {
        final class_2350 blockFacing = projector.method_11010().method_11654(ProjectorBlock.field_11177);
        final Quaternionf rotation = class_7833.field_40715.rotationDegrees(blockFacing.method_10144());
        stack.method_46416(0.5f, 0, 0.5f);
        stack.method_22907(rotation);
    }

    private static void renderProjectorLight(final class_4587 stack, final class_4597 bufferSource) {
        stack.method_22904(-0.5, 0, 0.5);
        final class_4588 consumer = bufferSource.getBuffer(ModRenderType.getProjectorLight());
        final Matrix4f matrix = stack.method_23760().method_23761();

        final float leftFar = 1.25f;
        final float rightFar = -0.25f;
        final float topFar = 1.5f;
        final float bottomFar = 0 + 1 / 16f;

        // Top.
        consumer.method_22918(matrix, leftFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top left far
        consumer.method_22918(matrix, LENS_LEFT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top left near
        consumer.method_22918(matrix, LENS_RIGHT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top right near
        consumer.method_22918(matrix, rightFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top right far

        // Bottom.
        consumer.method_22918(matrix, leftFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom left far
        consumer.method_22918(matrix, LENS_LEFT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom left near
        consumer.method_22918(matrix, LENS_RIGHT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom right near
        consumer.method_22918(matrix, rightFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom right far

        // Left.
        consumer.method_22918(matrix, leftFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top left far
        consumer.method_22918(matrix, leftFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom left far
        consumer.method_22918(matrix, LENS_LEFT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom left near
        consumer.method_22918(matrix, LENS_LEFT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top left near

        // Right.
        consumer.method_22918(matrix, rightFar, topFar, 1).method_39415(LIGHT_COLOR_FAR); // top right far
        consumer.method_22918(matrix, LENS_RIGHT, LENS_TOP, 0).method_39415(LIGHT_COLOR_NEAR); // top right near
        consumer.method_22918(matrix, LENS_RIGHT, LENS_BOTTOM, 0).method_39415(LIGHT_COLOR_NEAR); // bottom right near
        consumer.method_22918(matrix, rightFar, bottomFar, 1).method_39415(LIGHT_COLOR_FAR); // bottom right far

        renderLens(matrix, consumer, LENS_COLOR);
        renderLed(matrix, consumer);
    }

    private static void renderMissingEnergyIndicator(final class_4587 stack, final class_4597 bufferSource) {
        stack.method_22904(-0.5, 0, 0.5);
        final class_4588 consumer = bufferSource.getBuffer(ModRenderType.getProjectorLight());
        final Matrix4f matrix = stack.method_23760().method_23761();

        renderLens(matrix, consumer, MISSING_ENERGY_COLOR);
        renderLed(matrix, consumer);
    }

    private static void renderLens(final Matrix4f matrix, final class_4588 consumer, final int color) {
        final float lensDepth = -1 / 16f;
        consumer.method_22918(matrix, LENS_RIGHT, LENS_BOTTOM, lensDepth).method_39415(color);
        consumer.method_22918(matrix, LENS_LEFT, LENS_BOTTOM, lensDepth).method_39415(color);
        consumer.method_22918(matrix, LENS_LEFT, LENS_TOP, lensDepth).method_39415(color);
        consumer.method_22918(matrix, LENS_RIGHT, LENS_TOP, lensDepth).method_39415(color);
    }

    private static void renderLed(final Matrix4f matrix, final class_4588 consumer) {
        final float ledRight = 0 + 7 / 16f;
        final float ledLeft = 0 + 9 / 16f;
        final float ledBottom = 0 + 3 / 16f;
        final float ledTop = 0 + 4 / 16f;
        final float ledDepth = -0.75f / 16f;

        consumer.method_22918(matrix, ledRight, ledBottom, ledDepth).method_39415(LED_COLOR);
        consumer.method_22918(matrix, ledLeft, ledBottom, ledDepth).method_39415(LED_COLOR);
        consumer.method_22918(matrix, ledLeft, ledTop, ledDepth).method_39415(LED_COLOR);
        consumer.method_22918(matrix, ledRight, ledTop, ledDepth).method_39415(LED_COLOR);
    }
}
