/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.node;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.client.gui.Textures;
import li.cil.oc2.client.gui.widget.Texture;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.common.item.Items;
import net.minecraft.class_1087;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

import static li.cil.oc2.common.util.TranslationUtils.key;
import static li.cil.oc2.common.util.TranslationUtils.text;

public final class SideConfigurationWidget extends class_339 {
    private static final String SIDE_STATE_TEXT = key("gui.{mod}.sided_device.side_state");
    private static final class_2561 CONNECTIVITY_ENABLED_TEXT = text("gui.{mod}.sided_device.connectivity.enabled");
    private static final class_2561 CONNECTIVITY_DISABLED_TEXT = text("gui.{mod}.sided_device.connectivity.disabled");
    private static final int MAX_BLOCK_PITCH = 30;
    private static final double DRAG_THRESHOLD = 3;
    private static final int SIZE = 100;

    // --------------------------------------------------------------------- //

    private final Predicate<class_2350> getConfiguration;
    private final BiConsumer<class_2350, Boolean> sendConfiguration;
    private final ComputerBlockItemRenderer computerBlockItemRenderer = new ComputerBlockItemRenderer();

    private Vector3f blockRotation = new Vector3f(-30, 45, 0);
    @Nullable
    private class_2350 focusedSide;
    private boolean isPressed, hasDraggedBlock;
    private double dragStartX, dragStartY;

    // --------------------------------------------------------------------- //

    public SideConfigurationWidget(final Predicate<class_2350> getConfiguration, final BiConsumer<class_2350, Boolean> sendConfiguration) {
        super(0, 0, SIZE, SIZE, class_5244.field_39003);
        this.getConfiguration = getConfiguration;
        this.sendConfiguration = sendConfiguration;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25348(final double mouseX, final double mouseY) {
        isPressed = true;
        hasDraggedBlock = false;
        dragStartX = mouseX;
        dragStartY = mouseY;
    }

    @Override
    public void method_25357(final double mouseX, final double mouseY) {
        if (isPressed && !hasDraggedBlock && focusedSide != null) {
            sendConfiguration.accept(focusedSide, !getConfiguration.test(focusedSide));
            class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1));
        }
        isPressed = false;
    }

    @Override
    public void method_25354(final class_1144 soundManager) {
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25349(final double mouseX, final double mouseY, final double deltaX, final double deltaY) {
        if (!hasDraggedBlock) {
            final double dx = mouseX - dragStartX;
            final double dy = mouseY - dragStartY;
            hasDraggedBlock = Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD;
        }
        if (hasDraggedBlock) {
            blockRotation = new Vector3f(
                class_3532.method_15363(blockRotation.x() - (float) deltaY, -MAX_BLOCK_PITCH, MAX_BLOCK_PITCH),
                class_3532.method_15393(blockRotation.y() + (float) deltaX),
                blockRotation.z()
            );
        }
    }

    @Override
    protected void method_48579(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        final int blockX = method_46426() + field_22758 / 2;
        final int blockY = method_46427() + field_22759 / 2;
        focusedSide = method_49606() ? computerBlockItemRenderer.getFocusedSide(blockX - mouseX, blockY - mouseY, blockRotation) : null;
        computerBlockItemRenderer.render(blockX, blockY, blockRotation);

        final class_437 screen = class_310.method_1551().field_1755;
        if (focusedSide != null && screen != null) {
            final class_2561 enabledComponent = getConfiguration.test(focusedSide) ? CONNECTIVITY_ENABLED_TEXT : CONNECTIVITY_DISABLED_TEXT;
            screen.method_47415(class_2561.method_43469(SIDE_STATE_TEXT, enabledComponent));
        }
    }

    @Override
    protected void method_47399(final class_6382 output) {
    }

    // --------------------------------------------------------------------- //

    private final class ComputerBlockItemRenderer {
        public static final int BLOCK_RENDER_SIZE = 48;

        private final class_1799 computerItemStack = new class_1799(Items.COMPUTER.get());
        private final class_918 itemRenderer = class_310.method_1551().method_1480();
        private final class_1087 model = itemRenderer.method_4019(computerItemStack, null, null, 0);

        @Nullable
        private class_2350 getFocusedSide(final float mouseX, final float mouseY, final Vector3f rotation) {
            // Rotate ray inversely around block to represent visual block rotation.
            final Quaternionf quaternion = fromXYZDegrees(toRenderRotation(rotation));
            quaternion.conjugate();

            // Move ray in screen space to mouse position.
            final float relMouseX = -mouseX / BLOCK_RENDER_SIZE;
            final float relMouseY = -mouseY / BLOCK_RENDER_SIZE;

            final Vector3f source = new Vector3f();
            source.add(relMouseX, relMouseY, 1);
            source.rotate(quaternion);

            final Vector3f target = new Vector3f();
            target.add(relMouseX, relMouseY, -1);
            target.rotate(quaternion);

            // Intersect rotated ray with bounding box representing block.
            final class_238 aabb = new class_238(-0.5, -0.5, -0.5, 0.5, 0.5, 0.5);
            return aabb.method_992(new class_243(source), new class_243(target))
                .map(hit -> class_2350.method_10142(-hit.field_1352, -hit.method_10214(), -hit.method_10215()))
                .filter(side -> side != class_2350.field_11035)
                .orElse(null);
        }

        public void render(final int x, final int y, final Vector3f rotation) {
            RenderSystem.setShaderTexture(0, class_1723.field_21668);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderColor(1, 1, 1, 1);

            final Vector3f renderRotation = toRenderRotation(rotation);

            final class_4587 poseStack = new class_4587();
            poseStack.method_46416(x, y, BLOCK_RENDER_SIZE);
            poseStack.method_22907(fromXYZDegrees(renderRotation));
            poseStack.method_22905(BLOCK_RENDER_SIZE, -BLOCK_RENDER_SIZE, BLOCK_RENDER_SIZE);

            final class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();
            renderBlock(poseStack, bufferSource);
            renderOverlays(poseStack, bufferSource);
            bufferSource.method_22993();
        }

        private void renderBlock(final class_4587 poseStack, final class_4597.class_4598 bufferSource) {
            itemRenderer.method_23179(computerItemStack, class_811.field_4315, false, poseStack, bufferSource, 0xF000F0, class_4608.field_21444, model);
        }

        private void renderOverlays(final class_4587 poseStack, final class_4597.class_4598 bufferSource) {
            for (final class_2350 side : class_2350.values()) {
                // South face of computers is the front face (screen) and there's no connectivity allowed there.
                if (side == class_2350.field_11035) {
                    continue;
                }

                poseStack.method_22903();

                poseStack.method_22904(-side.method_10148() * 0.51, side.method_10164() * 0.51, -side.method_10165() * 0.51);

                final Vector3f sideRotation = switch (side) {
                    case field_11033 -> new Vector3f(-90, 0, 0);
                    case field_11036 -> new Vector3f(90, 0, 0);
                    case field_11043 -> new Vector3f(0, 180, 0);
                    case field_11039 -> new Vector3f(0, -90, 0);
                    case field_11034 -> new Vector3f(0, 90, 0);
                    default -> throw new IllegalStateException("Unexpected value: " + side);
                };
                poseStack.method_22907(fromXYZDegrees(sideRotation));

                poseStack.method_22904(-0.5, -0.5, 0);

                if (getConfiguration.test(side)) {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_ENABLED_TEXTURE);
                } else {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_DISABLED_TEXTURE);
                }

                if (side == focusedSide) {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_FOCUSED_TEXTURE);
                }

                poseStack.method_22909();
            }
        }

        private void renderOverlay(final class_4587 poseStack, final class_4597.class_4598 bufferSource, final Texture texture) {
            final class_4588 buffer = bufferSource.getBuffer(ModRenderType.getOverlay(texture.location));

            buffer.method_22918(poseStack.method_23760().method_23761(), 0, 0, 0).method_22913(0, 0);
            buffer.method_22918(poseStack.method_23760().method_23761(), 0, 1, 0).method_22913(0, 1);
            buffer.method_22918(poseStack.method_23760().method_23761(), 1, 1, 0).method_22913(1, 1);
            buffer.method_22918(poseStack.method_23760().method_23761(), 1, 0, 0).method_22913(1, 0);
        }

        private static Vector3f toRenderRotation(final Vector3f rotation) {
            return new Vector3f(rotation).add(0, 180, 0);
        }

        private static Quaternionf fromXYZDegrees(final Vector3f degrees) {
            return new Quaternionf().rotationXYZ(
                (float) Math.toRadians(degrees.x()),
                (float) Math.toRadians(degrees.y()),
                (float) Math.toRadians(degrees.z()));
        }
    }
}
