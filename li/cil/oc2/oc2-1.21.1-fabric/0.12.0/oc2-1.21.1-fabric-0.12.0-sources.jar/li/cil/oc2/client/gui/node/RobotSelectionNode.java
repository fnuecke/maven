/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.node;

import li.cil.oc2.api.API;
import li.cil.oc2.client.gui.layout.Node;
import li.cil.oc2.client.gui.layout.UiRenderer;
import li.cil.oc2.common.entity.Robot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_8030;

import static li.cil.oc2.client.gui.layout.SlotNode.SLOT_SIZE;

@Environment(EnvType.CLIENT)
public final class RobotSelectionNode extends Node {
    private static final class_2960 SELECTION = class_2960.method_60655(API.MOD_ID, "robot/selection");

    // --------------------------------------------------------------------- //

    private final Robot robot;
    private final int columns;

    // --------------------------------------------------------------------- //

    public RobotSelectionNode(final Robot robot, final int columns) {
        this.robot = robot;
        this.columns = columns;
        overlay();
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void drawBackground(final UiRenderer renderer, final int mouseX, final int mouseY) {
        final class_8030 bounds = bounds();
        final int selected = robot.getSelectedSlot();
        renderer.sprite(SELECTION, bounds.method_49620() + selected % columns * SLOT_SIZE, bounds.method_49618() + selected / columns * SLOT_SIZE, SLOT_SIZE, SLOT_SIZE);
    }
}
