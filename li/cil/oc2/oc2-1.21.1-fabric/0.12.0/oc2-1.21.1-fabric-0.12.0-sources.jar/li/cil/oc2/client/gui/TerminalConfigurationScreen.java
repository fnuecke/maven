/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.*;
import li.cil.oc2.client.gui.util.GuiUtils;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.TerminalBlockEntity;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.TerminalConfigurationMessage;
import li.cil.oc2.common.network.message.TerminalKeepAliveMessage;
import li.cil.oc2.common.serial.SerialFrame;
import net.minecraft.class_2561;
import net.minecraft.class_342;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class TerminalConfigurationScreen extends AbstractBlockEntityScreen<TerminalBlockEntity> {
    private static final int CONTENT_WIDTH = 80;
    private static final int BUTTON_HEIGHT = 16;

    private static final class_2561 ADDRESS_LABEL = text("gui.{mod}.terminal.address");
    private static final class_2561 BAUD_RATE_LABEL = text("gui.{mod}.terminal.baud_rate");

    private static final int[] BAUD_RATES = {300, 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200};

    // --------------------------------------------------------------------- //

    private int keepAliveCountdown;

    private final EditBoxNode addressNode;
    private final class_342 addressField;
    private int baudRateIndex;

    // --------------------------------------------------------------------- //

    public TerminalConfigurationScreen(final TerminalBlockEntity terminal) {
        super(Items.TERMINAL.get().method_7848(), terminal);
        baudRateIndex = indexOfNearestBaudRate(terminal.getBaudRate());
        addressNode = createAddressNode(terminal.getAddress());
        addressField = addressNode.editBox();
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25432() {
        super.method_25432();

        final int address = Math.clamp(valueOf(addressField, blockEntity.getAddress()), 0, SerialFrame.MAX_ADDRESS);
        final int baudRate = BAUD_RATES[baudRateIndex];
        if (address != blockEntity.getAddress() || baudRate != blockEntity.getBaudRate()) {
            Network.sendToServer(new TerminalConfigurationMessage.ToServer(blockEntity, address, baudRate));
        }
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Window createWindow() {
        final ImageButton backButton = new ImageButton(0, 0, 12, 12,
            Sprites.CONFIG_BUTTON_ACTIVE,
            Sprites.CONFIG_BUTTON_INACTIVE
        ) {
            @Override
            public void method_25306() {
                field_22787.method_1507(new TerminalScreen(blockEntity));
            }
        };
        backButton.withTooltip(class_2561.method_43471(Constants.MACHINE_OPEN_TERMINAL_CAPTION));

        return new Window(
            NodeStack.vertical(
                LabelNode.truncating(field_22785),
                Ui.field(ADDRESS_LABEL, addressNode),
                Ui.field(BAUD_RATE_LABEL, new WidgetNode(new BaudRateButton()).width(Size.GROW))
            ).width(Size.fixed(CONTENT_WIDTH)),
            Ui.toolbar(new WidgetNode(backButton)));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        method_48265(addressField);
    }

    @Override
    protected void safeTick() {
        sendKeepAlive();
    }

    // --------------------------------------------------------------------- //

    private void sendKeepAlive() {
        if (--keepAliveCountdown <= 0) {
            keepAliveCountdown = TerminalBlockEntity.CLIENT_KEEPALIVE_EVERY;
            Network.sendToServer(new TerminalKeepAliveMessage(blockEntity));
        }
    }

    private static EditBoxNode createAddressNode(final int value) {
        final EditBoxNode node = new EditBoxNode(ADDRESS_LABEL);
        node.width(Size.GROW);
        final class_342 field = node.editBox();
        field.method_1890(TerminalConfigurationScreen::isNumber);
        field.method_1852(String.valueOf(value));
        field.method_1863(text -> GuiUtils.clampToRange(field, 0, SerialFrame.MAX_ADDRESS));
        return node;
    }

    private static int indexOfNearestBaudRate(final int baudRate) {
        int nearest = 0;
        for (int i = 1; i < BAUD_RATES.length; i++) {
            if (Math.abs(BAUD_RATES[i] - baudRate) < Math.abs(BAUD_RATES[nearest] - baudRate)) {
                nearest = i;
            }
        }

        return nearest;
    }

    private static int valueOf(final class_342 field, final int fallback) {
        final String value = field.method_1882();
        return value.isEmpty() ? fallback : Integer.parseInt(value);
    }

    private static boolean isNumber(final String value) {
        return value.chars().allMatch(Character::isDigit);
    }

    // --------------------------------------------------------------------- //

    private final class BaudRateButton extends ImageButton {
        BaudRateButton() {
            super(0, 0, 0, BUTTON_HEIGHT, Sprites.GENERIC_BUTTON_BASE, Sprites.GENERIC_BUTTON_PRESSED);
            cycle(0);
        }

        @Override
        public void method_25306() {
            super.method_25306();
            cycle(1);
        }

        private void cycle(final int direction) {
            baudRateIndex = Math.floorMod(baudRateIndex + direction, BAUD_RATES.length);
            method_25355(class_2561.method_43470(String.valueOf(BAUD_RATES[baudRateIndex])));
        }
    }
}
