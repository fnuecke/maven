/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_342;

public final class EditBoxNode extends NodeStack {
    public static final int TEXT_COLOR = 0xFFFFFFFF;

    private static final Insets PADDING = new Insets(3, 5, 3, 5);
    private static final int FIELD_HEIGHT = 9;

    // --------------------------------------------------------------------- //

    private final class_342 editBox;

    // --------------------------------------------------------------------- //

    public EditBoxNode(final class_2561 message) {
        super(Axis.VERTICAL);
        editBox = new ResizableEditBox(message);
        editBox.method_1858(false);
        editBox.method_1868(TEXT_COLOR);
        add(new WidgetNode(editBox).width(Size.GROW));
        padding(PADDING);
        background(Theme::insetBlack);
    }

    // --------------------------------------------------------------------- //

    public class_342 editBox() {
        return editBox;
    }

    // --------------------------------------------------------------------- //

    private static final class ResizableEditBox extends class_342 {
        ResizableEditBox(final class_2561 message) {
            super(class_310.method_1551().field_1772, 0, 0, 0, FIELD_HEIGHT, message);
        }

        @Override
        public void method_25358(final int width) {
            super.method_25358(width);
            method_1875(method_1881());
        }

        @Override
        public void method_55445(final int width, final int height) {
            super.method_55445(width, height);
            method_1875(method_1881());
        }
    }
}
