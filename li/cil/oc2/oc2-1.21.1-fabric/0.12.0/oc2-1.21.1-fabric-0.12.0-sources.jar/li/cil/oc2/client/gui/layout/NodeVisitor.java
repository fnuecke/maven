/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import net.minecraft.class_1735;
import net.minecraft.class_339;

public interface NodeVisitor {
    default void slot(final Node node, final class_1735 slot) {
    }

    default void widget(final Node node, final class_339 widget) {
    }
}
