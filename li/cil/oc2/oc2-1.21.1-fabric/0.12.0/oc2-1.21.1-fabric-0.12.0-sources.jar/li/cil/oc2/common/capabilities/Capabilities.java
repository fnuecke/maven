/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.capabilities;

import dev.architectury.injectables.annotations.ExpectPlatform;
import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.capabilities.NetworkInterface;
import li.cil.oc2.api.capabilities.RedstoneEmitter;
import li.cil.oc2.api.capabilities.Robot;
import li.cil.oc2.api.capabilities.TerminalUserProvider;
import li.cil.oc2.common.energy.EnergyHandler;
import li.cil.oc2.common.fluid.FluidHandler;
import li.cil.oc2.common.inventory.ItemHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class Capabilities {
    @FunctionalInterface
    public interface InvalidationHandle {
        void drop();
    }

    // --------------------------------------------------------------------- //

    // Interop capabilities
    public static final CapabilityType<EnergyHandler> ENERGY_STORAGE = type("energy_storage", EnergyHandler.class);
    public static final CapabilityType<ItemHandler> ITEM_HANDLER = type("item_handler", ItemHandler.class);
    public static final CapabilityType<FluidHandler> FLUID_HANDLER = type("fluid_handler", FluidHandler.class);

    // Owned capabilities
    public static final CapabilityType<DeviceBusElement> DEVICE_BUS_ELEMENT = type("device_bus_element", DeviceBusElement.class);
    public static final CapabilityType<Device> DEVICE = type("device", Device.class);
    public static final CapabilityType<RedstoneEmitter> REDSTONE_EMITTER = type("redstone_emitter", RedstoneEmitter.class);
    public static final CapabilityType<NetworkInterface> NETWORK_INTERFACE = type("network_interface", NetworkInterface.class);
    public static final CapabilityType<TerminalUserProvider> TERMINAL_USER_PROVIDER = type("terminal_user_provider", TerminalUserProvider.class);
    public static final CapabilityType<Robot> ROBOT = type("robot", Robot.class);

    // --------------------------------------------------------------------- //

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_1937 level, final class_2338 pos, final CapabilityType<T> type, @Nullable final class_2350 side) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_2586 blockEntity, final CapabilityType<T> type, @Nullable final class_2350 side) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_1799 stack, final CapabilityType<T> type) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static <T> T get(final ItemHandler handler, final int slot, final CapabilityType<T> type) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_1297 entity, final CapabilityType<T> type, @Nullable final class_2350 side) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T> Optional<CapabilityCache<T>> cache(final class_3218 level, final class_2338 pos, @Nullable final class_2350 side,
                                                         final CapabilityType<T> type) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static InvalidationHandle listen(final class_3218 level, final class_2338 pos, final Runnable callback) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void invalidate(final class_2586 blockEntity) {
        throw new AssertionError();
    }

    public static <T> List<T> getAll(final class_3218 level, final class_2338 pos, final CapabilityType<T> type,
                                     final class_2350 side, @Nullable final class_1297 except) {
        final List<T> values = new ArrayList<>();
        if (!level.method_8477(pos)) {
            return values;
        }

        for (final class_1297 entity : level.method_8335(except, new class_238(pos))) {
            final T value = get(entity, type, side);
            if (value != null) {
                values.add(value);
            }
        }

        final T value = get(level, pos, type, side);
        if (value != null) {
            values.add(value);
        }

        return values;
    }

    // --------------------------------------------------------------------- //

    private static <T> CapabilityType<T> type(final String name, final Class<T> type) {
        return new CapabilityType<>(class_2960.method_60655(API.MOD_ID, name), type);
    }

    private Capabilities() {
    }
}
