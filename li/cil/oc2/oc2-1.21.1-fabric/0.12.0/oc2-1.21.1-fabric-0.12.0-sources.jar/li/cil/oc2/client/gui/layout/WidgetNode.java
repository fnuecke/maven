/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import net.minecraft.class_339;

public class WidgetNode extends Node {
    private final class_339 widget;
    private final int contentWidth, contentHeight;

    // --------------------------------------------------------------------- //

    public WidgetNode(final class_339 widget) {
        this.widget = widget;
        this.contentWidth = widget.method_25368();
        this.contentHeight = widget.method_25364();
    }

    // --------------------------------------------------------------------- //
    // Node

    @Override
    protected void accept(final NodeVisitor visitor) {
        visitor.widget(this, widget);
    }

    @Override
    protected int contentWidth() {
        return contentWidth;
    }

    @Override
    protected int contentHeight() {
        return contentHeight;
    }
}
