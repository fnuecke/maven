/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.model.fabric;

import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import java.util.function.Supplier;

public final class EmissiveBakedModel extends ForwardingBakedModel {
    private final RenderMaterial material;

    // --------------------------------------------------------------------- //

    public EmissiveBakedModel(final class_1087 wrapped, final RenderMaterial material) {
        super(wrapped);
        this.material = material;
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(final class_1920 level, final class_2680 state, final class_2338 pos,
                               final Supplier<class_5819> randomSupplier, final RenderContext context) {
        context.pushTransform(quad -> {
            quad.material(material);
            return true;
        });

        try {
            super.emitBlockQuads(level, state, pos, randomSupplier, context);
        } finally {
            context.popTransform();
        }
    }
}
