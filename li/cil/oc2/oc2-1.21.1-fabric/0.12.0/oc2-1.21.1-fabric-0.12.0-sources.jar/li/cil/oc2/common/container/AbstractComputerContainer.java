/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.container;

import li.cil.oc2.common.block.Blocks;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.energy.EnergyHandler;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.ComputerPowerMessage;
import li.cil.oc2.common.network.message.ComputerTerminalInputMessage;
import li.cil.oc2.common.network.message.OpenComputerInventoryMessage;
import li.cil.oc2.common.network.message.OpenComputerTerminalMessage;
import li.cil.oc2.common.vm.PowerAction;
import li.cil.oc2.common.vm.VirtualMachine;
import li.cil.oc2.common.vm.device.Terminal;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3914;
import net.minecraft.class_3917;
import java.nio.ByteBuffer;

public abstract class AbstractComputerContainer extends AbstractMachineTerminalContainer {
    private final ComputerBlockEntity computer;

    // --------------------------------------------------------------------- //

    protected AbstractComputerContainer(final class_3917<?> type, final int id, final class_1657 player, final ComputerBlockEntity computer, final IntPrecisionContainerData energyInfo) {
        super(type, id, energyInfo);
        this.computer = computer;

        this.computer.addTerminalUser(player);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void switchToInventory() {
        Network.sendToServer(new OpenComputerInventoryMessage(computer));
    }

    @Override
    public void switchToTerminal() {
        Network.sendToServer(new OpenComputerTerminalMessage(computer));
    }

    @Override
    public VirtualMachine getVirtualMachine() {
        return computer.getVirtualMachine();
    }

    @Override
    public void sendPowerActionToServer(final PowerAction action) {
        Network.sendToServer(new ComputerPowerMessage(computer, action));
    }

    @Override
    public Terminal getTerminal() {
        return computer.getTerminal();
    }

    @Override
    public void sendTerminalInputToServer(final ByteBuffer input) {
        Network.sendToServer(new ComputerTerminalInputMessage(computer, input));
    }

    @Override
    public boolean method_7597(final class_1657 player) {
        if (!computer.isValid()) {
            return false;
        }
        final class_1937 level = computer.method_10997();
        return level != null && method_17695(class_3914.method_17392(level, computer.method_11016()), player, Blocks.COMPUTER.get());
    }

    @Override
    public void method_7595(final class_1657 player) {
        super.method_7595(player);

        this.computer.removeTerminalUser(player);
    }

    // --------------------------------------------------------------------- //

    protected static IntPrecisionContainerData createEnergyInfo(final EnergyHandler energy, final CommonDeviceBusController busController) {
        return new IntPrecisionContainerData.Server() {
            @Override
            public int getInt(final int index) {
                return switch (index) {
                    case AbstractMachineContainer.ENERGY_STORED_INDEX -> (int) energy.getEnergyStored();
                    case AbstractMachineContainer.ENERGY_CAPACITY_INDEX -> (int) energy.getMaxEnergyStored();
                    case AbstractMachineContainer.ENERGY_CONSUMPTION_INDEX -> busController.getEnergyConsumption();
                    default -> 0;
                };
            }

            @Override
            public int getIntCount() {
                return ENERGY_INFO_SIZE;
            }
        };
    }
}
