/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import javax.annotation.Nullable;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public abstract class UiScreen extends class_437 {
    private final Theme theme;
    @Nullable
    private Window window;

    // --------------------------------------------------------------------- //

    protected UiScreen(final class_2561 title, final Theme theme) {
        super(title);
        this.theme = theme;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        final Window window = window();
        if (window.isStale()) {
            window.layout(field_22789, field_22790);
        }

        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        final UiRenderer renderer = new UiRenderer(graphics, theme);
        window.drawForeground(renderer, mouseX, mouseY);
        window.drawTooltip(renderer, mouseX, mouseY);
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        method_52752(graphics);
        window().drawBackground(new UiRenderer(graphics, theme), mouseX, mouseY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --------------------------------------------------------------------- //

    protected abstract Window createWindow();

    @Override
    protected void method_25426() {
        super.method_25426();
        if (window == null) {
            window = createWindow();
        }
        window.layout(field_22789, field_22790);
        window.widgets().forEach(this::method_37063);
    }

    // --------------------------------------------------------------------- //

    private Window window() {
        if (window == null) {
            throw new IllegalStateException("Screen was not initialized.");
        }
        return window;
    }
}
