/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.util;

import net.minecraft.class_342;

public final class GuiUtils {
    public static boolean clampToRange(final class_342 field, final int minimum, final int maximum) {
        final String value = field.method_1882();
        if (value.isEmpty()) {
            return false;
        }

        final String digits = value.replaceFirst("^0+(?=.)", "");
        final int parsed = digits.length() > Integer.toString(maximum).length() ? maximum : Integer.parseInt(digits);
        final String clamped = Integer.toString(Math.clamp(parsed, minimum, maximum));
        if (clamped.equals(value)) {
            return false;
        }

        field.method_1852(clamped);
        return true;
    }
}
