/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5253;
import net.minecraft.class_5481;
import net.minecraft.class_8001;

public final class UiRenderer {
    private static final int TOOLTIP_WIDTH = 200;

    // --------------------------------------------------------------------- //

    private final class_332 graphics;
    private final Theme theme;
    private final class_327 font;

    // --------------------------------------------------------------------- //

    public UiRenderer(final class_332 graphics, final Theme theme) {
        this.graphics = graphics;
        this.theme = theme;
        this.font = class_310.method_1551().field_1772;
    }

    // --------------------------------------------------------------------- //

    public Theme theme() {
        return theme;
    }

    public class_332 graphics() {
        return graphics;
    }

    public void sprite(final class_2960 sprite, final int x, final int y, final int width, final int height) {
        graphics.method_52706(sprite, x, y, width, height);
    }

    public void atlasSprite(final class_1058 sprite, final int x, final int y, final int width, final int height, final int argb) {
        graphics.method_48465(x, y, 0, width, height, sprite,
            class_5253.class_5254.method_27765(argb) / 255f, class_5253.class_5254.method_27766(argb) / 255f,
            class_5253.class_5254.method_27767(argb) / 255f, class_5253.class_5254.method_27762(argb) / 255f);
    }

    public void text(final class_2561 text, final int x, final int y, final int argb, final boolean shadow) {
        graphics.method_51439(font, text, x, y, argb, shadow);
    }

    public void pushScissor(final int x0, final int y0, final int x1, final int y1) {
        graphics.method_44379(x0, y0, x1, y1);
    }

    public void popScissor() {
        graphics.method_44380();
    }

    public void tooltip(final List<class_2561> lines) {
        final class_437 screen = class_310.method_1551().field_1755;
        if (screen == null) {
            return;
        }
        final List<class_5481> wrapped = new ArrayList<>();
        for (final class_2561 line : lines) {
            wrapped.addAll(font.method_1728(line, TOOLTIP_WIDTH));
        }
        screen.method_47942(wrapped, class_8001.field_41687, false);
    }
}
