/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.*;
import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.BusInterfaceNameMessage;
import li.cil.sedna.api.device.bus.DeviceDescription;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import org.lwjgl.glfw.GLFW;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class BusInterfaceScreen extends UiScreen {
    private static final int NAME_WIDTH = 198;

    // --------------------------------------------------------------------- //

    private final BusCableBlockEntity busCable;
    private final class_2350 side;
    private final EditBoxNode nameNode;
    private final class_342 nameField;

    // --------------------------------------------------------------------- //

    public BusInterfaceScreen(final BusCableBlockEntity busCable, final class_2350 side) {
        super(Items.BUS_INTERFACE.get().method_7848(), Sprites.THEME);
        this.busCable = busCable;
        this.side = side;

        nameNode = new EditBoxNode(text("{mod}.gui.bus_interface_name"));
        nameNode.width(Size.fixed(NAME_WIDTH));
        nameField = nameNode.editBox();
        nameField.method_1856(false);
        nameField.method_1880(32);
        nameField.method_1890(value -> value.isEmpty() || DeviceDescription.isValidName(value));
        nameField.method_1852(busCable.getInterfaceName(side));
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25393() {
        super.method_25393();

        final class_243 busCableCenter = class_243.method_24953(busCable.method_11016());
        if (!busCable.isValid() ||
            field_22787.field_1724 == null ||
            field_22787.field_1724.method_5707(busCableCenter) > 8 * 8) {
            method_25419();
        }
    }

    @Override
    public boolean method_25404(final int keyCode, final int scanCode, final int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER ||
            keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            setInterfaceName(nameField.method_1882());
            method_25419();
            return true;
        }

        return nameField.method_25404(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Window createWindow() {
        final ImageButton confirmButton = new ImageButton(0, 0,
            Sprites.CONFIRM_BASE.width, Sprites.CONFIRM_BASE.height,
            Sprites.CONFIRM_BASE,
            Sprites.CONFIRM_PRESSED
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                setInterfaceName(nameField.method_1882());
                method_25419();
            }
        };
        confirmButton.withTooltip(class_2561.method_43471(Constants.TOOLTIP_CONFIRM));

        final ImageButton cancelButton = new ImageButton(0, 0,
            Sprites.CANCEL_BASE.width, Sprites.CANCEL_BASE.height,
            Sprites.CANCEL_BASE,
            Sprites.CANCEL_PRESSED
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                method_25419();
            }
        };
        cancelButton.withTooltip(class_2561.method_43471(Constants.TOOLTIP_CANCEL));

        return new Window(NodeStack.horizontal(
            nameNode,
            new WidgetNode(confirmButton),
            new WidgetNode(cancelButton)
        ).alignment(Align.START, Align.CENTER));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        method_48265(nameField);
    }

    // --------------------------------------------------------------------- //

    private void setInterfaceName(final String name) {
        Network.sendToServer(new BusInterfaceNameMessage.ToServer(busCable, side, name));
    }
}
