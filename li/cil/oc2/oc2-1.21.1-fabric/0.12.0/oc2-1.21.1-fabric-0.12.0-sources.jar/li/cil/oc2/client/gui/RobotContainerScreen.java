/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.device.DeviceType;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.client.gui.layout.*;
import li.cil.oc2.client.gui.node.RobotSelectionNode;
import li.cil.oc2.client.gui.node.TankNode;
import li.cil.oc2.common.container.RobotInventoryContainer;
import li.cil.oc2.common.container.RobotSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.util.List;

import static li.cil.oc2.client.gui.layout.SlotNode.SLOT_SIZE;

@Environment(EnvType.CLIENT)
public final class RobotContainerScreen extends UiContainerScreen<RobotInventoryContainer> {
    private static final class_2960 MAINBOARD = class_2960.method_60655(API.MOD_ID, "robot/mainboard");
    private static final int MAINBOARD_WIDTH = 103, MAINBOARD_HEIGHT = 81;
    private static final int INVENTORY_COLUMNS = 3;
    private static final int TANK_GAP = 1;

    // --------------------------------------------------------------------- //

    private final class_1661 inventory;

    // --------------------------------------------------------------------- //

    public RobotContainerScreen(final RobotInventoryContainer container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title, Sprites.THEME);
        this.inventory = inventory;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Window createWindow() {
        final List<class_1735> robotSlots = field_2797.field_7761.stream().filter(slot -> slot instanceof RobotSlot).toList();
        final NodeStack robotInventory = Ui.slotGrid(robotSlots, INVENTORY_COLUMNS)
            .add(new RobotSelectionNode(field_2797.getRobot(), INVENTORY_COLUMNS));

        return new Window(
            NodeStack.vertical(
                Ui.section(field_22785, NodeStack.horizontal(
                    MachineScreens.mainboard(field_2797, MAINBOARD, MAINBOARD_WIDTH, MAINBOARD_HEIGHT, RobotContainerScreen::placeSlot),
                    NodeStack.vertical(robotInventory, new TankNode(field_2797)).spacing(TANK_GAP)
                )),
                Ui.section(field_29347, Ui.playerInventory(field_2797, inventory))
            ),
            MachineScreens.toolbar(field_2797, MachineScreens.openTerminalButton(field_2797)));
    }

    // --------------------------------------------------------------------- //

    private static void placeSlot(final DeviceType type, final int index, final Node node) {
        if (type == DeviceTypes.CPU.get()) {
            node.position(26, 32);
        } else if (type == DeviceTypes.FLASH_MEMORY.get()) {
            node.position(26, 58);
        } else if (type == DeviceTypes.MEMORY.get()) {
            node.position(26 + index * SLOT_SIZE, 4);
        } else if (type == DeviceTypes.HARD_DRIVE.get()) {
            node.position(62, 40 + index * SLOT_SIZE);
        } else if (type == DeviceTypes.FLOPPY.get()) {
            node.position(80, 40 + index * SLOT_SIZE);
        } else if (type == DeviceTypes.ROBOT_MODULE.get()) {
            node.position(0, 4 + index * SLOT_SIZE);
        } else {
            throw new IllegalArgumentException("Unexpected device type " + type);
        }
    }
}
