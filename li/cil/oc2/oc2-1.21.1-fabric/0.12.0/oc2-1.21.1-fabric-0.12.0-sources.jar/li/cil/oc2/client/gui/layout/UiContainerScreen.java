/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import javax.annotation.Nullable;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_768;
import net.minecraft.class_8030;
import java.util.ArrayList;
import java.util.List;

public abstract class UiContainerScreen<T extends class_1703> extends class_465<T> {
    private static final float FOREGROUND_Z = 320;

    // --------------------------------------------------------------------- //

    private final Theme theme;
    @Nullable
    private Window window;

    // --------------------------------------------------------------------- //

    protected UiContainerScreen(final T menu, final class_1661 inventory, final class_2561 title, final Theme theme) {
        super(menu, inventory, title);
        this.theme = theme;
    }

    // --------------------------------------------------------------------- //

    public List<class_768> getExtraAreas() {
        final List<class_768> areas = new ArrayList<>();
        if (window != null) {
            for (final class_8030 area : window.extraAreas()) {
                areas.add(new class_768(area.method_49620(), area.method_49618(), area.comp_1196(), area.comp_1197()));
            }
        }
        return areas;
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        final Window window = window();
        if (window.isStale()) {
            layout(window);
        }

        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        if (field_2797.method_34255().method_7960() && (field_2787 == null || !field_2787.method_7681())) {
            window.drawTooltip(new UiRenderer(graphics, theme), mouseX, mouseY);
        }
        method_2380(graphics, mouseX, mouseY);
    }

    // --------------------------------------------------------------------- //

    protected abstract Window createWindow();

    @Override
    protected void method_25426() {
        super.method_25426();
        if (window == null) {
            window = createWindow();
            for (final class_1735 slot : field_2797.field_7761) {
                if (!window.slots().contains(slot)) {
                    throw new IllegalStateException("Slot " + slot.field_7874 + " is not placed by the window.");
                }
            }
        }
        layout(window);
        window.widgets().forEach(this::method_37063);
    }

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        window().drawBackground(new UiRenderer(graphics, theme), mouseX, mouseY);
    }

    @Override
    protected void method_2388(final class_332 graphics, final int mouseX, final int mouseY) {
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(-field_2776, -field_2800, FOREGROUND_Z);
        window().drawForeground(new UiRenderer(graphics, theme), mouseX, mouseY);
        graphics.method_51448().method_22909();
    }

    @Override
    protected boolean method_2381(final double mouseX, final double mouseY, final int left, final int top, final int button) {
        return super.method_2381(mouseX, mouseY, left, top, button) && !window().isInExtraArea(mouseX, mouseY);
    }

    // --------------------------------------------------------------------- //

    private void layout(final Window window) {
        window.layout(field_22789, field_22790);
        final class_8030 bounds = window.bounds();
        field_2792 = bounds.comp_1196();
        field_2779 = bounds.comp_1197();
        field_2776 = bounds.method_49620();
        field_2800 = bounds.method_49618();
    }

    private Window window() {
        if (window == null) {
            throw new IllegalStateException("Screen was not initialized.");
        }
        return window;
    }
}
