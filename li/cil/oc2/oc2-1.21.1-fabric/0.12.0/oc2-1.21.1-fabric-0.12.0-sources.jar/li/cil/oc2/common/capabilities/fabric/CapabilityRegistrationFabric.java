/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.capabilities.fabric;

import li.cil.oc2.api.fabric.EnergyStorage;
import li.cil.oc2.api.fabric.FluidStorage;
import li.cil.oc2.api.fabric.ItemStorage;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.ModBlockEntity;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityType;
import li.cil.oc2.common.entity.Entities;
import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import java.util.List;

public final class CapabilityRegistrationFabric {
    private static final List<CapabilityType<?>> BLOCK_ENTITY_CAPABILITIES = List.of(
        Capabilities.DEVICE_BUS_ELEMENT,
        Capabilities.DEVICE,
        Capabilities.REDSTONE_EMITTER,
        Capabilities.NETWORK_INTERFACE,
        Capabilities.TERMINAL_USER_PROVIDER
    );

    private static final List<CapabilityType<?>> ENTITY_CAPABILITIES = List.of(
        Capabilities.ROBOT,
        Capabilities.TERMINAL_USER_PROVIDER
    );

    // --------------------------------------------------------------------- //

    public static void initialize() {
        CapabilityWatchers.initialize();

        final class_2591<?>[] types = BlockEntities.getAll().toArray(new class_2591<?>[0]);

        for (final CapabilityType<?> capability : BLOCK_ENTITY_CAPABILITIES) {
            registerBlockEntity(capability, types);
        }
        registerInteropBlockEntities(types);

        for (final CapabilityType<?> capability : ENTITY_CAPABILITIES) {
            registerEntity(capability);
        }
        registerInteropEntity();
    }

    // --------------------------------------------------------------------- //

    private static <T> void registerBlockEntity(final CapabilityType<T> capability, final class_2591<?>[] types) {
        CapabilitiesImpl.block(capability).registerForBlockEntities(
            (blockEntity, side) -> blockEntity instanceof final ModBlockEntity modBlockEntity
                ? modBlockEntity.getCapability(capability, side)
                : null,
            types);
    }

    private static void registerInteropBlockEntities(final class_2591<?>[] types) {
        EnergyStorage.SIDED.registerForBlockEntities((blockEntity, side) -> {
            if (!(blockEntity instanceof final ModBlockEntity modBlockEntity)) {
                return null;
            }
            final var energy = modBlockEntity.getCapability(Capabilities.ENERGY_STORAGE, side);
            return energy != null ? FabricCapabilityAdapters.toFabric(energy) : null;
        }, types);

        ItemStorage.SIDED.registerForBlockEntities((blockEntity, side) -> {
            if (!(blockEntity instanceof final ModBlockEntity modBlockEntity)) {
                return null;
            }
            final var items = modBlockEntity.getCapability(Capabilities.ITEM_HANDLER, side);
            return items != null ? FabricCapabilityAdapters.toFabric(items) : null;
        }, types);
    }

    private static <T> void registerEntity(final CapabilityType<T> capability) {
        CapabilitiesImpl.entity(capability).registerForType(
            (final Robot robot, final class_2350 side) -> robot.getCapability(capability, side),
            Entities.ROBOT.get());
    }

    private static void registerInteropEntity() {
        EnergyStorage.ENTITY.registerForType((final Robot robot, final class_2350 side) -> {
            final var energy = robot.getCapability(Capabilities.ENERGY_STORAGE, side);
            return energy != null ? FabricCapabilityAdapters.toFabric(energy) : null;
        }, Entities.ROBOT.get());

        ItemStorage.ENTITY.registerForType((final Robot robot, final class_2350 side) -> {
            final var items = robot.getCapability(Capabilities.ITEM_HANDLER, side);
            return items != null ? FabricCapabilityAdapters.toFabric(items) : null;
        }, Entities.ROBOT.get());

        FluidStorage.ENTITY.registerForType((final Robot robot, final class_2350 side) -> {
            final var fluids = robot.getCapability(Capabilities.FLUID_HANDLER, side);
            return fluids != null ? FabricCapabilityAdapters.toFabric(fluids) : null;
        }, Entities.ROBOT.get());
    }

    private CapabilityRegistrationFabric() {
    }
}
