/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.client.gui.layout;

import javax.annotation.ParametersAreNonnullByDefault;
