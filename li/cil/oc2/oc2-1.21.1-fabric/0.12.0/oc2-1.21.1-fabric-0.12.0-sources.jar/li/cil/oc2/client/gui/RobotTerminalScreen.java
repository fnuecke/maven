/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.Align;
import li.cil.oc2.client.gui.layout.Node;
import li.cil.oc2.client.gui.layout.NodeStack;
import li.cil.oc2.client.gui.layout.Ui;
import li.cil.oc2.client.gui.node.RobotSelectionNode;
import li.cil.oc2.common.container.RobotSlot;
import li.cil.oc2.common.container.RobotTerminalContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import java.util.List;

@Environment(EnvType.CLIENT)
public final class RobotTerminalScreen extends AbstractMachineTerminalScreen<RobotTerminalContainer> {
    @SuppressWarnings("all")
    private class_342 focusIndicatorEditBox;

    // --------------------------------------------------------------------- //

    public RobotTerminalScreen(final RobotTerminalContainer container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Node createContent() {
        final List<class_1735> robotSlots = field_2797.field_7761.stream().filter(slot -> slot instanceof RobotSlot).toList();
        final NodeStack slots = Ui.slotGrid(robotSlots, robotSlots.size())
            .add(new RobotSelectionNode(field_2797.getRobot(), robotSlots.size()));
        return NodeStack.vertical(super.createContent(), slots).alignment(Align.START, Align.CENTER);
    }

    @Override
    protected void setFocusIndicatorEditBox(final class_342 editBox) {
        focusIndicatorEditBox = editBox;
    }
}
