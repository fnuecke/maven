/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import net.minecraft.class_2960;

public record Theme(class_2960 panel,
                          class_2960 toolbar,
                          class_2960 slot,
                          class_2960 inset,
                          class_2960 insetBlack,
                          int titleColor,
                          int labelColor
) {
    public Theme {
        if ((titleColor >>> 24) == 0 || (labelColor >>> 24) == 0) {
            throw new IllegalArgumentException("Text colors must not be fully transparent.");
        }
    }

    public static Theme of(final String namespace, final int titleColor, final int labelColor) {
        return new Theme(
            class_2960.method_60655(namespace, "ui/panel"),
            class_2960.method_60655(namespace, "ui/toolbar"),
            class_2960.method_60655(namespace, "ui/slot"),
            class_2960.method_60655(namespace, "ui/inset"),
            class_2960.method_60655(namespace, "ui/inset_black"),
            titleColor,
            labelColor);
    }
}
