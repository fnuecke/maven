/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.node;

import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.device.DeviceType;
import li.cil.oc2.client.gui.DeviceHints;
import li.cil.oc2.client.gui.layout.Node;
import li.cil.oc2.client.gui.layout.SlotNode;
import li.cil.oc2.client.gui.layout.UiRenderer;
import li.cil.oc2.common.container.DeviceTypeSlotItemHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2073;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_8030;
import javax.annotation.Nullable;
import java.util.List;

import static li.cil.oc2.common.util.TranslationUtils.key;

@Environment(EnvType.CLIENT)
public final class MissingDeviceNode extends Node {
    private static final class_2960 INFO = class_2960.method_60655(API.MOD_ID, "ui/slot_info");
    private static final class_2960 WARN = class_2960.method_60655(API.MOD_ID, "ui/slot_warn");
    private static final int ICON_SIZE = 28;
    private static final int ICON_OFFSET = (SlotNode.SLOT_SIZE - ICON_SIZE) / 2;

    // --------------------------------------------------------------------- //

    private final class_1703 menu;
    private final DeviceType type;
    private final List<DeviceHints.Hint> hints;

    // --------------------------------------------------------------------- //

    public MissingDeviceNode(final class_1703 menu, final DeviceType type, final List<DeviceHints.Hint> hints) {
        this.menu = menu;
        this.type = type;
        this.hints = hints;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected int contentWidth() {
        return SlotNode.SLOT_SIZE;
    }

    @Override
    protected int contentHeight() {
        return SlotNode.SLOT_SIZE;
    }

    @Override
    protected void drawForeground(final UiRenderer renderer, final int mouseX, final int mouseY) {
        final DeviceHints.Hint hint = activeHint();
        if (hint != null) {
            final class_8030 bounds = bounds();
            renderer.sprite(hint.isRequired() ? WARN : INFO, bounds.method_49620() + ICON_OFFSET, bounds.method_49618() + ICON_OFFSET, ICON_SIZE, ICON_SIZE);
        }
    }

    @Nullable
    @Override
    protected List<class_2561> getTooltip() {
        final DeviceHints.Hint hint = activeHint();
        if (hint == null) {
            return null;
        }

        return List.of(class_2561.method_43469(key(hint.isRequired() ? "tooltip.{mod}.device_required" : "tooltip.{mod}.device_suggested"), type.getName()));
    }

    // --------------------------------------------------------------------- //

    @Nullable
    private DeviceHints.Hint activeHint() {
        if (isInstalled()) {
            return null;
        }

        for (final DeviceHints.Hint hint : hints) {
            if (hint.item().isEmpty() || isInstalled(hint.item().get())) {
                return hint;
            }
        }
        return null;
    }

    private boolean isInstalled() {
        for (final class_1735 slot : menu.field_7761) {
            if (slot instanceof final DeviceTypeSlotItemHandler typedSlot && typedSlot.getDeviceType() == type && slot.method_7681()) {
                return true;
            }
        }
        return false;
    }

    private boolean isInstalled(final class_2073 predicate) {
        for (final class_1735 slot : menu.field_7761) {
            if (slot instanceof DeviceTypeSlotItemHandler && slot.method_7681() && predicate.method_8970(slot.method_7677())) {
                return true;
            }
        }
        return false;
    }
}
