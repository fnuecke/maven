/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.UiScreen;
import li.cil.oc2.common.blockentity.ModBlockEntity;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public abstract class AbstractBlockEntityScreen<T extends ModBlockEntity> extends UiScreen {
    private static final int USE_DISTANCE = 8;

    // --------------------------------------------------------------------- //

    protected final T blockEntity;

    // --------------------------------------------------------------------- //

    protected AbstractBlockEntityScreen(final class_2561 title, final T blockEntity) {
        super(title, Sprites.THEME);
        this.blockEntity = blockEntity;
    }

    // --------------------------------------------------------------------- //

    public static boolean isStillValid(final ModBlockEntity blockEntity) {
        final class_310 minecraft = class_310.method_1551();
        final class_243 blockCenter = class_243.method_24953(blockEntity.method_11016());
        return blockEntity.isValid() &&
            minecraft.field_1724 != null &&
            minecraft.field_1724.method_5707(blockCenter) <= USE_DISTANCE * USE_DISTANCE;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25393() {
        super.method_25393();

        if (isStillValid(blockEntity)) {
            safeTick();
        } else {
            method_25419();
        }
    }

    // --------------------------------------------------------------------- //

    protected void safeTick() {
    }
}
