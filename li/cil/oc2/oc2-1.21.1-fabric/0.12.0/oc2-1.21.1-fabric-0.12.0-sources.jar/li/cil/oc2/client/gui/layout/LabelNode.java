/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.layout;

import javax.annotation.Nullable;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import java.util.List;
import java.util.function.ToIntFunction;

public class LabelNode extends Node {
    private static final String ELLIPSIS = "...";

    // --------------------------------------------------------------------- //

    private final class_2561 text;
    private final boolean allowTruncating;
    private ToIntFunction<Theme> color = Theme::titleColor;
    @Nullable
    private class_2561 cache;
    private int cacheKey = -1;
    private boolean isTruncated;

    // --------------------------------------------------------------------- //

    public static LabelNode truncating(final class_2561 text) {
        return new LabelNode(text, true);
    }

    // --------------------------------------------------------------------- //

    public LabelNode(final class_2561 text) {
        this(text, false);
    }

    private LabelNode(final class_2561 text, final boolean allowTruncating) {
        this.text = text;
        this.allowTruncating = allowTruncating;
        if (allowTruncating) {
            width(Size.GROW);
        }
    }

    // --------------------------------------------------------------------- //

    public LabelNode color(final ToIntFunction<Theme> color) {
        this.color = color;
        return this;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected int contentWidth() {
        return allowTruncating ? 0 : font().method_27525(text);
    }

    @Override
    protected int contentHeight() {
        return font().field_2000;
    }

    @Override
    protected void drawForeground(final UiRenderer renderer, final int mouseX, final int mouseY) {
        renderer.text(getOrBuildComponent(), x, y, color.applyAsInt(renderer.theme()), false);
    }

    @Nullable
    @Override
    protected List<class_2561> getTooltip() {
        final List<class_2561> tooltip = super.getTooltip();
        if (tooltip == null && isTruncated()) {
            return List.of(text);
        }
        return tooltip;
    }

    // --------------------------------------------------------------------- //

    private class_2561 getOrBuildComponent() {
        if (cacheKey != w || cache == null) {
            final class_327 font = font();
            cacheKey = w;
            isTruncated = font.method_27525(text) > w;
            cache = isTruncated
                ? class_2561.method_43470(font.method_27523(text.getString(), w - font.method_1727(ELLIPSIS)) + ELLIPSIS)
                : text;
        }
        return cache;
    }

    private boolean isTruncated() {
        getOrBuildComponent();
        return isTruncated;
    }

    private static class_327 font() {
        return class_310.method_1551().field_1772;
    }
}
