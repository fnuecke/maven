/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.layout.*;
import li.cil.oc2.client.gui.util.GuiUtils;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.item.SerialInterfaceCardItem;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.SerialInterfaceCardConfigurationMessage;
import li.cil.oc2.common.serial.SerialFrame;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_342;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class SerialInterfaceCardScreen extends AbstractSideConfigurationScreen {
    private static final class_2561 ADDRESS_TEXT = text("gui.{mod}.serial_interface_card.address");

    // --------------------------------------------------------------------- //

    public SerialInterfaceCardScreen(final class_1657 player, final class_1268 hand) {
        super(player, hand, Items.SERIAL_INTERFACE_CARD.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Node[] createControls() {
        final EditBoxNode addressNode = new EditBoxNode(ADDRESS_TEXT);
        addressNode.width(Size.GROW);
        final class_342 addressBox = addressNode.editBox();
        addressBox.method_1890(SerialInterfaceCardScreen::isNumber);
        addressBox.method_1852(Integer.toString(SerialInterfaceCardItem.getAddress(getCard())));
        addressBox.method_1863(value -> sendAddress(addressBox, value));
        return new Node[]{
            Ui.field(ADDRESS_TEXT, addressNode)
        };
    }

    @Override
    protected boolean getConfiguration(final class_2350 side) {
        return SerialInterfaceCardItem.getSideConfiguration(getCard(), side);
    }

    @Override
    protected void sendConfiguration(final class_2350 side, final boolean value) {
        SerialInterfaceCardItem.setSideConfiguration(getCard(), side, value);
        Network.sendToServer(new SerialInterfaceCardConfigurationMessage(hand, getCard()));
    }

    // --------------------------------------------------------------------- //

    private static boolean isNumber(final String value) {
        return value.chars().allMatch(Character::isDigit);
    }

    private class_1799 getCard() {
        return player.method_5998(hand);
    }

    private void sendAddress(final class_342 addressBox, final String value) {
        if (value.isEmpty()) {
            return;
        }

        if (GuiUtils.clampToRange(addressBox, 0, SerialFrame.MAX_ADDRESS)) {
            return; // setting the value calls this again
        }

        final int address = Integer.parseInt(value);
        if (address != SerialInterfaceCardItem.getAddress(getCard())) {
            SerialInterfaceCardItem.setAddress(getCard(), address);
            Network.sendToServer(new SerialInterfaceCardConfigurationMessage(hand, getCard()));
        }
    }
}
