/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.common.vm.device.Terminal;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class TerminalOverlayRenderer {
    // From the pose instead of world positions, so it also works for blocks on moving contraptions for example.
    public static class_243 getCameraOffset(final class_4587 stack) {
        final Vector3f camera = new Matrix4f(stack.method_23760().method_23761()).invertAffine().transformPosition(new Vector3f());
        return new class_243(camera.x() - 0.5, camera.y() - 0.5, camera.z() - 0.5);
    }

    public static void renderTerminal(final Terminal terminal, final class_4587 stack, final class_4597 bufferSource, final class_243 cameraOffset) {
        // Render terminal content if close enough.
        if (cameraOffset.method_1027() < 6 * 6) {
            stack.method_22903();
            stack.method_46416(2, 2, -0.9f);

            // Scale to make terminal fit fully.
            final float textScaleX = 12f / terminal.getWidth();
            final float textScaleY = 7f / terminal.getHeight();
            final float scale = Math.min(textScaleX, textScaleY) * 0.95f;

            // Center it on both axes.
            final float scaleDeltaX = textScaleX - scale;
            final float scaleDeltaY = textScaleY - scale;
            stack.method_46416(
                terminal.getWidth() * scaleDeltaX * 0.5f,
                terminal.getHeight() * scaleDeltaY * 0.5f,
                0f);

            stack.method_22905(scale, scale, 1f);

            TerminalTextures.get(terminal).draw(stack);

            stack.method_22909();
        } else {
            stack.method_22903();
            stack.method_46416(0, 0, -0.9f);

            Overlays.renderTerminal(stack.method_23760().method_23761(), bufferSource);

            stack.method_22909();
        }
    }
}
