/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.ModBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import javax.annotation.Nullable;

public final class TransposerBlock extends class_2248 implements class_2343 {
    public TransposerBlock() {
        super(class_2251.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9629(1.5f, 6.0f));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9536(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2680 newState, final boolean movedByPiston) {
        ModBlockEntity.markDestroyed(level, pos, state, newState, movedByPiston);
        super.method_9536(state, level, pos, newState, movedByPiston);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.TRANSPOSER.get().method_11032(pos, state);
    }
}
