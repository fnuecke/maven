/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.entity;

import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.client.renderer.Overlays;
import li.cil.oc2.client.renderer.entity.model.RobotModel;
import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class RobotRenderer extends class_897<Robot> {
    private static final Vector3f GLOW_COLOR = new Vector3f(0.16f, 0.43f, 0.45f);
    private static final Vector3f GLOW_COLOR_BRIGHT = new Vector3f(0.35f, 0.95f, 1f);

    private static final class_238 GLOW_BOUNDS = new class_238(-6.25 / 16.0, 7 / 16.0, -6.25 / 16.0, 6.25 / 16.0, 8 / 16.0, 6.25 / 16.0);

    private static final float STATUS_INNER_X = 2 / 16f;
    private static final float STATUS_OUTER_X = 4 / 16f;
    private static final float STATUS_Y = 10 / 16f;
    private static final float STATUS_HEIGHT = 1 / 16f;
    private static final float STATUS_Z = 7 / 16f;

    private final RobotModel model;

    // --------------------------------------------------------------------- //

    public RobotRenderer(final class_5617.class_5618 context) {
        super(context);
        model = new RobotModel(context.method_32167(RobotModel.ROBOT_MODEL_LAYER));
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2960 getTextureLocation(final Robot entity) {
        return RobotModel.ROBOT_ENTITY_TEXTURE;
    }

    @Override
    public void render(final Robot entity, final float entityYaw, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int packedLight) {
        final Robot.AnimationState state = entity.getAnimationState();
        final long gameTime = entity.method_37908().method_8510();
        final float time = gameTime + partialTicks;
        float deltaTime = class_310.method_1551().method_60646().method_60636();
        state.update(time, deltaTime, entity.method_37908().field_9229);

        stack.method_22903();
        // NB: we don't entityYaw given to use because that uses a plain lerp which can lead to ugly
        //     jumps in case we get a wrapped rotationYaw synced from the server (leading to ~360
        //     degree delta to the last known previous rotation). Haven't figured out where to
        //     alternatively prevent this wrapping or patch the prev value instead.
        final float partialRotation = class_3532.method_15356(entity.field_5982, entity.method_36454()) * partialTicks;
        final float rotation = class_3532.method_15388(entity.field_5982, entity.method_36454(), partialRotation);
        stack.method_22907(class_7833.field_40715.rotationDegrees(rotation));

        model.setupAnim(entity, 0, 0, 0, 0, 0);

        final class_4588 consumer = bufferSource.getBuffer(model.method_23500(getTextureLocation(entity)));
        model.method_2828(stack, consumer, packedLight, class_4608.field_21444, 0xFFFFFFFF);

        if (entity.getVirtualMachine().isRunning()) {
            stack.method_22903();
            model.applyTopTransform(stack);
            renderStatusLights(stack, bufferSource, entity.getStatusColor(), entity.getStatusValue());
            stack.method_22909();
        }

        if (state.topRenderOffsetY > Robot.AnimationState.TOP_IDLE_Y) {
            stack.method_46416(0, state.baseRenderOffsetY, 0);
            Overlays.renderBox(ModRenderType.getGlow(), stack, bufferSource, GLOW_BOUNDS, GLOW_COLOR, GLOW_COLOR_BRIGHT, gameTime, partialTicks);
        }

        stack.method_22909();
    }

    // --------------------------------------------------------------------- //

    private static void renderStatusLights(final class_4587 stack, final class_4597 bufferSource, final int color, final float value) {
        if (value <= 0) {
            return;
        }

        final float r = (color >>> 16) / 255f;
        final float g = ((color >>> 8) & 0xFF) / 255f;
        final float b = (color & 0xFF) / 255f;

        final class_4588 consumer = bufferSource.getBuffer(ModRenderType.getIndicator());
        final Matrix4f matrix = stack.method_23760().method_23761();
        final float top = STATUS_Y + STATUS_HEIGHT * value;
        addQuad(matrix, consumer, -STATUS_OUTER_X, -STATUS_INNER_X, top, r, g, b);
        addQuad(matrix, consumer, STATUS_INNER_X, STATUS_OUTER_X, top, r, g, b);
    }

    private static void addQuad(final Matrix4f matrix, final class_4588 consumer, final float x0, final float x1, final float y1, final float r, final float g, final float b) {
        addVertex(matrix, consumer, x0, STATUS_Y, r, g, b);
        addVertex(matrix, consumer, x1, STATUS_Y, r, g, b);
        addVertex(matrix, consumer, x1, y1, r, g, b);
        addVertex(matrix, consumer, x0, y1, r, g, b);
    }

    private static void addVertex(final Matrix4f matrix, final class_4588 consumer, final float x, final float y, final float r, final float g, final float b) {
        consumer.method_22918(matrix, x, y, STATUS_Z).method_22915(r, g, b, 1f);
    }
}
