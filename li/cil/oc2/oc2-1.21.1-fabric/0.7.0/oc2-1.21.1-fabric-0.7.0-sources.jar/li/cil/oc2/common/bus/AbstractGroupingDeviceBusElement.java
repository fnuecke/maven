/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus;

import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import li.cil.oc2.api.bus.DeviceBusController;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.common.util.NBTTagIds;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import java.util.*;

public abstract class AbstractGroupingDeviceBusElement<TEntry extends AbstractGroupingDeviceBusElement.Entry> extends AbstractDeviceBusElement {
    private static final String GROUPS_TAG_NAME = "groups";
    private static final String GROUP_ID_TAG_NAME = "groupId";
    private static final String GROUP_DATA_TAG_NAME = "groupData";

    protected interface Entry {
        Optional<String> getDeviceDataKey();

        OptionalInt getDeviceEnergyConsumption();

        Device getDevice();
    }

    // --------------------------------------------------------------------- //

    protected final int groupCount;
    protected final ArrayList<HashSet<TEntry>> groups;
    private final Object2IntOpenHashMap<Device> deviceGroups = new Object2IntOpenHashMap<>();

    // --------------------------------------------------------------------- //

    protected final UUID[] groupIds;
    protected final class_2487[] groupData;

    // --------------------------------------------------------------------- //

    protected AbstractGroupingDeviceBusElement(final int groupCount) {
        this.groupCount = groupCount;
        this.groups = new ArrayList<>(groupCount);
        this.groupIds = new UUID[groupCount];
        this.groupData = new class_2487[groupCount];

        deviceGroups.defaultReturnValue(-1);

        for (int i = 0; i < groupCount; i++) {
            groups.add(new HashSet<>());
            groupIds[i] = UUID.randomUUID();
            groupData[i] = new class_2487();
        }
    }

    // --------------------------------------------------------------------- //

    public class_2487 save() {
        if (groups.stream().anyMatch(group -> !group.isEmpty())) {
            onSaving();
        }

        final class_2499 listTag = new class_2499();
        for (int i = 0; i < groupCount; i++) {
            saveGroup(i);

            final class_2487 sideTag = new class_2487();

            sideTag.method_25927(GROUP_ID_TAG_NAME, groupIds[i]);
            sideTag.method_10566(GROUP_DATA_TAG_NAME, groupData[i]);

            listTag.add(sideTag);
        }

        final class_2487 tag = new class_2487();
        tag.method_10566(GROUPS_TAG_NAME, listTag);
        return tag;
    }

    public void load(final class_2487 tag) {
        final class_2499 listTag = tag.method_10554(GROUPS_TAG_NAME, NBTTagIds.TAG_COMPOUND);

        final int count = Math.min(groupCount, listTag.size());
        for (int i = 0; i < count; i++) {
            final class_2487 sideTag = listTag.method_10602(i);

            if (sideTag.method_25928(GROUP_ID_TAG_NAME)) {
                groupIds[i] = sideTag.method_25926(GROUP_ID_TAG_NAME);
            }
            if (sideTag.method_10573(GROUP_DATA_TAG_NAME, NBTTagIds.TAG_COMPOUND)) {
                groupData[i] = sideTag.method_10562(GROUP_DATA_TAG_NAME);
            }

            // Immediately load data into devices, if we already have some.
            for (final TEntry entry : groups.get(i)) {
                final class_2487 devicesTag = groupData[i];
                entry.getDeviceDataKey().ifPresent(key -> {
                    if (devicesTag.method_10573(key, NBTTagIds.TAG_COMPOUND)) {
                        entry.getDevice().deserializeNBT(devicesTag.method_10562(key));
                    }
                });
            }
        }
    }

    @Override
    public Optional<UUID> getDeviceIdentifier(final Device device) {
        final int index = deviceGroups.getInt(device);
        if (index >= 0) {
            return Optional.of(groupIds[index]);
        }
        return super.getDeviceIdentifier(device);
    }

    // --------------------------------------------------------------------- //

    protected final void setEntriesForGroupUnloaded(final int index) {
        final HashSet<TEntry> oldEntries = groups.get(index);
        if (oldEntries.isEmpty()) {
            return;
        }

        onSaving();
        saveGroup(index);

        for (final TEntry entry : oldEntries) {
            devices.removeInt(entry.getDevice());
            deviceGroups.removeInt(entry.getDevice());
            onEntryRemoved(entry);
        }

        oldEntries.clear();

        scanDevices();
    }

    protected final void setEntriesForGroup(final int index, final Set<TEntry> newEntries) {
        final HashSet<TEntry> entries = groups.get(index);
        if (Objects.equals(newEntries, entries)) {
            if (entries.isEmpty()) {
                groupData[index].method_10541().clear();
            }

            return;
        }

        final boolean hadOldEntries = !entries.isEmpty();

        final HashSet<TEntry> removedEntries = new HashSet<>(entries);
        removedEntries.removeAll(newEntries);
        for (final TEntry entry : removedEntries) {
            devices.removeInt(entry.getDevice());
            deviceGroups.removeInt(entry.getDevice());
            onEntryRemoved(entry);
        }

        final HashSet<TEntry> addedEntries = new HashSet<>(newEntries);
        addedEntries.removeAll(entries);
        for (final TEntry entry : addedEntries) {
            devices.put(entry.getDevice(), entry.getDeviceEnergyConsumption().orElse(0));
            deviceGroups.put(entry.getDevice(), index);
            onEntryAdded(entry);
        }

        entries.removeAll(removedEntries);
        entries.addAll(newEntries);

        // Remove serialized data for devices that were present before, but are gone now.
        final class_2487 devicesTag = groupData[index];
        for (final TEntry entry : removedEntries) {
            entry.getDeviceDataKey().ifPresent(devicesTag::method_10551);
        }

        // Deserialize data for found devices, if we have existing data for them. Also collect
        // the list of serialized data we have for devices that have gone missing without being
        // explicitly removed. This can happen if a device is removed while the bus element is
        // unloaded.
        final HashSet<String> invalidDataKeys = new HashSet<>(devicesTag.method_10541());
        for (final TEntry entry : addedEntries) {
            entry.getDeviceDataKey().ifPresent(key -> {
                invalidDataKeys.remove(key);
                if (devicesTag.method_10573(key, NBTTagIds.TAG_COMPOUND)) {
                    entry.getDevice().deserializeNBT(devicesTag.method_10562(key));
                } else {
                    devicesTag.method_10551(key);
                }
            });
        }

        invalidDataKeys.forEach(devicesTag::method_10551);

        // Assign a new ID to this side when the device configuration changes. Avoids confusion when
        // providing a different device to an interface when some running use programs in the VM may
        // still hold a reference to the old one. We consider "changing" anything that removes some
        // devices or adds new devices to an *existing* device set.
        if (hadOldEntries) {
            groupIds[index] = UUID.randomUUID();
        }

        // Trigger a device update on the controller, if we have one. This gives adapters a chance
        // to unmount old devices before we call dispose on them in the next step. If we don't
        // have a controller, devices must already be unmounted (either not mounted in this lifetime,
        // or controller unmounted them when it was removed).
        scanDevices();

        for (final TEntry entry : removedEntries) {
            entry.getDevice().dispose();
        }
    }

    protected void onEntryAdded(final TEntry entry) {
    }

    protected void onEntryRemoved(final TEntry entry) {
    }

    // --------------------------------------------------------------------- //

    private void onSaving() {
        for (final DeviceBusController controller : controllers) {
            if (controller instanceof final CommonDeviceBusController commonController) {
                commonController.onSaving();
            }
        }
    }

    private void saveGroup(final int index) {
        // We merge into what's already present instead of replacing it, because we might be saving
        // before we had a chance to do a full scan (something triggered a chunk save immediately
        // after its load for example). In that case we might end up dropping saved data here, which
        // would then be missing on the next load+scan. Any stale data we accumulate this way will
        // be cleaned up in the next controller scan.
        final class_2487 devicesTag = groupData[index];
        for (final TEntry entry : groups.get(index)) {
            entry.getDeviceDataKey().ifPresent(key ->
                // Always store, even if the data is empty, so we know a device by this provider existed.
                devicesTag.method_10566(key, entry.getDevice().serializeNBT()));
        }
    }
}
