/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.client.gui.TerminalConfigurationScreen;
import li.cil.oc2.client.gui.TerminalScreen;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.TerminalBlockEntity;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import li.cil.oc2.common.integration.Wrenches;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9062;
import javax.annotation.Nullable;

public final class TerminalBlock extends OrientableBlock implements class_2343 {
    public static final MapCodec<TerminalBlock> CODEC = MapCodec.unit(TerminalBlock::new);

    // --------------------------------------------------------------------- //

    public TerminalBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f), class_2350.field_11043, 6);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected MapCodec<? extends TerminalBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected class_9062 method_55765(final class_1799 stack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (Wrenches.isWrench(stack) && blockEntity instanceof final TerminalBlockEntity terminal) {
            if (player.method_5715()) {
                return class_9062.field_47732;
            }

            if (level.method_8608()) {
                openConfigurationScreen(terminal);
            }

            return class_9062.method_55644(level.method_8608());
        }

        return super.method_55765(stack, state, level, pos, player, hand, hit);
    }

    @Override
    protected class_1269 method_55766(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final TerminalBlockEntity terminal) {
            if (level.method_8608()) {
                openTerminalScreen(terminal);
            }

            return class_1269.method_29236(level.method_8608());
        }

        return super.method_55766(state, level, pos, player, hit);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.TERMINAL.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createServerTicker(level, type, BlockEntities.TERMINAL.get());
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    private static void openTerminalScreen(final TerminalBlockEntity terminal) {
        class_310.method_1551().method_1507(new TerminalScreen(terminal));
    }

    @Environment(EnvType.CLIENT)
    private static void openConfigurationScreen(final TerminalBlockEntity terminal) {
        class_310.method_1551().method_1507(new TerminalConfigurationScreen(terminal));
    }

}
