/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui.widget;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.client.gui.util.TooltipRenderer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4264;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static java.util.Collections.emptyList;
import static li.cil.oc2.common.util.TextFormatUtils.withFormat;

public abstract class ImageButton extends class_4264 {
    private static final long PRESS_DURATION = 200;
    private static final long TOOLTIP_DELAY = 250;

    // --------------------------------------------------------------------- //

    private final Background baseImage;
    private final Background pressedImage;
    private List<class_2561> tooltip = emptyList();
    private long lastPressedAt;
    private long hoveringStartedAt;

    // --------------------------------------------------------------------- //

    protected ImageButton(final int x, final int y, final int width, final int height, final Sprite baseImage, final Sprite pressedImage) {
        this(x, y, width, height,
            (graphics, bx, by, bw, bh) -> baseImage.draw(graphics, bx, by),
            (graphics, bx, by, bw, bh) -> pressedImage.draw(graphics, bx, by));
    }

    protected ImageButton(final int x, final int y, final int width, final int height, final NineSliceSprite baseImage, final NineSliceSprite pressedImage) {
        this(x, y, width, height, baseImage::draw, pressedImage::draw);
    }

    private ImageButton(final int x, final int y, final int width, final int height, final Background baseImage, final Background pressedImage) {
        super(x, y, width, height, class_5244.field_39003);
        this.baseImage = baseImage;
        this.pressedImage = pressedImage;
    }

    // --------------------------------------------------------------------- //

    public ImageButton withMessage(final class_2561 component) {
        method_25355(component);
        return this;
    }

    public ImageButton withTooltip(final class_2561... components) {
        tooltip = Arrays.asList(components);
        for (int i = 1; i < tooltip.size(); i++) {
            final class_2561 component = tooltip.get(i);
            tooltip.set(i, withFormat(component, class_124.field_1080));
        }
        return this;
    }

    @Override
    public void method_25306() {
        lastPressedAt = System.currentTimeMillis();
    }

    @Override
    protected void method_48579(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        renderBackground(graphics, mouseX, mouseY, partialTicks);

        renderTooltipIfHovered(graphics, mouseX, mouseY);
    }

    private void renderTooltipIfHovered(final class_332 graphics, final int mouseX, final int mouseY) {
        if (tooltip.isEmpty()) {
            return;
        }

        if (method_49606()) {
            if (hoveringStartedAt == 0) {
                hoveringStartedAt = System.currentTimeMillis();
            }

            if ((System.currentTimeMillis() - hoveringStartedAt) > TOOLTIP_DELAY) {
                TooltipRenderer.drawTooltip(graphics, tooltip, mouseX, mouseY, 200);
            }
        } else {
            hoveringStartedAt = 0;
        }
    }

    @Override
    protected void method_47399(final class_6382 element) {
        method_37021(element);
    }

    // --------------------------------------------------------------------- //

    protected void renderBackground(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        RenderSystem.enableDepthTest();

        final boolean isPressed = (System.currentTimeMillis() - lastPressedAt) < PRESS_DURATION;
        (isPressed ? pressedImage : baseImage).draw(graphics, method_46426(), method_46427(), field_22758, field_22759);

        if (!Objects.equals(method_25369(), class_5244.field_39003)) {
            graphics.method_27534(class_310.method_1551().field_1772, method_25369(),
                method_46426() + field_22758 / 2, method_46427() + (field_22759 - 8) / 2,
                (field_22763 ? 0xFFFFFF : 0xA0A0A0) | class_3532.method_15386(field_22765 * 255) << 24);
        }
    }

    // --------------------------------------------------------------------- //

    @FunctionalInterface
    private interface Background {
        void draw(class_332 graphics, int x, int y, int width, int height);
    }
}
