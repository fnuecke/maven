/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.client.renderer.Overlays;
import li.cil.oc2.client.renderer.TerminalOverlayRenderer;
import li.cil.oc2.common.block.OrientableBlock;
import li.cil.oc2.common.blockentity.TerminalBlockEntity;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_824;
import net.minecraft.class_827;

public final class TerminalRenderer implements class_827<TerminalBlockEntity> {
    private final class_824 renderer;

    // --------------------------------------------------------------------- //

    public TerminalRenderer(final class_5614.class_5615 context) {
        this.renderer = context.method_32139();
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final TerminalBlockEntity terminal, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        final class_2680 state = terminal.method_11010();
        final class_2350 blockFacing = state.method_11654(OrientableBlock.FACING);
        final class_243 cameraPosition = renderer.field_4344.method_19331().method_5836(partialTicks);

        final class_243 relativeCameraPosition = cameraPosition.method_1020(class_243.method_24953(terminal.method_11016()));
        final double projectedCameraPosition = relativeCameraPosition.method_1026(class_243.method_24954(blockFacing.method_10163()));
        if (projectedCameraPosition <= 0) {
            return;
        }

        stack.method_22903();

        // Align with front face of block.
        stack.method_46416(0.5f, 0.5f, 0.5f);
        stack.method_22907(class_7833.field_40715.rotationDegrees(OrientableBlock.getRotationY(state)));
        stack.method_22907(class_7833.field_40713.rotationDegrees(OrientableBlock.getRotationX(state)));
        stack.method_46416(-0.5f, -0.5f, -0.5f);

        // Flip and align with top left corner.
        stack.method_46416(1, 1, 0);
        stack.method_22905(-1, -1, -1);

        // Scale to make 1/16th of the block one unit and align with top left of terminal area.
        final float pixelScale = 1 / 16f;
        stack.method_22905(pixelScale, pixelScale, pixelScale);

        stack.method_46416(0, 0, -10f);
        TerminalOverlayRenderer.renderTerminal(terminal.method_11016(), terminal.getTerminal(), stack, bufferSource, cameraPosition);

        stack.method_46416(0, 0, -0.1f);

        if (terminal.isConnected()) {
            Overlays.renderPower(stack.method_23760().method_23761(), bufferSource);
        }

        if (terminal.hasRecentFrameError()) {
            Overlays.renderStatus(stack.method_23760().method_23761(), bufferSource);
        }

        stack.method_22909();
    }
}
