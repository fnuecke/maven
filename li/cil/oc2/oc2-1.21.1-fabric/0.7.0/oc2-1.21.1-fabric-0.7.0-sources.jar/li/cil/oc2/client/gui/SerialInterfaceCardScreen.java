/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.util.GuiUtils;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.item.SerialInterfaceCardItem;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.SerialInterfaceCardConfigurationMessage;
import li.cil.oc2.common.serial.SerialFrame;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import javax.annotation.Nullable;

import static li.cil.oc2.common.util.TranslationUtils.text;

public final class SerialInterfaceCardScreen extends AbstractSideConfigurationScreen {
    private static final class_2561 ADDRESS_TEXT = text("gui.{mod}.serial_interface_card.address");

    private static final int CONTROLS_TOP = 121;
    private static final int CONTROLS_HEIGHT = 16;
    private static final int LABEL_GAP = 5;
    private static final int LABEL_COLOR = 0xAAAAAA;
    private static final int ADDRESS_WIDTH = 38;

    // --------------------------------------------------------------------- //

    private class_342 addressBox;

    // --------------------------------------------------------------------- //

    public SerialInterfaceCardScreen(final class_1657 player, final class_1268 hand) {
        super(player, hand, Items.SERIAL_INTERFACE_CARD.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        addressBox = method_37063(new class_342(field_22793,
            left + addressLeft(), top + CONTROLS_TOP, ADDRESS_WIDTH, CONTROLS_HEIGHT, ADDRESS_TEXT));
        addressBox.method_1890(SerialInterfaceCardScreen::isNumber);
        addressBox.method_1852(Integer.toString(SerialInterfaceCardItem.getAddress(getCard())));
        addressBox.method_1863(this::sendAddress);
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        graphics.method_51439(field_22793, ADDRESS_TEXT, left + labelLeft(),
            top + CONTROLS_TOP + (CONTROLS_HEIGHT - field_22793.field_2000) / 2, LABEL_COLOR, false);
    }

    @Override
    protected boolean getConfiguration(@Nullable final class_2350 side) {
        return side != null && SerialInterfaceCardItem.getSideConfiguration(getCard(), side);
    }

    @Override
    protected void sendConfiguration(final class_2350 side, final boolean value) {
        SerialInterfaceCardItem.setSideConfiguration(getCard(), side, value);
        Network.sendToServer(new SerialInterfaceCardConfigurationMessage(hand, getCard()));
    }

    // --------------------------------------------------------------------- //

    private static boolean isNumber(final String value) {
        return value.chars().allMatch(Character::isDigit);
    }

    private int labelLeft() {
        return (UI_WIDTH - field_22793.method_27525(ADDRESS_TEXT) - LABEL_GAP - ADDRESS_WIDTH) / 2;
    }

    private int addressLeft() {
        return labelLeft() + field_22793.method_27525(ADDRESS_TEXT) + LABEL_GAP;
    }

    private class_1799 getCard() {
        return player.method_5998(hand);
    }

    private void sendAddress(final String value) {
        if (value.isEmpty()) {
            return;
        }

        if (GuiUtils.clampToRange(addressBox, 0, SerialFrame.MAX_ADDRESS)) {
            return; // setting the value calls this again
        }

        final int address = Integer.parseInt(value);
        if (address != SerialInterfaceCardItem.getAddress(getCard())) {
            SerialInterfaceCardItem.setAddress(getCard(), address);
            Network.sendToServer(new SerialInterfaceCardConfigurationMessage(hand, getCard()));
        }
    }
}
