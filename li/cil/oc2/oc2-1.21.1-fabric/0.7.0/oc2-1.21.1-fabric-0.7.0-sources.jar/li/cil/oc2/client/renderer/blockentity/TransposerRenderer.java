/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.api.API;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.common.blockentity.TransposerBlockEntity;
import net.minecraft.class_1723;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import org.joml.Matrix4f;

public final class TransposerRenderer implements class_827<TransposerBlockEntity> {
    private static final class_4730 TOP = material("top");
    private static final class_4730 SIDE = material("side");
    private static final class_4730 BOTTOM = material("bottom");

    private static final float NEAR = 0.5f / 16f;
    private static final float FAR = 15.5f / 16f;

    // --------------------------------------------------------------------- //

    public TransposerRenderer(final class_5614.class_5615 ignoredContext) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final TransposerBlockEntity transposer, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        final Matrix4f matrix = stack.method_23760().method_23761();

        final class_4588 top = TOP.method_24145(bufferSource, ModRenderType::getUnlitBlock);
        quad(matrix, top, 0, FAR, 0, 0, FAR, 1, 1, FAR, 1, 1, FAR, 0);

        final class_4588 bottom = BOTTOM.method_24145(bufferSource, ModRenderType::getUnlitBlock);
        quad(matrix, bottom, 0, NEAR, 0, 0, NEAR, 1, 1, NEAR, 1, 1, NEAR, 0);

        final class_4588 side = SIDE.method_24145(bufferSource, ModRenderType::getUnlitBlock);
        quad(matrix, side, 0, 1, NEAR, 0, 0, NEAR, 1, 0, NEAR, 1, 1, NEAR);
        quad(matrix, side, 0, 1, FAR, 0, 0, FAR, 1, 0, FAR, 1, 1, FAR);
        quad(matrix, side, NEAR, 1, 0, NEAR, 0, 0, NEAR, 0, 1, NEAR, 1, 1);
        quad(matrix, side, FAR, 1, 0, FAR, 0, 0, FAR, 0, 1, FAR, 1, 1);
    }

    // --------------------------------------------------------------------- //

    private static class_4730 material(final String name) {
        return new class_4730(class_1723.field_21668, class_2960.method_60655(API.MOD_ID, "block/transposer/" + name));
    }

    private static void quad(final Matrix4f matrix, final class_4588 consumer,
                             final float x0, final float y0, final float z0,
                             final float x1, final float y1, final float z1,
                             final float x2, final float y2, final float z2,
                             final float x3, final float y3, final float z3) {
        // Not chained: vanilla's SpriteCoordinateExpander.addVertex returns the delegate, so a
        // chained setUv would bypass the sprite remap (NeoForge patches this, Fabric does not).
        consumer.method_22918(matrix, x0, y0, z0);
        consumer.method_22913(0, 0);

        consumer.method_22918(matrix, x1, y1, z1);
        consumer.method_22913(0, 1);

        consumer.method_22918(matrix, x2, y2, z2);
        consumer.method_22913(1, 1);

        consumer.method_22918(matrix, x3, y3, z3);
        consumer.method_22913(1, 0);
    }
}
