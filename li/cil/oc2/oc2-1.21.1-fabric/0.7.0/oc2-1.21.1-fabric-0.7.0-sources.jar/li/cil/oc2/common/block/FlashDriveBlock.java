/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.FlashDriveBlockEntity;
import li.cil.oc2.common.util.BlockPlacement;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import javax.annotation.Nullable;

public final class FlashDriveBlock extends OrientableBlock implements class_2343 {
    public static final MapCodec<FlashDriveBlock> CODEC = MapCodec.unit(FlashDriveBlock::new);

    // --------------------------------------------------------------------- //

    public FlashDriveBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f), class_2350.field_11036, 8);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected MapCodec<? extends FlashDriveBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected class_9062 method_55765(final class_1799 heldStack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final FlashDriveBlockEntity drive) {
            final class_9062 result = drive.useWith(level, heldStack, player, hand);
            if (result != class_9062.field_47731) {
                return result;
            }
        }

        return super.method_55765(heldStack, state, level, pos, player, hand, hit);
    }

    @Override
    protected class_1269 method_55766(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final FlashDriveBlockEntity drive) {
            final class_1269 result = drive.useWithoutItem(level, player);
            if (result != class_1269.field_5811) {
                return result;
            }
        }

        return super.method_55766(state, level, pos, player, hit);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.FLASH_DRIVE.get().method_11032(pos, state);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9536(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2680 newState, final boolean movedByPiston) {
        if (!state.method_27852(newState.method_26204())) {
            final class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof final FlashDriveBlockEntity drive) {
                drive.dropMedia();
            }
        }

        super.method_9536(state, level, pos, newState, movedByPiston);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected BlockPlacement getPlacement(final class_1750 context) {
        return isPlacingOnBusInterface(context) ? BlockPlacement.attached(context) : BlockPlacement.free(context);
    }

    // --------------------------------------------------------------------- //

    private static boolean isPlacingOnBusInterface(final class_1750 context) {
        final class_2350 clicked = context.method_8038();
        final class_2680 state = context.method_8045().method_8320(context.method_8037().method_10093(clicked.method_10153()));
        return state.method_26204() instanceof BusCableBlock
            && BusCableBlock.getConnectionType(state, clicked) == BusCableBlock.ConnectionType.INTERFACE;
    }

}
