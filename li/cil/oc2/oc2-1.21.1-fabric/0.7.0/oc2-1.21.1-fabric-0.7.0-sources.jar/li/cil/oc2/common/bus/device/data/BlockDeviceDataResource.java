/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import net.minecraft.class_2960;

public interface BlockDeviceDataResource extends BlockDeviceData {
    class_2960 getLocation();
}
