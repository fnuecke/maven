/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import li.cil.sedna.api.device.BlockDevice;
import net.minecraft.class_1767;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import javax.annotation.Nullable;

public final class BlockDeviceDataClientView implements BlockDeviceDataResource {
    private final class_2960 location;
    private final long capacity;
    private final class_2561 displayName;
    @Nullable
    private final class_1767 color;

    public BlockDeviceDataClientView(final class_2960 location, final long capacity, final class_2561 displayName, @Nullable final class_1767 color) {
        this.location = location;
        this.capacity = capacity;
        this.displayName = displayName;
        this.color = color;
    }

    @Override
    public class_2960 getLocation() {
        return location;
    }

    @Override
    public BlockDevice getBlockDevice() {
        throw new IllegalStateException("The contents of [" + location + "] are only available on the server.");
    }

    @Override
    public long getCapacity() {
        return capacity;
    }

    @Override
    public class_2561 getDisplayName() {
        return displayName;
    }

    @Nullable
    @Override
    public class_1767 getColor() {
        return color;
    }
}
