/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.fabric;

import li.cil.oc2.client.renderer.BusInterfaceNameRenderer;
import li.cil.oc2.client.renderer.NetworkCableRenderer;
import li.cil.oc2.client.renderer.ProjectorDepthRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public final class ClientRenderEventsFabric {
    public static void initialize() {
        WorldRenderEvents.BEFORE_ENTITIES.register(context ->
            NetworkCableRenderer.render(context.camera(), context.positionMatrix(), context.frustum()));

        WorldRenderEvents.AFTER_TRANSLUCENT.register(context ->
            BusInterfaceNameRenderer.INSTANCE.render(context.matrixStack()));

        WorldRenderEvents.LAST.register(context ->
            ProjectorDepthRenderer.onAfterParticles(context.positionMatrix(), context.projectionMatrix()));
    }

    private ClientRenderEventsFabric() {
    }
}
