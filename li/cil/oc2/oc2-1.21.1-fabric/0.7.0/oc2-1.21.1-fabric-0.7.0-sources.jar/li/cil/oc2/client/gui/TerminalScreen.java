/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.client.gui.widget.ImageButton;
import li.cil.oc2.client.gui.widget.ToggleImageButton;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.TerminalBlockEntity;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.TerminalInputMessage;
import li.cil.oc2.common.network.message.TerminalKeepAliveMessage;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import java.nio.ByteBuffer;

public final class TerminalScreen extends AbstractBlockEntityScreen<TerminalBlockEntity> {
    private final TerminalWidget terminalWidget;

    private long lastKeepAliveSentAt;

    // --------------------------------------------------------------------- //

    public TerminalScreen(final TerminalBlockEntity terminal) {
        super(Items.TERMINAL.get().method_7848(), terminal);
        this.terminalWidget = new TerminalWidget(new TerminalWidget.Parent() {
            @Override
            public int getWidth() {
                return field_22789;
            }

            @Override
            public int getHeight() {
                return field_22790;
            }

            @Override
            public boolean shouldRenderTerminal() {
                return true;
            }

            @Override
            public void sendTerminalInputToServer(ByteBuffer input) {
                Network.sendToServer(new TerminalInputMessage(blockEntity, input));
            }
        }, terminal.getTerminal());
        imageWidth = Sprites.TERMINAL_SCREEN.width;
        imageHeight = Sprites.TERMINAL_SCREEN.height;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void safeTick() {
        super.safeTick();

        sendKeepAlive();

        terminalWidget.tick();
    }

    @Override
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        return terminalWidget.mouseClicked(mouseX, mouseY, button) ||
            super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(final double mouseX, final double mouseY, final int button) {
        return terminalWidget.mouseReleased(mouseX, mouseY, button) ||
            super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(final double mouseX, final double mouseY, final double deltaX, final double deltaY) {
        return terminalWidget.mouseScrolled(mouseX, mouseY, deltaY) ||
            super.method_25401(mouseX, mouseY, deltaX, deltaY);
    }

    @Override
    public boolean method_25400(final char ch, final int modifiers) {
        return terminalWidget.charTyped(ch, modifiers) ||
            super.method_25400(ch, modifiers);
    }

    @Override
    public boolean method_25404(final int keyCode, final int scanCode, final int modifiers) {
        return terminalWidget.keyPressed(keyCode, scanCode, modifiers) ||
            super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        terminalWidget.init();

        method_37063(new ToggleImageButton(
            leftPos - Sprites.SIDEBAR_2.width + 4, topPos + CONTROLS_TOP + 4,
            12, 12,
            Sprites.INPUT_BUTTON_BASE,
            Sprites.INPUT_BUTTON_PRESSED,
            Sprites.INPUT_BUTTON_ACTIVE
        ) {
            @Override
            public void method_25306() {
                super.method_25306();
                InputCapture.toggle();
            }

            @Override
            public boolean isToggled() {
                return InputCapture.isEnabled();
            }
        }).withTooltip(
            class_2561.method_43471(Constants.TERMINAL_CAPTURE_INPUT_CAPTION),
            class_2561.method_43471(Constants.TERMINAL_CAPTURE_INPUT_DESCRIPTION)
        );

        method_37063(new ImageButton(
            leftPos - Sprites.SIDEBAR_2.width + 4, topPos + CONTROLS_TOP + 4 + 14,
            12, 12,
            Sprites.CONFIG_BUTTON_INACTIVE,
            Sprites.CONFIG_BUTTON_ACTIVE
        ) {
            @Override
            public void method_25306() {
                field_22787.method_1507(new TerminalConfigurationScreen(blockEntity));
            }
        }).withTooltip(class_2561.method_43471(Constants.OPEN_CONFIGURATION_CAPTION));
    }

    @Override
    public void method_25432() {
        super.method_25432();
        terminalWidget.onClose();
    }

    // --------------------------------------------------------------------- //

    @Override
    public void renderFg(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        terminalWidget.render(graphics, mouseX, mouseY, null);
    }

    @Override
    public void renderBg(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        Sprites.SIDEBAR_2.draw(graphics, leftPos - Sprites.SIDEBAR_2.width, topPos + CONTROLS_TOP);

        terminalWidget.renderBackground(graphics, mouseX, mouseY);
    }

    // --------------------------------------------------------------------- //

    private void sendKeepAlive() {
        final long now = System.currentTimeMillis();
        if (now - lastKeepAliveSentAt > TerminalBlockEntity.CLIENT_KEEPALIVE_EVERY_MILLIS) {
            lastKeepAliveSentAt = now;
            Network.sendToServer(new TerminalKeepAliveMessage(blockEntity));
        }
    }
}
