/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.Config;
import li.cil.oc2.common.block.ProjectorBlock;
import li.cil.oc2.common.bus.device.vm.block.ProjectorDevice;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.energy.FixedEnergyStorage;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.ProjectorLoadBalancer;
import li.cil.oc2.common.network.message.ProjectorRequestFramebufferMessage;
import li.cil.oc2.common.network.message.ProjectorStateMessage;
import li.cil.oc2.jcodec.codecs.h264.H264Decoder;
import li.cil.oc2.jcodec.codecs.h264.H264Encoder;
import li.cil.oc2.jcodec.codecs.h264.encode.CQPRateControl;
import li.cil.oc2.jcodec.common.model.ColorSpace;
import li.cil.oc2.jcodec.common.model.Picture;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_4076;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public final class ProjectorBlockEntity extends ModBlockEntity implements TickableBlockEntity {
    @FunctionalInterface
    public interface FrameConsumer {
        void processFrame(final Picture picture);
    }

    public interface FrameSupplier {
        /**
         * Gets and resets the keyframe flag, to be passed to {@link #encode(boolean)}.
         * <p>
         * Separate so this can run on the server thread whereas encoding runs on a worker thread.
         *
         * @return whether the next encode should be a keyframe.
         */
        boolean consumeRequiresKeyframe();

        /**
         * Encodes the frame to send.
         *
         * @param forceKeyframe whether the frame must be decodable on its own.
         * @return the encoded frame, or {@code null} if there is nothing to send.
         */
        @Nullable
        byte[] encode(boolean forceKeyframe);
    }

    // --------------------------------------------------------------------- //

    public static final int MAX_FRAME_SIZE = 1024 * 1024;
    public static final int MAX_RENDER_DISTANCE = 16;
    public static final int MAX_WATCH_DISTANCE = 64; // Default max block entity render distance.
    public static final int MAX_GOOD_RENDER_DISTANCE = 12;
    public static final int MAX_WIDTH = MAX_GOOD_RENDER_DISTANCE + 1; // +1 To make it odd, so we can center.
    public static final int MAX_HEIGHT = (MAX_GOOD_RENDER_DISTANCE * ProjectorDevice.HEIGHT / ProjectorDevice.WIDTH) + 1; // + 1 To match horizontal margin.

    private static final String ENERGY_TAG_NAME = "energy";
    private static final String IS_PROJECTING_TAG_NAME = "projecting";
    private static final String HAS_ENERGY_TAG_NAME = "has_energy";

    private static final ExecutorService DECODER_WORKERS = Executors.newCachedThreadPool(r -> {
        final Thread thread = new Thread(r);
        thread.setDaemon(true);
        thread.setName("Projector Frame Decoder");
        return thread;
    });

    // --------------------------------------------------------------------- //

    private final ProjectorDevice projectorDevice = new ProjectorDevice(this, this::handleMountedChanged);
    private boolean isMounted, hasEnergy;
    private final FixedEnergyStorage energy = new FixedEnergyStorage(Config.projectorEnergyStorage);
    private final Picture picture = Picture.create(ProjectorDevice.WIDTH, ProjectorDevice.HEIGHT, ColorSpace.YUV420J);

    // Video encoding.
    private final H264Encoder encoder = new H264Encoder(new CQPRateControl(12));
    private final ByteBuffer encoderBuffer = ByteBuffer.allocateDirect(MAX_FRAME_SIZE); // Re-used compression buffer.
    private final ByteBuffer compressedBuffer = ByteBuffer.allocateDirect(MAX_FRAME_SIZE); // Re-used compression buffer.
    private final Deflater deflater = new Deflater(Deflater.BEST_COMPRESSION); // Re-used, native memory.
    private boolean needsIDR; // Whether we need to send a keyframe next.
    private final FrameSupplierImpl frameSupplier = new FrameSupplierImpl(); // Limited interface for load balancer.

    // Video decoding.
    private final H264Decoder decoder = new H264Decoder();
    @Nullable
    private CompletableFuture<?> runningDecode; // Current decoding operation, if any, to avoid race conditions.
    private final ByteBuffer decoderBuffer = ByteBuffer.allocateDirect(MAX_FRAME_SIZE); // Re-used decompression buffer.
    private final Inflater inflater = new Inflater(); // Re-used, native memory.
    @Nullable
    private FrameConsumer frameConsumer; // Where to throw received frames.

    private class_238 renderBounds; // Maximum possible render bounds, assuming we project on furthest away surface.
    private long lastKeepAliveSentAt;

    // --------------------------------------------------------------------- //

    public ProjectorBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.PROJECTOR.get(), pos, state);

        encoder.setKeyInterval(100);

        updateRenderBounds();
    }

    // --------------------------------------------------------------------- //

    public boolean isProjecting() {
        if (!isMounted || field_11863 == null) {
            return false;
        }

        final class_2350 facing = method_11010().method_11654(ProjectorBlock.field_11177);
        final class_2338 neighborPos = method_11016().method_10093(facing);
        final int neighborChunkX = class_4076.method_18675(neighborPos.method_10263());
        final int neighborChunkZ = class_4076.method_18675(neighborPos.method_10260());
        if (!field_11863.method_8393(neighborChunkX, neighborChunkZ)) {
            return false;
        }

        final class_2680 neighborBlockState = field_11863.method_8320(neighborPos);
        return !neighborBlockState.method_26216(field_11863, neighborPos);
    }

    public boolean hasEnergy() {
        return hasEnergy;
    }

    public void setRequiresKeyframe() {
        needsIDR = true;
    }

    public void setFrameConsumer(@Nullable final FrameConsumer consumer) {
        if (consumer == frameConsumer) {
            return;
        }
        synchronized (picture) {
            this.frameConsumer = consumer;
            if (frameConsumer != null) {
                frameConsumer.processFrame(picture);
            }
        }
    }

    public void onRendering() {
        final long now = System.currentTimeMillis();
        if (now - lastKeepAliveSentAt > 1000) {
            lastKeepAliveSentAt = now;
            Network.sendToServer(new ProjectorRequestFramebufferMessage(this));
        }
    }

    @Override
    public void serverTick() {
        if (!isMounted) {
            return;
        }

        final boolean isPowered;
        if (Config.projectorsUseEnergy()) {
            isPowered = energy.extractEnergy(Config.projectorEnergyPerTick, true) >= Config.projectorEnergyPerTick;
            if (isPowered) {
                energy.extractEnergy(Config.projectorEnergyPerTick, false);
            }
        } else {
            isPowered = true;
        }
        updateProjectorState(isMounted, isPowered);

        if (!hasEnergy || (!projectorDevice.hasChanges() && !needsIDR)) {
            return;
        }

        ProjectorLoadBalancer.offerFrame(this, frameSupplier);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);

        tag.method_10556(IS_PROJECTING_TAG_NAME, isMounted);
        tag.method_10556(HAS_ENERGY_TAG_NAME, hasEnergy);

        return tag;
    }


    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10566(ENERGY_TAG_NAME, energy.serializeNBT());
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        energy.deserializeNBT(tag.method_10562(ENERGY_TAG_NAME));

        if (tag.method_10545(IS_PROJECTING_TAG_NAME)) {
            isMounted = tag.method_10577(IS_PROJECTING_TAG_NAME);
        }
        if (tag.method_10545(HAS_ENERGY_TAG_NAME)) {
            hasEnergy = tag.method_10577(HAS_ENERGY_TAG_NAME);
        }
    }

    @Nullable
    @Override
    public class_238 getExpandedRenderBoundingBox() {
        return renderBounds;
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_31664(final class_2680 state) {
        super.method_31664(state);

        updateRenderBounds();
    }

    public void applyProjectorStateClient(final boolean isProjecting, final boolean hasEnergy) {
        if (field_11863 == null || !field_11863.method_8608()) {
            return;
        }

        this.isMounted = isProjecting;
        this.hasEnergy = hasEnergy;
    }

    public void applyNextFrameClient(final byte[] frameData) {
        if (field_11863 == null || !field_11863.method_8608() || !isValid()) {
            return;
        }

        final CompletableFuture<?> lastDecode = runningDecode;
        final CompletableFuture<?> previous = lastDecode != null
            ? lastDecode.exceptionally(unused -> null)
            : CompletableFuture.completedFuture(null);

        runningDecode = previous.thenRunAsync(() -> {
            try {
                inflater.reset();
                inflater.setInput(frameData);

                decoderBuffer.clear();
                inflater.inflate(decoderBuffer);
                decoderBuffer.flip();

                decoder.decodeFrame(decoderBuffer, picture.getData());

                synchronized (picture) {
                    if (frameConsumer != null) {
                        frameConsumer.processFrame(picture);
                    }
                }
            } catch (final DataFormatException ignored) {
            }
        }, DECODER_WORKERS);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void onUnload(final boolean isRemove) {
        super.onUnload(isRemove);

        setFrameConsumer(null); // expected to stay null -> this will no longer be rendered.

        final CompletableFuture<?> decode = runningDecode;
        runningDecode = null; // will stay null because unloaded -> !isValid() in applyNextFrameClient.

        // Await both in-flight codecs if necessary to not kill their native memory while in use.
        final CompletableFuture<?> encode = ProjectorLoadBalancer.stop(this);
        CompletableFuture.allOf(handled(decode), handled(encode))
            .whenComplete((result, error) -> endCodecs());
    }

    private void endCodecs() {
        deflater.end();
        inflater.end();
    }

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        if (Config.projectorsUseEnergy()) {
            collector.offer(Capabilities.ENERGY_STORAGE, energy);
        }

        if (direction == method_11010().method_11654(ProjectorBlock.field_11177).method_10153()) {
            collector.offer(Capabilities.DEVICE, projectorDevice);
        }
    }

    // --------------------------------------------------------------------- //

    private void handleMountedChanged(final boolean value) {
        updateProjectorState(value, hasEnergy);
    }

    private void updateProjectorState(final boolean isMounted, final boolean hasEnergy) {
        if (isMounted == this.isMounted && hasEnergy == this.hasEnergy) {
            return;
        }

        // We may get called from unmount() of our device, which can be triggered due to chunk unload.
        // Hence, we need to check the loaded state here, lest we ghost load the chunk, breaking everything.
        if (field_11863 != null && !field_11863.method_8608() && field_11863.method_8477(method_11016())) {
            if (this.isMounted && !isMounted) {
                Arrays.fill(picture.getPlaneData(0), (byte) -128);
                Arrays.fill(picture.getPlaneData(1), (byte) 0);
                Arrays.fill(picture.getPlaneData(2), (byte) 0);
            }

            this.isMounted = isMounted;
            this.hasEnergy = hasEnergy;

            field_11863.method_8652(method_11016(), method_11010().method_11657(ProjectorBlock.LIT, isMounted), class_2248.field_31028);

            Network.sendToClientsTrackingBlockEntity(new ProjectorStateMessage(this, isMounted, hasEnergy), this);
        }
    }

    private static CompletableFuture<?> handled(@Nullable final CompletableFuture<?> future) {
        return future == null ? CompletableFuture.completedFuture(null) : future.handle((result, error) -> null);
    }

    private final class FrameSupplierImpl implements FrameSupplier {
        @Override
        public boolean consumeRequiresKeyframe() {
            final boolean result = needsIDR;
            needsIDR = false;
            return result;
        }

        @Override
        @Nullable
        public byte[] encode(final boolean forceKeyframe) {
            final boolean hasChanges = projectorDevice.applyChanges(picture);
            if (!hasChanges && !forceKeyframe) {
                return null;
            }

            encoderBuffer.clear();
            final ByteBuffer frameData;
            try {
                if (forceKeyframe) {
                    frameData = encoder.encodeIDRFrame(picture, encoderBuffer);
                } else {
                    frameData = encoder.encodeFrame(picture, encoderBuffer).data();
                }
            } catch (final BufferOverflowException ignored) {
                return null;
            }

            deflater.reset();
            deflater.setInput(frameData);
            deflater.finish();

            compressedBuffer.clear();
            deflater.deflate(compressedBuffer, Deflater.FULL_FLUSH);
            compressedBuffer.flip();

            final byte[] compressedFrameData = new byte[compressedBuffer.remaining()];
            compressedBuffer.get(compressedFrameData);

            return compressedFrameData;
        }
    }

    private void updateRenderBounds() {
        final class_2350 blockFacing = method_11010().method_11654(ProjectorBlock.field_11177);
        final class_2350 canvasUp = class_2350.field_11036;
        final class_2350 canvasLeft = blockFacing.method_10160();

        final class_2338 projectorPos = method_11016();
        final class_2338 screenBasePos = projectorPos.method_10079(blockFacing, MAX_RENDER_DISTANCE);
        final class_2338 screenMinPos = screenBasePos.method_10079(canvasLeft.method_10153(), MAX_WIDTH / 2);
        final class_2338 screenMaxPos = screenBasePos.method_10079(canvasLeft, MAX_WIDTH / 2)
            // -1 for the MAX_HEIGHT padding, -1 for auto-expansion of AABB constructor
            .method_10079(canvasUp, MAX_HEIGHT - 2);

        renderBounds = new class_238(method_11016()).method_991(new class_238(screenMinPos)).method_991(new class_238(screenMaxPos));
    }
}
