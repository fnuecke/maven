/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import li.cil.sedna.api.device.BlockDevice;
import li.cil.sedna.device.block.ByteBufferBlockDevice;
import net.minecraft.class_1767;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import javax.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;

public final class DatapackBlockDeviceData implements BlockDeviceDataResource, AutoCloseable {
    private final class_2960 location;
    private final String name;
    @Nullable
    private final class_1767 color;
    private final BlockDevice blockDevice;

    public DatapackBlockDeviceData(final class_3300 resourceManager, final class_2960 location, final String name, @Nullable final class_1767 color) throws IOException {
        this.location = location;
        this.name = name;
        this.color = color;
        final InputStream stream = resourceManager.getResourceOrThrow(location).method_14482();
        this.blockDevice = ByteBufferBlockDevice.createFromStream(stream, true);
    }

    @Override
    public class_2960 getLocation() {
        return location;
    }

    @Override
    public void close() throws IOException {
        blockDevice.close();
    }

    @Override
    public BlockDevice getBlockDevice() {
        return blockDevice;
    }

    @Override
    public long getCapacity() {
        return blockDevice.getCapacity();
    }

    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_43470(name);
    }

    @Nullable
    @Override
    public class_1767 getColor() {
        return color;
    }
}
