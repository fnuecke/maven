/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.fabric;

import net.minecraft.class_1792;
import net.minecraft.class_2586;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_4604;
import net.minecraft.class_5272;
import net.minecraft.class_6395;
import net.minecraft.class_824;

public final class ClientPlatformImpl {
    private static boolean isHotbarVisible = true;

    public static void setHotbarVisible(final boolean value) {
        isHotbarVisible = value;
    }

    public static boolean isHotbarVisible() {
        return isHotbarVisible;
    }

    public static boolean isStencilEnabled(final class_276 ignoredTarget) {
        return false;
    }

    public static void enableStencil(final class_276 ignoredTarget) {
    }

    public static boolean isBlockEntityVisible(final class_824 ignoredDispatcher, final class_2586 ignoredBlockEntity, final class_4604 ignoredFrustum) {
        return true;
    }

    public static void registerItemProperty(final class_1792 item, final class_2960 name, final class_6395 property) {
        class_5272.method_27879(item, name, property);
    }

    private ClientPlatformImpl() {
    }
}
