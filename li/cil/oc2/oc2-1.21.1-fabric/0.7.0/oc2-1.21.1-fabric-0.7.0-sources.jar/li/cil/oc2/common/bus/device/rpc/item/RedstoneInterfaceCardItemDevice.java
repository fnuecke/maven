/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.item;

import li.cil.oc2.api.capabilities.RedstoneEmitter;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.rpc.RedstoneInterfaceDevice;
import li.cil.oc2.common.bus.device.util.NeighborChangeListener;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityProvider;
import li.cil.oc2.common.capabilities.CapabilityType;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import javax.annotation.Nullable;

public final class RedstoneInterfaceCardItemDevice extends AbstractItemRPCDevice implements CapabilityProvider, NeighborChangeListener {
    private final RedstoneInterfaceDevice redstoneInterface;
    private final RedstoneEmitter[] capabilities;

    // --------------------------------------------------------------------- //

    public RedstoneInterfaceCardItemDevice(final class_1799 identity, final class_2586 blockEntity) {
        this(identity, new RedstoneInterfaceDevice(blockEntity));
    }

    private RedstoneInterfaceCardItemDevice(final class_1799 identity, final RedstoneInterfaceDevice redstoneInterface) {
        super(identity, redstoneInterface);
        this.redstoneInterface = redstoneInterface;

        capabilities = new RedstoneEmitter[Constants.BLOCK_FACE_COUNT];
        for (int i = 0; i < Constants.BLOCK_FACE_COUNT; i++) {
            final class_2350 direction = class_2350.method_10143(i);
            capabilities[i] = () -> redstoneInterface.getOutput(direction);
        }
    }

    // --------------------------------------------------------------------- //

    @Nullable
    @SuppressWarnings("unchecked")
    @Override
    public <T> T getCapability(final CapabilityType<T> capability, @Nullable final class_2350 side) {
        if (capability == Capabilities.REDSTONE_EMITTER && side != null) {
            return (T) capabilities[side.method_10146()];
        }

        return null;
    }

    @Override
    public void handleNeighborChanged() {
        redstoneInterface.handleNeighborChanged();
    }

    @Override
    public class_2487 serializeNBT() {
        final class_2487 tag = new class_2487();
        redstoneInterface.save(tag);
        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        redstoneInterface.load(tag);
    }
}
