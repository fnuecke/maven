/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.common.bus.device.rpc.RedstoneInterfaceDevice;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.util.HorizontalBlockUtils;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import javax.annotation.Nullable;

public final class RedstoneInterfaceBlockEntity extends ModBlockEntity {
    private final RedstoneInterfaceDevice redstoneInterface = new RedstoneInterfaceDevice(this);
    private final ObjectDevice device = new ObjectDevice(redstoneInterface);

    // --------------------------------------------------------------------- //

    public RedstoneInterfaceBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.REDSTONE_INTERFACE.get(), pos, state);
    }

    public void handleNeighborChanged() {
        redstoneInterface.handleNeighborChanged();
    }

    public int getOutputForDirection(final class_2350 direction) {
        return redstoneInterface.getOutput(HorizontalBlockUtils.toLocal(method_11010(), direction));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        redstoneInterface.save(tag);
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        redstoneInterface.load(tag);
    }

    @Override
    protected void loadServerInLoadedLevel() {
        super.loadServerInLoadedLevel();

        redstoneInterface.refreshInputs();
    }

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.DEVICE, device);
    }
}
