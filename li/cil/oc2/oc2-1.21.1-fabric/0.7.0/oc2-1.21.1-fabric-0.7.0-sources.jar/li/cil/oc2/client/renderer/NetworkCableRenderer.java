/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.common.blockentity.NetworkConnectorBlockEntity;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_9801;
import net.minecraft.world.level.*;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.*;
import java.util.function.Predicate;

public final class NetworkCableRenderer {
    private static final int MAX_RENDER_DISTANCE = 100;
    private static final int CABLE_VERTEX_COUNT = 9;
    private static final float CABLE_THICKNESS = 0.025f;
    private static final float CABLE_LENGTH_FOR_MAX_SWING = 6f;
    private static final float CABLE_MAX_SWING_AMOUNT = 0.05f;
    private static final int CABLE_SWING_INTERVAL = 8000;
    private static final float CABLE_HANG_MIN = 0.1f;
    private static final float CABLE_HANG_MAX = 0.5f;
    private static final float CABLE_MAX_LENGTH = 8f;
    private static final Vector3f CABLE_COLOR = new Vector3f(0.0f, 0.33f, 0.4f);
    private static final float WHITE_U = 0.5f, WHITE_V = 0.5f;

    private static final Set<NetworkConnectorBlockEntity> connectors = Collections.newSetFromMap(new WeakHashMap<>());
    private static int lastKnownConnectorCount;
    private static boolean isDirty;

    private static final ArrayList<Connection> connections = new ArrayList<>();

    private static final float[] cableLeft = new float[CABLE_VERTEX_COUNT * 3];
    private static final float[] cableRight = new float[CABLE_VERTEX_COUNT * 3];
    private static final int[] cableLight = new int[CABLE_VERTEX_COUNT];
    private static final class_2338.class_2339 cablePos = new class_2338.class_2339();

    // --------------------------------------------------------------------- //

    public static void addNetworkConnector(final NetworkConnectorBlockEntity connector) {
        connectors.add(connector);
        invalidateConnections();
    }

    public static void invalidateConnections() {
        isDirty = true;
    }

    // --------------------------------------------------------------------- //

    public static void onChunkUnload(final class_1923 chunkPos) {
        removeConnectors(connector -> Objects.equals(new class_1923(connector.method_11016()), chunkPos));
    }

    public static void onLevelUnload(final class_1936 level) {
        removeConnectors(connector -> connector.method_10997() == level);
    }

    public static void render(final class_4184 camera, final Matrix4f modelViewMatrix, final class_4604 frustum) {
        validateConnectors();
        validatePairs();

        if (connections.isEmpty()) {
            return;
        }

        final class_310 client = class_310.method_1551();
        final class_1937 level = client.field_1687;
        if (level == null) {
            return;
        }

        final class_243 eye = camera.method_19326();

        renderCables(level, modelViewMatrix, eye, connections, frustum::method_23093);
    }

    private static void renderCables(final class_1920 level, final Matrix4f viewMatrix, final class_243 eye, final ArrayList<Connection> connections, final Predicate<class_238> filter) {
        final class_1921 renderType = ModRenderType.getNetworkCable();
        final class_287 consumer = class_289.method_1348().method_60827(renderType.method_23033(), renderType.method_23031());

        final float r = CABLE_COLOR.x();
        final float g = CABLE_COLOR.y();
        final float b = CABLE_COLOR.z();

        for (final Connection connection : connections) {
            final class_243 p0 = connection.from;
            final class_243 p1 = connection.to;

            if (!p0.method_24802(eye, MAX_RENDER_DISTANCE) && !p1.method_24802(eye, MAX_RENDER_DISTANCE)) {
                continue;
            }

            // We may easily get false positives here for diagonal cables, but it's good enough for now.
            if (!filter.test(connection.bounds)) {
                continue;
            }

            final class_243 p2 = animateCableSwing(
                lerp(p0, p1, 0.5f).method_1023(0, computeCableHang(p0, p1), 0),
                connection.right,
                computeCableSwingAmount(p0, p1),
                connection.hashCode());

            buildCableOutline(level, eye, connection.forward, p0, p1, p2);

            for (int i = 0; i < CABLE_VERTEX_COUNT - 1; i++) {
                final int i0 = i * 3, i1 = (i + 1) * 3;
                final int light = cableLight[i];

                consumer.method_22918(viewMatrix, cableLeft[i0], cableLeft[i0 + 1], cableLeft[i0 + 2])
                    .method_22915(r, g, b, 1f)
                    .method_22913(WHITE_U, WHITE_V)
                    .method_22922(class_4608.field_21444)
                    .method_60803(light)
                    .method_22914(0, 1, 0);
                consumer.method_22918(viewMatrix, cableRight[i0], cableRight[i0 + 1], cableRight[i0 + 2])
                    .method_22915(r, g, b, 1f)
                    .method_22913(WHITE_U, WHITE_V)
                    .method_22922(class_4608.field_21444)
                    .method_60803(light)
                    .method_22914(0, 1, 0);
                consumer.method_22918(viewMatrix, cableRight[i1], cableRight[i1 + 1], cableRight[i1 + 2])
                    .method_22915(r, g, b, 1f)
                    .method_22913(WHITE_U, WHITE_V)
                    .method_22922(class_4608.field_21444)
                    .method_60803(light)
                    .method_22914(0, 1, 0);
                consumer.method_22918(viewMatrix, cableLeft[i1], cableLeft[i1 + 1], cableLeft[i1 + 2])
                    .method_22915(r, g, b, 1f)
                    .method_22913(WHITE_U, WHITE_V)
                    .method_22922(class_4608.field_21444)
                    .method_60803(light)
                    .method_22914(0, 1, 0);
            }
        }

        final class_9801 mesh = consumer.method_60794();
        if (mesh != null) {
            renderType.method_60895(mesh);
        }
    }

    private static void buildCableOutline(final class_1920 level, final class_243 eye, final class_243 forward,
                                          final class_243 p0, final class_243 p1, final class_243 p2) {
        for (int i = 0; i < CABLE_VERTEX_COUNT; i++) {
            final float t = i / (CABLE_VERTEX_COUNT - 1f);

            final class_243 p = quadraticBezier(p0, p1, p2, t);
            final class_243 n = getExtrusionVector(eye, p, forward);

            cablePos.method_10102(p.field_1352, p.field_1351, p.field_1350);
            cableLight[i] = class_765.method_23687(
                level.method_8314(class_1944.field_9282, cablePos),
                level.method_8314(class_1944.field_9284, cablePos));

            final int o = i * 3;
            final double x = p.field_1352 - eye.field_1352, y = p.field_1351 - eye.field_1351, z = p.field_1350 - eye.field_1350;
            cableLeft[o] = (float) (x - n.field_1352);
            cableLeft[o + 1] = (float) (y - n.field_1351);
            cableLeft[o + 2] = (float) (z - n.field_1350);
            cableRight[o] = (float) (x + n.field_1352);
            cableRight[o + 1] = (float) (y + n.field_1351);
            cableRight[o + 2] = (float) (z + n.field_1350);
        }
    }

    private static class_243 lerp(final class_243 a, final class_243 b, final float t) {
        return a.method_1019(b.method_1020(a).method_1021(t)); // a + (b - a)*t = a*(1-t) + b*t
    }

    private static class_243 quadraticBezier(final class_243 a, final class_243 b, final class_243 c, final float t) {
        final class_243 a1 = lerp(a, c, t);
        final class_243 b1 = lerp(c, b, t);
        return lerp(a1, b1, t);
    }

    private static class_243 getExtrusionVector(final class_243 eye, final class_243 v, final class_243 forward) {
        return forward.method_1036(eye.method_1020(v)).method_1029().method_1021(CABLE_THICKNESS);
    }

    private static float computeCableHang(final class_243 a, final class_243 b) {
        final double length = a.method_1022(b);
        final double hangFactor = class_3532.method_15350(length / CABLE_MAX_LENGTH, 0, 1);
        return (float) (CABLE_HANG_MIN + (CABLE_HANG_MAX - CABLE_HANG_MIN) * hangFactor);
    }

    private static float computeCableSwingAmount(final class_243 p0, final class_243 p1) {
        return class_3532.method_15363((float) p0.method_1022(p1) / CABLE_LENGTH_FOR_MAX_SWING, 0.1f, 1f) * CABLE_MAX_SWING_AMOUNT;
    }

    private static class_243 animateCableSwing(final class_243 c, @Nullable final class_243 right, final float swingAmount, final int seed) {
        final float relTime = (System.currentTimeMillis() + seed) % CABLE_SWING_INTERVAL / (float) CABLE_SWING_INTERVAL;
        final float relRadialTime = relTime * 2 * (float) Math.PI;

        if (right == null) {
            return c.method_1031(swingAmount * class_3532.method_15374(relRadialTime),
                0,
                swingAmount * class_3532.method_15362(relRadialTime));
        } else {
            return c.method_1031(swingAmount * class_3532.method_15362(relRadialTime) * right.field_1352,
                0.5f * swingAmount * class_3532.method_15374(relRadialTime * 2 - (float) Math.PI) - swingAmount,
                swingAmount * class_3532.method_15362(relRadialTime) * right.field_1350);
        }
    }

    private static void removeConnectors(final Predicate<NetworkConnectorBlockEntity> filter) {
        boolean removedAny = false;
        for (final NetworkConnectorBlockEntity connector : new ArrayList<>(connectors)) {
            if (filter.test(connector)) {
                connectors.remove(connector);
                removedAny = true;
            }
        }

        if (removedAny) {
            invalidateConnections();
        }
    }

    private static void validateConnectors() {
        int count = 0;
        final var iterator = connectors.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().isValid()) {
                count++;
            } else {
                iterator.remove();
                invalidateConnections();
            }
        }

        // We track the size because the WeakHasMap may expunge dead entries without
        // us knowing otherwise.
        if (count != lastKnownConnectorCount) {
            invalidateConnections();
        }
        lastKnownConnectorCount = count;
    }

    private static void validatePairs() {
        if (!isDirty) {
            return;
        }

        isDirty = false;
        connections.clear();

        final HashSet<Connection> seen = new HashSet<>();
        for (final NetworkConnectorBlockEntity connector : connectors) {
            final class_2338 position = connector.method_11016();
            for (final class_2338 connectedPosition : connector.getConnectedPositions()) {
                final Connection connection = new Connection(position, connectedPosition);
                if (seen.add(connection)) {
                    connections.add(connection);
                }
            }
        }
    }

    // --------------------------------------------------------------------- //

    private static final class Connection {
        private static final class_243 POS_Y = new class_243(0, 1, 0);

        public final class_2338 fromPos, toPos;
        public final class_243 from, to, forward, right;
        public final class_238 bounds;

        private Connection(final class_2338 fromPos, final class_2338 toPos) {
            if (fromPos.method_10265(toPos) > 0) {
                this.fromPos = toPos;
                this.toPos = fromPos;
            } else {
                this.fromPos = fromPos;
                this.toPos = toPos;
            }

            from = class_243.method_24953(fromPos);
            to = class_243.method_24953(toPos);
            forward = to.method_1020(from).method_1029();
            right = fromPos.method_10263() == toPos.method_10263() && fromPos.method_10260() == toPos.method_10260()
                ? null : forward.method_1036(POS_Y);
            bounds = new class_238(from, to).method_1009(0, CABLE_HANG_MAX, 0);
        }

        @Override
        public boolean equals(final Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            final Connection that = (Connection) o;
            return fromPos.equals(that.fromPos) && toPos.equals(that.toPos);
        }

        @Override
        public int hashCode() {
            return Objects.hash(fromPos, toPos);
        }
    }
}
