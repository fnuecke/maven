/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.client.renderer.Overlays;
import li.cil.oc2.client.renderer.TerminalOverlayRenderer;
import li.cil.oc2.common.block.ComputerBlock;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5348;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_824;
import net.minecraft.class_827;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.List;

public final class ComputerRenderer implements class_827<ComputerBlockEntity> {
    private final class_824 renderer;

    // --------------------------------------------------------------------- //

    public ComputerRenderer(final class_5614.class_5615 context) {
        this.renderer = context.method_32139();
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final ComputerBlockEntity computer, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        final class_2350 blockFacing = computer.method_11010().method_11654(ComputerBlock.field_11177);
        final class_243 cameraPosition = renderer.field_4344.method_19331().method_5836(partialTicks);

        // If viewer is not in front of the block we can skip the rest, it cannot be visible.
        // We check against the center of the block instead of the actual relevant face for simplicity.
        final class_243 relativeCameraPosition = cameraPosition.method_1020(class_243.method_24953(computer.method_11016()));
        final double projectedCameraPosition = relativeCameraPosition.method_1026(class_243.method_24954(blockFacing.method_10163()));
        if (projectedCameraPosition <= 0) {
            return;
        }

        stack.method_22903();

        // Align with front face of block.
        final Quaternionf rotation = class_7833.field_40715.rotationDegrees(blockFacing.method_10144() + 180);
        stack.method_46416(0.5f, 0, 0.5f);
        stack.method_22907(rotation);
        stack.method_46416(-0.5f, 0, -0.5f);

        // Flip and align with top left corner.
        stack.method_46416(1, 1, 0);
        stack.method_22905(-1, -1, -1);

        // Scale to make 1/16th of the block one unit and align with top left of terminal area.
        final float pixelScale = 1 / 16f;
        stack.method_22905(pixelScale, pixelScale, pixelScale);

        if (computer.getVirtualMachine().isRunning()) {
            TerminalOverlayRenderer.renderTerminal(computer.method_11016(), computer.getTerminal(), stack, bufferSource, cameraPosition);
        } else {
            renderStatusText(computer, stack, bufferSource, cameraPosition);
        }

        stack.method_46416(0, 0, -0.1f);
        final Matrix4f matrix = stack.method_23760().method_23761();

        switch (computer.getVirtualMachine().getBusState()) {
            case SCAN_PENDING:
            case INCOMPLETE:
                Overlays.renderStatus(matrix, bufferSource);
                break;
            case TOO_COMPLEX:
                Overlays.renderStatus(matrix, bufferSource, 1000);
                break;
            case MULTIPLE_CONTROLLERS:
                Overlays.renderStatus(matrix, bufferSource, 250);
                break;
            case READY:
                switch (computer.getVirtualMachine().getRunState()) {
                    case STOPPED:
                        break;
                    case LOADING_DEVICES:
                        Overlays.renderStatus(matrix, bufferSource);
                        break;
                    case RUNNING:
                        Overlays.renderPower(matrix, bufferSource);
                        break;
                }
                break;
        }

        stack.method_22909();
    }

    // --------------------------------------------------------------------- //

    private void renderStatusText(final ComputerBlockEntity computer, final class_4587 stack, final class_4597 bufferSource, final class_243 cameraPosition) {
        if (!class_243.method_24953(computer.method_11016()).method_24802(cameraPosition, 12f)) {
            return;
        }

        final class_2561 bootError = computer.getVirtualMachine().getError();
        if (bootError == null) {
            return;
        }

        stack.method_22903();
        stack.method_46416(3, 3, -0.9f);

        drawText(stack, bufferSource, bootError);

        stack.method_22909();
    }

    private void drawText(final class_4587 stack, final class_4597 bufferSource, final class_2561 text) {
        final int maxWidth = 100;

        stack.method_22903();
        stack.method_22905(10f / maxWidth, 10f / maxWidth, 10f / maxWidth);

        final class_327 fontRenderer = class_310.method_1551().field_1772;
        final Matrix4f matrix = stack.method_23760().method_23761();
        final List<class_5348> wrappedText = fontRenderer.method_27527().method_27495(text, maxWidth, class_2583.field_24360);
        if (wrappedText.size() == 1) {
            final int textWidth = fontRenderer.method_27525(text);
            drawTextLine(fontRenderer, text.getString(), (maxWidth - textWidth) * 0.5f, 0, matrix, bufferSource);
        } else {
            for (int i = 0; i < wrappedText.size(); i++) {
                drawTextLine(fontRenderer, wrappedText.get(i).getString(), 0, i * fontRenderer.field_2000, matrix, bufferSource);
            }
        }

        stack.method_22909();
    }

    private static void drawTextLine(final class_327 font, final String text, final float x, final float y,
                                     final Matrix4f matrix, final class_4597 bufferSource) {
        font.method_27521(text, x, y, 0xFFEE3322, false, matrix, bufferSource,
            class_327.class_6415.field_33993, 0, class_765.method_23687(15, 15));
    }
}
