/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import li.cil.oc2.common.util.BlockPlacement;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3726;
import java.util.Map;

public abstract class OrientableBlock extends class_2248 {
    public static final class_2753 FACING = class_2741.field_12525;
    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 3);

    // --------------------------------------------------------------------- //

    private final Map<class_2350, class_265> shapes;

    // --------------------------------------------------------------------- //

    protected OrientableBlock(final class_2251 properties, final class_2350 facing, final int depth) {
        super(properties);
        this.shapes = shapesWithDepth(depth);
        method_9590(method_9595().method_11664()
            .method_11657(FACING, facing)
            .method_11657(ROTATION, 0));
    }

    // --------------------------------------------------------------------- //

    public static int getRotationX(final class_2680 state) {
        return switch (state.method_11654(FACING)) {
            case field_11033 -> 90;
            case field_11036 -> 270;
            default -> 0;
        };
    }

    public static int getRotationY(final class_2680 state) {
        final class_2350 facing = state.method_11654(FACING);
        return facing.method_10166().method_10178()
            ? state.method_11654(ROTATION) * 90
            : (int) facing.method_10153().method_10144();
    }

    @Override
    public class_2680 method_9605(final class_1750 context) {
        final BlockPlacement placement = getPlacement(context);
        return method_9564()
            .method_11657(FACING, placement.facing())
            .method_11657(ROTATION, getRotationForPlacement(placement.facing(), placement.upward()));
    }

    // --------------------------------------------------------------------- //

    protected BlockPlacement getPlacement(final class_1750 context) {
        return BlockPlacement.free(context);
    }

    @Override
    protected class_265 method_9530(final class_2680 state, final class_1922 level, final class_2338 pos, final class_3726 context) {
        return shapes.get(state.method_11654(FACING));
    }

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING, ROTATION);
    }

    // --------------------------------------------------------------------- //

    private static int getRotationForPlacement(final class_2350 facing, final class_2350 upward) {
        if (facing.method_10166().method_10179()) {
            return 0;
        }

        return (int) (facing == class_2350.field_11033 ? upward.method_10153() : upward).method_10144() / 90;
    }

    private static Map<class_2350, class_265> shapesWithDepth(final int depth) {
        return Map.of(
            class_2350.field_11036, method_9541(0, 0, 0, 16, depth, 16),
            class_2350.field_11033, method_9541(0, 16 - depth, 0, 16, 16, 16),
            class_2350.field_11043, method_9541(0, 0, 16 - depth, 16, 16, 16),
            class_2350.field_11035, method_9541(0, 0, 0, 16, 16, depth),
            class_2350.field_11034, method_9541(0, 0, 0, depth, 16, 16),
            class_2350.field_11039, method_9541(16 - depth, 0, 0, 16, 16, 16)
        );
    }
}
