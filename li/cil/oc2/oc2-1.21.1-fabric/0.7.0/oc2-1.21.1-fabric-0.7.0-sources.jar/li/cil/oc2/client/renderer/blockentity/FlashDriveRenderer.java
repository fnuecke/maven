/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.common.block.OrientableBlock;
import li.cil.oc2.common.blockentity.FlashDriveBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.minecraft.class_918;

public final class FlashDriveRenderer implements class_827<FlashDriveBlockEntity> {
    private static final float FLASH_MEMORY_Y = 10.5f / 16f;
    private static final float FLASH_MEMORY_Z = 9.0f / 16f;
    private static final float FLASH_MEMORY_SCALE = 6.0f / 16f;

    // --------------------------------------------------------------------- //

    private final class_824 renderer;

    // --------------------------------------------------------------------- //

    public FlashDriveRenderer(final class_5614.class_5615 context) {
        this.renderer = context.method_32139();
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final FlashDriveBlockEntity flashDrive, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        final class_1799 flashMemory = flashDrive.getMedia();
        if (flashMemory.method_7960()) {
            return;
        }

        final class_2680 state = flashDrive.method_11010();
        final class_2350 facing = state.method_11654(OrientableBlock.FACING);
        final int neighborLight = class_761.method_23794(renderer.field_4348, flashDrive.method_11016().method_10093(facing));
        final class_918 itemRenderer = class_310.method_1551().method_1480();

        stack.method_22903();

        stack.method_46416(0.5f, 0.5f, 0.5f);
        stack.method_22907(class_7833.field_40715.rotationDegrees(OrientableBlock.getRotationY(state)));
        stack.method_22907(class_7833.field_40713.rotationDegrees(OrientableBlock.getRotationX(state)));
        stack.method_46416(-0.5f, -0.5f, -0.5f);

        stack.method_46416(0.5f, FLASH_MEMORY_Y, FLASH_MEMORY_Z);
        stack.method_22907(class_7833.field_40714.rotationDegrees(90));
        stack.method_22905(FLASH_MEMORY_SCALE, FLASH_MEMORY_SCALE, FLASH_MEMORY_SCALE);

        itemRenderer.method_23178(flashMemory, class_811.field_4319, neighborLight, overlay, stack, bufferSource,
            flashDrive.method_10997(), (int) flashDrive.method_11016().method_10063());

        stack.method_22909();
    }
}
