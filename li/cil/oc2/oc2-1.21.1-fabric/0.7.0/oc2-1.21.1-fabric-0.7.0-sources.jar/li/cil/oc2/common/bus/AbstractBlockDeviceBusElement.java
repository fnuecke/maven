/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus;

import li.cil.oc2.api.bus.BlockDeviceBusElement;
import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.rpc.TypeNameRPCDevice;
import li.cil.oc2.common.bus.device.util.BlockDeviceInfo;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.util.LevelUtils;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import javax.annotation.Nullable;
import java.util.*;

import static li.cil.oc2.common.bus.device.provider.Providers.optionalKey;

public abstract class AbstractBlockDeviceBusElement extends AbstractGroupingDeviceBusElement<AbstractBlockDeviceBusElement.BlockEntry> implements BlockDeviceBusElement {
    private final Invalidatable<?>[] neighbors = new Invalidatable<?>[Constants.BLOCK_FACE_COUNT];

    // --------------------------------------------------------------------- //

    public AbstractBlockDeviceBusElement() {
        super(Constants.BLOCK_FACE_COUNT);
    }

    // --------------------------------------------------------------------- //
    // DeviceBusElement

    @Override
    public Optional<Collection<Invalidatable<DeviceBusElement>>> getNeighbors() {
        final class_1936 level = getLevel();
        if (level == null || level.method_8608()) {
            return Optional.empty();
        }

        final ArrayList<Invalidatable<DeviceBusElement>> neighbors = new ArrayList<>();
        for (final class_2350 neighborDirection : Constants.DIRECTIONS) {
            if (!canScanContinueTowards(neighborDirection)) {
                continue;
            }

            final class_2338 neighborPos = getPosition().method_10093(neighborDirection);

            final class_1923 chunkPos = new class_1923(neighborPos);
            if (!level.method_8393(chunkPos.field_9181, chunkPos.field_9180)) {
                return Optional.empty();
            }

            final Invalidatable<DeviceBusElement> neighbor = getNeighbor(level, neighborPos, neighborDirection);
            if (neighbor.isPresent()) {
                neighbors.add(neighbor);
            }
        }

        return Optional.of(neighbors);
    }

    @Override
    public void invalidateDevices() {
        for (final class_2350 side : class_2350.values()) {
            updateDevicesForNeighbor(side);
        }
    }

    // --------------------------------------------------------------------- //

    public void updateDevicesForNeighbor(final class_2350 side) {
        final class_1936 level = getLevel();
        if (level == null || level.method_8608()) {
            return;
        }

        final int index = side.method_10146();
        final class_2338 neighborPos = getPosition().method_10093(side);

        // Without a controller we have no architecture, which can result in some
        // providers returning nothing or something different to what's saved.
        // In this state, we might discard persisted data of devices that don't get
        // provided in the current state. When a controller is added, we re-run this
        // anyway, so it's fine to just skip it for now.
        if (getControllers().isEmpty()) {
            // BUT! If this is a neighbor chunk unloading, we have to save the device
            // state of the devices in it, or we'll lose it .
            final class_1923 neighborChunk = new class_1923(neighborPos);
            if (!level.method_8393(neighborChunk.field_9181, neighborChunk.field_9180)) {
                setEntriesForGroupUnloaded(index);
            }
        } else {
            collectDevices(level, neighborPos, side).ifPresentOrElse(
                entries -> setEntriesForGroup(index, entries),
                () -> setEntriesForGroupUnloaded(index)
            );
        }
    }

    public void setRemoved() {
        Arrays.fill(neighbors, null);

        final class_1936 level = getLevel();
        if (level == null || level.method_8608()) {
            return;
        }

        for (final class_2350 side : class_2350.values()) {
            setEntriesForGroup(side.method_10146(), Collections.emptySet());
        }

        scheduleScan();
    }

    // --------------------------------------------------------------------- //

    protected boolean canScanContinueTowards(@Nullable final class_2350 direction) {
        return true;
    }

    protected boolean canDetectDevicesTowards(@Nullable final class_2350 direction) {
        return canScanContinueTowards(direction);
    }

    protected Optional<Set<BlockEntry>> collectDevices(final class_1936 level, final class_2338 pos, @Nullable final class_2350 side) {
        final BlockDeviceQuery query = Devices.makeQuery(getArchitectureType().orElse(null), level, pos, side != null ? side.method_10153() : null);
        final HashSet<BlockEntry> entries = new HashSet<>();

        if (canDetectDevicesTowards(side)) {
            final Optional<List<Invalidatable<BlockDeviceInfo>>> loadedDevices = Devices.getDevices(query);
            if (loadedDevices.isPresent()) {
                for (final Invalidatable<BlockDeviceInfo> deviceInfo : loadedDevices.get()) {
                    if (deviceInfo.isPresent()) {
                        entries.add(new BlockEntry(deviceInfo, side));
                    }
                }
            } else {
                return Optional.empty();
            }

            collectSyntheticDevices(level, pos, side, entries);
        }

        return Optional.of(entries);
    }

    protected void collectSyntheticDevices(final class_1936 level, final class_2338 pos, @Nullable final class_2350 side, final HashSet<BlockEntry> entries) {
        if (entries.isEmpty()) {
            return;
        }

        final String blockName = LevelUtils.getBlockName(level, pos);
        if (blockName != null) {
            entries.add(new BlockEntry(new BlockDeviceInfo(null, new TypeNameRPCDevice(blockName)), side));
        }
    }

    @Override
    protected void onEntryAdded(final BlockEntry entry) {
        super.onEntryAdded(entry);
        entry.addListener();
    }

    @Override
    protected void onEntryRemoved(final BlockEntry entry) {
        super.onEntryRemoved(entry);
        entry.removeListener();
    }

    // --------------------------------------------------------------------- //

    protected final class BlockEntry implements Entry {
        private final Invalidatable<BlockDeviceInfo> deviceInfo;
        @Nullable
        private final String dataKey;
        private final Device device;
        @Nullable
        private final class_2350 side;
        private Invalidatable.ListenerToken token;

        public BlockEntry(final Invalidatable<BlockDeviceInfo> deviceInfo, @Nullable final class_2350 side) {
            this.deviceInfo = deviceInfo;
            this.side = side;

            // Grab these while the device info has not yet been invalidated. We still need to access
            // these even after the device has been invalidated to clean up.
            this.dataKey = optionalKey(deviceInfo.get().provider).orElse(null);
            this.device = deviceInfo.get().device;
        }

        public BlockEntry(final BlockDeviceInfo deviceInfo, @Nullable final class_2350 side) {
            this(Invalidatable.of(deviceInfo), side);
        }

        @Override
        public Optional<String> getDeviceDataKey() {
            return Optional.ofNullable(dataKey);
        }

        @Override
        public OptionalInt getDeviceEnergyConsumption() {
            return deviceInfo.isPresent() ? OptionalInt.of(deviceInfo.get().getEnergyConsumption()) : OptionalInt.empty();
        }

        @Override
        public Device getDevice() {
            return device;
        }

        public void addListener() {
            // Side can be null for the block that owns the bus element, e.g. in the computer, where the
            // block adds itself. In this case, we can skip the listener, since the bus element's existence
            // and validity is tightly coupled to the device source anyway.
            if (token == null && side != null) {
                token = deviceInfo.addListener(unused -> updateDevicesForNeighbor(side));
            }
        }

        public void removeListener() {
            if (token != null) {
                token.removeListener();
                token = null;
            }
        }

        @Override
        public boolean equals(final Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            final BlockEntry that = (BlockEntry) o;
            return Objects.equals(dataKey, that.dataKey) && device.equals(that.device) && side == that.side;
        }

        @Override
        public int hashCode() {
            return Objects.hash(dataKey, device, side);
        }

        @Override
        public String toString() {
            return device.toString();
        }
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("unchecked")
    private Invalidatable<DeviceBusElement> getNeighbor(final class_1936 level, final class_2338 pos, final class_2350 side) {
        final int index = side.method_10146();

        final Invalidatable<DeviceBusElement> cached = (Invalidatable<DeviceBusElement>) neighbors[index];
        if (cached != null && cached.isPresent()) {
            return cached;
        }

        final Invalidatable<DeviceBusElement> neighbor = Capabilities.watch(
            level, pos, side.method_10153(), Capabilities.DEVICE_BUS_ELEMENT);
        neighbors[index] = neighbor;
        return neighbor;
    }
}
