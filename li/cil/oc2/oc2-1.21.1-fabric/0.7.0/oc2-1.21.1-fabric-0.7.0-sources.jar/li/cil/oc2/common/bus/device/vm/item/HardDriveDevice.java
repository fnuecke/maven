/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.vm.item;

import li.cil.oc2.common.util.*;
import li.cil.sedna.device.block.ByteBufferBlockDevice;
import net.minecraft.class_1799;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

public class HardDriveDevice extends AbstractBlockStorageDevice<ByteBufferBlockDevice, class_1799> {
    private final int size;
    private final Supplier<Optional<BlockLocation>> location;
    private final ThrottledSoundEmitter soundEmitter;

    // --------------------------------------------------------------------- //

    public HardDriveDevice(final class_1799 identity, final int size, final boolean readonly, final Supplier<Optional<BlockLocation>> location) {
        super(identity, readonly);
        this.size = size;
        this.location = location;
        this.soundEmitter = new ThrottledSoundEmitter(location, SoundEvents.HDD_ACCESS.get())
            .withMinInterval(Duration.ofSeconds(1));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected int getMappedByteCount() {
        return size;
    }

    @Override
    protected CompletableFuture<ByteBufferBlockDevice> createBlockDevice() throws IOException {
        // Make sure we can access the data now, so base can handle missing/in use errors.
        final FileChannel channel = blob.open();

        return CompletableFuture.supplyAsync(() -> {
            try {
                return ByteBufferBlockDevice.createFromFileChannel(channel, size, readonly);
            } catch (final IOException e) {
                throw new RuntimeException(e);
            }
        }, WORKERS);
    }

    @Override
    protected void handleDataAccess() {
        soundEmitter.play();
    }

    @Override
    protected class_1799 getStorageItem() {
        return identity;
    }

    @Override
    protected void handleStorageChanged() {
        location.get().ifPresent(blockLocation -> blockLocation.tryGetLevel().ifPresent(level ->
            ChunkUtils.setLazyUnsaved(level, blockLocation.blockPos())));
    }
}
