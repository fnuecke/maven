/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import li.cil.oc2.common.vm.Terminal;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_6367;
import net.minecraft.class_8251;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.lwjgl.opengl.GL30;

import javax.annotation.Nullable;

@Environment(EnvType.CLIENT)
public final class TerminalTexture implements Terminal.Listener, AutoCloseable {
    private static final float CURSOR_DEPTH_OFFSET = 0.025f;

    // --------------------------------------------------------------------- //

    private final Terminal terminal;
    private final TerminalRenderer renderer;
    private final Matrix4f projectionMatrix = new Matrix4f();

    @Nullable
    private class_6367 target;
    private volatile boolean isDirty = true;

    // --------------------------------------------------------------------- //

    public TerminalTexture(final Terminal terminal) {
        this.terminal = terminal;
        this.renderer = new TerminalRenderer(terminal);
        terminal.addListener(this);
    }

    // --------------------------------------------------------------------- //

    public void draw(final class_4587 stack) {
        if (target == null) {
            return;
        }

        RenderSystem.setShaderTexture(0, target.method_30277());

        final class_1921 renderType = ModRenderType.getTerminalScreen();
        class_287 builder = class_289.method_1348().method_60827(renderType.method_23033(), renderType.method_23031());
        final Matrix4f matrix = stack.method_23760().method_23761();
        final float x = terminal.getWidth(), y = terminal.getHeight();

        builder.method_22918(matrix, 0, 0, 0).method_22913(0, 1).method_39415(-1);
        builder.method_22918(matrix, 0, y, 0).method_22913(0, 0).method_39415(-1);
        builder.method_22918(matrix, x, y, 0).method_22913(1, 0).method_39415(-1);
        builder.method_22918(matrix, x, 0, 0).method_22913(1, 1).method_39415(-1);

        class_9801 mesh = builder.method_60794();
        if (mesh != null) {
            renderType.method_60895(mesh);
        }

        if (!TerminalRenderer.shouldRenderCursor(terminal)) {
            return;
        }

        RenderSystem.setShaderTexture(0, TerminalRenderer.getFontTexture());
        builder = class_289.method_1348().method_60827(renderType.method_23033(), renderType.method_23031());
        renderer.buildCursor(new Matrix4f(matrix).translate(0, 0, CURSOR_DEPTH_OFFSET), builder);

        mesh = builder.method_60794();
        if (mesh != null) {
            renderType.method_60895(mesh);
        }
    }

    public void refresh() {
        if (!isDirty) {
            return;
        }
        isDirty = false;

        if (target == null) {
            target = new class_6367(terminal.getWidth(), terminal.getHeight(), false, class_310.field_1703);
            // Mipmapped so the copy survives being minified in world; premultiplied colour is exactly what
            // filtering wants, so the levels stay correct. setFilterMode unbinds, hence the rebind.
            target.method_58226(GlConst.GL_LINEAR);
            RenderSystem.bindTexture(target.method_30277());
            GlStateManager._texParameter(GlConst.GL_TEXTURE_2D, GlConst.GL_TEXTURE_MIN_FILTER, GlConst.GL_LINEAR_MIPMAP_LINEAR);
        }

        target.method_1236(0, 0, 0, 0);
        target.method_1230(class_310.field_1703);
        target.method_1235(true);

        projectionMatrix.setOrtho(0, terminal.getWidth(), terminal.getHeight(), 0, -1, 1);
        RenderSystem.backupProjectionMatrix();
        RenderSystem.setProjectionMatrix(projectionMatrix, class_8251.field_43361);
        final Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.pushMatrix().identity();
        RenderSystem.applyModelViewMatrix();

        RenderSystem.disableDepthTest();
        renderer.renderBody(new class_4587(), new Matrix4f(), projectionMatrix);
        RenderSystem.enableDepthTest();

        modelViewStack.popMatrix();
        RenderSystem.applyModelViewMatrix();
        RenderSystem.restoreProjectionMatrix();

        final class_276 mainTarget = class_310.method_1551().method_1522();
        mainTarget.method_1235(true);

        RenderSystem.bindTexture(target.method_30277());
        GL30.glGenerateMipmap(GlConst.GL_TEXTURE_2D);
    }

    @Override
    public void handleTerminalChanged() {
        isDirty = true;
    }

    @Override
    public void close() {
        terminal.removeListener(this);
        renderer.close();
        releaseTarget();
    }

    // --------------------------------------------------------------------- //

    private void releaseTarget() {
        if (target != null) {
            target.method_1238();
            target = null;
        }
    }
}
