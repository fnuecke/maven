/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.api.API;
import net.minecraft.class_1723;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class Overlays {
    private static final int PULSE_TICKS = 40;

    private static final class_2960 POWER_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/power");
    private static final class_2960 STATUS_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/status");
    private static final class_2960 TERMINAL_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/terminal");

    private static final class_4730 POWER = new class_4730(class_1723.field_21668, POWER_LOCATION);
    private static final class_4730 STATUS = new class_4730(class_1723.field_21668, STATUS_LOCATION);
    private static final class_4730 TERMINAL = new class_4730(class_1723.field_21668, TERMINAL_LOCATION);

    // --------------------------------------------------------------------- //

    public static void renderPower(final Matrix4f matrix, final class_4597 bufferSource) {
        renderQuad(matrix, bufferSource, POWER);
    }

    public static void renderStatus(final Matrix4f matrix, final class_4597 bufferSource) {
        renderQuad(matrix, bufferSource, STATUS);
    }

    public static void renderStatus(final Matrix4f matrix, final class_4597 bufferSource, final int frequency) {
        if (System.currentTimeMillis() / frequency % 2 == 1) {
            renderStatus(matrix, bufferSource);
        }
    }

    public static void renderTerminal(final Matrix4f matrix, final class_4597 bufferSource) {
        renderQuad(matrix, bufferSource, TERMINAL);
    }

    public static void renderBox(final class_4587 stack, final class_4597 bufferSource, final class_238 bounds, final Vector3f color, final Vector3f colorBright, final long gameTime, final float partialTicks) {
        renderBox(ModRenderType.getIndicator(), stack, bufferSource, bounds, color, colorBright, gameTime, partialTicks);
    }

    public static void renderBox(final class_1921 renderType, final class_4587 stack, final class_4597 bufferSource, final class_238 bounds, final Vector3f color, final Vector3f colorBright, final long gameTime, final float partialTicks) {
        final float phase = (gameTime % PULSE_TICKS + partialTicks) / PULSE_TICKS;
        final float blend = (1 + class_3532.method_15374(phase * (float) (Math.PI * 2))) * 0.5f;

        final float r = class_3532.method_16439(blend, color.x(), colorBright.x());
        final float g = class_3532.method_16439(blend, color.y(), colorBright.y());
        final float b = class_3532.method_16439(blend, color.z(), colorBright.z());

        addBoxVertices(stack.method_23760().method_23761(), bufferSource.getBuffer(renderType), bounds, r, g, b);
    }

    // --------------------------------------------------------------------- //

    private static void addBoxVertices(final Matrix4f matrix, final class_4588 consumer, final class_238 bounds, final float r, final float g, final float b) {
        final float x0 = (float) bounds.field_1323;
        final float y0 = (float) bounds.field_1322;
        final float z0 = (float) bounds.field_1321;
        final float x1 = (float) bounds.field_1320;
        final float y1 = (float) bounds.field_1325;
        final float z1 = (float) bounds.field_1324;

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x0, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z0, r, g, b);

        addVertex(matrix, consumer, x0, y0, z1, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x0, y0, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z0, r, g, b);

        addVertex(matrix, consumer, x1, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);
        addVertex(matrix, consumer, x0, y0, z1, r, g, b);

        addVertex(matrix, consumer, x0, y1, z0, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
    }

    private static void addVertex(final Matrix4f matrix, final class_4588 consumer, final float x, final float y, final float z, final float r, final float g, final float b) {
        consumer.method_22918(matrix, x, y, z).method_22915(r, g, b, 1f);
    }

    private static void renderQuad(final Matrix4f matrix, final class_4597 bufferSource, final class_4730 material) {
        final class_4588 consumer = material.method_24145(bufferSource, ModRenderType::getUnlitBlock);

        // Not chained: vanilla's SpriteCoordinateExpander.addVertex returns the delegate, so a
        // chained setUv would bypass the sprite remap (NeoForge patches this, Fabric does not).
        consumer.method_22918(matrix, 0, 0, 0);
        consumer.method_22913(0, 0);

        consumer.method_22918(matrix, 0, 16, 0);
        consumer.method_22913(0, 1);

        consumer.method_22918(matrix, 16, 16, 0);
        consumer.method_22913(1, 1);

        consumer.method_22918(matrix, 16, 0, 0);
        consumer.method_22913(1, 0);
    }

    private Overlays() {
    }
}
