/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import li.cil.oc2.common.blockentity.ModBlockEntity;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class AbstractBlockEntityScreen<T extends ModBlockEntity> extends class_437 {
    private static final int USE_DISTANCE = 8;
    private static final int DEFAULT_WIDTH = 176;
    private static final int DEFAULT_HEIGHT = 166;

    protected static final int CONTROLS_TOP = 8;

    // --------------------------------------------------------------------- //

    protected final T blockEntity;

    protected int imageWidth = DEFAULT_WIDTH;
    protected int imageHeight = DEFAULT_HEIGHT;
    protected int leftPos, topPos;

    // --------------------------------------------------------------------- //

    protected AbstractBlockEntityScreen(class_2561 title, T blockEntity) {
        super(title);
        this.blockEntity = blockEntity;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        leftPos = (field_22789 - imageWidth) / 2;
        topPos = (field_22790 - imageHeight) / 2;
    }

    @Override
    public void method_25393() {
        super.method_25393();

        if (stillValid()) {
            safeTick();
        } else {
            method_25419();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        method_52752(graphics);
        renderBg(graphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.method_25394(graphics, mouseX, mouseY, partialTicks);
        renderFg(graphics, mouseX, mouseY, partialTicks);
    }

    // --------------------------------------------------------------------- //

    protected void safeTick() {
    }

    protected void renderBg(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
    }

    protected void renderFg(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
    }

    // --------------------------------------------------------------------- //

    private boolean stillValid() {
        final class_243 blockCenter = class_243.method_24953(blockEntity.method_11016());
        return blockEntity.isValid() &&
            field_22787.field_1724 != null &&
            field_22787.field_1724.method_5707(blockCenter) <= USE_DISTANCE * USE_DISTANCE;
    }
}
