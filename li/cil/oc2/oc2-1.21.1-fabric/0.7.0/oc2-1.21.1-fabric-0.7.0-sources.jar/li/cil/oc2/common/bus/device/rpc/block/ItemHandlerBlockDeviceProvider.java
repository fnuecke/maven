/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockEntityCapabilityDeviceProvider;
import li.cil.oc2.common.bus.device.rpc.ItemHandlerDevice;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.inventory.ItemHandler;
import net.minecraft.class_2586;

public final class ItemHandlerBlockDeviceProvider extends AbstractBlockEntityCapabilityDeviceProvider<ItemHandler, class_2586> {
    public ItemHandlerBlockDeviceProvider() {
        super(Capabilities.ITEM_HANDLER);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Invalidatable<Device> getBlockDevice(final BlockDeviceQuery query, final ItemHandler value) {
        return Invalidatable.of(new ObjectDevice(new ItemHandlerDevice(value)));
    }
}
