/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import li.cil.oc2.client.ClientPlatform;
import li.cil.oc2.common.blockentity.KeyboardBlockEntity;
import li.cil.oc2.common.bus.device.vm.block.KeyboardDevice;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.KeyboardInputMessage;
import li.cil.oc2.common.network.message.KeyboardKeepAliveMessage;
import net.minecraft.class_1268;
import net.minecraft.class_2561;
import net.minecraft.class_312;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_5250;
import net.minecraft.class_5819;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

public final class KeyboardScreen extends AbstractBlockEntityScreen<KeyboardBlockEntity> {
    private static final int BORDER_SIZE = 4;
    private static final float ARM_SWING_RATE = 0.8f;
    private static final int BORDER_COLOR = 0xFFFFFFFF;

    private static final class_5250 CLOSE_INFO = class_2561.method_43471("gui.oc2.keyboard.close_info");

    // --------------------------------------------------------------------- //

    private final IntSet pressedKeys = new IntOpenHashSet();
    private long lastKeepAliveSentAt;

    // --------------------------------------------------------------------- //

    public KeyboardScreen(final KeyboardBlockEntity keyboard) {
        super(Items.KEYBOARD.get().method_7848(), keyboard);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        // Grabbing the mouse allows us to let the player keep turning the camera (to get a better
        // look at the projection of a projector, e.g.), while still grabbing all keyboard input.
        grabMouse();

        // Disable hotbar since we don't need it here, and it just blocks screen space.
        ClientPlatform.setHotbarVisible(false);
    }

    @Override
    protected void safeTick() {
        sendKeepAlive();
    }

    @Override
    public boolean method_25404(final int keycode, final int scancode, final int modifiers) {
        if (pressedKeys.add(keycode)) {
            sendInputMessage(keycode, true);
        }

        return true;
    }

    @Override
    public boolean method_16803(final int keycode, final int scancode, final int modifiers) {
        if (pressedKeys.remove(keycode)) {
            sendInputMessage(keycode, false);
        }

        return true;
    }

    @Override
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_2) {
            method_25419();
            return true;
        } else {
            return super.method_25402(mouseX, mouseY, button);
        }
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        // This page intentionally left blank.
    }

    @Override
    protected void renderFg(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        renderBorderOverlay(graphics);

        graphics.method_51440(field_22793, CLOSE_INFO,
            BORDER_SIZE * 3, field_22790 - BORDER_SIZE * 3 - field_22793.field_2000,
            field_22789 - BORDER_SIZE * 6, 0x88FFFFFF);
    }

    @Override
    public void method_25432() {
        super.method_25432();

        if (field_22787.method_1562() != null) {
            for (final int keycode : pressedKeys) {
                sendKeyState(keycode, false);
            }
        }
        pressedKeys.clear();

        ClientPlatform.setHotbarVisible(true);
    }

    // --------------------------------------------------------------------- //

    private void renderBorderOverlay(final class_332 graphics) {
        graphics.method_25294(BORDER_SIZE, BORDER_SIZE, field_22789 - BORDER_SIZE, BORDER_SIZE * 2, BORDER_COLOR);
        graphics.method_25294(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE * 2, field_22790 - BORDER_SIZE, BORDER_COLOR);
        graphics.method_25294(BORDER_SIZE, field_22790 - BORDER_SIZE * 2, field_22789 - BORDER_SIZE, field_22790 - BORDER_SIZE, BORDER_COLOR);
        graphics.method_25294(field_22789 - BORDER_SIZE * 2, BORDER_SIZE, field_22789 - BORDER_SIZE, field_22790 - BORDER_SIZE, BORDER_COLOR);
    }

    private void grabMouse() {
        final class_312 mouseHandler = field_22787.field_1729;
        mouseHandler.field_1783 = true;
        class_3675.method_15984(field_22787.method_22683().method_4490(), class_3675.field_32005, mouseHandler.method_1603(), mouseHandler.method_1604());
    }

    private void sendKeepAlive() {
        final long now = System.currentTimeMillis();
        if (now - lastKeepAliveSentAt > KeyboardDevice.USER_KEEPALIVE_EVERY) {
            lastKeepAliveSentAt = now;
            Network.sendToServer(new KeyboardKeepAliveMessage(blockEntity));
        }
    }

    private void sendInputMessage(final int keycode, final boolean isDown) {
        if (KeyCodeMapping.MAPPING.containsKey(keycode)) {
            swingArm();
            sendKeyState(keycode, isDown);
        }
    }

    private void sendKeyState(final int keycode, final boolean isDown) {
        if (KeyCodeMapping.MAPPING.containsKey(keycode)) {
            final int evdevCode = KeyCodeMapping.MAPPING.get(keycode);
            Network.sendToServer(new KeyboardInputMessage(blockEntity, evdevCode, isDown));
        }
    }

    private void swingArm() {
        final class_746 player = field_22787.field_1724;
        if (player == null) {
            return;
        }

        final class_5819 random = player.method_59922();
        if (random.method_43057() < ARM_SWING_RATE) {
            return;
        }

        final class_1268 handToSwing;
        if (field_22787.field_1690.method_31044().method_31034()) {
            handToSwing = class_1268.field_5808;
        } else {
            handToSwing = random.method_43056() ? class_1268.field_5808 : class_1268.field_5810;
        }

        player.method_6104(handToSwing);
    }
}
