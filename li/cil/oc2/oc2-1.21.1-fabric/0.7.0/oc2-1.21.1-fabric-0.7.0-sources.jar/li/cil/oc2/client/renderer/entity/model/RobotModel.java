/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.entity.model;

import li.cil.oc2.api.API;
import li.cil.oc2.common.entity.Robot;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_765;
import org.joml.Quaternionf;

public final class RobotModel extends class_583<Robot> {
    public static final class_5601 ROBOT_MODEL_LAYER = new class_5601(class_2960.method_60655(API.MOD_ID, "robot"), "main");
    public static final class_2960 ROBOT_ENTITY_TEXTURE = class_2960.method_60655(API.MOD_ID, "textures/entity/robot/robot.png");

    // --------------------------------------------------------------------- //

    private final class_630 topRenderer;
    private final class_630 baseRenderer;
    private final class_630 coreRenderer;
    private float baseY, topY;
    private final float[] topRotation = new float[3];
    private final Quaternionf topRotationQuaternion = new Quaternionf();

    // --------------------------------------------------------------------- //

    public RobotModel(final class_630 modelPart) {
        topRenderer = modelPart.method_32086("top");
        baseRenderer = modelPart.method_32086("base");
        coreRenderer = modelPart.method_32086("core");
    }

    public static class_5607 createRobotLayer() {
        final class_5609 meshDefinition = new class_5609();
        final class_5610 partDefinition = meshDefinition.method_32111();
        partDefinition.method_32117("top", class_5606.method_32108()
                .method_32101(1, 1)
                .method_32097(-7, 8, -7, 14, 6, 14),
            class_5603.field_27701);
        partDefinition.method_32117("base", class_5606.method_32108()
                .method_32101(1, 23)
                .method_32097(-7, 0, -7, 14, 7, 14),
            class_5603.field_27701);
        partDefinition.method_32117("core", class_5606.method_32108()
                .method_32101(1, 34)
                .method_32097(-6, 7, -6, 12, 1, 12),
            class_5603.field_27701);
        return class_5607.method_32110(meshDefinition, 64, 64);
    }

    // --------------------------------------------------------------------- //

    public void applyTopTransform(final class_4587 stack) {
        stack.method_46416(0, topY, 0);
        stack.method_22907(topRotationQuaternion.rotationXYZ(
            topRotation[0] * class_3532.field_29847, topRotation[1] * class_3532.field_29847, topRotation[2] * class_3532.field_29847));
    }

    @Override
    public void setupAnim(final Robot entity, final float limbSwing, final float limbSwingAmount, final float ageInTicks, final float netHeadYaw, final float headPitch) {
        final Robot.AnimationState state = entity.getAnimationState();
        baseY = state.baseRenderOffsetY;
        topY = state.topRenderOffsetY;
        topRotation[1] = state.topRenderRotationY;
    }

    @Override
    public void method_2828(final class_4587 stack, final class_4588 consumer, final int packedLight, final int packedOverlay, final int color) {
        stack.method_22903();
        applyTopTransform(stack);
        topRenderer.method_22699(stack, consumer, packedLight, packedOverlay, color);
        stack.method_22909();

        stack.method_22903();
        stack.method_46416(0, baseY, 0);
        baseRenderer.method_22699(stack, consumer, packedLight, packedOverlay, color);
        coreRenderer.method_22699(stack, consumer, class_765.method_23687(15, 15), packedOverlay, color);
        stack.method_22909();
    }
}
