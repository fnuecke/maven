/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc;

import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.Parameter;
import li.cil.oc2.api.bus.device.object.RPCDeviceDescription;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.util.BlockLocation;
import li.cil.oc2.common.util.FakePlayerUtils;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2428;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_3218;
import javax.annotation.Nullable;

@RPCDeviceDescription(typeNames = {"note_block"}, description = """
    Provided by note blocks connected to a [bus interface](../block/bus_interface.md).

    The device changes what the note block is set to. It does not play it, use redstone signals for that.

    Note that the instrument configuration is transient. Environmental changes will override it back to its natural configuration.""")
public final class NoteBlockDevice extends IdentityProxy<BlockLocation> {
    private static final int MIN_NOTE = 0;
    private static final int MAX_NOTE = 24;

    // --------------------------------------------------------------------- //

    public NoteBlockDevice(final BlockLocation identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    @Callback(description = "Returns the note the block is tuned to.",
        returnValueDescription = "a note from `0` to `24`.")
    public int getNote() {
        return getNoteBlockState().method_11654(class_2428.field_11324);
    }

    @Callback(description = "Tunes the block to a note.")
    public void setNote(@Parameter(value = "note", description = "the note to tune to, from `0` to `24`.") final int note) {
        if (note < MIN_NOTE || note > MAX_NOTE) {
            throw new IllegalArgumentException("note must be between " + MIN_NOTE + " and " + MAX_NOTE);
        }

        setNoteBlockState(getNoteBlockState().method_11657(class_2428.field_11324, note));
    }

    @Callback(description = "Returns the name of the instrument the block plays.",
        returnValueDescription = "the instrument name, such as `harp` or `bit`.")
    public String getInstrument() {
        return getNoteBlockState().method_11654(class_2428.field_11325).method_15434();
    }

    @Callback(description = "Changes the instrument the block plays.")
    public void setInstrument(@Nullable @Parameter(value = "instrument", description = "the name of the instrument, such as `harp`, `bass`, `bell`, `chime`, `flute`, `guitar`, `pling`, `xylophone` or `bit`.") final String instrument) {
        if (instrument == null) {
            throw new IllegalArgumentException("instrument is required");
        }

        setNoteBlockState(getNoteBlockState().method_11657(class_2428.field_11325, toInstrument(instrument)));
    }

    // --------------------------------------------------------------------- //

    private static class_2766 toInstrument(final String name) {
        for (final class_2766 instrument : class_2766.values()) {
            if (instrument.method_15434().equals(name)) {
                return instrument;
            }
        }

        throw new IllegalArgumentException("instrument not found");
    }

    private class_2680 getNoteBlockState() {
        final class_2680 blockState = getLevel().method_8320(identity.blockPos());
        if (!blockState.method_27852(class_2246.field_10179)) {
            throw new IllegalStateException("no note block at this position");
        }

        return blockState;
    }

    private void setNoteBlockState(final class_2680 blockState) {
        final class_3218 level = getLevel();
        if (!level.method_8505(FakePlayerUtils.getFakePlayer(level), identity.blockPos())) {
            throw new IllegalStateException("not allowed");
        }

        level.method_8652(identity.blockPos(), blockState, class_2248.field_31036);
    }

    private class_3218 getLevel() {
        if (identity.tryGetLevel().orElse(null) instanceof final class_3218 level) {
            return level;
        }

        throw new IllegalStateException("level is not loaded");
    }
}
