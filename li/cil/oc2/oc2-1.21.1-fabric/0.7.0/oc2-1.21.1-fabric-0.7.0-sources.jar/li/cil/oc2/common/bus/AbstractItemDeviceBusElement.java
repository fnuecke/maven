/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.ItemDevice;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.common.bus.device.rpc.TypeNameRPCDevice;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.bus.device.util.ItemDeviceInfo;
import li.cil.oc2.common.util.ItemDeviceUtils;
import li.cil.oc2.common.util.NBTTagIds;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.*;

import static li.cil.oc2.common.bus.device.provider.Providers.optionalKey;

public abstract class AbstractItemDeviceBusElement extends AbstractGroupingDeviceBusElement<AbstractItemDeviceBusElement.ItemEntry> {
    public AbstractItemDeviceBusElement(final int groupCount) {
        super(groupCount);
    }

    // --------------------------------------------------------------------- //

    public boolean groupContains(final int groupIndex, final Device device) {
        for (final ItemEntry entry : groups.get(groupIndex)) {
            if (Objects.equals(entry.getDevice(), device)) {
                return true;
            }
        }

        return false;
    }

    public void handleSlotContentsChanged(final int slot, final class_1799 stack) {
        setEntriesForGroup(slot, collectDevices(stack));
    }

    public void exportDeviceDataToItemStack(final int slot, final class_1799 stack) {
        if (stack.method_7960()) {
            return;
        }

        final class_2487 exportedTag = new class_2487();
        for (final ItemEntry entry : groups.get(slot)) {
            entry.getDeviceDataKey().ifPresent(key -> {
                final class_2487 deviceTag = new class_2487();
                entry.getDevice().exportToItemStack(deviceTag);
                if (!deviceTag.method_33133()) {
                    exportedTag.method_10566(key, deviceTag);
                }
            });
        }

        if (!exportedTag.method_33133()) {
            ItemDeviceUtils.setItemDeviceData(stack, exportedTag);
        }
    }

    // --------------------------------------------------------------------- //

    protected abstract ItemDeviceQuery makeQuery(final class_1799 stack);

    protected Set<ItemEntry> collectDevices(final class_1799 stack) {
        final ItemDeviceQuery query = makeQuery(stack);
        final HashSet<ItemEntry> entries = new HashSet<>();

        for (final ItemDeviceInfo deviceInfo : Devices.getDevices(query)) {
            entries.add(new ItemEntry(deviceInfo));
        }

        collectSyntheticDevices(query, entries);

        importDeviceDataFromItemStack(query, entries);

        return entries;
    }

    protected void collectSyntheticDevices(final ItemDeviceQuery query, final HashSet<ItemEntry> entries) {
        if (entries.isEmpty()) {
            return;
        }

        final class_2960 registryName = class_7923.field_41178.method_10221(query.getItemStack().method_7909());
        if (registryName != null) {
            final String itemName = registryName.toString();
            entries.add(new ItemEntry(new ItemDeviceInfo(null, new TypeNameRPCDevice(itemName), 0)));
        }
    }

    // --------------------------------------------------------------------- //

    private void importDeviceDataFromItemStack(final ItemDeviceQuery query, final HashSet<ItemEntry> entries) {
        final class_2487 exportedTag = ItemDeviceUtils.getItemDeviceData(query.getItemStack());
        if (!exportedTag.method_33133()) {
            for (final ItemEntry entry : entries) {
                entry.getDeviceDataKey().ifPresent(key -> {
                    if (exportedTag.method_10573(key, NBTTagIds.TAG_COMPOUND)) {
                        entry.deviceInfo.device.importFromItemStack(exportedTag.method_10562(key));
                    }
                });
            }
        }
    }

    // --------------------------------------------------------------------- //

    protected record ItemEntry(ItemDeviceInfo deviceInfo) implements Entry {
        @Override
        public Optional<String> getDeviceDataKey() {
            return optionalKey(deviceInfo.provider);
        }

        @Override
        public OptionalInt getDeviceEnergyConsumption() {
            return OptionalInt.of(deviceInfo.getEnergyConsumption());
        }

        @Override
        public ItemDevice getDevice() {
            return deviceInfo.device;
        }
    }
}
