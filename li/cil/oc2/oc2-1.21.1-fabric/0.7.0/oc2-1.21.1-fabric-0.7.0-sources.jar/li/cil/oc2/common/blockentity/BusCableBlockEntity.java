/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.block.BusCableBlock;
import li.cil.oc2.common.bus.AbstractBlockDeviceBusElement;
import li.cil.oc2.common.bus.device.rpc.TypeNameRPCDevice;
import li.cil.oc2.common.bus.device.util.BlockDeviceInfo;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.BusCableFacadeMessage;
import li.cil.oc2.common.network.message.BusInterfaceNameMessage;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.LevelUtils;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.oc2.common.util.ServerScheduler;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_3544;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Objects;

import static java.util.Objects.requireNonNull;

public final class BusCableBlockEntity extends ModBlockEntity {
    public enum FacadeType {
        NOT_A_BLOCK,
        INVALID_BLOCK,
        VALID_BLOCK,
    }

    private static final String BUS_ELEMENT_TAG_NAME = "busElement";
    private static final String INTERFACE_NAMES_TAG_NAME = "interfaceNames";
    private static final String FACADE_TAG_NAME = "facade";

    // --------------------------------------------------------------------- //

    private final AbstractBlockDeviceBusElement busElement = new BusCableBusElement();
    private final String[] interfaceNames = new String[Constants.BLOCK_FACE_COUNT];
    private final NeighborTracker[] neighborTrackers = new NeighborTracker[Constants.BLOCK_FACE_COUNT];
    private class_1799 facade = class_1799.field_8037;

    // --------------------------------------------------------------------- //

    public BusCableBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.BUS_CABLE.get(), pos, state);

        for (final class_2350 side : class_2350.values()) {
            neighborTrackers[side.method_10146()] = new NeighborTracker(side);
        }
    }

    // --------------------------------------------------------------------- //

    public String getInterfaceName(final class_2350 side) {
        final String interfaceName = interfaceNames[side.method_10146()];
        return interfaceName == null ? "" : interfaceName;
    }

    public void setInterfaceName(final class_2350 side, final String name) {
        if (field_11863 == null) {
            return;
        }

        final String validatedName = validateName(name);
        if (Objects.equals(validatedName, interfaceNames[side.method_10146()])) {
            return;
        }

        interfaceNames[side.method_10146()] = validatedName;
        method_5431();

        if (!field_11863.method_8608()) {
            final BusInterfaceNameMessage message = new BusInterfaceNameMessage.ToClient(this, side, interfaceNames[side.method_10146()]);
            Network.sendToClientsTrackingBlockEntity(message, this);
            busElement.updateDevicesForNeighbor(side);
        }
    }

    public FacadeType getFacadeType(final class_1799 stack) {
        return getFacadeType(ItemStackUtils.getBlockState(stack));
    }

    public FacadeType getFacadeType(@Nullable final class_2680 state) {
        if (state == null) {
            return FacadeType.NOT_A_BLOCK;
        }

        if (field_11863 == null ||
            state.method_26217() != class_2464.field_11458 ||
            !state.method_26216(field_11863, method_11016()) ||
            state.method_26204() instanceof class_2343) {
            return FacadeType.INVALID_BLOCK;
        }

        return FacadeType.VALID_BLOCK;
    }

    public class_1799 getFacade() {
        return facade;
    }

    public void setFacade(final class_1799 stack) {
        if (field_11863 == null) {
            return;
        }

        if (stack.method_7960()) {
            removeFacade();
            return;
        }

        final class_2680 facadeState = ItemStackUtils.getBlockState(stack);
        if (getFacadeType(facadeState) != FacadeType.VALID_BLOCK
            || class_1799.method_31577(stack, facade)) {
            return;
        }

        facade = stack.method_7972();
        facade.method_7939(1);
        BusCableBlock.setHasFacade(field_11863, method_11016(), method_11010(), facadeState, true);

        method_5431();
        field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);

        if (!field_11863.method_8608()) {
            final BusCableFacadeMessage message = new BusCableFacadeMessage(method_11016(), facade);
            Network.sendToClientsTrackingBlockEntity(message, this);
        }
    }

    public void removeFacade() {
        if (field_11863 == null || facade.method_7960()) {
            return;
        }

        final class_2680 facadeState = ItemStackUtils.getBlockState(facade);
        facade = class_1799.field_8037;
        BusCableBlock.setHasFacade(field_11863, method_11016(), method_11010(), facadeState, false);

        method_5431();
        field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);

        if (!field_11863.method_8608()) {
            final BusCableFacadeMessage message = new BusCableFacadeMessage(method_11016(), facade);
            Network.sendToClientsTrackingBlockEntity(message, this);
        }
    }

    public void handleNeighborChanged(final class_2338 pos) {
        final class_2338 toPos = pos.method_10059(method_11016());
        final class_2350 side = class_2350.method_50026(toPos.method_10263(), toPos.method_10264(), toPos.method_10260());
        if (side != null) {
            busElement.updateDevicesForNeighbor(side);
        }
    }

    public void handleConfigurationChanged(@Nullable final class_2350 side, final boolean neighborConnectivityChanged) {
        if (side != null) {
            // Whenever the type changes we can clear it. Technically only needed
            // for the interface->none transition, but all others are no-ops, so
            // we can just do this.
            setInterfaceName(side, "");

            Capabilities.invalidate(this);

            final NeighborTracker tracker = neighborTrackers[side.method_10146()];
            tracker.updateListener();
            tracker.scheduleNeighborDeviceUpdate();
        }

        if (neighborConnectivityChanged) {
            busElement.scheduleScan();
        }
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);

        tag.method_10566(INTERFACE_NAMES_TAG_NAME, serializeInterfaceNames());
        tag.method_10566(FACADE_TAG_NAME, facade.method_57375(registries));

        return tag;
    }


    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10566(BUS_ELEMENT_TAG_NAME, busElement.save());
        tag.method_10566(INTERFACE_NAMES_TAG_NAME, serializeInterfaceNames());
        tag.method_10566(FACADE_TAG_NAME, facade.method_57375(registries));
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        busElement.load(tag.method_10562(BUS_ELEMENT_TAG_NAME));
        deserializeInterfaceNames(tag.method_10554(INTERFACE_NAMES_TAG_NAME, NBTTagIds.TAG_STRING));
        facade = class_1799.method_57359(registries, tag.method_10562(FACADE_TAG_NAME));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        if (BusCableBlock.getConnectionType(method_11010(), direction) != BusCableBlock.ConnectionType.NONE) {
            collector.offer(Capabilities.DEVICE_BUS_ELEMENT, busElement);
        }
    }

    @Override
    protected void loadServer() {
        super.loadServer();

        for (final NeighborTracker tracker : neighborTrackers) {
            tracker.updateListener();
            tracker.scheduleNeighborDeviceUpdate();
        }
    }

    @Override
    protected void loadServerInLoadedLevel() {
        super.loadServerInLoadedLevel();

        scanAdjacentBusElements();
    }

    @Override
    protected void unloadServer(final boolean isRemove) {
        super.unloadServer(isRemove);

        if (isRemove) {
            busElement.setRemoved();
        }

        for (final NeighborTracker tracker : neighborTrackers) {
            tracker.close();
        }
    }

    // --------------------------------------------------------------------- //

    private class_2499 serializeInterfaceNames() {
        final class_2499 tag = new class_2499();
        for (int i = 0; i < Constants.BLOCK_FACE_COUNT; i++) {
            tag.add(class_2519.method_23256(getInterfaceName(class_2350.method_10143(i))));
        }
        return tag;
    }

    private void deserializeInterfaceNames(final class_2499 tag) {
        for (int i = 0; i < Constants.BLOCK_FACE_COUNT; i++) {
            final String name = tag.method_10608(i).trim();
            interfaceNames[i] = name.substring(0, Math.min(32, name.length()));
        }
    }

    private static String validateName(final String name) {
        final String trimmed = name.trim();
        return trimmed.length() > 32 ? trimmed.substring(0, 32) : trimmed;
    }

    private void scanAdjacentBusElements() {
        final class_1937 level = requireNonNull(method_10997());
        final class_2338 pos = method_11016();
        for (final class_2350 direction : Constants.DIRECTIONS) {
            final class_2338 neighborPos = pos.method_10093(direction);
            final class_2586 blockEntity = LevelUtils.getBlockEntityIfChunkExists(level, neighborPos);
            if (blockEntity == null) {
                continue;
            }

            final DeviceBusElement busElement = Capabilities.get(blockEntity, Capabilities.DEVICE_BUS_ELEMENT, direction.method_10153());
            if (busElement != null) {
                busElement.scheduleScan();
            }
        }
    }

    // --------------------------------------------------------------------- //

    private final class BusCableBusElement extends AbstractBlockDeviceBusElement {
        @Nullable
        @Override
        public class_1936 getLevel() {
            return BusCableBlockEntity.this.method_10997();
        }

        @Override
        public class_2338 getPosition() {
            return method_11016();
        }

        @Override
        public boolean canScanContinueTowards(@Nullable final class_2350 direction) {
            final BusCableBlock.ConnectionType connectionType = BusCableBlock.getConnectionType(method_11010(), direction);
            return connectionType == BusCableBlock.ConnectionType.CABLE ||
                connectionType == BusCableBlock.ConnectionType.INTERFACE;
        }

        @Override
        public boolean canDetectDevicesTowards(@Nullable final class_2350 direction) {
            final BusCableBlock.ConnectionType connectionType = BusCableBlock.getConnectionType(method_11010(), direction);
            return connectionType == BusCableBlock.ConnectionType.INTERFACE;
        }

        @Override
        protected void collectSyntheticDevices(final class_1936 level, final class_2338 pos, @Nullable final class_2350 side, final HashSet<BlockEntry> entries) {
            super.collectSyntheticDevices(level, pos, side, entries);

            if (side == null || entries.isEmpty()) {
                return;
            }

            final String interfaceName = interfaceNames[side.method_10146()];
            if (!class_3544.method_15438(interfaceName)) {
                entries.add(new BlockEntry(new BlockDeviceInfo(null, new TypeNameRPCDevice(interfaceName)), side));
            }
        }

        @Override
        public double getEnergyConsumption() {
            return super.getEnergyConsumption()
                + Config.busCableEnergyPerTick
                + BusCableBlock.getInterfaceCount(method_11010()) * Config.busInterfaceEnergyPerTick;
        }
    }

    /**
     * Utility class to track neighboring blocks, per side.
     * <p>
     * Since we manage devices for blocks that may not even be aware of this, we need to actively
     * track their presence and state. There are to major cases:
     * <ul>
     * <li>The neighboring block is in the same chunk as the cable. In this case, we only need to
     * listen to neighbor block changes (via {@link #handleNeighborChanged(class_2338)}).</li>
     * <li>The neighboring block is in another chunk as the cable. In this case, we also need to
     * track chunk load status, since we won't get any other event in case the block gets
     * loaded or unloaded.</li>
     * </ul>
     * The second case is handled by this class.
     * <p>
     * To avoid unnecessary overhead, we only track neighbors which actually are in another chunk,
     * and to which this cable has a Bus Interface. As such, configuration changes need to update
     * listeners. This is done in {@link #handleConfigurationChanged(class_2350, boolean)} by calling
     * {@link #updateListener()}.
     * <p>
     * We initialize our state from {@link #loadServer()}, where all trackers are updated.
     */
    private final class NeighborTracker implements AutoCloseable {
        private final Runnable onChunkLoadedStateChanged = this::handleChunkLoadOrUnload;

        final class_2350 side;
        final class_2754<BusCableBlock.ConnectionType> connectionProperty;
        private final class_1923 chunkPos;
        private final boolean isSameChunk;
        private boolean hasRegisteredListener;
        private boolean hasScheduledUpdate;

        public NeighborTracker(final class_2350 side) {
            this.side = side;
            connectionProperty = BusCableBlock.FACING_TO_CONNECTION_MAP.get(side);
            chunkPos = new class_1923(method_11016().method_10093(side));
            isSameChunk = Objects.equals(new class_1923(method_11016()), chunkPos);
        }

        public void close() {
            removeListener();
        }

        public void scheduleNeighborDeviceUpdate() {
            if (field_11863 != null && !hasScheduledUpdate) {
                ServerScheduler.schedule(field_11863, this::updateNeighborDevices);
                hasScheduledUpdate = true;
            }
        }

        public void updateListener() {
            if (isSameChunk) {
                return;
            }

            final boolean needsListener = method_11010().method_11654(connectionProperty) == BusCableBlock.ConnectionType.INTERFACE;
            if (needsListener && !hasRegisteredListener) {
                addListener();
            } else if (!needsListener && hasRegisteredListener) {
                removeListener();
            }
        }

        private void addListener() {
            if (field_11863 != null && !hasRegisteredListener) {
                ServerScheduler.subscribeOnLoad(field_11863, chunkPos, onChunkLoadedStateChanged);
                ServerScheduler.subscribeOnUnload(field_11863, chunkPos, onChunkLoadedStateChanged);
            }
            hasRegisteredListener = true;
        }

        private void removeListener() {
            if (field_11863 != null && hasRegisteredListener) {
                ServerScheduler.unsubscribeOnLoad(field_11863, chunkPos, onChunkLoadedStateChanged);
                ServerScheduler.unsubscribeOnUnload(field_11863, chunkPos, onChunkLoadedStateChanged);
            }
            hasRegisteredListener = false;
        }

        private void handleChunkLoadOrUnload() {
            // Don't directly run a device update, as this may cause deadlocks.
            scheduleNeighborDeviceUpdate();
        }

        private void updateNeighborDevices() {
            if (isValid()) {
                busElement.updateDevicesForNeighbor(side);
            }
            hasScheduledUpdate = false;
        }
    }
}
