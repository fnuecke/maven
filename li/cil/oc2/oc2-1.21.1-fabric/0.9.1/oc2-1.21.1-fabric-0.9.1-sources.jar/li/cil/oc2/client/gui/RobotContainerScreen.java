/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.architectury.hooks.fluid.FluidStackHooks;
import li.cil.oc2.client.gui.util.TooltipRenderer;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.container.RobotInventoryContainer;
import li.cil.oc2.common.fluid.FluidStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_757;
import java.util.List;

import static li.cil.oc2.common.util.TextFormatUtils.withFormat;

@Environment(EnvType.CLIENT)
public final class RobotContainerScreen extends AbstractMachineInventoryScreen<RobotInventoryContainer> {
    private static final int SLOT_SIZE = 18;
    private static final int INVENTORY_X = 115;
    private static final int INVENTORY_Y = 19;
    private static final int INVENTORY_COLUMNS = 3;
    private static final int TANK_X = 116;
    private static final int TANK_Y = 94;
    private static final int TANK_WIDTH = 52;
    private static final int TANK_HEIGHT = 5;
    private static final int FLUID_SPRITE_SIZE = 16;

    // --------------------------------------------------------------------- //

    public static void renderSelection(final class_332 graphics, final int selectedSlot, final int x, final int y, final int columns) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1, 1, 1, 1);

        final int slotX = selectedSlot % columns * SLOT_SIZE;
        final int slotY = selectedSlot / columns * SLOT_SIZE;
        final int offset = SLOT_SIZE * (int) (15 * (System.currentTimeMillis() % 1000) / 1000);
        Sprites.SLOT_SELECTION.draw(graphics, x + slotX, y + slotY, 0, offset);
    }

    // --------------------------------------------------------------------- //

    public RobotContainerScreen(final RobotInventoryContainer container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title);
        field_2792 = Sprites.ROBOT_CONTAINER.width;
        field_2779 = Sprites.ROBOT_CONTAINER.height;
        field_25270 = field_2779 - 94;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        super.method_2389(graphics, partialTicks, mouseX, mouseY);

        Sprites.ROBOT_CONTAINER.draw(graphics, field_2776, field_2800);
        renderSelection(graphics, field_2797.getRobot().getSelectedSlot(), field_2776 + INVENTORY_X, field_2800 + INVENTORY_Y, INVENTORY_COLUMNS);
        renderTank(graphics);
    }

    @Override
    protected void method_2380(final class_332 graphics, final int mouseX, final int mouseY) {
        super.method_2380(graphics, mouseX, mouseY);

        if (isMouseOver(mouseX, mouseY, TANK_X, TANK_Y, TANK_WIDTH, TANK_HEIGHT)) {
            final FluidStack fluid = field_2797.getFluid();
            final class_2561 name = fluid.isEmpty()
                ? class_2561.method_43471(Constants.TOOLTIP_FLUID_EMPTY)
                : FluidStackHooks.getName(toArchitectury(fluid));
            final class_2561 tooltip = class_2561.method_43469(Constants.TOOLTIP_FLUID, name,
                withFormat(fluid.amount() + "/" + field_2797.getFluidCapacity(), class_124.field_1060));
            TooltipRenderer.drawTooltip(graphics, List.of(tooltip), mouseX, mouseY, 200);
        }
    }

    // --------------------------------------------------------------------- //

    private void renderTank(final class_332 graphics) {
        final FluidStack fluid = field_2797.getFluid();
        if (fluid.isEmpty()) {
            return;
        }

        final var stack = toArchitectury(fluid);
        final var sprite = FluidStackHooks.getStillTexture(stack);
        if (sprite == null) {
            return;
        }

        final int color = FluidStackHooks.getColor(stack);
        final float r = ((color >> 16) & 0xFF) / 255f;
        final float g = ((color >> 8) & 0xFF) / 255f;
        final float b = (color & 0xFF) / 255f;

        final int x = field_2776 + TANK_X;
        final int y = field_2800 + TANK_Y;
        final int width = Math.max(1, TANK_WIDTH * fluid.amount() / field_2797.getFluidCapacity());

        // Animated atlas sprites don't do tiling, so we hack around it like this, oh well.
        graphics.method_44379(x, y, x + width, y + TANK_HEIGHT);
        for (int offset = 0; offset < width; offset += FLUID_SPRITE_SIZE) {
            graphics.method_48465(x + offset, y, 0, FLUID_SPRITE_SIZE, FLUID_SPRITE_SIZE, sprite, r, g, b, 1);
        }
        graphics.method_44380();
    }

    private static dev.architectury.fluid.FluidStack toArchitectury(final FluidStack fluid) {
        return dev.architectury.fluid.FluidStack.create(fluid.fluid(), fluid.amount(), fluid.components());
    }
}
