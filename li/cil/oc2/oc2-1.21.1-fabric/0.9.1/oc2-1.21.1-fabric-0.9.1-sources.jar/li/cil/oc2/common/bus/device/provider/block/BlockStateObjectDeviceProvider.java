/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.object.Callbacks;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockDeviceProvider;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import java.util.Optional;

public final class BlockStateObjectDeviceProvider extends AbstractBlockDeviceProvider {
    @Override
    public Optional<Device> getDevice(final BlockDeviceQuery query) {
        final class_1936 level = query.getLevel();
        final class_2338 position = query.getQueryPosition();

        final class_2680 blockState = level.method_8320(position);

        if (blockState.method_26215()) {
            return Optional.empty();
        }

        final class_2248 block = blockState.method_26204();
        if (!Callbacks.hasMethods(block)) {
            return Optional.empty();
        }

        return Optional.of(new ObjectDevice(block));
    }
}
