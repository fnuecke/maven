/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.util;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityCache;
import li.cil.oc2.common.capabilities.CapabilityType;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import java.util.Optional;

public abstract class AbstractBlockEntityCapabilityDeviceProvider<TCapability, TBlockEntity extends class_2586> extends AbstractBlockEntityDeviceProvider<TBlockEntity> {
    private final CapabilityType<TCapability> capability;

    // --------------------------------------------------------------------- //

    protected AbstractBlockEntityCapabilityDeviceProvider(final class_2591<TBlockEntity> blockEntityType, final CapabilityType<TCapability> capability) {
        super(blockEntityType);
        this.capability = capability;
    }

    protected AbstractBlockEntityCapabilityDeviceProvider(final CapabilityType<TCapability> capability) {
        this.capability = capability;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected final Optional<Device> getBlockDevice(final BlockDeviceQuery query, final class_2586 blockEntity) {
        return Capabilities.cache(query.getLevel(), blockEntity.method_11016(), query.getQuerySide(), capability)
            .flatMap(value -> getBlockDevice(query, value));
    }

    protected abstract Optional<Device> getBlockDevice(final BlockDeviceQuery query, final CapabilityCache<TCapability> value);
}
