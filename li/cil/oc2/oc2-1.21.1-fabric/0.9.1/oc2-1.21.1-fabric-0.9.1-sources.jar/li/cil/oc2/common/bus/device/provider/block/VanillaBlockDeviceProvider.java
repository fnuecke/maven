/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockDeviceProvider;
import li.cil.oc2.common.util.BlockLocation;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import java.lang.ref.WeakReference;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Function;

public final class VanillaBlockDeviceProvider extends AbstractBlockDeviceProvider {
    private final BiPredicate<class_1936, class_2338> predicate;
    private final Function<BlockLocation, Object> factory;

    // --------------------------------------------------------------------- //

    public static VanillaBlockDeviceProvider of(final class_2248 block, final Function<BlockLocation, Object> factory) {
        return new VanillaBlockDeviceProvider((level, pos) -> level.method_8320(pos).method_27852(block), factory);
    }

    public static VanillaBlockDeviceProvider of(final Class<? extends class_2586> type, final Function<BlockLocation, Object> factory) {
        return new VanillaBlockDeviceProvider((level, pos) -> type.isInstance(level.method_8321(pos)), factory);
    }

    private VanillaBlockDeviceProvider(final BiPredicate<class_1936, class_2338> predicate, final Function<BlockLocation, Object> factory) {
        this.predicate = predicate;
        this.factory = factory;
    }

    // --------------------------------------------------------------------- //

    @Override
    public Optional<Device> getDevice(final BlockDeviceQuery query) {
        if (!predicate.test(query.getLevel(), query.getQueryPosition())) {
            return Optional.empty();
        }

        final BlockLocation location = new BlockLocation(new WeakReference<>(query.getLevel()), query.getQueryPosition());
        return Optional.of(new ObjectDevice(factory.apply(location)));
    }
}
