/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.util;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import java.util.Optional;

public abstract class AbstractBlockEntityDeviceProvider<T extends class_2586> extends AbstractBlockDeviceProvider {
    private final class_2591<T> blockEntityType;

    // --------------------------------------------------------------------- //

    protected AbstractBlockEntityDeviceProvider(final class_2591<T> blockEntityType) {
        this.blockEntityType = blockEntityType;
    }

    protected AbstractBlockEntityDeviceProvider() {
        this.blockEntityType = null;
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("unchecked")
    @Override
    public final Optional<Device> getDevice(final BlockDeviceQuery query) {
        final class_2586 blockEntity = query.getLevel().method_8321(query.getQueryPosition());
        if (blockEntity == null) {
            return Optional.empty();
        }

        if (blockEntityType != null && blockEntity.method_11017() != blockEntityType) {
            return Optional.empty();
        }

        return getBlockDevice(query, (T) blockEntity);
    }

    // --------------------------------------------------------------------- //

    protected abstract Optional<Device> getBlockDevice(final BlockDeviceQuery query, final T blockEntity);
}
