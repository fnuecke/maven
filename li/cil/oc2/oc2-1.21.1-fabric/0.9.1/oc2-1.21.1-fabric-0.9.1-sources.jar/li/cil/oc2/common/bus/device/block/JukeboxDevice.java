/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.block;

import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.IOCallback;
import li.cil.oc2.api.bus.device.object.IODeviceDescription;
import li.cil.oc2.api.bus.device.object.RPCDeviceDescription;
import li.cil.oc2.common.util.BlockLocation;
import net.minecraft.class_2619;
import net.minecraft.class_2960;
import net.minecraft.class_7924;
import net.minecraft.class_9793;
import net.minecraft.class_9794;
import javax.annotation.Nullable;
import java.io.IOException;
import java.util.Objects;

@RPCDeviceDescription(typeName = "jukebox", description = """
    Provided by jukeboxes connected to a [bus interface](../block/bus_interface.md). Times are in ticks.""")
@IODeviceDescription(name = "JUKEBX", description = """
    Times are two bytes, low byte first, capped at 65535.""")
public final class JukeboxDevice extends AbstractBlockDevice {
    private static final int IS_PLAYING_CODE = 1;
    private static final int GET_SONG_CODE = 2;
    private static final int GET_SONG_LENGTH_CODE = 3;
    private static final int GET_ELAPSED_CODE = 4;

    // --------------------------------------------------------------------- //

    public JukeboxDevice(final BlockLocation identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    @Callback(description = "Gets whether the jukebox is playing a song.",
        returnValueDescription = "whether a track is playing.")
    public boolean isPlaying() {
        return getPlayer().method_60754();
    }

    @Callback(description = "Gets the song the jukebox is playing.",
        returnValueDescription = "the name of the song, such as `minecraft:cat`, if any.")
    @Nullable
    public String getSong() {
        final class_9793 song = getPlayer().method_60759();
        if (song == null) {
            return null;
        }

        final class_2960 key = getServerLevel().method_30349().method_30530(class_7924.field_52176).method_10221(song);
        return key == null ? null : key.toString();
    }

    @Callback(description = "Gets how long the song the jukebox is playing lasts.",
        returnValueDescription = "the length of the song.")
    public int getSongLength() {
        final class_9793 song = getPlayer().method_60759();
        return song == null ? 0 : song.method_60750();
    }

    @Callback(description = "Gets how long the jukebox has been playing the current song.",
        returnValueDescription = "the time since the song started.")
    public int getElapsed() {
        final class_9794 player = getPlayer();
        return player.method_60754() ? (int) player.method_60761() : 0;
    }

    // --------------------------------------------------------------------- //

    @IOCallback(value = IS_PLAYING_CODE,
        description = "Gets whether the jukebox is playing a song.",
        resultsDescription = "one byte, `1` while a track is playing, `0` otherwise.")
    public void isPlaying(final IOOutputStream results) throws IOException {
        results.writeU8(isPlaying() ? 1 : 0);
    }

    @IOCallback(value = GET_SONG_CODE,
        description = "Gets the song the jukebox is playing.",
        resultsDescription = "the name of the song, such as `minecraft:cat`, if any. Read while `OCDAV` is set to read fully.")
    public void getSong(final IOOutputStream results) throws IOException {
        results.writeString(Objects.requireNonNullElse(getSong(), ""));
    }

    @IOCallback(value = GET_SONG_LENGTH_CODE,
        description = "Reads how long the song the jukebox is playing lasts.",
        resultsDescription = "two bytes, the length of the song.")
    public void getSongLength(final IOOutputStream results) throws IOException {
        results.writeU16(Math.min(getSongLength(), 0xFFFF));
    }

    @IOCallback(value = GET_ELAPSED_CODE,
        description = "Reads how long the jukebox has been playing the current song.",
        resultsDescription = "two bytes, the time since the song started.")
    public void getElapsed(final IOOutputStream results) throws IOException {
        results.writeU16(Math.min(getElapsed(), 0xFFFF));
    }

    // --------------------------------------------------------------------- //

    private class_9794 getPlayer() {
        return getBlockEntity(class_2619.class).method_60784();
    }
}
