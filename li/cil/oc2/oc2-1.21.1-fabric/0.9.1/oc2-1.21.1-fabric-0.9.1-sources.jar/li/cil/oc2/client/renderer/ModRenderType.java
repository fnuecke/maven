/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.api.API;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_757;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public abstract class ModRenderType extends class_1921 {
    private static final class_2960 WHITE_TEXTURE = class_2960.method_60655(API.MOD_ID, "textures/misc/white.png");

    private static final class_1921 INDICATOR = method_24049(
        API.MOD_ID + "/indicator",
        class_290.field_1576,
        class_293.class_5596.field_27382,
        256,
        false,
        false,
        class_4688.method_23598()
            .method_34578(field_29442)
            .method_34577(field_21378)
            .method_23615(field_21364)
            .method_23607(field_21353)
            .method_23617(false));

    private static final class_1921 GLOW = method_24049(
        API.MOD_ID + "/glow",
        class_290.field_1576,
        class_293.class_5596.field_27382,
        256,
        false,
        false,
        class_4688.method_23598()
            .method_34578(field_29442)
            .method_34577(field_21378)
            .method_23615(field_21366)
            .method_23616(field_21350)
            .method_23617(false));

    private static final class_1921 PROJECTOR_LIGHT = method_24049(
        API.MOD_ID + "/projector_light",
        class_290.field_1576,
        class_293.class_5596.field_27382,
        256,
        false,
        true,
        class_4688.method_23598()
            .method_34578(field_29429)
            .method_23615(field_21367)
            .method_23616(field_21350)
            .method_23603(field_21345)
            .method_23617(false));

    private static final Function<class_2960, class_1921> UNLIT_BLOCK = class_156.method_34866(location -> method_24049(
        API.MOD_ID + "/unlit_block/" + location,
        class_290.field_1585,
        class_293.class_5596.field_27382,
        256,
        false,
        true,
        class_4688.method_23598()
            .method_34578(field_29440)
            .method_34577(new class_4683(location, false, true))
            .method_23615(field_21366)
            .method_23603(field_21345)
            .method_23617(false)));

    private static final Function<class_2960, class_1921> OVERLAY = class_156.method_34866(location -> method_24049(
        API.MOD_ID + "/overlay/" + location,
        class_290.field_1585,
        class_293.class_5596.field_27382,
        256,
        false,
        true,
        class_4688.method_23598()
            .method_34578(field_29440)
            .method_34577(new class_4683(location, false, true))
            .method_23615(field_21366)
            .method_23617(false)));

    private static final class_4685 PREMULTIPLIED_TRANSPARENCY = new class_4685(
        API.MOD_ID + ":premultiplied_transparency",
        () -> {
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(
                GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA,
                GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        },
        () -> {
            RenderSystem.disableBlend();
            RenderSystem.defaultBlendFunc();
        });

    private static final class_1921 TERMINAL_SCREEN = method_24049(
        API.MOD_ID + "/terminal_screen",
        class_290.field_1575,
        class_293.class_5596.field_27382,
        256,
        false,
        false,
        class_4688.method_23598()
            .method_34578(new class_5942(class_757::method_34543))
            .method_34577(field_21378)
            .method_23615(PREMULTIPLIED_TRANSPARENCY)
            .method_23617(false));

    // --------------------------------------------------------------------- //

    public static class_1921 getNetworkCable() {
        return method_23578(WHITE_TEXTURE);
    }

    public static class_1921 getIndicator() {
        return INDICATOR;
    }

    public static class_1921 getGlow() {
        return GLOW;
    }

    public static class_1921 getProjectorLight() {
        return PROJECTOR_LIGHT;
    }

    public static class_1921 getUnlitBlock(final class_2960 location) {
        return UNLIT_BLOCK.apply(location);
    }

    public static class_1921 getOverlay(final class_2960 location) {
        return OVERLAY.apply(location);
    }

    public static class_1921 getTerminalScreen() {
        return TERMINAL_SCREEN;
    }

    // --------------------------------------------------------------------- //

    private ModRenderType(final String name, final class_293 format, final class_293.class_5596 drawMode, final int bufferSize, final boolean useDelegate, final boolean needsSorting, final Runnable setupTask, final Runnable clearTask) {
        super(name, format, drawMode, bufferSize, useDelegate, needsSorting, setupTask, clearTask);
    }
}
