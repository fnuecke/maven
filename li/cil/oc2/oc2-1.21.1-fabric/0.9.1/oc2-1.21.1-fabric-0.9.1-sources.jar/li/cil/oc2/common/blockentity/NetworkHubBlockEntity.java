/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.capabilities.NetworkInterface;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.capabilities.Capabilities;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import javax.annotation.Nullable;
import java.util.Arrays;

public final class NetworkHubBlockEntity extends ModBlockEntity implements NetworkInterface {
    private static final int TTL_COST = 1;

    private int frameCount;
    private long lastGameTime;

    // --------------------------------------------------------------------- //

    private final NetworkInterface[] adjacentBlockInterfaces = new NetworkInterface[Constants.BLOCK_FACE_COUNT];
    private final Capabilities.InvalidationHandle[] adjacentBlockHandles = new Capabilities.InvalidationHandle[Constants.BLOCK_FACE_COUNT];
    private boolean haveAdjacentBlocksChanged = true;

    // --------------------------------------------------------------------- //

    public NetworkHubBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.NETWORK_HUB.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    public void handleNeighborChanged() {
        haveAdjacentBlocksChanged = true;
    }

    @Override
    @Nullable
    public byte[] readEthernetFrame() {
        return null;
    }

    @Override
    public void writeEthernetFrame(final NetworkInterface source, final byte[] frame, final int timeToLive) {
        if (field_11863 == null) {
            return;
        }

        // Give a cap on top of the TLL, just in case trolls intentionally build
        // loops that exponentially multiply ethernet frames after people crank up
        // the default TTL.
        final long gameTime = field_11863.method_8510();
        if (gameTime > lastGameTime) {
            lastGameTime = gameTime;
            frameCount = 1;
        } else if (frameCount > Config.hubEthernetFramesPerTick) {
            return;
        } else {
            frameCount++;
        }

        validateAdjacentBlocks();

        for (final NetworkInterface adjacentInterface : adjacentBlockInterfaces) {
            if (adjacentInterface != null && adjacentInterface != source) {
                adjacentInterface.writeEthernetFrame(this, frame, timeToLive - TTL_COST);
            }
        }
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.NETWORK_INTERFACE, this);
    }

    // --------------------------------------------------------------------- //

    private void validateAdjacentBlocks() {
        if (!isValid() || !haveAdjacentBlocksChanged) {
            return;
        }

        for (final var handle : adjacentBlockHandles) {
            if (handle != null) {
                handle.drop();
            }
        }
        Arrays.fill(adjacentBlockHandles, null);
        Arrays.fill(adjacentBlockInterfaces, null);

        haveAdjacentBlocksChanged = false;

        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        final class_2338 pos = method_11016();
        for (final class_2350 side : Constants.DIRECTIONS) {
            final class_2338 neighborPos = pos.method_10093(side);
            adjacentBlockHandles[side.method_10146()] = Capabilities.listen((class_3218) field_11863, neighborPos, () -> haveAdjacentBlocksChanged = true);
            if (field_11863.method_8477(neighborPos)) {
                adjacentBlockInterfaces[side.method_10146()] = Capabilities.get(field_11863, neighborPos, Capabilities.NETWORK_INTERFACE, side.method_10153());
            }
        }
    }
}
