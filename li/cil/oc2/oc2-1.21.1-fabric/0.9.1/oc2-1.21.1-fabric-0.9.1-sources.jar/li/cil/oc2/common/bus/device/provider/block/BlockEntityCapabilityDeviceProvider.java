/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockEntityDeviceProvider;
import li.cil.oc2.common.capabilities.Capabilities;
import net.minecraft.class_2586;
import java.util.Optional;

public final class BlockEntityCapabilityDeviceProvider extends AbstractBlockEntityDeviceProvider<class_2586> {
    @Override
    protected Optional<Device> getBlockDevice(final BlockDeviceQuery query, final class_2586 blockEntity) {
        return Optional.ofNullable(Capabilities.get(blockEntity, Capabilities.DEVICE, query.getQuerySide()));
    }
}
