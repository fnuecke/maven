/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.IOCallback;
import li.cil.oc2.api.bus.device.object.IODeviceDescription;
import li.cil.oc2.api.bus.device.object.RPCDeviceDescription;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.energy.EnergyHandler;
import li.cil.oc2.common.energy.FixedEnergyHandler;
import li.cil.oc2.common.inventory.ItemHandler;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.ChargerStateMessage;
import li.cil.oc2.common.util.ChunkUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.io.IOException;
import java.util.List;
import java.util.function.Predicate;


@RPCDeviceDescription(typeName = "charger", description = "Provided by the [charger](../block/charger.md) block.")
@IODeviceDescription(name = "CHARGR")
public final class ChargerBlockEntity extends ModBlockEntity implements TickableBlockEntity {
    private static final String HAS_ENERGY_TAG_NAME = "has_energy";

    private static final int IS_CHARGING_CODE = 1;

    private static final Predicate<class_1297> ENTITY_PREDICATE =
        class_1301.field_6155
            .and(class_1301.field_6154);

    // --------------------------------------------------------------------- //

    private final FixedEnergyHandler energy = new FixedEnergyHandler(Config.chargerEnergyStorage);
    private boolean hasEnergy;
    private boolean isCharging;
    private final class_238 renderBoundingBox;

    // --------------------------------------------------------------------- //

    ChargerBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.CHARGER.get(), pos, state);
        renderBoundingBox = new class_238(pos).method_1012(0, 1, 0);
    }

    // --------------------------------------------------------------------- //

    public boolean hasEnergy() {
        return hasEnergy;
    }

    public void setHasEnergyClient(final boolean value) {
        hasEnergy = value;
    }

    @Callback(description = "Gets whether the charger is currently transferring energy to something on top of it.",
        returnValueDescription = "whether energy is being transferred.")
    public boolean isCharging() {
        return isCharging;
    }

    @IOCallback(value = IS_CHARGING_CODE,
        description = "Gets whether the charger is currently transferring energy to something on top of it.",
        resultsDescription = "one byte, `1` if energy is being transferred, `0` otherwise.")
    public void isCharging(final IOOutputStream results) throws IOException {
        results.writeU8(isCharging ? 1 : 0);
    }

    @Override
    public void serverTick() {
        if (field_11863 == null) {
            return;
        }

        isCharging = false;
        final boolean hasEnergy = energy.getEnergyStored() > 0;
        if (hasEnergy) {
            chargeBlock();
            chargeEntities();
        }

        if (hasEnergy != this.hasEnergy) {
            this.hasEnergy = hasEnergy;
            Network.sendToClientsTrackingBlockEntity(new ChargerStateMessage(this, this.hasEnergy), this);
        }

        if (isCharging) {
            ChunkUtils.setLazyUnsaved(field_11863, method_11016());
        }
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);

        tag.method_10556(HAS_ENERGY_TAG_NAME, hasEnergy);

        return tag;
    }

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10566(Constants.ENERGY_TAG_NAME, energy.serializeNBT());
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        energy.deserializeNBT(tag.method_10562(Constants.ENERGY_TAG_NAME));
        hasEnergy = tag.method_10577(HAS_ENERGY_TAG_NAME);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.ENERGY_STORAGE, energy);
    }

    // --------------------------------------------------------------------- //

    private void chargeBlock() {
        assert field_11863 != null;

        final class_2586 blockEntity = field_11863.method_8321(method_11016().method_10084());
        if (blockEntity != null) {
            chargeBlockEntity(blockEntity);
        }
    }

    private void chargeEntities() {
        assert field_11863 != null;

        final List<class_1297> entities = field_11863.method_8333((class_1297) null, new class_238(method_11016().method_10084()), ENTITY_PREDICATE);
        for (final class_1297 entity : entities) {
            chargeEntity(entity);
        }
    }

    private void chargeBlockEntity(final class_2586 blockEntity) {
        charge(Capabilities.get(blockEntity, Capabilities.ENERGY_STORAGE, class_2350.field_11033), Capabilities.get(blockEntity, Capabilities.ITEM_HANDLER, class_2350.field_11033));
    }

    private void chargeEntity(final class_1297 entity) {
        charge(Capabilities.get(entity, Capabilities.ENERGY_STORAGE, class_2350.field_11033), Capabilities.get(entity, Capabilities.ITEM_HANDLER, class_2350.field_11033));
    }

    private void charge(@Nullable EnergyHandler energyHandler, @Nullable ItemHandler itemHandler) {
        if (energyHandler != null) {
            chargeStorage(energyHandler);
        }

        if (itemHandler != null) {
            chargeItems(itemHandler);
        }
    }

    private void chargeStorage(final EnergyHandler energyHandler) {
        assert field_11863 != null;

        final long amount = Math.min(energy.getEnergyStored(), Config.chargerEnergyPerTick);
        final boolean simulate = field_11863.field_9236;
        if (energy.extractEnergy(energyHandler.receiveEnergy(amount, simulate), simulate) > 0) {
            isCharging = true;
        }
    }

    private void chargeItems(final ItemHandler itemHandler) {
        for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
            final EnergyHandler stackEnergy = Capabilities.get(itemHandler, slot, Capabilities.ENERGY_STORAGE);
            if (stackEnergy != null) {
                chargeStorage(stackEnergy);
            }
        }
    }

    @Nullable
    @Override
    public class_238 getExpandedRenderBoundingBox() {
        return renderBoundingBox;
    }
}
