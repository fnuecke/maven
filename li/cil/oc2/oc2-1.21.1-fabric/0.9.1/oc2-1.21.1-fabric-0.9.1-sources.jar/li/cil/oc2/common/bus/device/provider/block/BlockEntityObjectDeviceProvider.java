/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.object.Callbacks;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockEntityDeviceProvider;
import net.minecraft.class_2586;
import java.util.Optional;

public final class BlockEntityObjectDeviceProvider extends AbstractBlockEntityDeviceProvider<class_2586> {
    @Override
    public Optional<Device> getBlockDevice(final BlockDeviceQuery query, final class_2586 blockEntity) {
        if (Callbacks.hasMethods(blockEntity)) {
            return Optional.of(new ObjectDevice(blockEntity));
        } else {
            return Optional.empty();
        }
    }
}
