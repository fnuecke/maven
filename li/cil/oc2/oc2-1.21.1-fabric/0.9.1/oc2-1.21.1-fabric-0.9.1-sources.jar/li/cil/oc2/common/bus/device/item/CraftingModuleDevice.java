/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.item;

import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.*;
import li.cil.oc2.api.capabilities.Robot;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.inventory.ItemHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.IntStream;

@RPCDeviceDescription(typeName = "crafting", description = """
    Provided by the [crafting module](../item/crafting_module.md) to robots.

    The top part of the robot's inventory, slots `0` to `8`, serves as the crafting grid. Crafted items go into the bottom row, starting at the selected slot.""")
@IODeviceDescription(name = "CRFTNG")
public final class CraftingModuleDevice extends AbstractItemDevice {
    private static final int CRAFT_CODE = 1;

    private static final int GRID_SIZE = 3;
    private static final int GRID_SLOTS = GRID_SIZE * GRID_SIZE;

    private static final String CRAFT_DESCRIPTION = "Tries to craft once from the crafting grid. Fails if the grid matches no recipe " +
        "or the result does not fit into the bottom row.";

    // --------------------------------------------------------------------- //

    private final class_1297 entity;
    private final Robot robot;

    // --------------------------------------------------------------------- //

    public CraftingModuleDevice(final class_1799 identity, final class_1297 entity, final Robot robot) {
        super(identity);
        this.entity = entity;
        this.robot = robot;
    }

    // --------------------------------------------------------------------- //

    @Callback(energy = 1,
        description = CRAFT_DESCRIPTION,
        returnValueDescription = "the number of items crafted, or `0` if crafting failed.")
    public int craft() {
        final class_1937 level = entity.method_37908();
        final ItemHandler inventory = inventory();

        final class_9694.class_9765 positioned = class_9694.method_60505(GRID_SIZE, GRID_SIZE, gridItems(inventory));
        final class_9694 input = positioned.comp_2795();
        final Optional<class_8786<class_3955>> recipe = level.method_8433().method_8132(class_3956.field_17545, input, level);
        if (recipe.isEmpty()) {
            return 0;
        }

        final class_1799 result = recipe.get().comp_1933().method_8116(input, level.method_30349());
        if (result.method_7960() || !insertIntoOutput(inventory, result, true).method_7960()) {
            return 0;
        }

        final class_2371<class_1799> remainders = recipe.get().comp_1933().method_8111(input);
        result.method_54466(level);
        final int crafted = result.method_7947();
        insertIntoOutput(inventory, result, false);
        consumeIngredients(inventory, positioned, remainders);

        return crafted;
    }

    // --------------------------------------------------------------------- //

    @IOCallback(energy = 1, value = CRAFT_CODE,
        description = CRAFT_DESCRIPTION,
        resultsDescription = "one byte, the number of items crafted, `0` if crafting failed.")
    public void craft(final IOOutputStream results) throws IOException {
        results.writeU8(craft());
    }

    // --------------------------------------------------------------------- //

    private List<class_1799> gridItems(final ItemHandler inventory) {
        return IntStream.range(0, GRID_SLOTS).mapToObj(inventory::getStackInSlot).toList();
    }

    private void consumeIngredients(final ItemHandler inventory, final class_9694.class_9765 positioned,
                                    final class_2371<class_1799> remainders) {
        final class_9694 input = positioned.comp_2795();
        for (int row = 0; row < input.method_59992(); row++) {
            for (int column = 0; column < input.method_59991(); column++) {
                final int slot = positioned.comp_2796() + column + (positioned.comp_2797() + row) * GRID_SIZE;
                inventory.extractItem(slot, 1, false);

                final class_1799 remainder = remainders.get(column + row * input.method_59991());
                if (remainder.method_7960()) {
                    continue;
                }

                final class_1799 rejected = insertIntoOutput(inventory, inventory.insertItem(slot, remainder, false), false);
                if (!rejected.method_7960()) {
                    entity.method_5775(rejected);
                }
            }
        }
    }

    private class_1799 insertIntoOutput(final ItemHandler inventory, class_1799 stack, final boolean simulate) {
        final int outputSlots = inventory.getSlots() - GRID_SLOTS;
        final int start = Math.max(robot.getSelectedSlot() - GRID_SLOTS, 0);
        for (int i = 0; i < outputSlots && !stack.method_7960(); i++) {
            stack = inventory.insertItem(GRID_SLOTS + (start + i) % outputSlots, stack, simulate);
        }

        return stack;
    }

    private ItemHandler inventory() {
        return Objects.requireNonNull(Capabilities.get(entity, Capabilities.ITEM_HANDLER, null));
    }
}
