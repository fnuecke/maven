/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.block;

import li.cil.oc2.common.bus.device.util.IdentityProxy;
import li.cil.oc2.common.util.BlockLocation;
import li.cil.oc2.common.util.FakePlayerUtils;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public abstract class AbstractBlockDevice extends IdentityProxy<BlockLocation> {
    protected AbstractBlockDevice(final BlockLocation identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    protected class_3218 getServerLevel() {
        if (identity.tryGetLevel().orElse(null) instanceof final class_3218 level) {
            return level;
        }

        throw new IllegalStateException("level is not loaded");
    }

    protected class_2680 getBlockState(final class_2248 block) {
        final class_2680 blockState = getServerLevel().method_8320(identity.blockPos());
        if (!blockState.method_27852(block)) {
            throw new IllegalStateException("block has changed");
        }

        return blockState;
    }

    protected <T extends class_2586> T getBlockEntity(final Class<T> type) {
        final class_2586 blockEntity = getServerLevel().method_8321(identity.blockPos());
        if (type.isInstance(blockEntity)) {
            return type.cast(blockEntity);
        }

        throw new IllegalStateException("block has changed");
    }

    protected void setBlockState(final class_2680 blockState) {
        checkPermission();
        getServerLevel().method_8652(identity.blockPos(), blockState, class_2248.field_31036);
    }

    protected void checkPermission() {
        final class_3218 level = getServerLevel();
        if (!level.method_8505(FakePlayerUtils.getFakePlayer(level), identity.blockPos())) {
            throw new IllegalStateException("not allowed");
        }
    }
}
