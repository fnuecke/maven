/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_3542;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

public enum FlippableOrientation implements class_3542 {
    NORTH("north", class_2350.field_11043, class_2350.field_11036),
    EAST("east", class_2350.field_11034, class_2350.field_11036),
    SOUTH("south", class_2350.field_11035, class_2350.field_11036),
    WEST("west", class_2350.field_11039, class_2350.field_11036),
    NORTH_UPSIDE_DOWN("north_upside_down", class_2350.field_11043, class_2350.field_11033),
    EAST_UPSIDE_DOWN("east_upside_down", class_2350.field_11034, class_2350.field_11033),
    SOUTH_UPSIDE_DOWN("south_upside_down", class_2350.field_11035, class_2350.field_11033),
    WEST_UPSIDE_DOWN("west_upside_down", class_2350.field_11039, class_2350.field_11033),
    UP_NORTH("up_north", class_2350.field_11036, class_2350.field_11043),
    UP_EAST("up_east", class_2350.field_11036, class_2350.field_11034),
    UP_SOUTH("up_south", class_2350.field_11036, class_2350.field_11035),
    UP_WEST("up_west", class_2350.field_11036, class_2350.field_11039),
    DOWN_NORTH("down_north", class_2350.field_11033, class_2350.field_11043),
    DOWN_EAST("down_east", class_2350.field_11033, class_2350.field_11034),
    DOWN_SOUTH("down_south", class_2350.field_11033, class_2350.field_11035),
    DOWN_WEST("down_west", class_2350.field_11033, class_2350.field_11039);

    // --------------------------------------------------------------------- //

    private final String serializedName;
    private final class_2350 facing;
    private final class_2350 up;
    private final class_2350 right;
    private final int rotationX;
    private final int rotationY;
    private final Quaternionf rotation;

    // --------------------------------------------------------------------- //

    FlippableOrientation(final String serializedName, final class_2350 facing, final class_2350 up) {
        this.serializedName = serializedName;
        this.facing = facing;
        this.up = up;
        this.rotationX = computeRotationX(facing, up);
        this.rotationY = computeRotationY(facing, up);
        this.rotation = new Quaternionf().rotationYXZ(
            (float) Math.toRadians(-rotationY),
            (float) Math.toRadians(-rotationX),
            0);
        this.right = class_2350.method_23225(new Matrix4f().rotation(rotation), class_2350.field_11034);
    }

    // --------------------------------------------------------------------- //

    public static FlippableOrientation of(final class_2350 facing, final class_2350 up) {
        for (final FlippableOrientation orientation : values()) {
            if (orientation.facing == facing && orientation.up == up) {
                return orientation;
            }
        }
        throw new IllegalArgumentException("No orientation faces [" + facing + "] with its top towards [" + up + "].");
    }

    public class_2350 getFacing() {
        return facing;
    }

    public class_2350 getUp() {
        return up;
    }

    public class_2350 getRight() {
        return right;
    }

    public int getRotationX() {
        return rotationX;
    }

    public int getRotationY() {
        return rotationY;
    }

    public Quaternionf getRotation() {
        return rotation;
    }

    public boolean isUpsideDown() {
        return up == class_2350.field_11033;
    }

    public FlippableOrientation getUpright() {
        return isUpsideDown() ? of(facing, class_2350.field_11036) : this;
    }

    public FlippableOrientation rotate(final class_2470 rotation) {
        return of(rotation.method_10503(facing), rotation.method_10503(up));
    }

    public FlippableOrientation mirror(final class_2415 mirror) {
        return of(mirror.method_10343(facing), mirror.method_10343(up));
    }

    @Override
    public String method_15434() {
        return serializedName;
    }

    // --------------------------------------------------------------------- //

    private static int computeRotationX(final class_2350 facing, final class_2350 up) {
        return switch (facing) {
            case field_11036 -> 270;
            case field_11033 -> 90;
            default -> up == class_2350.field_11033 ? 180 : 0;
        };
    }

    private static int computeRotationY(final class_2350 facing, final class_2350 up) {
        return (int) switch (facing) {
            case field_11036 -> up.method_10144();
            case field_11033 -> up.method_10153().method_10144();
            default -> up == class_2350.field_11033 ? facing.method_10144() : facing.method_10153().method_10144();
        };
    }
}
