/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3620;
import net.minecraft.class_5558;
import javax.annotation.Nullable;

public final class ProjectorBlock extends FlippableOrientableBlock implements class_2343, EnergyConsumingBlock {
    public static final MapCodec<ProjectorBlock> CODEC = MapCodec.unit(ProjectorBlock::new);

    @Override
    protected MapCodec<? extends ProjectorBlock> method_53969() {
        return field_46280;
    }

    public static final class_2746 LIT = class_2741.field_12548;

    // We bake the visual indents on the front and sides into the collision shape, to prevent stuff being
    // placeable on those sides, such as network connectors, torches, etc.
    private static final class_265 NEG_Z_SHAPE = class_259.method_1072(class_259.method_1077(), class_259.method_17786(
        class_259.method_1081(0 / 16f, 2 / 16f, 2 / 16f, 1 / 16f, 6 / 16f, 14 / 16f),
        class_259.method_1081(15 / 16f, 2 / 16f, 2 / 16f, 16 / 16f, 6 / 16f, 14 / 16f),
        class_259.method_1081(4 / 16f, 4 / 16f, 0 / 16f, 12 / 16f, 12 / 16f, 2 / 16f)
    ), (a, b) -> a && !b);

    public ProjectorBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9631(state -> state.method_11654(LIT) ? 8 : 0)
            .method_9629(1.5f, 6.0f), FlippableOrientation.NORTH, NEG_Z_SHAPE);
        method_9590(method_9564().method_11657(LIT, false));
    }

    // --------------------------------------------------------------------- //

    @Override
    public int getEnergyConsumption() {
        if (Config.projectorsUseEnergy()) {
            return Config.projectorEnergyPerTick;
        } else {
            return 0;
        }
    }

    @Override
    @Nullable
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.PROJECTOR.get().method_11032(pos, state);
    }

    @Override
    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createServerTicker(level, type, BlockEntities.PROJECTOR.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(LIT);
    }
}
