/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalNotification;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.architectury.event.events.client.ClientTickEvent;
import li.cil.oc2.client.ClientPlatform;
import li.cil.oc2.common.block.FlippableOrientableBlock;
import li.cil.oc2.common.block.FlippableOrientation;
import li.cil.oc2.common.blockentity.ProjectorBlockEntity;
import li.cil.oc2.common.bus.device.vm.block.ProjectorDevice;
import li.cil.oc2.common.ext.LevelRendererExt;
import li.cil.oc2.common.ext.MinecraftExt;
import li.cil.oc2.common.util.FakePlayerUtils;
import li.cil.oc2.jcodec.common.model.Picture;
import li.cil.oc2.jcodec.scale.Yuv420jToRgb;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_276;
import net.minecraft.class_2818;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4076;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_4722;
import net.minecraft.class_6364;
import net.minecraft.class_6367;
import net.minecraft.class_638;
import net.minecraft.class_6854;
import net.minecraft.class_746;
import net.minecraft.class_761;
import net.minecraft.class_824;
import net.minecraft.class_8251;
import net.minecraft.class_9779;
import net.minecraft.class_9799;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;

import java.lang.ref.WeakReference;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL30.*;

// No @Mod.EventBusSubscriber: we need to register this manually, because static init throws errors when running data generation.
public final class ProjectorDepthRenderer {
    private static final int DEPTH_CAPTURE_SIZE = 256;
    private static final int DEPTH_BUFFER_SOURCE_BYTES = 768 * 1024;
    private static final float BASE_EMISSIVE_STRENGTH = 1.0f;
    private static final float SHADER_EMISSIVE_STRENGTH = 3.0f;

    private static final List<ProjectorBlockEntity> VISIBLE_PROJECTORS = new ArrayList<>();
    private static final LazyDepthOnlyRenderBuffer[] PROJECTOR_DEPTH_BUFFER_LEDGER = new LazyDepthOnlyRenderBuffer[ModShaders.MAX_PROJECTORS];
    private static final DepthOnlyRenderTarget[] PROJECTOR_DEPTH_BUFFERS = new DepthOnlyRenderTarget[ModShaders.MAX_PROJECTORS];
    private static final class_1043[] PROJECTOR_COLOR_BUFFERS = new class_1043[ModShaders.MAX_PROJECTORS];
    private static final Matrix4f[] PROJECTOR_CAMERA_MATRICES = new Matrix4f[ModShaders.MAX_PROJECTORS];
    private static final class_4184 PROJECTOR_DEPTH_CAMERA = new class_4184();
    private static final float PROJECTOR_FORWARD_SHIFT = 7 / 16f; // From center of projector block.
    private static final float PROJECTOR_NEAR = 0.5f - PROJECTOR_FORWARD_SHIFT;
    private static final float PROJECTOR_FAR = ProjectorBlockEntity.MAX_RENDER_DISTANCE;
    private static final int HALF_FRUSTUM_WIDTH = (ProjectorBlockEntity.MAX_WIDTH - 1) / 2;
    private static final int FRUSTUM_HEIGHT = ProjectorBlockEntity.MAX_HEIGHT - 1;
    private static final Matrix4f DEPTH_CAMERA_PROJECTION_MATRIX = getFrustumMatrix(
        PROJECTOR_NEAR, PROJECTOR_FAR,
        ProjectorBlockEntity.MAX_GOOD_RENDER_DISTANCE,
        -HALF_FRUSTUM_WIDTH, HALF_FRUSTUM_WIDTH,
        FRUSTUM_HEIGHT, 0);
    private static final Matrix4f UPSIDE_DOWN_DEPTH_CAMERA_PROJECTION_MATRIX = getFrustumMatrix(
        PROJECTOR_NEAR, PROJECTOR_FAR,
        ProjectorBlockEntity.MAX_GOOD_RENDER_DISTANCE,
        -HALF_FRUSTUM_WIDTH, HALF_FRUSTUM_WIDTH,
        0, -FRUSTUM_HEIGHT);
    private static final Quaternionf VIEW_ROTATION = new Quaternionf();
    private static final Matrix4f MODEL_VIEW_MATRIX = new Matrix4f();
    private static final Matrix4f PROJECTION_MATRIX = new Matrix4f();

    private static final Cache<ProjectorBlockEntity, RenderInfo> RENDER_INFO = CacheBuilder.newBuilder()
        .expireAfterAccess(Duration.ofSeconds(5))
        .removalListener(ProjectorDepthRenderer::handleProjectorNoLongerRendering)
        .build();

    private static DepthOnlyRenderTarget mainCameraDepth;
    private static class_276 activeProjectorDepthTarget;
    private static class_4597.class_4598 depthBufferSource;

    private static ProjectorRenderPath currentPath;
    private static int pendingRenderCount;
    private static int refreshSlot;
    private static boolean isRenderingProjectorDepth;
    private static class_239 hitResultBak;
    private static boolean entityShadowsBak;
    private static class_1297 minecraftCameraEntityBak;
    private static class_4184 gameRendererMainCameraBak;
    private static float shaderFogStartBak;
    private static float shaderFogEndBak;
    private static final float[] SHADER_FOG_COLOR_BAK = new float[4];
    private static class_6854 shaderFogShapeBak;

    private static void handleProjectorNoLongerRendering(final RemovalNotification<ProjectorBlockEntity, RenderInfo> notification) {
        final ProjectorBlockEntity projector = notification.getKey();
        if (projector != null) {
            projector.setFrameConsumer(null);
        }
        final RenderInfo renderInfo = notification.getValue();
        if (renderInfo != null) {
            renderInfo.close();
        }
    }

    static {
        for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
            PROJECTOR_CAMERA_MATRICES[i] = new Matrix4f();
        }
    }

    private static LazyDepthOnlyRenderBuffer[] projectorDepthBuffers() {
        if (PROJECTOR_DEPTH_BUFFER_LEDGER[0] == null) {
            for (int i = 0; i < ModShaders.MAX_PROJECTORS; i++) {
                PROJECTOR_DEPTH_BUFFER_LEDGER[i] = new LazyDepthOnlyRenderBuffer();
            }
        }
        return PROJECTOR_DEPTH_BUFFER_LEDGER;
    }

    private static DepthOnlyRenderTarget mainCameraDepth() {
        if (mainCameraDepth == null) {
            mainCameraDepth = new DepthOnlyRenderTarget(class_6364.field_33724, class_6364.field_33725);
        }
        return mainCameraDepth;
    }

    // --------------------------------------------------------------------- //

    public static void addProjector(final ProjectorBlockEntity projector) {
        // Projectors may be rendered multiple times, e.g. in shadow passes when shaders are enabled.
        if (!VISIBLE_PROJECTORS.contains(projector) && isProjectionVisible(projector)) {
            VISIBLE_PROJECTORS.add(projector);
        }
    }

    public static boolean isRenderingProjectorDepth() {
        return isRenderingProjectorDepth;
    }

    public static void bindProjectorDepthTarget() {
        if (activeProjectorDepthTarget != null) {
            glBindFramebuffer(GL_FRAMEBUFFER, activeProjectorDepthTarget.field_1476);
        }
    }

    public static void onBeforeTerrainSetup(final class_9779 deltaTracker) {
        try {
            if (VISIBLE_PROJECTORS.isEmpty()) {
                return;
            }

            final int projectorIndex = getNextDepthTargetSlotToRender(Math.min(VISIBLE_PROJECTORS.size(), ModShaders.MAX_PROJECTORS));
            if (projectorIndex < 0) {
                return;
            }

            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(projectorIndex);
            final class_310 minecraft = class_310.method_1551();
            final class_638 level = minecraft.field_1687;
            if (level == null || projector.method_11015() || projector.method_10997() != level) {
                return;
            }

            renderDepthBuffer(minecraft, level, deltaTracker, projectorIndex, projector);
        } finally {
            VISIBLE_PROJECTORS.clear();
        }
    }

    public static void onBeforeTransparencyChain(final class_4597.class_4598 bufferSource) {
        path().beforeTransparencyChain(bufferSource);
    }

    public static void onBeforeTranslucentTerrain(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
        path().beforeTranslucentTerrain(modelViewMatrix, projectionMatrix);
    }

    public static void onAfterParticles(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
        path().afterParticles(modelViewMatrix, projectionMatrix);
    }

    public static void onAfterLevel() {
        try {
            path().afterLevel();
        } finally {
            currentPath = null;
            pendingRenderCount = 0;
            Arrays.fill(PROJECTOR_COLOR_BUFFERS, null);
        }
    }

    public static void initialize() {
        ClientTickEvent.CLIENT_POST.register(minecraft -> {
            RENDER_INFO.cleanUp();
            if (minecraft.field_1687 == null) {
                VISIBLE_PROJECTORS.clear();
            }
        });
    }

    // --------------------------------------------------------------------- //

    private static ProjectorRenderPath path() {
        if (currentPath == null) {
            currentPath = ShaderPackCompat.isShaderPackRendering()
                ? ProjectorRenderPath.SHADER_PACK
                : class_310.method_29611()
                ? ProjectorRenderPath.FABULOUS
                : ProjectorRenderPath.DEFAULT;
        }
        return currentPath;
    }

    private static boolean isProjectionVisible(final ProjectorBlockEntity projector) {
        return ((LevelRendererExt) class_310.method_1551().field_1769)
            .getCullingFrustum().method_23093(projectionBounds(projector));
    }

    private static class_238 projectionBounds(final ProjectorBlockEntity projector) {
        return projector.getExpandedRenderBoundingBox()
            .method_1014(1); // Compensate e.g. view bobbing and allow init a bit early.
    }

    private static boolean hasVisibleProjectors() {
        return !VISIBLE_PROJECTORS.isEmpty();
    }

    private static boolean hasPendingProjectors() {
        return pendingRenderCount > 0;
    }

    private static boolean prepareProjectorRendering(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
        if (VISIBLE_PROJECTORS.isEmpty()) {
            return false;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_638 level = minecraft.field_1687;
        final class_746 player = minecraft.field_1724;
        if (level == null || player == null) {
            VISIBLE_PROJECTORS.clear();
            return false;
        }

        VISIBLE_PROJECTORS.sort((projector1, projector2) -> {
            final double distance1 = player.method_5707(class_243.method_24953(projector1.method_11016()));
            final double distance2 = player.method_5707(class_243.method_24953(projector2.method_11016()));
            return Double.compare(distance1, distance2);
        });

        final int projectorCount = Math.min(VISIBLE_PROJECTORS.size(), ModShaders.MAX_PROJECTORS);
        for (int i = 0; i < projectorCount; i++) {
            VISIBLE_PROJECTORS.get(i).onRendering();
        }

        pendingRenderCount = updateProjectorDepths(minecraft, level, projectorCount);
        MODEL_VIEW_MATRIX.set(modelViewMatrix);
        PROJECTION_MATRIX.set(projectionMatrix);

        return hasPendingProjectors();
    }

    private static void flushDepthWritingSheets(final class_4597.class_4598 bufferSource) {
        bufferSource.method_22994(class_4722.method_24076());
        bufferSource.method_22994(class_4722.method_24059());
        bufferSource.method_22994(class_4722.method_24067());
    }

    private static void compositeIntoMainTarget() {
        final class_310 minecraft = class_310.method_1551();
        minecraft.method_1522().method_1235(true);
        renderProjector(minecraft, pendingRenderCount, BASE_EMISSIVE_STRENGTH);
    }

    private static void compositeIntoShaderTarget() {
        final class_310 minecraft = class_310.method_1551();
        final int previousFrameBuffer = glGetInteger(GL_DRAW_FRAMEBUFFER_BINDING);

        mainCameraDepth().method_1235(false);
        if (!ShaderPackCompat.bindShaderPackGBuffer()) {
            glBindFramebuffer(GL_FRAMEBUFFER, previousFrameBuffer);
            minecraft.method_1522().method_1235(false);
            return;
        }

        try {
            renderProjector(minecraft, pendingRenderCount, SHADER_EMISSIVE_STRENGTH);
        } finally {
            glBindFramebuffer(GL_FRAMEBUFFER, previousFrameBuffer);
            minecraft.method_1522().method_1235(false);
        }
    }

    private static void captureMainCameraDepth() {
        final class_276 mainRenderTarget = class_310.method_1551().method_1522();
        if (mainRenderTarget.field_1482 != mainCameraDepth().field_1482 || mainRenderTarget.field_1481 != mainCameraDepth().field_1481) {
            mainCameraDepth().method_1234(mainRenderTarget.field_1482, mainRenderTarget.field_1481, class_310.field_1703);
        }
        if (ClientPlatform.isStencilEnabled(mainRenderTarget)) {
            ClientPlatform.enableStencil(mainCameraDepth());
        } else if (ClientPlatform.isStencilEnabled(mainCameraDepth())) {
            mainCameraDepth().method_1238();
            mainCameraDepth = new DepthOnlyRenderTarget(mainRenderTarget.field_1482, mainRenderTarget.field_1481);
        }
        mainCameraDepth().method_29329(mainRenderTarget);
        mainRenderTarget.method_1235(false);
    }

    private static int updateProjectorDepths(final class_310 minecraft, final class_638 level, final int projectorCount) {
        final class_243 mainCameraPosition = minecraft.field_1773.method_19418().method_19326();
        final class_4587 viewModelStack = new class_4587();

        matchDepthTargetsToOwningProjectors(projectorCount);

        final int validDepthTargetCount = sortByDepthBufferValidity(projectorCount);

        for (int i = 0; i < validDepthTargetCount; i++) {
            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(i);
            final FlippableOrientation orientation = projector.method_11010().method_11654(FlippableOrientableBlock.ORIENTATION);
            final class_243 projectorPos = class_243
                .method_24953(projector.method_11016())
                .method_1019(new class_243(orientation.getFacing().method_23955()).method_1021(PROJECTOR_FORWARD_SHIFT));

            configureProjectorDepthCamera(level, projectorPos, orientation);

            setupViewModelMatrix(viewModelStack, orientation);

            storeProjectorMatrix(i, projectorPos, mainCameraPosition, viewModelStack, getProjectionMatrix(orientation));

            storeProjectorBuffers(i, projector);
        }

        return validDepthTargetCount;
    }

    private static void matchDepthTargetsToOwningProjectors(final int projectorCount) {
        for (int i = 0; i < projectorCount; i++) {
            final ProjectorBlockEntity projector = VISIBLE_PROJECTORS.get(i);
            for (int j = i; j < ModShaders.MAX_PROJECTORS; j++) {
                if (projectorDepthBuffers()[j].isOwnedBy(projector)) {
                    swapDepthTargets(i, j);
                    break;
                }
            }
        }
    }

    private static int sortByDepthBufferValidity(final int projectorCount) {
        int validDepthTargetCount = 0;

        for (int i = 0; i < projectorCount; i++) {
            if (!projectorDepthBuffers()[i].isOwnedBy(VISIBLE_PROJECTORS.get(i))) {
                continue;
            }

            Collections.swap(VISIBLE_PROJECTORS, i, validDepthTargetCount);
            swapDepthTargets(i, validDepthTargetCount);

            validDepthTargetCount++;
        }

        return validDepthTargetCount;
    }

    private static void swapDepthTargets(final int a, final int b) {
        if (a == b) {
            return;
        }

        final var target = PROJECTOR_DEPTH_BUFFER_LEDGER[a];
        PROJECTOR_DEPTH_BUFFER_LEDGER[a] = PROJECTOR_DEPTH_BUFFER_LEDGER[b];
        PROJECTOR_DEPTH_BUFFER_LEDGER[b] = target;
    }

    private static void renderDepthBuffer(final class_310 minecraft, final class_638 level,
                                          final class_9779 deltaTracker, final int projectorIndex,
                                          final ProjectorBlockEntity projector) {
        final class_4587 viewModelStack = new class_4587();
        final FlippableOrientation orientation = projector.method_11010().method_11654(FlippableOrientableBlock.ORIENTATION);
        final class_243 projectorPos = class_243
            .method_24953(projector.method_11016())
            .method_1019(new class_243(orientation.getFacing().method_23955()).method_1021(PROJECTOR_FORWARD_SHIFT));

        try {
            prepareDepthBufferRendering(minecraft, level, deltaTracker.method_60637(false));

            configureProjectorDepthCamera(level, projectorPos, orientation);

            final Matrix4f projectionMatrix = getProjectionMatrix(orientation);
            RenderSystem.setProjectionMatrix(projectionMatrix, class_8251.field_43360);
            setupViewModelMatrix(viewModelStack, orientation);

            bindProjectorDepthRenderTarget(projectorIndex, projector, minecraft);

            renderProjectorDepthBuffer(minecraft, level, deltaTracker, viewModelStack, projectionMatrix);
        } finally {
            finishDepthBufferRendering(minecraft);
        }
    }

    private static int getNextDepthTargetSlotToRender(final int projectorCount) {
        refreshSlot = (refreshSlot + 1) % ModShaders.MAX_PROJECTORS;
        return refreshSlot < projectorCount ? refreshSlot : -1;
    }

    private static void prepareDepthBufferRendering(final class_310 minecraft, final class_638 level, final float partialTicks) {
        isRenderingProjectorDepth = true;

        // Suppresses hit outlines being rendered.
        hitResultBak = minecraft.field_1765;
        minecraft.field_1765 = null;

        // Skip shadow rendering for perf.
        entityShadowsBak = minecraft.field_1690.method_42435().method_41753();
        minecraft.field_1690.method_42435().method_41748(false);

        minecraftCameraEntityBak = minecraft.method_1560();
        minecraft.method_1504(ProjectorCameraEntity.get(level, class_243.field_1353, partialTicks, 0));
        gameRendererMainCameraBak = minecraft.field_1773.field_18765;
        minecraft.field_1773.field_18765 = PROJECTOR_DEPTH_CAMERA;
        prepareRenderDispatchers(minecraft, PROJECTOR_DEPTH_CAMERA);

        RenderSystem.backupProjectionMatrix();
        RenderSystem.getModelViewStack().pushMatrix().identity();
        RenderSystem.applyModelViewMatrix();

        backupFog();
    }

    private static void finishDepthBufferRendering(final class_310 minecraft) {
        isRenderingProjectorDepth = false;
        activeProjectorDepthTarget = null;

        minecraft.field_1765 = hitResultBak;
        minecraft.field_1690.method_42435().method_41748(entityShadowsBak);

        ((MinecraftExt) minecraft).setMainRenderTargetOverride(null);
        minecraft.method_1522().method_1235(true);

        minecraft.method_1504(minecraftCameraEntityBak);
        minecraft.field_1773.field_18765 = gameRendererMainCameraBak;
        prepareRenderDispatchers(minecraft, gameRendererMainCameraBak);

        RenderSystem.restoreProjectionMatrix();
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();

        restoreFog();
    }

    @SuppressWarnings("DataFlowIssue")
    private static void prepareRenderDispatchers(final class_310 minecraft, final class_4184 camera) {
        // Same calls as in LevelRenderer::renderLevel() before it renders entities.
        minecraft.method_31975().method_3549(minecraft.field_1687, camera, minecraft.field_1765);
        minecraft.method_1561().method_3941(minecraft.field_1687, camera, minecraft.field_1692);
    }

    private static void backupFog() {
        shaderFogStartBak = RenderSystem.getShaderFogStart();
        shaderFogEndBak = RenderSystem.getShaderFogEnd();
        System.arraycopy(RenderSystem.getShaderFogColor(), 0, SHADER_FOG_COLOR_BAK, 0, SHADER_FOG_COLOR_BAK.length);
        shaderFogShapeBak = RenderSystem.getShaderFogShape();
    }

    private static void restoreFog() {
        RenderSystem.setShaderFogStart(shaderFogStartBak);
        RenderSystem.setShaderFogEnd(shaderFogEndBak);
        RenderSystem.setShaderFogColor(SHADER_FOG_COLOR_BAK[0], SHADER_FOG_COLOR_BAK[1], SHADER_FOG_COLOR_BAK[2], SHADER_FOG_COLOR_BAK[3]);
        RenderSystem.setShaderFogShape(shaderFogShapeBak);
    }

    // Manual level rendering a la LevelRenderer::renderLevel(), with the bits we need for the projector depth.
    private static void renderProjectorDepthBuffer(final class_310 minecraft, final class_638 level, final class_9779 deltaTracker, final class_4587 viewModelStack, final Matrix4f projectionMatrix) {
        final class_761 levelRenderer = minecraft.field_1769;
        final Matrix4f frustumMatrix = viewModelStack.method_23760().method_23761();
        final class_243 cameraPosition = PROJECTOR_DEPTH_CAMERA.method_19326();
        final double cameraX = cameraPosition.method_10216(), cameraY = cameraPosition.method_10214(), cameraZ = cameraPosition.method_10215();
        final float partialTicks = deltaTracker.method_60637(false);

        final class_4604 frustum = new class_4604(frustumMatrix, projectionMatrix);
        frustum.method_23088(cameraX, cameraY, cameraZ);

        levelRenderer.method_3273(PROJECTOR_DEPTH_CAMERA, frustum, false, false);

        final LevelRendererExt levelRendererExt = (LevelRendererExt) levelRenderer;
        final class_4604 cullingFrustum = levelRendererExt.getCullingFrustum();
        levelRendererExt.setCullingFrustum(frustum);
        try {
            levelRenderer.method_3251(class_1921.method_23577(), cameraX, cameraY, cameraZ, frustumMatrix, projectionMatrix);
            levelRenderer.method_3251(class_1921.method_23579(), cameraX, cameraY, cameraZ, frustumMatrix, projectionMatrix);
            levelRenderer.method_3251(class_1921.method_23581(), cameraX, cameraY, cameraZ, frustumMatrix, projectionMatrix);
        } finally {
            levelRendererExt.setCullingFrustum(cullingFrustum);
        }

        bindActiveProjectorDepthTarget(minecraft);

        RenderSystem.getModelViewStack().pushMatrix().mul(frustumMatrix);
        RenderSystem.applyModelViewMatrix();
        try {
            final class_4597.class_4598 bufferSource = depthBufferSource();
            final class_4587 poseStack = new class_4587();

            for (final class_1297 entity : level.method_18112()) {
                if (minecraft.method_1561().method_3950(entity, frustum, cameraX, cameraY, cameraZ)) {
                    levelRenderer.method_22977(entity, cameraX, cameraY, cameraZ, partialTicks, poseStack, bufferSource);
                }
            }
            bufferSource.method_22993();

            renderBlockEntities(minecraft, level, frustum, poseStack, bufferSource, partialTicks, cameraX, cameraY, cameraZ);

            minecraft.field_1713.method_3049(minecraft.field_1773.method_22974(), PROJECTOR_DEPTH_CAMERA, partialTicks);
            levelRenderer.method_22714(minecraft.field_1773.method_22974(), partialTicks, cameraX, cameraY, cameraZ);
        } finally {
            RenderSystem.getModelViewStack().popMatrix();
            RenderSystem.applyModelViewMatrix();
        }
    }

    // Same as in LevelRenderer::renderLevel() with the relevant entity subset (chunks in projector frustum).
    private static void renderBlockEntities(final class_310 minecraft, final class_638 level, final class_4604 frustum,
                                            final class_4587 poseStack, final class_4597.class_4598 bufferSource,
                                            final float partialTicks,
                                            final double cameraX, final double cameraY, final double cameraZ) {
        final class_238 bounds = frustumBounds(cameraX, cameraY, cameraZ);
        final int minChunkX = class_4076.method_18675(class_3532.method_15357(bounds.field_1323));
        final int maxChunkX = class_4076.method_18675(class_3532.method_15357(bounds.field_1320));
        final int minChunkZ = class_4076.method_18675(class_3532.method_15357(bounds.field_1321));
        final int maxChunkZ = class_4076.method_18675(class_3532.method_15357(bounds.field_1324));
        final int minSectionY = class_4076.method_18675(class_3532.method_15357(bounds.field_1322));
        final int maxSectionY = class_4076.method_18675(class_3532.method_15357(bounds.field_1325));
        final class_824 dispatcher = minecraft.method_31975();

        for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
            for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
                final class_2818 chunk = level.method_2935().method_21730(chunkX, chunkZ);
                if (chunk == null) {
                    continue;
                }

                for (final class_2586 blockEntity : chunk.method_12214().values()) {
                    final class_2338 pos = blockEntity.method_11016();
                    final int sectionY = class_4076.method_18675(pos.method_10264());
                    if (sectionY < minSectionY || sectionY > maxSectionY) {
                        continue;
                    }
                    if (!ClientPlatform.isBlockEntityVisible(dispatcher, blockEntity, frustum)) {
                        continue;
                    }

                    poseStack.method_22903();
                    poseStack.method_22904(pos.method_10263() - cameraX, pos.method_10264() - cameraY, pos.method_10260() - cameraZ);
                    dispatcher.method_3555(blockEntity, partialTicks, poseStack, bufferSource);
                    poseStack.method_22909();
                }
            }
        }

        bufferSource.method_22993();
    }

    private static void configureProjectorDepthCamera(final class_638 level, final class_243 pos, final FlippableOrientation orientation) {
        final FlippableOrientation viewOrientation = orientation.getUpright();
        final float rotationY = viewOrientation.getRotationY() + 180;
        final float rotationX = viewOrientation.getRotationX();
        PROJECTOR_DEPTH_CAMERA.method_19321(level, ProjectorCameraEntity.get(level, pos, rotationY, rotationX), false, false, 0);
    }

    private static void setupViewModelMatrix(final class_4587 viewModelStack, final FlippableOrientation orientation) {
        viewModelStack.method_34426();
        viewModelStack.method_22907(orientation.getUpright().getRotation().conjugate(VIEW_ROTATION));
    }

    private static Matrix4f getProjectionMatrix(final FlippableOrientation orientation) {
        return orientation.isUpsideDown() ? UPSIDE_DOWN_DEPTH_CAMERA_PROJECTION_MATRIX : DEPTH_CAMERA_PROJECTION_MATRIX;
    }

    private static class_238 frustumBounds(final double cameraX, final double cameraY, final double cameraZ) {
        final double reach = ProjectorBlockEntity.MAX_RENDER_DISTANCE;
        return new class_238(cameraX - reach, cameraY - reach, cameraZ - reach,
            cameraX + reach, cameraY + reach, cameraZ + reach);
    }

    private static class_4597.class_4598 depthBufferSource() {
        if (depthBufferSource == null) {
            depthBufferSource = class_4597.method_22991(new class_9799(DEPTH_BUFFER_SOURCE_BYTES));
        }
        return depthBufferSource;
    }

    private static void bindProjectorDepthRenderTarget(final int projectorIndex, final ProjectorBlockEntity projector, final class_310 minecraft) {
        final var projectorDepthTarget = projectorDepthBuffers()[projectorIndex];
        if (!projectorDepthTarget.isOwnedBy(projector)) {
            projectorDepthTarget.owner = new WeakReference<>(projector);
        }
        RenderSystem.depthMask(true);
        RenderSystem.disableScissor();
        projectorDepthTarget.target.method_1230(class_310.field_1703);
        activeProjectorDepthTarget = projectorDepthTarget.target;
        bindActiveProjectorDepthTarget(minecraft);
    }

    private static void bindActiveProjectorDepthTarget(final class_310 minecraft) {
        ((MinecraftExt) minecraft).setMainRenderTargetOverride(null);
        activeProjectorDepthTarget.method_1235(true);
        ((MinecraftExt) minecraft).setMainRenderTargetOverride(activeProjectorDepthTarget);
    }

    private static void storeProjectorMatrix(final int projectorIndex, final class_243 projectorPos, final class_243 mainCameraPosition, final class_4587 viewModelStack, final Matrix4f projectionMatrix) {
        // Save model-view-projection matrix for mapping in compositing shader. We use the position relative to the
        // main camera here, so that the main camera can sit at the origin. This avoids loss of precision.
        PROJECTOR_CAMERA_MATRICES[projectorIndex].set(projectionMatrix);
        viewModelStack.method_22903();
        viewModelStack.method_22904(
            mainCameraPosition.method_10216() - projectorPos.method_10216(),
            mainCameraPosition.method_10214() - projectorPos.method_10214(),
            mainCameraPosition.method_10215() - projectorPos.method_10215()
        );
        PROJECTOR_CAMERA_MATRICES[projectorIndex].mul(viewModelStack.method_23760().method_23761());
        viewModelStack.method_22909();
    }

    private static void storeProjectorBuffers(final int projectorIndex, final ProjectorBlockEntity projector) {
        PROJECTOR_COLOR_BUFFERS[projectorIndex] = getColorBuffer(projector);
        PROJECTOR_DEPTH_BUFFERS[projectorIndex] = projectorDepthBuffers()[projectorIndex].target;
    }

    private static void renderProjector(final class_310 minecraft, final int renderCount, final float emissiveStrength) {
        prepareColorBufferRendering();
        try {
            prepareOrthographicRendering(minecraft);

            RenderSystem.setShader(ModShaders::getProjectorsShader);
            ModShaders.configureProjectorsShader(
                mainCameraDepth(),
                constructInverseMainCameraMatrix(),
                PROJECTOR_COLOR_BUFFERS,
                PROJECTOR_DEPTH_BUFFERS,
                PROJECTOR_CAMERA_MATRICES,
                renderCount,
                emissiveStrength
            );

            renderIntoScreenRect();
        } finally {
            finishColorBufferRendering();
        }
    }

    private static void prepareColorBufferRendering() {
        RenderSystem.backupProjectionMatrix();
        RenderSystem.getModelViewStack().pushMatrix();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE);

        RenderSystem.colorMask(true, true, true, false);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
    }

    private static void finishColorBufferRendering() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.disableBlend();

        RenderSystem.restoreProjectionMatrix();
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();
    }

    private static void prepareOrthographicRendering(final class_310 minecraft) {
        final Matrix4f screenProjectionMatrix = new Matrix4f().setOrtho(
            0, minecraft.method_22683().method_4489(),
            minecraft.method_22683().method_4506(), 0,
            1000, 3000
        );
        RenderSystem.setProjectionMatrix(screenProjectionMatrix, class_8251.field_43361);

        final Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.identity();
        modelViewStack.translate(0, 0, -2000);
        RenderSystem.applyModelViewMatrix();
    }

    private static Matrix4f constructInverseMainCameraMatrix() {
        final Matrix4f inverseModelViewMatrix = new Matrix4f(PROJECTION_MATRIX);
        inverseModelViewMatrix.mul(MODEL_VIEW_MATRIX);
        inverseModelViewMatrix.invert();
        return inverseModelViewMatrix;
    }

    private static void renderIntoScreenRect() {
        final class_287 builder = class_289.method_1348()
            .method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        builder.method_22912(0, 0, 0).method_22913(0, 1);
        builder.method_22912(0, mainCameraDepth().field_1481, 0).method_22913(0, 0);
        builder.method_22912(mainCameraDepth().field_1482, mainCameraDepth().field_1481, 0).method_22913(1, 0);
        builder.method_22912(mainCameraDepth().field_1482, 0, 0).method_22913(1, 1);
        class_286.method_43433(builder.method_60800());
    }

    private static Matrix4f getFrustumMatrix(final float near, final float far, final float dist,
                                             final float left, final float right,
                                             final float top, final float bottom) {
        return new Matrix4f().set(new float[]{
            2 * dist / (right - left), 0, 0, 0,
            0, 2 * dist / (top - bottom), 0, 0,
            (right + left) / (right - left), (top + bottom) / (top - bottom), -(far + near) / (far - near), -1,
            0, 0, -(2 * far * near) / (far - near), 0,
        });
    }

    private static class_1043 getColorBuffer(final ProjectorBlockEntity projector) {
        try {
            final RenderInfo renderInfo = RENDER_INFO.get(projector, () -> {
                final class_1043 texture = new class_1043(ProjectorDevice.WIDTH, ProjectorDevice.HEIGHT, false);
                final RenderInfo info = new RenderInfo(texture);
                info.upload();
                projector.setFrameConsumer(info);
                return info;
            });

            renderInfo.uploadIfDirty();

            return renderInfo.texture();
        } catch (final ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    // --------------------------------------------------------------------- //

    private enum ProjectorRenderPath {
        DEFAULT {
            @Override
            void afterParticles(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
                prepareProjectorRendering(modelViewMatrix, projectionMatrix);
            }

            @Override
            void afterLevel() {
                if (hasPendingProjectors()) {
                    captureMainCameraDepth();
                    compositeIntoMainTarget();
                }
            }
        },
        FABULOUS {
            @Override
            void beforeTransparencyChain(final class_4597.class_4598 bufferSource) {
                if (hasVisibleProjectors()) {
                    flushDepthWritingSheets(bufferSource);
                    captureMainCameraDepth();
                }
            }

            @Override
            void afterParticles(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
                prepareProjectorRendering(modelViewMatrix, projectionMatrix);
            }

            @Override
            void afterLevel() {
                if (hasPendingProjectors()) {
                    compositeIntoMainTarget();
                }
            }
        },
        SHADER_PACK {
            @Override
            void beforeTranslucentTerrain(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
                if (prepareProjectorRendering(modelViewMatrix, projectionMatrix)) {
                    captureMainCameraDepth();
                    compositeIntoShaderTarget();
                }
            }
        };

        void beforeTransparencyChain(final class_4597.class_4598 bufferSource) {
        }

        void beforeTranslucentTerrain(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
        }

        void afterParticles(final Matrix4f modelViewMatrix, final Matrix4f projectionMatrix) {
        }

        void afterLevel() {
        }
    }

    private static class LazyDepthOnlyRenderBuffer {
        public DepthOnlyRenderTarget target = new DepthOnlyRenderTarget(DEPTH_CAPTURE_SIZE, DEPTH_CAPTURE_SIZE);
        public WeakReference<?> owner;

        public boolean isOwnedBy(ProjectorBlockEntity projector) {
            return owner != null && owner.get() == projector;
        }
    }

    private static final class RenderInfo implements ProjectorBlockEntity.FrameConsumer {
        private static final ThreadLocal<byte[]> RGB = ThreadLocal.withInitial(() -> new byte[3]);

        private final class_1043 texture;
        private boolean hasNewFrame;

        RenderInfo(final class_1043 texture) {
            this.texture = texture;
        }

        public class_1043 texture() {
            return texture;
        }

        public synchronized void close() {
            texture.close();
        }

        public synchronized void uploadIfDirty() {
            if (hasNewFrame) {
                hasNewFrame = false;
                upload();
            }
        }

        public void upload() {
            final class_1011 pixels = texture.method_4525();
            if (pixels == null) {
                return;
            }

            texture.method_23207();
            pixels.method_22619(0, 0, 0, 0, 0, pixels.method_4307(), pixels.method_4323(),
                /* blur: */ true, /* clamp: */ true, /* mipmap: */ false, /* autoClose: */ false);
        }

        @Override
        public synchronized void processFrame(final Picture picture) {
            final class_1011 image = texture.method_4525();
            if (image == null) {
                return;
            }

            final byte[] y = picture.getPlaneData(0);
            final byte[] u = picture.getPlaneData(1);
            final byte[] v = picture.getPlaneData(2);

            // Convert in quads, based on the half resolution of UV. As such, skip every other row, since
            // we're setting the current and the next.
            int lumaIndex = 0, chromaIndex = 0;
            for (int halfRow = 0; halfRow < ProjectorDevice.HEIGHT / 2; halfRow++, lumaIndex += ProjectorDevice.WIDTH * 2) {
                final int row = halfRow * 2;
                for (int halfCol = 0; halfCol < ProjectorDevice.WIDTH / 2; halfCol++, chromaIndex++) {
                    final int col = halfCol * 2;
                    final int yIndex = lumaIndex + col;
                    final byte cb = u[chromaIndex];
                    final byte cr = v[chromaIndex];
                    setFromYUV420(image, col, row, y[yIndex], cb, cr);
                    setFromYUV420(image, col + 1, row, y[yIndex + 1], cb, cr);
                    setFromYUV420(image, col, row + 1, y[yIndex + ProjectorDevice.WIDTH], cb, cr);
                    setFromYUV420(image, col + 1, row + 1, y[yIndex + ProjectorDevice.WIDTH + 1], cb, cr);
                }
            }

            hasNewFrame = true;
        }

        private static void setFromYUV420(final class_1011 image, final int col, final int row, final byte y, final byte cb, final byte cr) {
            final byte[] bytes = RGB.get();
            Yuv420jToRgb.YUVJtoRGB(y, cb, cr, bytes, 0);
            final int r = bytes[0] + 128;
            final int g = bytes[1] + 128;
            final int b = bytes[2] + 128;
            image.method_4305(col, row, r | (g << 8) | (b << 16) | (0xFF << 24));
        }
    }

    private static final class DepthOnlyRenderTarget extends class_6367 {
        public DepthOnlyRenderTarget(final int width, final int height) {
            super(width, height, true, class_310.field_1703);
        }

        @Override
        public void method_1231(final int width, final int height, final boolean isOnOSX) {
            super.method_1231(width, height, isOnOSX);
            if (field_1475 > -1) {
                if (field_1476 > -1) {
                    glBindFramebuffer(GL_FRAMEBUFFER, field_1476);
                    glDrawBuffer(GL_NONE);
                    glReadBuffer(GL_NONE);
                    glBindFramebuffer(GL_FRAMEBUFFER, 0);
                }
                TextureUtil.releaseTextureId(this.field_1475);
                this.field_1475 = -1;
            }
        }
    }

    private static final class ProjectorCameraEntity extends class_1657 {
        private static ProjectorCameraEntity instance;

        public static ProjectorCameraEntity get(final class_1937 level, final class_243 pos, final float rotationY, final float rotationX) {
            if (instance == null) {
                instance = new ProjectorCameraEntity(level, class_2338.field_10980, rotationY);
            }

            instance.method_51502(level);
            instance.method_5808(pos.method_10216(), pos.method_10214(), pos.method_10215(), rotationY, rotationX);

            return instance;
        }

        private ProjectorCameraEntity(final class_1937 level, final class_2338 blockPos, final float rotationY) {
            super(level, blockPos, rotationY, FakePlayerUtils.getFakePlayerProfile());
        }

        @Override
        public float method_5705(final float partialTicks) {
            return field_5982;
        }

        @Override
        public float method_5695(final float partialTicks) {
            return field_6004;
        }

        @Override
        public boolean method_7325() {
            return false;
        }

        @Override
        public boolean method_7337() {
            return true;
        }
    }
}
