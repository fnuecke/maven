/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.vm.block.AbstractRemovableMediaDevice;
import li.cil.oc2.common.bus.device.vm.block.RemovableMediaContainer;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.container.TypedItemStackHandler;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.AbstractMessage;
import li.cil.oc2.common.util.ItemDeviceUtils;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.LocationSupplierUtils;
import li.cil.oc2.common.util.ThrottledSoundEmitter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_9062;
import javax.annotation.Nullable;
import java.time.Duration;

public abstract class AbstractRemovableMediaBlockEntity<TDevice extends AbstractRemovableMediaDevice> extends ModBlockEntity implements RemovableMediaContainer {
    private final RemovableMediaItemStackHandler itemHandler;
    private final ThrottledSoundEmitter insertSoundEmitter;
    private final ThrottledSoundEmitter ejectSoundEmitter;

    @Nullable
    private TDevice device;

    // --------------------------------------------------------------------- //

    protected AbstractRemovableMediaBlockEntity(
        final class_2591<?> type,
        final class_2338 pos,
        final class_2680 state,
        final class_6862<class_1792> mediaTag,
        final class_3414 insertSound,
        final class_3414 ejectSound
    ) {
        super(type, pos, state);

        this.itemHandler = new RemovableMediaItemStackHandler(mediaTag);
        this.insertSoundEmitter = new ThrottledSoundEmitter(LocationSupplierUtils.of(this),
            insertSound).withMinInterval(Duration.ofMillis(100));
        this.ejectSoundEmitter = new ThrottledSoundEmitter(LocationSupplierUtils.of(this),
            ejectSound).withMinInterval(Duration.ofMillis(100));
    }

    // --------------------------------------------------------------------- //

    protected abstract class_2350 getEjectDirection();

    protected abstract AbstractMessage createMediaMessage();

    // --------------------------------------------------------------------- //

    public boolean canInsert(final class_1799 stack) {
        return itemHandler.isItemValid(0, stack);
    }

    public class_1799 insert(final class_1799 stack, @Nullable final class_1657 player) {
        if (!canInsert(stack)) {
            return stack;
        }

        eject(player);

        insertSoundEmitter.play();
        return itemHandler.insertItem(0, stack, false);
    }

    public boolean canEject() {
        return !itemHandler.extractItem(0, 1, true).method_7960();
    }

    public void eject(@Nullable final class_1657 player) {
        if (field_11863 == null) {
            return;
        }

        final class_1799 stack = itemHandler.extractItem(0, 1, false);
        if (!stack.method_7960()) {
            final class_2350 facing = getEjectDirection();
            ejectSoundEmitter.play();
            ItemStackUtils.spawnAsEntity(field_11863, method_11016().method_10093(facing), stack, facing).ifPresent(entity -> {
                if (player != null) {
                    entity.method_6975();
                    entity.method_48349(player.method_5667());
                }
            });
        }
    }

    public void dropMedia() {
        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        final class_1799 stack = itemHandler.extractItem(0, 1, false);
        if (!stack.method_7960()) {
            ItemStackUtils.spawnAsEntity(field_11863, method_11016(), stack);
        }
    }

    public class_9062 useWith(final class_1937 level, final class_1799 heldStack, final class_1657 player, final class_1268 hand) {
        if (player.method_5715()) {
            if (canEject()) {
                if (!level.method_8608()) {
                    eject(player);
                }
                return class_9062.method_55644(level.method_8608());
            }
        } else {
            if (canInsert(heldStack)) {
                if (!level.method_8608()) {
                    player.method_6122(hand, insert(heldStack, player));
                }
                return class_9062.method_55644(level.method_8608());
            }
        }

        return class_9062.field_47731;
    }

    public class_1269 useWithoutItem(final class_1937 level, final class_1657 player) {
        if (player.method_5715() && canEject()) {
            if (!level.method_8608()) {
                eject(player);
            }
            return class_1269.method_29236(level.method_8608());
        }

        return class_1269.field_5811;
    }

    public class_1799 getMedia() {
        return itemHandler.getStackInSlot(0);
    }

    @Environment(EnvType.CLIENT)
    public void setMediaClient(final class_1799 stack) {
        itemHandler.setStackInSlot(0, stack);
    }

    @Nullable
    public TDevice getDevice() {
        return device;
    }

    public void setDevice(final TDevice value) {
        device = value;
    }

    @Override
    public class_1799 getMediaItemStack() {
        return itemHandler.getStackInSlotRaw(0);
    }

    @Override
    public void handleMediaChanged() {
        method_5431();
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);
        tag.method_10566(Constants.ITEMS_TAG_NAME, itemHandler.serializeNBT(registries));
        return tag;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.ITEM_HANDLER, itemHandler);
    }

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10566(Constants.ITEMS_TAG_NAME, itemHandler.serializeNBT(registries));
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        itemHandler.deserializeNBT(registries, tag.method_10562(Constants.ITEMS_TAG_NAME));
    }

    // --------------------------------------------------------------------- //

    private final class RemovableMediaItemStackHandler extends TypedItemStackHandler {
        public RemovableMediaItemStackHandler(final class_6862<class_1792> mediaTag) {
            super(1, mediaTag);
        }

        public class_1799 getStackInSlotRaw(final int slot) {
            return super.getStackInSlot(slot);
        }

        @Override
        public class_1799 getStackInSlot(final int slot) {
            final class_1799 stack = getStackInSlotRaw(slot);
            exportDeviceDataToItemStack(stack);
            return stack;
        }

        @Override
        public class_1799 extractItem(final int slot, final int amount, final boolean simulate) {
            if (slot == 0 && !simulate && amount > 0) {
                exportDeviceDataToItemStack(getStackInSlotRaw(0));
            }

            return super.extractItem(slot, amount, simulate);
        }

        @Override
        public int getSlotLimit(final int slot) {
            return 1;
        }

        @Override
        public class_2487 serializeNBT(final class_7225.class_7874 provider) {
            exportDeviceDataToItemStack(getStackInSlotRaw(0));
            return super.serializeNBT(provider);
        }

        @Override
        protected void onContentsChanged(final int slot) {
            super.onContentsChanged(slot);

            if (field_11863 == null || field_11863.method_8608()) {
                return;
            }

            final class_1799 stack = getStackInSlotRaw(slot);
            if (device != null) {
                if (stack.method_7960()) {
                    device.removeBlockDevice();
                } else {
                    device.updateBlockDevice(ItemDeviceUtils.getDeviceData(stack, device.getDeviceDataKey()));
                }
            }

            Network.sendToClientsTrackingBlockEntity(createMediaMessage(), AbstractRemovableMediaBlockEntity.this);

            method_5431();
        }

        private void exportDeviceDataToItemStack(final class_1799 stack) {
            if (stack.method_7960()) {
                return;
            }

            if (field_11863 == null || field_11863.method_8608()) {
                return;
            }

            if (device == null) {
                return;
            }

            final class_2487 tag = new class_2487();
            device.exportToItemStack(tag);

            if (tag.method_33133()) {
                return;
            }

            ItemDeviceUtils.setDeviceData(stack, device.getDeviceDataKey(), tag);
        }
    }
}
