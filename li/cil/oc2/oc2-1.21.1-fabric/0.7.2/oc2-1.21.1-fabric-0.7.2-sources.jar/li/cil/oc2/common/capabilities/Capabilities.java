/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.capabilities;

import dev.architectury.injectables.annotations.ExpectPlatform;
import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.capabilities.NetworkInterface;
import li.cil.oc2.api.capabilities.RedstoneEmitter;
import li.cil.oc2.api.capabilities.Robot;
import li.cil.oc2.api.capabilities.TerminalUserProvider;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.energy.EnergyHandler;
import li.cil.oc2.common.fluid.FluidHandler;
import li.cil.oc2.common.inventory.ItemHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import javax.annotation.Nullable;

public final class Capabilities {
    // Interop capabilities
    public static final CapabilityType<EnergyHandler> ENERGY_STORAGE = type("energy_storage", EnergyHandler.class);
    public static final CapabilityType<ItemHandler> ITEM_HANDLER = type("item_handler", ItemHandler.class);
    public static final CapabilityType<FluidHandler> FLUID_HANDLER = type("fluid_handler", FluidHandler.class);

    // Owned capabilities
    public static final CapabilityType<DeviceBusElement> DEVICE_BUS_ELEMENT = type("device_bus_element", DeviceBusElement.class);
    public static final CapabilityType<Device> DEVICE = type("device", Device.class);
    public static final CapabilityType<RedstoneEmitter> REDSTONE_EMITTER = type("redstone_emitter", RedstoneEmitter.class);
    public static final CapabilityType<NetworkInterface> NETWORK_INTERFACE = type("network_interface", NetworkInterface.class);
    public static final CapabilityType<TerminalUserProvider> TERMINAL_USER_PROVIDER = type("terminal_user_provider", TerminalUserProvider.class);
    public static final CapabilityType<Robot> ROBOT = type("robot", Robot.class);

    // --------------------------------------------------------------------- //

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_1937 level, final class_2338 pos, final CapabilityType<T> type, @Nullable final class_2350 side) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_2586 blockEntity, final CapabilityType<T> type, @Nullable final class_2350 side) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_1799 stack, final CapabilityType<T> type) {
        throw new AssertionError();
    }

    @ExpectPlatform
    @Nullable
    public static <T> T get(final class_1297 entity, final CapabilityType<T> type, @Nullable final class_2350 side) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T> Invalidatable<T> watch(final class_1936 level, final class_2338 pos, @Nullable final class_2350 side,
                                             final CapabilityType<T> type) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void invalidate(final class_2586 blockEntity) {
        throw new AssertionError();
    }

    // --------------------------------------------------------------------- //

    private static <T> CapabilityType<T> type(final String name, final Class<T> type) {
        return new CapabilityType<>(class_2960.method_60655(API.MOD_ID, name), type);
    }

    private Capabilities() {
    }
}
