/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import li.cil.oc2.common.util.VoxelShapeUtils;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_3726;
import java.util.EnumMap;
import java.util.Map;

public abstract class FlippableOrientableBlock extends class_2248 {
    public static final class_2754<FlippableOrientation> ORIENTATION = class_2754.method_11850("facing", FlippableOrientation.class);

    // --------------------------------------------------------------------- //

    private final Map<FlippableOrientation, class_265> shapes;

    // --------------------------------------------------------------------- //

    protected FlippableOrientableBlock(final class_2251 properties, final FlippableOrientation orientation, final class_265 northShape) {
        super(properties);
        this.shapes = shapesRotatedFrom(northShape);
        method_9590(method_9595().method_11664()
            .method_11657(ORIENTATION, orientation));
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2680 method_9605(final class_1750 context) {
        final class_2350 horizontalDirection = context.method_8042();
        final class_2350 facing = context.method_8036() != null
            ? context.method_7715().method_10153()
            : horizontalDirection.method_10153();
        final class_2350 up = switch (facing) {
            case field_11036 -> horizontalDirection.method_10153();
            case field_11033 -> horizontalDirection;
            default -> context.method_8038() == class_2350.field_11033 ? class_2350.field_11033 : class_2350.field_11036;
        };
        return method_9564().method_11657(ORIENTATION, FlippableOrientation.of(facing, up));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected class_265 method_9530(final class_2680 state, final class_1922 level, final class_2338 pos, final class_3726 context) {
        return shapes.get(state.method_11654(ORIENTATION));
    }

    @Override
    protected class_2680 method_9598(final class_2680 state, final class_2470 rotation) {
        return state.method_11657(ORIENTATION, state.method_11654(ORIENTATION).rotate(rotation));
    }

    @Override
    protected class_2680 method_9569(final class_2680 state, final class_2415 mirror) {
        return state.method_11657(ORIENTATION, state.method_11654(ORIENTATION).mirror(mirror));
    }

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(ORIENTATION);
    }

    // --------------------------------------------------------------------- //

    private static Map<FlippableOrientation, class_265> shapesRotatedFrom(final class_265 northShape) {
        final Map<FlippableOrientation, class_265> shapes = new EnumMap<>(FlippableOrientation.class);
        for (final FlippableOrientation orientation : FlippableOrientation.values()) {
            shapes.put(orientation, VoxelShapeUtils.rotateAroundCenter(northShape, orientation.getRotation()));
        }
        return shapes;
    }
}
