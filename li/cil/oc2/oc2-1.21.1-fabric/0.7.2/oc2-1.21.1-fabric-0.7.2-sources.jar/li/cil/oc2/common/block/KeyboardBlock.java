/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.client.gui.KeyboardScreen;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.KeyboardBlockEntity;
import li.cil.oc2.common.entity.CatSitOnDeviceGoal;
import li.cil.oc2.common.util.VoxelShapeUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_310;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import org.jetbrains.annotations.Nullable;

public final class KeyboardBlock extends class_2383 implements class_2343 {
    public static final MapCodec<KeyboardBlock> CODEC = MapCodec.unit(KeyboardBlock::new);

    @Override
    protected MapCodec<? extends KeyboardBlock> method_53969() {
        return field_46280;
    }

    private static final class_265 NEG_Z_SHAPE = class_259.method_1084(
        class_2248.method_9541(0, 0, 0, 16, 8, 16), // main body
        class_2248.method_9541(0, 8, 8, 16, 11, 16) // top
    );
    private static final class_265 NEG_X_SHAPE = VoxelShapeUtils.rotateHorizontalClockwise(NEG_Z_SHAPE);
    private static final class_265 POS_Z_SHAPE = VoxelShapeUtils.rotateHorizontalClockwise(NEG_X_SHAPE);
    private static final class_265 POS_X_SHAPE = VoxelShapeUtils.rotateHorizontalClockwise(POS_Z_SHAPE);

    // --------------------------------------------------------------------- //

    public KeyboardBlock() {
        super(class_2251.method_9637()
            .method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2680 method_9605(final class_1750 context) {
        return super.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    public class_265 method_9530(final class_2680 state, final class_1922 level, final class_2338 pos, final class_3726 context) {
        return switch (state.method_11654(field_11177)) {
            case field_11043 -> NEG_Z_SHAPE;
            case field_11035 -> POS_Z_SHAPE;
            case field_11039 -> NEG_X_SHAPE;
            default -> POS_X_SHAPE;
        };
    }

    @Override
    protected boolean method_9516(final class_2680 state, final class_10 type) {
        return false;
    }

    @Override
    protected class_9062 method_55765(final class_1799 stack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof final KeyboardBlockEntity keyboard)) {
            return super.method_55765(stack, state, level, pos, player, hand, hit);
        }

        if (level.method_8608() && !CatSitOnDeviceGoal.isCatSittingAt(level, pos)) {
            openKeyboardScreen(keyboard);
        }

        return class_9062.method_55644(level.method_8608());
    }

    @Override
    protected class_1269 method_55766(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof final KeyboardBlockEntity keyboard)) {
            return super.method_55766(state, level, pos, player, hit);
        }

        if (level.method_8608() && !CatSitOnDeviceGoal.isCatSittingAt(level, pos)) {
            openKeyboardScreen(keyboard);
        }

        return class_1269.method_29236(level.method_8608());
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.KEYBOARD.get().method_11032(pos, state);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(field_11177);
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    private static void openKeyboardScreen(final KeyboardBlockEntity keyboard) {
        final KeyboardScreen screen = new KeyboardScreen(keyboard);
        class_310.method_1551().method_1507(screen);
    }
}
