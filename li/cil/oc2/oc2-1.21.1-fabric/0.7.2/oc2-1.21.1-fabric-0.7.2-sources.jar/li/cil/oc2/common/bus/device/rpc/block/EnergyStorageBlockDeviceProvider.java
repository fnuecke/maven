/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.bus.device.provider.util.AbstractBlockEntityCapabilityDeviceProvider;
import li.cil.oc2.common.bus.device.rpc.EnergyHandlerDevice;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.energy.EnergyHandler;
import net.minecraft.class_2586;

public final class EnergyStorageBlockDeviceProvider extends AbstractBlockEntityCapabilityDeviceProvider<EnergyHandler, class_2586> {
    public EnergyStorageBlockDeviceProvider() {
        super(Capabilities.ENERGY_STORAGE);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected Invalidatable<Device> getBlockDevice(final BlockDeviceQuery query, final EnergyHandler value) {
        return Invalidatable.of(new ObjectDevice(new EnergyHandlerDevice(value)));
    }
}
