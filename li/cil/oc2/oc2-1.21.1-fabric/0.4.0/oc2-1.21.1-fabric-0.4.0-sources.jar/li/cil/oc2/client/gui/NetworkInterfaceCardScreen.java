/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.client.gui.widget.Texture;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.item.NetworkInterfaceCardItem;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.NetworkInterfaceCardConfigurationMessage;
import net.minecraft.class_1087;
import net.minecraft.class_1109;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5250;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;

import static li.cil.oc2.common.util.TranslationUtils.key;
import static li.cil.oc2.common.util.TranslationUtils.text;

public final class NetworkInterfaceCardScreen extends class_437 {
    private static final String SIDE_STATE_TEXT = key("gui.{mod}.network_interface_card.side_state");
    private static final class_2561 CONNECTIVITY_ENABLED_TEXT = text("gui.{mod}.network_interface_card.connectivity.enabled");
    private static final class_2561 CONNECTIVITY_DISABLED_TEXT = text("gui.{mod}.network_interface_card.connectivity.disabled");
    private static final class_2561 INFO_TEXT = text("gui.{mod}.network_interface_card.info");

    public static final int UI_WIDTH = Sprites.NETWORK_INTERFACE_CARD_SCREEN.width;
    public static final int UI_HEIGHT = Sprites.NETWORK_INTERFACE_CARD_SCREEN.height;
    public static final int BLOCK_LEFT = UI_WIDTH / 2;
    public static final int BLOCK_TOP = 53;
    public static final int INFO_TEXT_LEFT = 8;
    public static final int INFO_TEXT_TOP = 104;
    public static final int INFO_TEXT_WIDTH = UI_WIDTH - 16;
    public static final int MAX_BLOCK_PITCH = 30;

    // --------------------------------------------------------------------- //

    private final class_1657 player;
    private final class_1268 hand;

    private final ComputerBlockItemRenderer computerBlockItemRenderer = new ComputerBlockItemRenderer();

    private Vector3f blockRotation = new Vector3f(-30, 45, 0);
    private int left, top;
    @Nullable
    private class_2350 focusedSide;
    private boolean isDraggingBlock, hasDraggedBlock;
    private double dragStartX, dragStartY;

    // --------------------------------------------------------------------- //

    public NetworkInterfaceCardScreen(final class_1657 player, final class_1268 hand) {
        super(Items.NETWORK_INTERFACE_CARD.get().method_7848());
        this.player = player;
        this.hand = hand;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_25426() {
        super.method_25426();

        left = (field_22789 - UI_WIDTH) / 2;
        top = (field_22790 - UI_HEIGHT) / 2;
    }

    @Override
    public void method_25393() {
        super.method_25393();

        final class_1799 heldItem = player.method_5998(hand);
        if (!heldItem.method_31574(Items.NETWORK_INTERFACE_CARD.get())) {
            method_25419();
        }
    }

    @Override
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        final boolean result = super.method_25402(mouseX, mouseY, button);

        if (!result && isMouseInBlockArea(mouseX, mouseY) && button == 0) {
            isDraggingBlock = true;
            hasDraggedBlock = false;
            dragStartX = mouseX;
            dragStartY = mouseY;
        }

        return result;
    }

    @Override
    public boolean method_25406(final double mouseX, final double mouseY, final int button) {
        if (isDraggingBlock && button == 0) {
            isDraggingBlock = false;
            if (!hasDraggedBlock && focusedSide != null) {
                final NetworkInterfaceCardConfigurationMessage message = new NetworkInterfaceCardConfigurationMessage(hand, focusedSide, !getConfiguration(focusedSide));
                Network.sendToServer(message);
                class_310.method_1551().method_1483()
                    .method_4873(class_1109.method_47978(class_3417.field_15015, 1));
            }
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(final double mouseX, final double mouseY, final int activeButton, final double deltaX, final double deltaY) {
        if (isDraggingBlock && activeButton == 0) {
            if (!hasDraggedBlock) {
                final double dx = mouseX - dragStartX;
                final double dy = mouseY - dragStartY;
                final double delta = Math.sqrt(dx * dx + dy * dy);
                hasDraggedBlock = delta > 3;
            }
            if (hasDraggedBlock) {
                blockRotation = new Vector3f(
                    class_3532.method_15363(blockRotation.x() - (float) deltaY, -MAX_BLOCK_PITCH, MAX_BLOCK_PITCH),
                    class_3532.method_15393(blockRotation.y() + (float) deltaX),
                    blockRotation.z()
                );
            }
        }

        return true;
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        method_52752(graphics);
        Sprites.NETWORK_INTERFACE_CARD_SCREEN.draw(graphics, left, top);
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        final int blockX = left + BLOCK_LEFT;
        final int blockY = top + BLOCK_TOP;
        focusedSide = computerBlockItemRenderer.getFocusedSide(blockX - mouseX, blockY - mouseY, blockRotation);
        computerBlockItemRenderer.render(blockX, blockY, blockRotation);

        if (focusedSide != null) {
            final class_2561 enabledComponent = getConfiguration(focusedSide) ? CONNECTIVITY_ENABLED_TEXT : CONNECTIVITY_DISABLED_TEXT;
            final class_5250 tooltip = class_2561.method_43469(SIDE_STATE_TEXT, enabledComponent);
            graphics.method_51438(field_22793, tooltip, mouseX, mouseY);
        }

        graphics.method_51440(field_22793, INFO_TEXT, left + INFO_TEXT_LEFT, top + INFO_TEXT_TOP, INFO_TEXT_WIDTH, 0xAAAAAA);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --------------------------------------------------------------------- //

    private boolean isMouseInBlockArea(final double mouseX, final double mouseY) {
        return mouseX >= left + 37 && mouseX <= left + 37 + 102 &&
            mouseY >= top + 10 && mouseY <= top + 10 + 102;
    }

    private boolean getConfiguration(@Nullable final class_2350 side) {
        return side != null && NetworkInterfaceCardItem.getSideConfiguration(player.method_5998(hand), side);
    }

    // --------------------------------------------------------------------- //

    private final class ComputerBlockItemRenderer {
        public static final int BLOCK_RENDER_SIZE = 48;

        private final class_1799 computerItemStack = new class_1799(Items.COMPUTER.get());
        private final class_918 itemRenderer = class_310.method_1551().method_1480();
        private final class_1087 model = itemRenderer.method_4019(computerItemStack, null, null, 0);

        @Nullable
        private class_2350 getFocusedSide(final float mouseX, final float mouseY, final Vector3f rotation) {
            // Rotate ray inversely around block to represent visual block rotation.
            final Quaternionf quaternion = fromXYZDegrees(toRenderRotation(rotation));
            quaternion.conjugate();

            // Move ray in screen space to mouse position.
            final float relMouseX = -mouseX / BLOCK_RENDER_SIZE;
            final float relMouseY = -mouseY / BLOCK_RENDER_SIZE;

            final Vector3f source = new Vector3f();
            source.add(relMouseX, relMouseY, 1);
            source.rotate(quaternion);

            final Vector3f target = new Vector3f();
            target.add(relMouseX, relMouseY, -1);
            target.rotate(quaternion);

            // Intersect rotated ray with bounding box representing block.
            final class_238 aabb = new class_238(-0.5, -0.5, -0.5, 0.5, 0.5, 0.5);
            return aabb.method_992(new class_243(source), new class_243(target))
                .map(hit -> class_2350.method_10142(hit.field_1352, -hit.method_10214(), hit.method_10215()))
                .filter(side -> side != class_2350.field_11035)
                .orElse(null);
        }

        public void render(final int x, final int y, final Vector3f rotation) {
            RenderSystem.setShaderTexture(0, class_1723.field_21668);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderColor(1, 1, 1, 1);

            final Vector3f renderRotation = toRenderRotation(rotation);

            final Matrix4fStack stack = RenderSystem.getModelViewStack();
            stack.pushMatrix();
            stack.translate(x, y, 0);
            stack.rotate(fromXYZDegrees(renderRotation));
            stack.scale(BLOCK_RENDER_SIZE, -BLOCK_RENDER_SIZE, BLOCK_RENDER_SIZE);
            RenderSystem.applyModelViewMatrix();

            final class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();
            renderBlock(bufferSource);
            renderOverlays(new class_4587(), bufferSource);
            bufferSource.method_22993();

            stack.popMatrix();
            RenderSystem.applyModelViewMatrix();
        }

        private void renderBlock(final class_4597.class_4598 bufferSource) {
            itemRenderer.method_23179(computerItemStack, class_811.field_4315, false, new class_4587(), bufferSource, 0xF000F0, class_4608.field_21444, model);
        }

        private void renderOverlays(final class_4587 poseStack, final class_4597.class_4598 bufferSource) {
            for (final class_2350 side : class_2350.values()) {
                // South face of computers is the front face (screen) and there's no connectivity allowed there.
                if (side == class_2350.field_11035) {
                    continue;
                }

                poseStack.method_22903();
                poseStack.method_34426();

                poseStack.method_22904(-side.method_10148() * 0.51, side.method_10164() * 0.51, -side.method_10165() * 0.51);

                final Vector3f sideRotation = switch (side) {
                    case field_11033 -> new Vector3f(-90, 0, 0);
                    case field_11036 -> new Vector3f(90, 0, 0);
                    case field_11043 -> new Vector3f(0, 180, 0);
                    case field_11039 -> new Vector3f(0, -90, 0);
                    case field_11034 -> new Vector3f(0, 90, 0);
                    default -> throw new IllegalStateException("Unexpected value: " + side);
                };
                poseStack.method_22907(fromXYZDegrees(sideRotation));

                poseStack.method_22904(-0.5, -0.5, 0);

                if (getConfiguration(side)) {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_ENABLED_TEXTURE);
                } else {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_DISABLED_TEXTURE);
                }

                if (side == focusedSide) {
                    renderOverlay(poseStack, bufferSource, Textures.BLOCK_FACE_FOCUSED_TEXTURE);
                }

                poseStack.method_22909();
            }
        }

        private void renderOverlay(final class_4587 poseStack, final class_4597.class_4598 bufferSource, final Texture texture) {
            final class_4588 buffer = bufferSource.getBuffer(ModRenderType.getOverlay(texture.location));

            buffer.method_22918(poseStack.method_23760().method_23761(), 0, 0, 0).method_22913(0, 0);
            buffer.method_22918(poseStack.method_23760().method_23761(), 0, 1, 0).method_22913(0, 1);
            buffer.method_22918(poseStack.method_23760().method_23761(), 1, 1, 0).method_22913(1, 1);
            buffer.method_22918(poseStack.method_23760().method_23761(), 1, 0, 0).method_22913(1, 0);
        }

        private static Vector3f toRenderRotation(final Vector3f rotation) {
            return new Vector3f(rotation).add(0, 180, 0);
        }

        private static Quaternionf fromXYZDegrees(final Vector3f degrees) {
            return new Quaternionf().rotationXYZ(
                (float) Math.toRadians(degrees.x()),
                (float) Math.toRadians(degrees.y()),
                (float) Math.toRadians(degrees.z()));
        }
    }
}
