/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.NamedDevice;
import li.cil.oc2.api.inventory.ItemHandler;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.energy.EnergyStorage;
import li.cil.oc2.common.energy.FixedEnergyStorage;
import li.cil.oc2.common.util.ChunkUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;

import static java.util.Collections.singletonList;

public final class ChargerBlockEntity extends ModBlockEntity implements NamedDevice, TickableBlockEntity {
    private static final Predicate<class_1297> ENTITY_PREDICATE =
        class_1301.field_6155
            .and(class_1301.field_6154);

    // --------------------------------------------------------------------- //

    private final FixedEnergyStorage energy = new FixedEnergyStorage(Config.chargerEnergyStorage);
    private boolean isCharging;
    private final class_238 renderBoundingBox;

    // --------------------------------------------------------------------- //

    ChargerBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.CHARGER.get(), pos, state);
        renderBoundingBox = new class_238(pos.method_10084());
    }

    // --------------------------------------------------------------------- //

    @Override
    public void serverTick() {
        if (field_11863 == null) {
            return;
        }

        isCharging = false;
        chargeBlock();
        chargeEntities();

        if (isCharging) {
            ChunkUtils.setLazyUnsaved(field_11863, method_11016());
        }
    }

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10566(Constants.ENERGY_TAG_NAME, energy.serializeNBT());
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        energy.deserializeNBT(tag.method_10562(Constants.ENERGY_TAG_NAME));
    }

    @Callback
    public boolean isCharging() {
        return isCharging;
    }

    @Override
    public Collection<String> getDeviceTypeNames() {
        return singletonList("charger");
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.ENERGY_STORAGE, energy);
    }

    // --------------------------------------------------------------------- //

    private void chargeBlock() {
        assert field_11863 != null;

        if (energy.getEnergyStored() == 0) {
            return;
        }

        final class_2586 blockEntity = field_11863.method_8321(method_11016().method_10084());
        if (blockEntity != null) {
            chargeBlockEntity(blockEntity);
        }
    }

    private void chargeEntities() {
        assert field_11863 != null;

        if (energy.getEnergyStored() == 0) {
            return;
        }

        final List<class_1297> entities = field_11863.method_8333((class_1297) null, new class_238(method_11016().method_10084()), ENTITY_PREDICATE);
        for (final class_1297 entity : entities) {
            chargeEntity(entity);
        }
    }

    private void chargeBlockEntity(final class_2586 blockEntity) {
        charge(Capabilities.get(blockEntity, Capabilities.ENERGY_STORAGE, class_2350.field_11033), Capabilities.get(blockEntity, Capabilities.ITEM_HANDLER, class_2350.field_11033));
    }

    private void chargeEntity(final class_1297 entity) {
        charge(Capabilities.get(entity, Capabilities.ENERGY_STORAGE, class_2350.field_11033), Capabilities.get(entity, Capabilities.ITEM_HANDLER, class_2350.field_11033));
    }

    private void charge(@Nullable EnergyStorage energyStorage, @Nullable ItemHandler itemHandler) {
        if (energyStorage != null) {
            chargeStorage(energyStorage);
        }

        if (itemHandler != null) {
            chargeItems(itemHandler);
        }
    }

    private void chargeStorage(final EnergyStorage energyStorage) {
        assert field_11863 != null;

        final long amount = Math.min(energy.getEnergyStored(), Config.chargerEnergyPerTick);
        final boolean simulate = field_11863.field_9236;
        if (energy.extractEnergy(energyStorage.receiveEnergy(amount, simulate), simulate) > 0) {
            isCharging = true;
        }
    }

    private void chargeItems(final ItemHandler itemHandler) {
        for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
            final class_1799 stack = itemHandler.getStackInSlot(slot);
            if (!stack.method_7960()) {
                final EnergyStorage stackEnergy = Capabilities.get(stack, Capabilities.ENERGY_STORAGE);
                if (stackEnergy != null) {
                    chargeStorage(stackEnergy);
                }
            }
        }
    }

    @Nullable
    @Override
    public class_238 getExpandedRenderBoundingBox() {
        return renderBoundingBox;
    }
}
