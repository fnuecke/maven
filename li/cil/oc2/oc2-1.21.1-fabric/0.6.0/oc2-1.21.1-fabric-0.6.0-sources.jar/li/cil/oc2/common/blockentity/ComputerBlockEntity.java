/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import dev.architectury.utils.EnvExecutor;
import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.api.capabilities.TerminalUserProvider;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.client.audio.LoopingSoundManager;
import li.cil.oc2.client.audio.TerminalBell;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.block.ComputerBlock;
import li.cil.oc2.common.bus.AbstractBlockDeviceBusElement;
import li.cil.oc2.common.bus.BlockDeviceBusController;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityProvider;
import li.cil.oc2.common.capabilities.CapabilityType;
import li.cil.oc2.common.capabilities.CompoundNetworkInterface;
import li.cil.oc2.common.container.ComputerInventoryContainer;
import li.cil.oc2.common.container.ComputerTerminalContainer;
import li.cil.oc2.common.energy.FixedEnergyStorage;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.*;
import li.cil.oc2.common.serialization.NBTSerialization;
import li.cil.oc2.common.util.*;
import li.cil.oc2.common.vm.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4076;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.*;

import static java.util.Objects.requireNonNull;
import static li.cil.oc2.common.Constants.ITEMS_TAG_NAME;

public final class ComputerBlockEntity extends ModBlockEntity implements TerminalUserProvider, TickableBlockEntity {
    private static final String BUS_ELEMENT_TAG_NAME = "busElement";
    private static final String DEVICES_TAG_NAME = "devices";
    private static final String TERMINAL_TAG_NAME = "terminal";
    private static final String STATE_TAG_NAME = "state";
    private static final String ENERGY_TAG_NAME = "energy";

    private static final int CPU_SLOTS = 1;
    private static final int MEMORY_SLOTS = 4;
    private static final int HARD_DRIVE_SLOTS = 4;
    private static final int FLASH_MEMORY_SLOTS = 1;
    private static final int CARD_SLOTS = 4;

    private static final int MAX_RUNNING_SOUND_DELAY = TickUtils.toTicks(Duration.ofSeconds(2));

    private static final int TERMINAL_RECIPIENT_REFRESH_INTERVAL = TickUtils.toTicks(Duration.ofSeconds(1));
    private static final double TERMINAL_VIEW_DISTANCE = 8;

    // --------------------------------------------------------------------- //

    private boolean hasAddedOwnDevices;
    private boolean isNeighborUpdateScheduled;
    private class_2818 chunk;

    // --------------------------------------------------------------------- //

    private final Terminal terminal = new Terminal();
    private final ComputerBusElement busElement = new ComputerBusElement();
    private final ComputerItemStackHandlers deviceItems = new ComputerItemStackHandlers();
    private final FixedEnergyStorage energy = new FixedEnergyStorage(Config.computerEnergyStorage);
    private final ComputerVirtualMachine virtualMachine = new ComputerVirtualMachine(new BlockDeviceBusController(busElement, this::cpuEnergyPerTick, this, deviceItems::getArchitectureType), deviceItems::getDeviceLocation);
    private final Set<class_1657> terminalUsers = Collections.newSetFromMap(new WeakHashMap<>());
    private final List<CapabilityProvider> capabilityProviders = new ArrayList<>();
    private volatile List<class_3222> terminalRecipients = List.of(); // Players to send live terminal updates to.
    private int terminalRecipientRefreshCountdown;

    // --------------------------------------------------------------------- //

    public ComputerBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.COMPUTER.get(), pos, state);

        // We want to unload devices even on level unload to free global resources.
        setNeedsLevelUnloadEvent();

        // Device scan can change our capability set (cards in the computer having capabilities).
        virtualMachine.getBusController().onAfterDeviceScan.add(this::handleAfterDeviceScan);
    }

    public Terminal getTerminal() {
        return terminal;
    }

    public VirtualMachine getVirtualMachine() {
        return virtualMachine;
    }

    public VirtualMachineClientState getVirtualMachineClientState() {
        return virtualMachine;
    }

    public VMItemStackHandlers getItemStackHandlers() {
        return deviceItems;
    }

    public void start() {
        if (field_11863 != null && !field_11863.method_8608()) {
            virtualMachine.start();
        }
    }

    public void stop() {
        if (field_11863 != null && !field_11863.method_8608()) {
            virtualMachine.stop();
        }
    }

    public void openTerminalScreen(final class_3222 player) {
        ComputerTerminalContainer.createServer(this, energy, virtualMachine.getBusController(), player);
    }

    public void openInventoryScreen(final class_3222 player) {
        ComputerInventoryContainer.createServer(this, energy, virtualMachine.getBusController(), player);
    }

    public void addTerminalUser(final class_1657 player) {
        terminalUsers.add(player);
        updateTerminalRecipients();
    }

    public void removeTerminalUser(final class_1657 player) {
        terminalUsers.remove(player);
        updateTerminalRecipients();
    }

    @Override
    public Iterable<class_1657> getTerminalUsers() {
        final Set<class_1657> users = new LinkedHashSet<>(terminalUsers);
        for (final Device device : virtualMachine.getBusController().getDevices()) {
            if (device instanceof final TerminalUserProvider provider) {
                provider.getTerminalUsers().forEach(users::add);
            }
        }

        return users;
    }

    public void handleNeighborChanged() {
        if (field_11863 != null && !field_11863.method_8608()) {
            virtualMachine.getBusController().scheduleBusScan();
        }
    }

    @Nullable
    @Override
    @SuppressWarnings("unchecked")
    public <T> T getCapability(final CapabilityType<T> capability, @Nullable final class_2350 side) {
        if (!isValid()) {
            return null;
        }

        final T own = super.getCapability(capability, side);
        if (own != null) {
            return own;
        }

        final class_2350 localSide = HorizontalBlockUtils.toLocal(method_11010(), side);
        if (capability == Capabilities.NETWORK_INTERFACE) {
            return (T) CompoundNetworkInterface.of(capabilityProviders, localSide);
        }

        for (final CapabilityProvider capabilityProvider : capabilityProviders) {
            final T value = capabilityProvider.getCapability(capability, localSide);
            if (value != null) {
                return value;
            }
        }

        return null;
    }

    @Override
    public void clientTick() {
        if (terminal.consumePendingBell()) {
            TerminalBell.play();
        }
    }

    @Override
    public void serverTick() {
        if (field_11863 == null) {
            return;
        }

        // Always add devices provided for the computer itself, even if there's no
        // adjacent cable. Because that would just be weird.
        if (!hasAddedOwnDevices) {
            hasAddedOwnDevices = true;
            busElement.addOwnDevices();
        }

        if (isNeighborUpdateScheduled) {
            isNeighborUpdateScheduled = false;
            field_11863.method_8452(method_11016(), method_11010().method_26204());
        }

        if (--terminalRecipientRefreshCountdown <= 0) {
            terminalRecipientRefreshCountdown = TERMINAL_RECIPIENT_REFRESH_INTERVAL;
            updateTerminalRecipients();
        }

        final class_2338 blockPos = method_11016();
        final int chunkX = class_4076.method_18675(blockPos.method_10263());
        final int chunkZ = class_4076.method_18675(blockPos.method_10260());
        if (chunk == null || chunk.method_12004().field_9181 != chunkX || chunk.method_12004().field_9180 != chunkZ) {
            chunk = field_11863.method_8500(blockPos);
        }

        virtualMachine.tick();
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);

        synchronized (terminal) {
            tag.method_10566(TERMINAL_TAG_NAME, NBTSerialization.serialize(terminal));
        }

        tag.method_10569(AbstractVirtualMachine.BUS_STATE_TAG_NAME, virtualMachine.getBusState().ordinal());
        tag.method_10569(AbstractVirtualMachine.RUN_STATE_TAG_NAME, virtualMachine.getRunState().ordinal());
        final class_2561 bootError = virtualMachine.getBootError();
        if (bootError != null) {
            tag.method_10582(AbstractVirtualMachine.BOOT_ERROR_TAG_NAME, class_2561.class_2562.method_10867(bootError, registries));
        }

        return tag;
    }


    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        if (virtualMachine.getRunState() != VMRunState.STOPPED) {
            tag.method_10566(STATE_TAG_NAME, virtualMachine.serialize());
            synchronized (terminal) {
                tag.method_10566(TERMINAL_TAG_NAME, NBTSerialization.serialize(terminal));
            }
        }

        tag.method_10566(ENERGY_TAG_NAME, energy.serializeNBT());
        tag.method_10566(BUS_ELEMENT_TAG_NAME, busElement.save());
        tag.method_10566(ITEMS_TAG_NAME, deviceItems.saveItems(registries));
        tag.method_10566(DEVICES_TAG_NAME, deviceItems.saveDevices());
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        energy.deserializeNBT(tag.method_10562(ENERGY_TAG_NAME));
        virtualMachine.deserialize(tag.method_10562(STATE_TAG_NAME));
        NBTSerialization.deserialize(tag.method_10562(TERMINAL_TAG_NAME), terminal);

        // Client-visible state, only present in the tag produced by getUpdateTag().
        if (tag.method_10545(AbstractVirtualMachine.BUS_STATE_TAG_NAME)) {
            EnvExecutor.runInEnv(EnvType.CLIENT, () -> () -> {
                virtualMachine.setBusStateClient(CommonDeviceBusController.BusState.values()[tag.method_10550(AbstractVirtualMachine.BUS_STATE_TAG_NAME)]);
                virtualMachine.setRunStateClient(VMRunState.values()[tag.method_10550(AbstractVirtualMachine.RUN_STATE_TAG_NAME)]);
                virtualMachine.setBootErrorClient(tag.method_10545(AbstractVirtualMachine.BOOT_ERROR_TAG_NAME)
                    ? class_2561.class_2562.method_10877(tag.method_10558(AbstractVirtualMachine.BOOT_ERROR_TAG_NAME), registries)
                    : null);
            });
        }
        busElement.load(tag.method_10562(BUS_ELEMENT_TAG_NAME));

        deviceItems.loadItems(registries, tag.method_10562(ITEMS_TAG_NAME));
        deviceItems.loadDevices(tag.method_10562(DEVICES_TAG_NAME));
    }

    public void exportToItemStack(final class_1799 stack) {
        final class_7225.class_7874 registries = requireNonNull(method_10997()).method_30349();
        ItemStackUtils.modifyBlockEntityDataTag(stack, method_11017(), tag -> {
            deviceItems.saveItems(registries, NBTUtils.getOrCreateChildTag(tag, ITEMS_TAG_NAME));
            tag.method_10566(ENERGY_TAG_NAME, energy.serializeNBT());
        });
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.ITEM_HANDLER, deviceItems.combinedItemHandlers);
        collector.offer(Capabilities.DEVICE_BUS_ELEMENT, busElement);
        collector.offer(Capabilities.TERMINAL_USER_PROVIDER, this);

        if (Config.computersUseEnergy()) {
            collector.offer(Capabilities.ENERGY_STORAGE, energy);
        }
    }

    @Override
    protected void loadClient() {
        super.loadClient();

        terminal.setDisplayOnly(true);
    }

    @Override
    protected void loadServer() {
        super.loadServer();

        assert field_11863 != null;

        virtualMachine.setGameTimeSource(LevelUtils.gameTimeSupplier(field_11863));
    }

    @Override
    protected void loadServerInLoadedLevel() {
        super.loadServerInLoadedLevel();

        // For item devices that want a capability from the computer; not available during nbt load yet.
        deviceItems.updateDevices();
    }

    @Override
    protected void unloadServer(final boolean isRemove) {
        super.unloadServer(isRemove);

        if (isRemove) {
            virtualMachine.stop();
        } else {
            virtualMachine.suspend();
        }

        virtualMachine.dispose();

        // Just in case, so we don't keep it alive if something holds on to us.
        chunk = null;

        // This is necessary in case some other controller found us before our controller
        // did its scan, which can happen because the scan can happen with a delay. In
        // that case we don't know that controller and disposing our controller won't
        // notify it, so we also send out a notification through our bus element, which
        // would be registered with other controllers in that case.
        busElement.scheduleScan();
    }

    // --------------------------------------------------------------------- //

    private int cpuEnergyPerTick() {
        return Config.cpuEnergyPerTick(deviceItems.getArchitectureType().orElse(null));
    }

    private void updateTerminalRecipients() {
        if (!(field_11863 instanceof final class_3218 serverLevel)) {
            return;
        }

        final class_238 bounds = class_238.method_30048(class_243.method_24953(method_11016()),
            TERMINAL_VIEW_DISTANCE * 2, TERMINAL_VIEW_DISTANCE * 2, TERMINAL_VIEW_DISTANCE * 2);
        final Set<class_3222> players = new LinkedHashSet<>(serverLevel.method_18467(class_3222.class, bounds));

        for (final class_1657 player : terminalUsers) {
            if (player instanceof final class_3222 serverPlayer) {
                players.add(serverPlayer);
            }
        }

        final List<class_3222> previous = terminalRecipients;
        terminalRecipients = List.copyOf(players);

        for (final class_3222 player : terminalRecipients) {
            if (!previous.contains(player)) {
                player.field_13987.method_14364(class_2622.method_38585(this));
            }
        }
    }

    private void sendToTerminalRecipients(final AbstractMessage message) {
        for (final class_3222 player : terminalRecipients) {
            Network.sendToClient(message, player);
        }
    }

    private <T extends AbstractMessage> void sendToClientsTrackingComputer(final T message) {
        if (chunk != null) {
            Network.sendToClientsTrackingChunk(message, chunk);
        }
    }

    private void handleAfterDeviceScan() {
        capabilityProviders.clear();
        for (final Device device : virtualMachine.getBusController().getDevices()) {
            if (device instanceof final CapabilityProvider capabilityProvider) {
                capabilityProviders.add(capabilityProvider);
            }
        }

        if (field_11863 != null && !field_11863.method_8608()) {
            Capabilities.invalidate(this);
        }
    }

    // --------------------------------------------------------------------- //

    private final class ComputerItemStackHandlers extends AbstractVMItemStackHandlers {
        public ComputerItemStackHandlers() {
            super(
                new GroupDefinition(DeviceTypes.CPU.get(), CPU_SLOTS),
                new GroupDefinition(DeviceTypes.MEMORY.get(), MEMORY_SLOTS),
                new GroupDefinition(DeviceTypes.HARD_DRIVE.get(), HARD_DRIVE_SLOTS),
                new GroupDefinition(DeviceTypes.FLASH_MEMORY.get(), FLASH_MEMORY_SLOTS),
                new GroupDefinition(DeviceTypes.CARD.get(), CARD_SLOTS)
            );
        }

        @Override
        protected ItemDeviceQuery makeQuery(final class_1799 stack) {
            return Devices.makeQuery(deviceItems.getArchitectureType().orElse(null), ComputerBlockEntity.this, stack);
        }

        @Override
        protected void onChanged() {
            super.onChanged();
            if (field_11863 != null && !field_11863.method_8608()) {
                virtualMachine.getBusController().scheduleBusScan();
                ChunkUtils.setLazyUnsaved(field_11863, method_11016());
            }
            isNeighborUpdateScheduled = true;
        }
    }

    private final class ComputerBusElement extends AbstractBlockDeviceBusElement {
        private static final String DEVICE_ID_TAG_NAME = "device_id";

        private final HashSet<Device> devices = new HashSet<>();
        private UUID deviceId = UUID.randomUUID();

        @Nullable
        @Override
        public class_1936 getLevel() {
            return ComputerBlockEntity.this.method_10997();
        }

        @Override
        public class_2338 getPosition() {
            return method_11016();
        }

        public void addOwnDevices() {
            assert field_11863 != null;

            collectDevices(field_11863, getPosition(), null).ifPresent(entries -> {
                for (final BlockEntry info : entries) {
                    devices.add(info.getDevice());
                    super.addDevice(info.getDevice());
                }
            });
        }

        @Override
        public Optional<Collection<Invalidatable<DeviceBusElement>>> getNeighbors() {
            return super.getNeighbors().map(neighbors -> {
                // If we have valid neighbors (complete bus) also add a connection to the bus
                // element hosting our item devices.
                final ArrayList<Invalidatable<DeviceBusElement>> list = new ArrayList<>(neighbors);
                list.add(Invalidatable.of(deviceItems.busElement));
                return list;
            });
        }

        @Override
        public boolean canScanContinueTowards(@Nullable final class_2350 direction) {
            return method_11010().method_11654(ComputerBlock.field_11177) != direction;
        }

        @Override
        protected boolean canDetectDevicesTowards(@Nullable final class_2350 direction) {
            return direction == null;
        }

        @Override
        public Optional<UUID> getDeviceIdentifier(final Device device) {
            if (devices.contains(device)) {
                return Optional.of(deviceId);
            }
            return super.getDeviceIdentifier(device);
        }

        @Override
        public class_2487 save() {
            final class_2487 tag = super.save();
            tag.method_25927(DEVICE_ID_TAG_NAME, deviceId);
            return tag;
        }

        public void load(final class_2487 tag) {
            super.load(tag);
            if (tag.method_25928(DEVICE_ID_TAG_NAME)) {
                deviceId = tag.method_25926(DEVICE_ID_TAG_NAME);
            }
        }
    }

    private final class ComputerVMRunner extends AbstractTerminalVMRunner {
        public ComputerVMRunner(final AbstractArchitecture architecture, final Terminal terminal) {
            super(architecture, terminal);
        }

        @Override
        protected void sendTerminalUpdateToClient(final ByteBuffer output) {
            sendToTerminalRecipients(new ComputerTerminalOutputMessage(ComputerBlockEntity.this, output));
        }
    }

    private final class ComputerVirtualMachine extends AbstractVirtualMachine {
        private ComputerVirtualMachine(final CommonDeviceBusController busController, final DeviceLocationProvider deviceLocationProvider) {
            super(busController);
            setDeviceLocationProvider(deviceLocationProvider);
        }

        @Override
        @Environment(EnvType.CLIENT)
        public void setRunStateClient(final VMRunState value) {
            super.setRunStateClient(value);

            if (value == VMRunState.RUNNING) {
                if (!LoopingSoundManager.isPlaying(ComputerBlockEntity.this) && field_11863 != null) {
                    LoopingSoundManager.play(ComputerBlockEntity.this, SoundEvents.COMPUTER_RUNNING.get(), field_11863.method_8409().method_43048(MAX_RUNNING_SOUND_DELAY));
                }
            } else {
                LoopingSoundManager.stop(ComputerBlockEntity.this);
            }
        }

        @Override
        public void tick() {
            assert field_11863 != null;

            if (isRunning()) {
                ChunkUtils.setLazyUnsaved(field_11863, method_11016());
                getBusController().setDeviceContainersChanged();
            }

            super.tick();
        }

        @Override
        protected boolean consumeEnergy(final int amount, final boolean simulate) {
            if (!Config.computersUseEnergy()) {
                return true;
            }

            if (amount > energy.getEnergyStored()) {
                return false;
            }

            energy.extractEnergy(amount, simulate);
            return true;
        }

        @Override
        protected void stopRunnerAndReset() {
            super.stopRunnerAndReset();

            TerminalUtils.resetTerminal(terminal, output -> sendToTerminalRecipients(new ComputerTerminalOutputMessage(ComputerBlockEntity.this, output)));
        }

        @Override
        protected AbstractTerminalVMRunner createRunner(final AbstractArchitecture architecture) {
            return new ComputerVMRunner(architecture, terminal);
        }

        @Override
        protected void handleBusStateChanged(final CommonDeviceBusController.BusState value) {
            sendToClientsTrackingComputer(new ComputerBusStateMessage(ComputerBlockEntity.this, value));

            if (value == CommonDeviceBusController.BusState.READY && field_11863 != null) {
                // Bus just became ready, meaning new devices may be available, meaning new
                // capabilities may be available, so we need to tell our neighbors.
                field_11863.method_8452(method_11016(), method_11010().method_26204());
            }
        }

        @Override
        protected void handleRunStateChanged(final VMRunState value) {
            sendToClientsTrackingComputer(new ComputerRunStateMessage(ComputerBlockEntity.this, value));
        }

        @Override
        protected void handleBootErrorChanged(@Nullable final class_2561 value) {
            sendToClientsTrackingComputer(new ComputerBootErrorMessage(ComputerBlockEntity.this, value));
        }
    }
}
