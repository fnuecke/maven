/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.api.API;
import li.cil.oc2.client.renderer.ModRenderType;
import net.minecraft.class_1723;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import org.joml.Matrix4f;

public final class BlockOverlays {
    private static final class_2960 POWER_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/power");
    private static final class_2960 STATUS_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/status");
    private static final class_2960 TERMINAL_LOCATION = class_2960.method_60655(API.MOD_ID, "block/overlay/terminal");

    private static final class_4730 POWER = new class_4730(class_1723.field_21668, POWER_LOCATION);
    private static final class_4730 STATUS = new class_4730(class_1723.field_21668, STATUS_LOCATION);
    private static final class_4730 TERMINAL = new class_4730(class_1723.field_21668, TERMINAL_LOCATION);

    // --------------------------------------------------------------------- //

    private BlockOverlays() {
    }

    // --------------------------------------------------------------------- //

    public static void renderPower(final Matrix4f matrix, final class_4597 bufferSource) {
        render(matrix, bufferSource, POWER);
    }

    public static void renderStatus(final Matrix4f matrix, final class_4597 bufferSource) {
        render(matrix, bufferSource, STATUS);
    }

    public static void renderStatus(final Matrix4f matrix, final class_4597 bufferSource, final int frequency) {
        if (System.currentTimeMillis() / frequency % 2 == 1) {
            renderStatus(matrix, bufferSource);
        }
    }

    public static void renderTerminal(final Matrix4f matrix, final class_4597 bufferSource) {
        render(matrix, bufferSource, TERMINAL);
    }

    // --------------------------------------------------------------------- //

    private static void render(final Matrix4f matrix, final class_4597 bufferSource, final class_4730 material) {
        final class_4588 consumer = material.method_24145(bufferSource, ModRenderType::getUnlitBlock);

        // Not chained: vanilla's SpriteCoordinateExpander.addVertex returns the delegate, so a
        // chained setUv would bypass the sprite remap (NeoForge patches this, Fabric does not).
        consumer.method_22918(matrix, 0, 0, 0);
        consumer.method_22913(0, 0);

        consumer.method_22918(matrix, 0, 16, 0);
        consumer.method_22913(0, 1);

        consumer.method_22918(matrix, 16, 16, 0);
        consumer.method_22913(1, 1);

        consumer.method_22918(matrix, 16, 0, 0);
        consumer.method_22913(1, 0);
    }
}
