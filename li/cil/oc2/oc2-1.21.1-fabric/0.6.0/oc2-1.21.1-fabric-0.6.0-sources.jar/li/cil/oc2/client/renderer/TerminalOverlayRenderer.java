/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.client.renderer.blockentity.BlockOverlays;
import li.cil.oc2.common.vm.Terminal;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public class TerminalOverlayRenderer {
    public static void renderTerminal(final class_2338 blockPos, final Terminal terminal, final class_4587 stack, final class_4597 bufferSource, final class_243 cameraPosition) {
        // Render terminal content if close enough.
        if (class_243.method_24953(blockPos).method_24802(cameraPosition, 6f)) {
            stack.method_22903();
            stack.method_46416(2, 2, -0.9f);

            // Scale to make terminal fit fully.
            final float textScaleX = 12f / terminal.getWidth();
            final float textScaleY = 7f / terminal.getHeight();
            final float scale = Math.min(textScaleX, textScaleY) * 0.95f;

            // Center it on both axes.
            final float scaleDeltaX = textScaleX - scale;
            final float scaleDeltaY = textScaleY - scale;
            stack.method_46416(
                terminal.getWidth() * scaleDeltaX * 0.5f,
                terminal.getHeight() * scaleDeltaY * 0.5f,
                0f);

            stack.method_22905(scale, scale, 1f);

            TerminalTextures.get(terminal).draw(stack);

            stack.method_22909();
        } else {
            stack.method_22903();
            stack.method_46416(0, 0, -0.9f);

            BlockOverlays.renderTerminal(stack.method_23760().method_23761(), bufferSource);

            stack.method_22909();
        }
    }
}
