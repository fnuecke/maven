/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.util.LevelUtils;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_638;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public final class MessageUtils {
    private static final int INTERACTION_DISTANCE = 8;

    // --------------------------------------------------------------------- //

    public static <T extends class_2586> void withNearbyServerBlockEntityForInteraction(final NetworkManager.PacketContext context, final class_2338 pos, final Class<T> type, final BiConsumer<class_3222, T> callback) {
        withNearbyServerBlockEntity(context, pos, type, INTERACTION_DISTANCE, callback);
    }

    @SuppressWarnings("unchecked")
    public static <T extends class_2586> void withNearbyServerBlockEntity(final NetworkManager.PacketContext context, final class_2338 pos, final Class<T> type, final int maxDistance, final BiConsumer<class_3222, T> callback) {
        if (!(context.getPlayer() instanceof final class_3222 player)
            || !pos.method_19769(player.method_19538(), maxDistance)) {
            return;
        }

        final class_3218 level = player.method_51469();
        final class_2586 blockEntity = LevelUtils.getBlockEntityIfChunkExists(level, pos);
        if (type.isInstance(blockEntity)) {
            callback.accept(player, (T) blockEntity);
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends class_1297> void withTrackedServerEntity(final NetworkManager.PacketContext context, final int id, final Class<T> type, final Consumer<T> callback) {
        if (!(context.getPlayer() instanceof final class_3222 player)) {
            return;
        }

        final class_3218 level = player.method_51469();
        final class_1297 entity = level.method_8469(id);
        if (!type.isInstance(entity)) {
            return;
        }

        final double range = entity.method_5864().method_18387() * 16.0;
        if (Math.abs(player.method_23317() - entity.method_23317()) <= range
            && Math.abs(player.method_23321() - entity.method_23321()) <= range) {
            callback.accept((T) entity);
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends class_1297> void withNearbyServerEntity(final NetworkManager.PacketContext context, final int id, final Class<T> type, final Consumer<T> callback) {
        if (!(context.getPlayer() instanceof final class_3222 player)) {
            return;
        }

        final class_3218 level = player.method_51469();
        final class_1297 entity = level.method_8469(id);
        if (type.isInstance(entity) && entity.method_24516(player, 8)) {
            callback.accept((T) entity);
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends class_2586> void withClientBlockEntityAt(final class_2338 pos, final Class<T> type, final Consumer<T> callback) {
        final class_638 level = class_310.method_1551().field_1687;
        if (level == null) {
            return;
        }

        final class_2586 blockEntity = level.method_8321(pos);
        if (type.isInstance(blockEntity)) {
            callback.accept((T) blockEntity);
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends class_1297> void withClientEntity(final int id, final Class<T> type, final Consumer<T> callback) {
        final class_638 level = class_310.method_1551().field_1687;
        if (level == null) {
            return;
        }

        final class_1297 entity = level.method_8469(id);
        if (type.isInstance(entity)) {
            callback.accept((T) entity);
        }
    }
}
