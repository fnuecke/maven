/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.entity;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.ObjectDevice;
import li.cil.oc2.api.bus.device.object.Parameter;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.api.capabilities.TerminalUserProvider;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.client.audio.TerminalBell;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.bus.AbstractDeviceBusElement;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityProvider;
import li.cil.oc2.common.capabilities.CapabilityType;
import li.cil.oc2.common.container.FixedSizeItemStackHandler;
import li.cil.oc2.common.container.ItemStackHandler;
import li.cil.oc2.common.container.RobotInventoryContainer;
import li.cil.oc2.common.container.RobotTerminalContainer;
import li.cil.oc2.common.energy.FixedEnergyStorage;
import li.cil.oc2.common.entity.robot.*;
import li.cil.oc2.common.integration.Wrenches;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.*;
import li.cil.oc2.common.serialization.NBTSerialization;
import li.cil.oc2.common.util.*;
import li.cil.oc2.common.vm.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_247;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import net.minecraft.class_3532;
import net.minecraft.class_3980;
import net.minecraft.class_4076;
import net.minecraft.class_5819;
import net.minecraft.class_7225;
import net.minecraft.core.*;
import javax.annotation.Nullable;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.*;
import java.util.function.Consumer;

import static java.util.Collections.singleton;
import static li.cil.oc2.common.Constants.ENERGY_TAG_NAME;
import static li.cil.oc2.common.Constants.ITEMS_TAG_NAME;

public final class Robot extends class_1297 implements li.cil.oc2.api.capabilities.Robot, TerminalUserProvider {
    public static final class_2940<class_2338> TARGET_POSITION = class_2945.method_12791(Robot.class, class_2943.field_13324);
    public static final class_2940<class_2350> TARGET_DIRECTION = class_2945.method_12791(Robot.class, class_2943.field_13321);
    public static final class_2940<Byte> SELECTED_SLOT = class_2945.method_12791(Robot.class, class_2943.field_13319);

    private static final String TERMINAL_TAG_NAME = "terminal";
    private static final String STATE_TAG_NAME = "state";
    private static final String BUS_ELEMENT_TAG_NAME = "bus_element";
    private static final String DEVICES_TAG_NAME = "devices";
    private static final String COMMAND_PROCESSOR_TAG_NAME = "commands";
    private static final String INVENTORY_TAG_NAME = "inventory";
    private static final String SELECTED_SLOT_TAG_NAME = "selected_slot";

    private static final int MAX_QUEUED_ACTIONS = 16;
    private static final int MAX_QUEUED_RESULTS = 16;

    private static final int CPU_SLOTS = 1;
    private static final int MEMORY_SLOTS = 4;
    private static final int HARD_DRIVE_SLOTS = 1;
    private static final int FLOPPY_SLOTS = 1;
    private static final int FLASH_MEMORY_SLOTS = 1;
    private static final int MODULE_SLOTS = 4;
    private static final int INVENTORY_SIZE = 12;

    private static final int CONTAINING_BLOCK_CHECK_INTERVAL = TickUtils.toTicks(Duration.ofSeconds(1));

    // --------------------------------------------------------------------- //

    private final Runnable unloadListener = this::handleUnload;
    private final Consumer<class_1923> chunkUnloadListener = this::handleChunkUnload;
    private final class_2338.class_2339 mutablePosition = new class_2338.class_2339();

    @Nullable
    private class_238 lastContainingBlockSweepBounds;
    private int containingBlockSweepCountdown;

    private final AnimationState animationState = new AnimationState();
    private final RobotActionProcessor actionProcessor = new RobotActionProcessor();
    private final Terminal terminal = new Terminal();
    private final RobotVirtualMachine virtualMachine;
    private final RobotBusElement busElement = new RobotBusElement();
    private final RobotItemStackHandlers deviceItems = new RobotItemStackHandlers();
    private final FixedEnergyStorage energy = new FixedEnergyStorage(Config.robotEnergyStorage);
    private final ItemStackHandler inventory = new FixedSizeItemStackHandler(INVENTORY_SIZE);
    private final Set<class_1657> terminalUsers = Collections.newSetFromMap(new WeakHashMap<>());
    private volatile List<class_3222> terminalRecipients = List.of(); // Copy for threaded send.
    private long lastPistonMovement;

    // --------------------------------------------------------------------- //

    public Robot(final class_1299<?> type, final class_1937 world) {
        super(type, world);
        this.field_23807 = true;
        method_5875(true);

        final CommonDeviceBusController busController = new CommonDeviceBusController(busElement, this::cpuEnergyPerTick, deviceItems::getArchitectureType);
        virtualMachine = new RobotVirtualMachine(busController);
        virtualMachine.setGameTimeSource(LevelUtils.gameTimeSupplier(world));
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    public AnimationState getAnimationState() {
        return animationState;
    }

    public Terminal getTerminal() {
        return terminal;
    }

    public VirtualMachine getVirtualMachine() {
        return virtualMachine;
    }

    public VirtualMachineClientState getVirtualMachineClientState() {
        return virtualMachine;
    }

    public VMItemStackHandlers getItemStackHandlers() {
        return deviceItems;
    }

    @Override
    public ItemStackHandler getInventory() {
        return inventory;
    }

    @Override
    public int getSelectedSlot() {
        return method_5841().method_12789(SELECTED_SLOT);
    }

    @Override
    public void setSelectedSlot(final int value) {
        method_5841().method_12778(SELECTED_SLOT, (byte) class_3532.method_15340(value, 0, INVENTORY_SIZE - 1));
    }

    @Nullable
    @SuppressWarnings("unchecked")
    public <T> T getCapability(final CapabilityType<T> capability, @Nullable final class_2350 side) {
        if (capability == Capabilities.ITEM_HANDLER) {
            return (T) inventory;
        }
        if (capability == Capabilities.ENERGY_STORAGE && Config.robotsUseEnergy()) {
            return (T) energy;
        }
        if (capability == Capabilities.ROBOT) {
            return (T) this;
        }
        if (capability == Capabilities.TERMINAL_USER_PROVIDER) {
            return (T) this;
        }

        for (final Device device : virtualMachine.getBusController().getDevices()) {
            if (device instanceof final CapabilityProvider capabilityProvider) {
                final T value = capabilityProvider.getCapability(capability, side);
                if (value != null) {
                    return value;
                }
            }
        }

        return null;
    }

    public long getLastPistonMovement() {
        return lastPistonMovement;
    }

    public void start() {
        if (!method_37908().method_8608()) {
            virtualMachine.start();
        }
    }

    public void stop() {
        if (!method_37908().method_8608()) {
            virtualMachine.stop();
        }
    }

    public void openTerminalScreen(final class_3222 player) {
        // For full terminal snapshot.
        Network.sendToClient(new RobotInitializationMessage(this), player);

        RobotTerminalContainer.createServer(this, energy, virtualMachine.getBusController(), player);
    }

    public void openInventoryScreen(final class_3222 player) {
        RobotInventoryContainer.createServer(this, energy, virtualMachine.getBusController(), player);
    }

    public void addTerminalUser(final class_1657 player) {
        terminalUsers.add(player);
        updateTerminalRecipients();
    }

    public void removeTerminalUser(final class_1657 player) {
        terminalUsers.remove(player);
        updateTerminalRecipients();
    }

    @Override
    public Iterable<class_1657> getTerminalUsers() {
        return terminalUsers;
    }

    public void dropSelf() {
        if (!method_5805()) {
            return;
        }

        final class_1799 stack = new class_1799(Items.ROBOT.get());
        exportToItemStack(stack);
        method_5775(stack);

        method_31472();
        LevelUtils.playSound(method_37908(), method_24515(), class_2498.field_11533, class_2498::method_10595);
    }

    @Override
    public void method_5773() {
        final boolean isClient = method_37908().method_8608();

        if (field_5953) {
            if (isClient) {
                requestInitialState();
            } else {
                registerListeners();
                RobotActions.initializeData(this);
                final AbstractRobotAction currentAction = actionProcessor.action;
                if (currentAction != null) {
                    currentAction.initialize(this);
                }
            }
        }

        super.method_5773();

        if (isClient && terminal.consumePendingBell()) {
            TerminalBell.play();
        }

        if (!isClient) {
            virtualMachine.tick();
        }

        actionProcessor.tick();

        if (!isClient && method_37908() instanceof final class_3218 serverLevel) {
            // Getting stuck in a block should be rare / impossible unless world-editing,
            // so we avoid checking this every frame.
            final class_238 bounds = method_5829();
            if (--containingBlockSweepCountdown <= 0 || !bounds.equals(lastContainingBlockSweepBounds)) {
                containingBlockSweepCountdown = CONTAINING_BLOCK_CHECK_INTERVAL;
                lastContainingBlockSweepBounds = bounds;
                clearContainingBlocks(serverLevel, bounds);
            }
        }
    }

    @Override
    public boolean method_5698(final class_1297 entity) {
        if (entity instanceof class_1657 player && player.method_7337()) {
            dropSelf();
        }
        return true;
    }

    @Override
    public class_1269 method_5688(final class_1657 player, final class_1268 hand) {
        final class_1799 stack = player.method_5998(hand);
        if (!method_37908().method_8608()) {
            if (Wrenches.isWrench(stack)) {
                if (player.method_5715()) {
                    dropSelf();
                } else if (player instanceof final class_3222 serverPlayer) {
                    openInventoryScreen(serverPlayer);
                }
            } else {
                if (player.method_5715()) {
                    start();
                } else if (player instanceof final class_3222 serverPlayer) {
                    openTerminalScreen(serverPlayer);
                }
            }
        }

        return class_1269.method_29236(method_37908().method_8608());
    }

    @Override
    public class_2596<class_2602> method_18002(final class_3231 serverEntity) {
        return NetworkManager.createAddEntityPacket(this, serverEntity);
    }

    @Override
    public void method_5650(final class_5529 reason) {
        super.method_5650(reason);

        if (!method_37908().method_8608()) {
            // Full unload to release out-of-nbt persisted runtime-only data such as ram.
            virtualMachine.stop();
            virtualMachine.dispose();
        }
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public boolean method_30949(final class_1297 entity) {
        return entity != this;
    }

    @Override
    public void method_5697(final class_1297 entity) {
    }

    @Override
    public boolean method_30948() {
        return true;
    }

    @Override
    public boolean method_27298() {
        return false;
    }

    public void exportToItemStack(final class_1799 stack) {
        final class_7225.class_7874 registries = method_37908().method_30349();
        ItemStackUtils.modifyModDataTag(stack, modTag -> {
            final class_2487 itemsTag = NBTUtils.getOrCreateChildTag(modTag, ITEMS_TAG_NAME);
            deviceItems.saveItems(registries, itemsTag); // One tag per device type, as TooltipUtils expects.
            itemsTag.method_10566(INVENTORY_TAG_NAME, inventory.serializeNBT(registries)); // Won't show up in tooltip.

            modTag.method_10566(ENERGY_TAG_NAME, energy.serializeNBT());
        });
    }

    public void importFromItemStack(final class_1799 stack) {
        final class_7225.class_7874 registries = method_37908().method_30349();
        final class_2487 modTag = ItemStackUtils.getModDataTag(stack);

        final class_2487 itemsTag = NBTUtils.getChildTag(modTag, ITEMS_TAG_NAME);
        deviceItems.loadItems(registries, itemsTag);
        inventory.deserializeNBT(registries, itemsTag.method_10562(INVENTORY_TAG_NAME));

        energy.deserializeNBT(NBTUtils.getChildTag(modTag, ENERGY_TAG_NAME));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_5693(final class_2945.class_9222 builder) {
        builder.method_56912(TARGET_POSITION, class_2338.field_10980);
        builder.method_56912(TARGET_DIRECTION, class_2350.field_11043);
        builder.method_56912(SELECTED_SLOT, (byte) 0);
    }

    @Override
    protected void method_5652(final class_2487 tag) {
        if (virtualMachine.getRunState() != VMRunState.STOPPED) {
            tag.method_10566(STATE_TAG_NAME, virtualMachine.serialize());
            synchronized (terminal) {
                tag.method_10566(TERMINAL_TAG_NAME, NBTSerialization.serialize(terminal));
            }
        }

        tag.method_10566(COMMAND_PROCESSOR_TAG_NAME, actionProcessor.serialize());
        tag.method_10566(BUS_ELEMENT_TAG_NAME, busElement.serialize());
        final class_7225.class_7874 registries = method_37908().method_30349();
        tag.method_10566(ITEMS_TAG_NAME, deviceItems.saveItems(registries));
        tag.method_10566(DEVICES_TAG_NAME, deviceItems.saveDevices());
        tag.method_10566(ENERGY_TAG_NAME, energy.serializeNBT());
        tag.method_10566(INVENTORY_TAG_NAME, inventory.serializeNBT(registries));
        tag.method_10567(SELECTED_SLOT_TAG_NAME, method_5841().method_12789(SELECTED_SLOT));
    }

    @Override
    protected void method_5749(final class_2487 tag) {
        virtualMachine.deserialize(tag.method_10562(STATE_TAG_NAME));
        NBTSerialization.deserialize(tag.method_10562(TERMINAL_TAG_NAME), terminal);
        actionProcessor.deserialize(tag.method_10562(COMMAND_PROCESSOR_TAG_NAME));
        busElement.deserialize(tag.method_10562(BUS_ELEMENT_TAG_NAME));
        final class_7225.class_7874 registries = method_37908().method_30349();
        deviceItems.loadItems(registries, tag.method_10562(ITEMS_TAG_NAME));
        deviceItems.loadDevices(tag.method_10562(DEVICES_TAG_NAME));
        energy.deserializeNBT(tag.method_10562(ENERGY_TAG_NAME));
        inventory.deserializeNBT(registries, tag.method_10562(INVENTORY_TAG_NAME));
        setSelectedSlot(tag.method_10571(SELECTED_SLOT_TAG_NAME));
    }

    @Override
    protected class_1297.class_5799 method_33570() {
        return class_1297.class_5799.field_28630;
    }

    @Override
    protected void method_5852() {
    }

    @Override
    protected class_243 method_18794(final class_243 pos) {
        lastPistonMovement = method_37908().method_8510();
        return super.method_18794(pos);
    }

    // --------------------------------------------------------------------- //

    private int cpuEnergyPerTick() {
        return Config.robotCpuEnergyPerTick(deviceItems.getArchitectureType().orElse(null));
    }

    @Environment(EnvType.CLIENT)
    private void requestInitialState() {
        Network.sendToServer(new RobotInitializationRequestMessage(this));
    }

    private void registerListeners() {
        ServerScheduler.scheduleOnUnload(method_37908(), unloadListener);
        ServerScheduler.subscribeOnAnyChunkUnload(method_37908(), chunkUnloadListener);
    }

    private void unregisterListeners() {
        ServerScheduler.cancelOnUnload(method_37908(), unloadListener);
        ServerScheduler.unsubscribeOnAnyChunkUnload(method_37908(), chunkUnloadListener);
    }

    private void handleChunkUnload(final class_1923 chunkPos) {
        if (chunkPos.field_9181 != class_4076.method_18675(method_31477()) ||
            chunkPos.field_9180 != class_4076.method_18675(method_31479())) {
            return;
        }

        handleUnload();
    }

    private void handleUnload() {
        unregisterListeners();
        virtualMachine.suspend();
        virtualMachine.dispose();
    }

    private void updateTerminalRecipients() {
        final ArrayList<class_3222> recipients = new ArrayList<>();
        for (final class_1657 player : terminalUsers) {
            if (player instanceof final class_3222 serverPlayer) {
                recipients.add(serverPlayer);
            }
        }

        terminalRecipients = List.copyOf(recipients);
    }

    private void clearContainingBlocks(final class_3218 serverLevel, final class_238 bounds) {
        final class_265 shape = class_259.method_1078(bounds);
        final class_3980 iterator = getBlockPosIterator();
        while (iterator.method_17963()) {
            final int x = iterator.method_18671();
            final int y = iterator.method_18672();
            final int z = iterator.method_18673();
            mutablePosition.method_10103(x, y, z);
            final class_2680 blockState = serverLevel.method_8320(mutablePosition);
            if (blockState.method_26215() ||
                blockState.method_27852(class_2246.field_10008) ||
                blockState.method_27852(class_2246.field_10379)) {
                continue;
            }

            final class_265 blockShape = blockState.method_26220(serverLevel, mutablePosition);
            if (class_259.method_1074(shape, blockShape.method_1096(x, y, z), class_247.field_16896)) {
                tryClearContainingBlock(serverLevel, mutablePosition.method_10062(), blockState);
            }
        }
    }

    private class_3980 getBlockPosIterator() {
        final class_238 bounds = method_5829();
        return new class_3980(
            class_3532.method_15357(bounds.field_1323), class_3532.method_15357(bounds.field_1322), class_3532.method_15357(bounds.field_1321),
            class_3532.method_15357(bounds.field_1320), class_3532.method_15357(bounds.field_1325), class_3532.method_15357(bounds.field_1324)
        );
    }

    private void tryClearContainingBlock(final class_3218 level, final class_2338 blockPos, final class_2680 blockState) {
        // Quick and dirty pre-fake-player check.
        if (blockState.method_26214(level, blockPos) < 0) {
            return;
        }

        final class_3222 player = FakePlayerUtils.getFakePlayer(level, this);

        if (!LevelUtils.fireBlockBreak(level, player, blockPos, blockState)) {
            return;
        }

        if (!level.method_8651(blockPos, true, player)) {
            // We tried being nice... kill it. Might revisit this :D
            level.method_8501(blockPos, class_2246.field_10124.method_9564());
        }
    }

    private static float lerpClamped(final float from, final float to, final float delta) {
        if (from < to) {
            return Math.min(from + delta, to);
        } else if (from > to) {
            return Math.max(from - delta, to);
        } else {
            return from;
        }
    }

    private static float remapFrom01To(final float x, final float a1, final float b1) {
        if (a1 == b1) {
            return a1;
        } else {
            return x * (b1 - a1) + a1;
        }
    }

    // --------------------------------------------------------------------- //

    public final class AnimationState {
        private static final float TOP_IDLE_Y = -2f / 16f;
        private static final float BASE_IDLE_Y = -1f / 16f;

        private static final float TRANSLATION_SPEED = 0.015f;
        private static final float ROTATION_SPEED = 1f;
        private static final float MAX_ROTATION = 5f;
        private static final float MIN_ROTATION_SPEED = 0.165f;
        private static final float MAX_ROTATION_SPEED = 0.180f;
        private static final float HOVER_ANIMATION_SPEED = 0.03f;

        public float topRenderOffsetY = TOP_IDLE_Y;
        public float baseRenderOffsetY = BASE_IDLE_Y;
        public float topRenderRotationY;
        public float topRenderTargetRotationY;
        public float topRenderRotationSpeed;
        private final float hoverPhase = hashCode() & 0xFFFF;

        public void update(final float time, final float deltaTime, final class_5819 random) {
            if (getVirtualMachine().isRunning() || actionProcessor.hasQueuedActions()) {
                final float topOffsetY = class_3532.method_15374(time * HOVER_ANIMATION_SPEED + hoverPhase) / 32f;

                topRenderOffsetY = lerpClamped(topRenderOffsetY, topOffsetY, deltaTime * TRANSLATION_SPEED);
                baseRenderOffsetY = lerpClamped(baseRenderOffsetY, topOffsetY, deltaTime * TRANSLATION_SPEED);

                topRenderRotationY = lerpClamped(topRenderRotationY, topRenderTargetRotationY, deltaTime * topRenderRotationSpeed);
                if (topRenderRotationY == topRenderTargetRotationY) {
                    topRenderTargetRotationY = remapFrom01To(random.method_43057(), -MAX_ROTATION, MAX_ROTATION);
                    topRenderRotationSpeed = remapFrom01To(random.method_43057(), MIN_ROTATION_SPEED, MAX_ROTATION_SPEED);
                }
            } else {
                topRenderOffsetY = lerpClamped(topRenderOffsetY, TOP_IDLE_Y, deltaTime * TRANSLATION_SPEED * 2);
                baseRenderOffsetY = lerpClamped(baseRenderOffsetY, BASE_IDLE_Y, deltaTime * TRANSLATION_SPEED);

                topRenderRotationY = lerpClamped(topRenderRotationY, 0, deltaTime * ROTATION_SPEED);
            }
        }
    }

    private static final class RobotActionProcessorResult {
        private static final String ACTION_ID_TAG_NAME = "action_id";
        private static final String RESULT_TAG_NAME = "result";

        public int actionId;
        public RobotActionResult result;

        public RobotActionProcessorResult(final int actionId, final RobotActionResult result) {
            this.actionId = actionId;
            this.result = result;
        }

        public RobotActionProcessorResult(final class_2487 tag) {
            deserialize(tag);
        }

        public class_2487 serialize() {
            final class_2487 tag = new class_2487();

            tag.method_10569(ACTION_ID_TAG_NAME, actionId);
            NBTUtils.putEnum(tag, RESULT_TAG_NAME, result);

            return tag;
        }

        public void deserialize(final class_2487 tag) {
            actionId = tag.method_10550(ACTION_ID_TAG_NAME);
            result = NBTUtils.getEnum(tag, RESULT_TAG_NAME, RobotActionResult.class);
        }
    }

    private final class RobotActionProcessor {
        private static final String QUEUE_TAG_NAME = "queue";
        private static final String ACTION_TAG_NAME = "action";
        private static final String RESULTS_TAG_NAME = "results";
        private static final String LAST_ACTION_ID_TAG_NAME = "last_action_id";

        private final Queue<AbstractRobotAction> queue = new ArrayDeque<>(MAX_QUEUED_ACTIONS - 1);
        @Nullable
        private volatile AbstractRobotAction action; // VM -> server thread

        private final Queue<RobotActionProcessorResult> results = new ArrayDeque<>(MAX_QUEUED_RESULTS);
        private int lastActionId;

        public boolean hasQueuedActions() {
            synchronized (queue) {
                return action != null || !queue.isEmpty();
            }
        }

        public int getQueuedActionCount() {
            synchronized (queue) {
                return (action != null ? 1 : 0) + queue.size();
            }
        }

        public boolean move(final MovementDirection direction) {
            return addAction(new RobotMovementAction(direction));
        }

        public boolean rotate(final RotationDirection direction) {
            return addAction(new RobotRotationAction(direction));
        }

        public void tick() {
            if (method_37908().method_8608()) {
                RobotActions.performClient(Robot.this);
            } else {
                if (action != null) {
                    final RobotActionResult result = action.perform(Robot.this);
                    if (result != RobotActionResult.INCOMPLETE) {
                        final int actionId = action.getId();

                        synchronized (results) {
                            if (results.size() == MAX_QUEUED_RESULTS) {
                                results.remove();
                            }

                            results.add(new RobotActionProcessorResult(actionId, result));
                        }

                        action = null;

                        virtualMachine.sendEvent(RobotActionCompletedEvent.TYPE,
                            new RobotActionCompletedEvent(actionId, result));
                    }
                }
                if (action == null) {
                    synchronized (queue) {
                        action = queue.poll();
                    }
                    if (action != null) {
                        action.initialize(Robot.this);
                    }
                }
                RobotActions.performServer(Robot.this, action);
            }
        }

        public void clear() {
            synchronized (queue) {
                queue.clear();
                lastActionId = 0;
            }
            synchronized (results) {
                results.clear();
            }
        }

        public class_2487 serialize() {
            final class_2487 tag = new class_2487();

            final class_2499 queueTag = new class_2499();
            synchronized (queue) {
                for (final AbstractRobotAction action : queue) {
                    queueTag.add(RobotActions.serialize(action));
                }
            }
            tag.method_10566(QUEUE_TAG_NAME, queueTag);

            final AbstractRobotAction currentAction = action;
            if (currentAction != null) {
                tag.method_10566(ACTION_TAG_NAME, RobotActions.serialize(currentAction));
            }

            final class_2499 resultsTag = new class_2499();
            synchronized (results) {
                for (final RobotActionProcessorResult result : results) {
                    resultsTag.add(result.serialize());
                }
            }
            tag.method_10566(RESULTS_TAG_NAME, resultsTag);

            synchronized (queue) {
                tag.method_10569(LAST_ACTION_ID_TAG_NAME, lastActionId);
            }

            return tag;
        }

        public void deserialize(final class_2487 tag) {
            final class_2499 queueTag = tag.method_10554(QUEUE_TAG_NAME, NBTTagIds.TAG_COMPOUND);
            synchronized (queue) {
                queue.clear();
                for (int i = 0; i < Math.min(queueTag.size(), MAX_QUEUED_ACTIONS - 1); i++) {
                    final AbstractRobotAction action = RobotActions.deserialize(queueTag.method_10602(i));
                    if (action != null) {
                        queue.add(action);
                    }
                }
                lastActionId = tag.method_10550(LAST_ACTION_ID_TAG_NAME);
            }

            action = RobotActions.deserialize(tag.method_10562(ACTION_TAG_NAME));

            final class_2499 resultsTag = tag.method_10554(RESULTS_TAG_NAME, NBTTagIds.TAG_COMPOUND);
            synchronized (results) {
                results.clear();
                for (int i = 0; i < Math.min(resultsTag.size(), MAX_QUEUED_RESULTS); i++) {
                    final RobotActionProcessorResult result = new RobotActionProcessorResult(resultsTag.method_10602(i));
                    if (result.actionId != 0) {
                        results.add(result);
                    }
                }
            }
        }

        private boolean addAction(final AbstractRobotAction action) {
            if (method_37908().method_8608()) {
                return false;
            }

            if (!getVirtualMachine().isRunning()) {
                return false;
            }

            synchronized (queue) {
                if (queue.size() >= MAX_QUEUED_ACTIONS - 1) { // -1 for current action
                    return false;
                }

                lastActionId = (lastActionId + 1) & 0x7FFFFFFF; // only positive ids; unlikely to ever wrap, but eh.
                action.setId(lastActionId);
                queue.add(action);
                return true;
            }
        }
    }

    private final class RobotItemStackHandlers extends AbstractVMItemStackHandlers {
        public RobotItemStackHandlers() {
            super(
                new GroupDefinition(DeviceTypes.CPU.get(), CPU_SLOTS),
                new GroupDefinition(DeviceTypes.MEMORY.get(), MEMORY_SLOTS),
                new GroupDefinition(DeviceTypes.HARD_DRIVE.get(), HARD_DRIVE_SLOTS),
                new GroupDefinition(DeviceTypes.FLOPPY.get(), FLOPPY_SLOTS),
                new GroupDefinition(DeviceTypes.FLASH_MEMORY.get(), FLASH_MEMORY_SLOTS),
                new GroupDefinition(DeviceTypes.ROBOT_MODULE.get(), MODULE_SLOTS)
            );
        }

        @Override
        protected ItemDeviceQuery makeQuery(final class_1799 stack) {
            return Devices.makeQuery(deviceItems.getArchitectureType().orElse(null), Robot.this, stack);
        }

        @Override
        protected void onChanged() {
            super.onChanged();
            if (!method_37908().method_8608()) {
                virtualMachine.getBusController().scheduleBusScan();
            }
        }
    }

    private final class RobotBusElement extends AbstractDeviceBusElement {
        private static final String DEVICE_ID_TAG_NAME = "device_id";

        private final Device device = new ObjectDevice(new RobotDevice(), "robot");
        private UUID deviceId = UUID.randomUUID();

        @Override
        public Optional<Collection<Invalidatable<DeviceBusElement>>> getNeighbors() {
            return Optional.of(singleton(Invalidatable.of(deviceItems.busElement)));
        }

        @Override
        public Collection<Device> getLocalDevices() {
            return singleton(device);
        }

        @Override
        public Optional<UUID> getDeviceIdentifier(final Device device) {
            if (device == this.device) {
                return Optional.of(deviceId);
            }
            return super.getDeviceIdentifier(device);
        }

        public class_2487 serialize() {
            final class_2487 tag = new class_2487();
            tag.method_25927(DEVICE_ID_TAG_NAME, deviceId);
            return tag;
        }

        public void deserialize(final class_2487 tag) {
            if (tag.method_25928(DEVICE_ID_TAG_NAME)) {
                deviceId = tag.method_25926(DEVICE_ID_TAG_NAME);
            }
        }
    }

    private final class RobotVMRunner extends AbstractTerminalVMRunner {
        public RobotVMRunner(final AbstractArchitecture architecture, final Terminal terminal) {
            super(architecture, terminal);
        }

        @Override
        protected void sendTerminalUpdateToClient(final ByteBuffer output) {
            final List<class_3222> recipients = terminalRecipients;
            if (recipients.isEmpty()) {
                return;
            }

            final RobotTerminalOutputMessage message = new RobotTerminalOutputMessage(Robot.this, output);
            for (final class_3222 player : recipients) {
                Network.sendToClient(message, player);
            }
        }
    }

    private final class RobotVirtualMachine extends AbstractVirtualMachine {
        private RobotVirtualMachine(final CommonDeviceBusController busController) {
            super(busController);
            setDeviceLocationProvider(deviceItems::getDeviceLocation);
        }

        @Override
        protected boolean consumeEnergy(final int amount, final boolean simulate) {
            if (!Config.robotsUseEnergy()) {
                return true;
            }

            if (amount > energy.getEnergyStored()) {
                return false;
            }

            energy.extractEnergy(amount, simulate);
            return true;
        }

        @Override
        protected void stopRunnerAndReset() {
            super.stopRunnerAndReset();

            TerminalUtils.resetTerminal(terminal, output -> {
                for (final class_3222 player : terminalRecipients) {
                    Network.sendToClient(new RobotTerminalOutputMessage(Robot.this, output), player);
                }
            });

            actionProcessor.clear();
        }

        @Override
        protected AbstractTerminalVMRunner createRunner(final AbstractArchitecture architecture) {
            return new RobotVMRunner(architecture, terminal);
        }

        @Override
        protected void handleBusStateChanged(final CommonDeviceBusController.BusState value) {
            Network.sendToClientsTrackingEntity(new RobotBusStateMessage(Robot.this, value), Robot.this);
        }

        @Override
        protected void handleRunStateChanged(final VMRunState value) {
            Network.sendToClientsTrackingEntity(new RobotRunStateMessage(Robot.this, value), Robot.this);
        }

        @Override
        protected void handleBootErrorChanged(@Nullable final class_2561 value) {
            Network.sendToClientsTrackingEntity(new RobotBootErrorMessage(Robot.this, value), Robot.this);
        }
    }

    public final class RobotDevice {
        @Callback(synchronize = false)
        public int getEnergyStored() {
            return (int) energy.getEnergyStored();
        }

        @Callback(synchronize = false)
        public int getEnergyCapacity() {
            return (int) energy.getMaxEnergyStored();
        }

        @Callback
        public int getSelectedSlot() {
            return Robot.this.getSelectedSlot();
        }

        @Callback
        public void setSelectedSlot(@Parameter("slot") final int slot) {
            Robot.this.setSelectedSlot(slot);
        }

        @Callback
        public class_1799 getStackInSlot(@Parameter("slot") final int slot) {
            return inventory.getStackInSlot(slot);
        }

        @Callback(synchronize = false)
        public boolean move(@Parameter("direction") @Nullable final MovementDirection direction) {
            if (direction == null) throw new IllegalArgumentException();
            return actionProcessor.move(direction);
        }

        @Callback(synchronize = false)
        public boolean turn(@Parameter("direction") @Nullable final RotationDirection direction) {
            if (direction == null) throw new IllegalArgumentException();
            return actionProcessor.rotate(direction);
        }

        @Callback(synchronize = false)
        public int getLastActionId() {
            // Written by addAction under the queue monitor; read it under the same one
            // or the guest can see an id older than the action it just queued.
            synchronized (actionProcessor.queue) {
                return actionProcessor.lastActionId;
            }
        }

        @Callback(synchronize = false)
        public int getQueuedActionCount() {
            return actionProcessor.getQueuedActionCount();
        }

        @Nullable
        @Callback(synchronize = false)
        public RobotActionResult getActionResult(@Parameter("actionId") final int actionId) {
            final AbstractRobotAction currentAction = actionProcessor.action;
            if (currentAction != null && currentAction.getId() == actionId) {
                return RobotActionResult.INCOMPLETE;
            }
            synchronized (actionProcessor.queue) {
                for (final AbstractRobotAction action : actionProcessor.queue) {
                    if (action.getId() == actionId) {
                        return RobotActionResult.INCOMPLETE;
                    }
                }
            }
            synchronized (actionProcessor.results) {
                for (final RobotActionProcessorResult result : actionProcessor.results) {
                    if (result.actionId == actionId) {
                        return result.result;
                    }
                }
            }

            return null;
        }

        private RobotDevice() {
        }
    }
}
