/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.client.gui.FileChooserScreen;
import net.minecraft.class_9129;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;

public final class ExportedFileMessage extends AbstractMessage {
    private static final Logger LOGGER = LogManager.getLogger();

    // --------------------------------------------------------------------- //

    private String name;
    private byte[] data;

    // --------------------------------------------------------------------- //

    public ExportedFileMessage(final String name, final byte[] data) {
        this.name = name;
        this.data = data;
    }

    public ExportedFileMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        name = buffer.method_19772();
        data = buffer.method_10795();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10814(name);
        buffer.method_10813(data);
    }

    // --------------------------------------------------------------------- //

    protected void handleMessage(final NetworkManager.PacketContext context) {
        FileChooserScreen.openFileChooserForSave(name, path -> {
            try {
                Files.write(path, data);
            } catch (final IOException e) {
                LOGGER.error(e);
            }
        });
    }
}
