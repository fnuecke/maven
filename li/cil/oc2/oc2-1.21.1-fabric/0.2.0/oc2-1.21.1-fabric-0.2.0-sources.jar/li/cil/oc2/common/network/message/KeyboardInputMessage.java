/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.KeyboardBlockEntity;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_2338;
import net.minecraft.class_9129;

public final class KeyboardInputMessage extends AbstractMessage {
    private class_2338 pos;
    private int keycode;
    private boolean isDown;

    // --------------------------------------------------------------------- //

    public KeyboardInputMessage(final KeyboardBlockEntity keyboard, final int keycode, final boolean isDown) {
        this.pos = keyboard.method_11016();
        this.keycode = keycode;
        this.isDown = isDown;
    }

    public KeyboardInputMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        keycode = buffer.method_10816();
        isDown = buffer.readBoolean();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        buffer.method_10804(keycode);
        buffer.method_52964(isDown);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        MessageUtils.withNearbyServerBlockEntityForInteraction(context, pos, KeyboardBlockEntity.class,
            (player, keyboard) -> keyboard.handleInput(keycode, isDown));
    }
}
