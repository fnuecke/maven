/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import li.cil.oc2.api.bus.device.provider.ItemDeviceQuery;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.block.EnergyConsumingBlock;
import li.cil.oc2.common.bus.device.DeviceTypeRegistry;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.energy.EnergyStorage;
import li.cil.oc2.common.tags.ItemTags;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.NBTTagIds;
import li.cil.oc2.common.util.NBTUtils;
import li.cil.oc2.common.util.StorageItemUtils;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2477;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_7225;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;

import static java.util.Objects.requireNonNull;
import static li.cil.oc2.common.Constants.ITEMS_TAG_NAME;
import static li.cil.oc2.common.util.TextFormatUtils.withFormat;

public final class TooltipUtils {
    private static final class_5250 DEVICE_NEEDS_REBOOT =
        class_2561.method_43471(Constants.TOOLTIP_DEVICE_NEEDS_REBOOT)
            .method_27694(s -> s.method_27703(class_5251.method_27718(class_124.field_1054)));

    private static final class_5250 DATA_CORRUPTED =
        class_2561.method_43471(Constants.TOOLTIP_DATA_CORRUPTED)
            .method_27694(s -> s.method_27703(class_5251.method_27718(class_124.field_1061)));

    private static final class_5250 DATA_INCONSISTENT =
        class_2561.method_43471(Constants.TOOLTIP_DATA_INCONSISTENT)
            .method_27694(s -> s.method_27703(class_5251.method_27718(class_124.field_1054)));

    private static final ThreadLocal<List<class_1799>> ITEM_STACKS = ThreadLocal.withInitial(ArrayList::new);
    private static final ThreadLocal<IntList> ITEM_STACKS_SIZES = ThreadLocal.withInitial(IntArrayList::new);

    // --------------------------------------------------------------------- //

    public static void tryAddDescription(final class_1799 stack, final List<class_2561> tooltip) {
        if (stack.method_7960()) {
            return;
        }

        final String translationKey = stack.method_7922() + Constants.TOOLTIP_DESCRIPTION_SUFFIX;
        final class_2477 language = class_2477.method_10517();
        if (language.method_4678(translationKey)) {
            final class_5250 description = class_2561.method_43471(translationKey);
            tooltip.add(withFormat(description, class_124.field_1080));
        }

        if (stack.method_31573(ItemTags.DEVICE_NEEDS_REBOOT)) {
            tooltip.add(DEVICE_NEEDS_REBOOT);
        }

        final int energyConsumption;
        if (stack.method_7909() instanceof class_1747 blockItem &&
            blockItem.method_7711() instanceof EnergyConsumingBlock energyConsumingBlock) {
            energyConsumption = energyConsumingBlock.getEnergyConsumption();
        } else {
            final ItemDeviceQuery query = Devices.makeQuery(stack);
            energyConsumption = Devices.getEnergyConsumption(query);
        }

        if (energyConsumption > 0) {
            final class_5250 energy = withFormat(String.valueOf(energyConsumption), class_124.field_1060);
            tooltip.add(withFormat(class_2561.method_43469(Constants.TOOLTIP_ENERGY_CONSUMPTION, energy), class_124.field_1080));
        }
    }

    public static void addBlockEntityInventoryInformation(final class_1799 stack, final List<class_2561> tooltip) {
        addInventoryInformation(NBTUtils.getChildTag(ItemStackUtils.getBlockEntityDataTag(stack), ITEMS_TAG_NAME), tooltip);
    }

    public static void addEntityInventoryInformation(final class_1799 stack, final List<class_2561> tooltip) {
        addInventoryInformation(NBTUtils.getChildTag(ItemStackUtils.getModDataTag(stack), ITEMS_TAG_NAME), tooltip);
    }

    public static void addInventoryInformation(final class_2487 itemsTag, final List<class_2561> tooltip) {
        addInventoryInformation(itemsTag, tooltip, getDeviceTypeNames());
    }

    public static void addInventoryInformation(final class_2487 itemsTag, final List<class_2561> tooltip, final String... subInventoryNames) {
        final List<class_1799> itemStacks = ITEM_STACKS.get();
        itemStacks.clear();
        final IntList itemStackSizes = ITEM_STACKS_SIZES.get();
        itemStackSizes.clear();

        collectItemStacks(itemsTag, itemStacks, itemStackSizes);

        for (final String subInventoryName : subInventoryNames) {
            if (itemsTag.method_10573(subInventoryName, NBTTagIds.TAG_COMPOUND)) {
                collectItemStacks(itemsTag.method_10562(subInventoryName), itemStacks, itemStackSizes);
            }
        }

        for (int i = 0; i < itemStacks.size(); i++) {
            final class_1799 itemStack = itemStacks.get(i);
            tooltip.add(class_2561.method_43470("- ")
                .method_10852(itemStack.method_7954())
                .method_27694(style -> style.method_27703(class_5251.method_27718(class_124.field_1080)))
                .method_10852(class_2561.method_43470(" x")
                    .method_27693(String.valueOf(itemStackSizes.getInt(i)))
                    .method_27694(style -> style.method_27703(class_5251.method_27718(class_124.field_1063))))
            );
        }
    }

    public static void addEntityEnergyInformation(final class_1799 stack, final List<class_2561> tooltip) {
        final EnergyStorage energy = Capabilities.get(stack, Capabilities.ENERGY_STORAGE);
        if (energy == null || energy.getEnergyStored() == 0) {
            return;
        }

        final class_5250 value = withFormat(energy.getEnergyStored() + "/" + energy.getMaxEnergyStored(), class_124.field_1060);
        tooltip.add(withFormat(class_2561.method_43469(Constants.TOOLTIP_ENERGY, value), class_124.field_1080));
    }

    public static void addEnergyConsumption(final double value, final List<class_2561> tooltip) {
        if (value > 0) {
            tooltip.add(withFormat(class_2561.method_43469(Constants.TOOLTIP_ENERGY_CONSUMPTION, withFormat(new DecimalFormat("#.##").format(value), class_124.field_1060)), class_124.field_1080));
        }
    }

    public static void addDataCorrupted(final class_1799 stack, final List<class_2561> tooltip) {
        if (stack.method_7960()) {
            return;
        }

        switch (StorageItemUtils.getState(stack)) {
            case CORRUPTED -> {
                tooltip.add(DATA_CORRUPTED);
                tooltip.add(withFormat(class_2561.method_43471(Constants.TOOLTIP_DATA_CORRUPTED_HINT), class_124.field_1063));
            }
            case INCONSISTENT -> {
                tooltip.add(DATA_INCONSISTENT);
                tooltip.add(withFormat(class_2561.method_43471(Constants.TOOLTIP_DATA_INCONSISTENT_HINT), class_124.field_1063));
            }
            default -> {
            }
        }
    }

    // --------------------------------------------------------------------- //

    private static String[] getDeviceTypeNames() {
        return StreamSupport.stream(DeviceTypeRegistry.REGISTRY.spliterator(), false)
            .map(DeviceTypeRegistry::key)
            .toArray(String[]::new);
    }

    private static void collectItemStacks(final class_2487 tag, final List<class_1799> stacks, final IntList stackSizes) {
        final class_7225.class_7874 registries = requireNonNull(class_310.method_1551().field_1687).method_30349();
        final class_2499 itemsTag = tag.method_10554("Items", NBTTagIds.TAG_COMPOUND);
        for (int i = 0; i < itemsTag.size(); i++) {
            final class_2487 itemTag = itemsTag.method_10602(i);
            final class_1799 itemStack = class_1799.method_57360(registries, itemTag).orElse(class_1799.field_8037);
            if (itemStack.method_7960()) {
                continue;
            }

            boolean didMerge = false;
            for (int j = 0; j < stacks.size(); j++) {
                final class_1799 existingStack = stacks.get(j);
                if (class_1799.method_31577(existingStack, itemStack)) {
                    final int existingCount = stackSizes.getInt(j);
                    stackSizes.set(j, existingCount + itemStack.method_7947());
                    didMerge = true;
                    break;
                }
            }

            if (!didMerge) {
                stacks.add(itemStack);
                stackSizes.add(itemStack.method_7947());
            }
        }
    }

    // --------------------------------------------------------------------- //

    private TooltipUtils() {
    }
}
