/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc;

import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.NamedDevice;
import li.cil.oc2.api.inventory.ItemHandler;
import li.cil.oc2.common.bus.device.util.IdentityProxy;
import net.minecraft.class_1799;
import java.util.Collection;
import java.util.Collections;

public final class ItemHandlerDevice extends IdentityProxy<ItemHandler> implements NamedDevice {
    public ItemHandlerDevice(final ItemHandler identity) {
        super(identity);
    }

    @Override
    public Collection<String> getDeviceTypeNames() {
        return Collections.singleton("item_handler");
    }

    @Callback
    public int getItemSlotCount() {
        return identity.getSlots();
    }

    @Callback
    public class_1799 getItemStackInSlot(final int slot) {
        return identity.getStackInSlot(requireValidSlot(slot));
    }

    @Callback
    public int getItemSlotLimit(final int slot) {
        return identity.getSlotLimit(requireValidSlot(slot));
    }

    // --------------------------------------------------------------------- //

    private int requireValidSlot(final int slot) {
        if (slot < 0 || slot >= identity.getSlots()) {
            throw new IllegalArgumentException("slot out of range: " + slot
                + " (expected 0 to " + (identity.getSlots() - 1) + ")");
        }
        return slot;
    }
}
