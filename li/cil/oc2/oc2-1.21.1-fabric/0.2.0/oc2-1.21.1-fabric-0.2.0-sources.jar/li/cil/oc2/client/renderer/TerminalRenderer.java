/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import li.cil.oc2.api.API;
import li.cil.oc2.common.vm.Terminal;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

import javax.annotation.Nullable;
import java.util.concurrent.atomic.AtomicBoolean;

import static li.cil.oc2.common.vm.Terminal.*;

@Environment(EnvType.CLIENT)
public final class TerminalRenderer implements Terminal.Listener, AutoCloseable {
    private static final class_2960 LOCATION_FONT_TEXTURE = class_2960.method_60655(API.MOD_ID, "textures/font/terminus.png");
    private static final int TEXTURE_RESOLUTION = 256;
    private static final float ONE_OVER_TEXTURE_RESOLUTION = 1.0f / TEXTURE_RESOLUTION;
    private static final float CHAR_WIDTH_IN_UV = CHAR_WIDTH * ONE_OVER_TEXTURE_RESOLUTION;
    private static final float CHAR_HEIGHT_IN_UV = CHAR_HEIGHT * ONE_OVER_TEXTURE_RESOLUTION;
    private static final int TEXTURE_COLUMNS = 16;
    private static final int TEXTURE_BOLD_SHIFT = TEXTURE_COLUMNS; // Bold chars are in right half of texture.
    private static final int WHITE_CELL = 0x7F;
    private static final int WHITE_CELL_X = (WHITE_CELL % TEXTURE_COLUMNS + TEXTURE_BOLD_SHIFT) * CHAR_WIDTH + CHAR_WIDTH / 2;
    private static final int WHITE_CELL_Y = WHITE_CELL / TEXTURE_COLUMNS * CHAR_HEIGHT + CHAR_HEIGHT / 2;
    private static final float WHITE_U = WHITE_CELL_X * ONE_OVER_TEXTURE_RESOLUTION;
    private static final float WHITE_V = WHITE_CELL_Y * ONE_OVER_TEXTURE_RESOLUTION;

    private static final int[] COLORS = {
        0x010101, // Black
        0xEE3322, // Red
        0x33DD44, // Green
        0xFFCC11, // Yellow
        0x1188EE, // Blue
        0xDD33CC, // Magenta
        0x22CCDD, // Cyan
        0xEEEEEE, // White
    };

    private static final int[] DIM_COLORS = {
        0x010101, // Black
        0x772211, // Red
        0x116622, // Green
        0x886611, // Yellow
        0x115588, // Blue
        0x771177, // Magenta
        0x116677, // Cyan
        0x777777, // White
    };

    private static final int CURSOR_COLOR = COLORS[COLOR_WHITE];

    // --------------------------------------------------------------------- //

    private final Terminal terminal;

    @Nullable
    private class_291 buffer;

    private final AtomicBoolean dirty = new AtomicBoolean(true);

    private final Matrix4f rowMatrix = new Matrix4f();
    private final Matrix4f modelViewMatrix = new Matrix4f();

    // --------------------------------------------------------------------- //

    public TerminalRenderer(final Terminal terminal) {
        this.terminal = terminal;
        terminal.addListener(this);
    }

    // --------------------------------------------------------------------- //

    public void render(final class_4587 stack, final Matrix4f modelViewBase, final Matrix4f projectionMatrix) {
        validateMesh();
        renderBuffer(stack, modelViewBase, projectionMatrix);

        if ((System.currentTimeMillis() + terminal.hashCode()) % 1000 > 500) {
            renderCursor(stack);
        }
    }

    @Override
    public void handleTerminalChanged() {
        dirty.set(true);
    }

    @Override
    public void close() {
        terminal.removeListener(this);
        releaseBuffer();
    }

    // --------------------------------------------------------------------- //

    private void releaseBuffer() {
        if (buffer != null) {
            buffer.close();
            buffer = null;
        }
    }

    // --------------------------------------------------------------------- //

    private void renderBuffer(final class_4587 stack, final Matrix4f modelViewBase, final Matrix4f projectionMatrix) {
        if (buffer == null) {
            return;
        }

        class_5944 shader = ModShaders.getTerminalShader();
        if (shader == null) {
            // Shouldn't really happen, but just in case.
            shader = class_757.method_34543();
        }
        if (shader == null) {
            return;
        }

        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderTexture(0, LOCATION_FONT_TEXTURE);

        modelViewMatrix.set(modelViewBase).mul(stack.method_23760().method_23761());

        buffer.method_1353();
        buffer.method_34427(modelViewMatrix, projectionMatrix, shader);
        class_291.method_1354();

        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
    }

    private void validateMesh() {
        if (!dirty.getAndSet(false)) {
            return;
        }

        final class_287 builder = class_289.method_1348()
            .method_60827(class_293.class_5596.field_27382, class_290.field_1575);

        for (int row = 0; row < HEIGHT; row++) {
            rowMatrix.translation(0, row * CHAR_HEIGHT, 0);
            renderBackground(rowMatrix, builder, row);
            renderForeground(rowMatrix, builder, row);
        }

        final class_9801 mesh = builder.method_60794();
        if (mesh == null) {
            // Nothing visible at all; drop the buffer rather than leave the last frame on screen.
            releaseBuffer();
            return;
        }

        if (buffer == null) {
            buffer = new class_291(class_291.class_8555.field_44793);
        }

        buffer.method_1353();
        buffer.method_1352(mesh);
        class_291.method_1354();
    }

    private void renderBackground(final Matrix4f matrix, final class_287 buffer, final int row) {
        // State tracking for drawing background quads spanning multiple characters.
        float backgroundStartX = -1;
        int backgroundColor = 0;

        float tx = 0f;
        for (int col = 0, index = row * WIDTH; col < WIDTH; col++, index++) {
            final int cell = terminal.getCell(index);

            if (isHidden(cell)) continue;

            final int[] palette = isDim(cell) ? DIM_COLORS : COLORS;
            final int background = palette[getBackgroundColorIndex(cell)];

            final boolean hadBackground = backgroundStartX >= 0;
            final boolean hasBackground = background != palette[0];
            if (!hadBackground && hasBackground) {
                backgroundStartX = tx;
                backgroundColor = background;
            } else if (hadBackground && (!hasBackground || backgroundColor != background)) {
                renderBackground(matrix, buffer, backgroundStartX, tx, backgroundColor);

                if (hasBackground) {
                    backgroundStartX = tx;
                    backgroundColor = background;
                } else {
                    backgroundStartX = -1;
                }
            }

            tx += CHAR_WIDTH;
        }

        if (backgroundStartX >= 0) {
            renderBackground(matrix, buffer, backgroundStartX, tx, backgroundColor);
        }
    }

    private void renderBackground(final Matrix4f matrix, final class_287 buffer, final float x0, final float x1, final int color) {
        final float r = ((color >> 16) & 0xFF) / 255f;
        final float g = ((color >> 8) & 0xFF) / 255f;
        final float b = (color & 0xFF) / 255f;

        buffer.method_22918(matrix, x0, CHAR_HEIGHT, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
        buffer.method_22918(matrix, x1, CHAR_HEIGHT, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
        buffer.method_22918(matrix, x1, 0, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
        buffer.method_22918(matrix, x0, 0, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
    }

    private void renderForeground(final Matrix4f matrix, final class_287 buffer, final int row) {
        float tx = 0f;
        for (int col = 0, index = row * WIDTH; col < WIDTH; col++, index++) {
            final int cell = terminal.getCell(index);

            if (isHidden(cell)) continue;

            final int[] palette = isDim(cell) ? DIM_COLORS : COLORS;
            final int foreground = palette[getForegroundColorIndex(cell)];

            renderForeground(matrix, buffer, tx, getCharacter(cell), foreground, isBold(cell), isUnderline(cell));

            tx += CHAR_WIDTH;
        }
    }

    private void renderForeground(final Matrix4f matrix, final class_287 buffer, final float offset, final int character, final int color, final boolean isBold, final boolean isUnderline) {
        final float r = ((color >> 16) & 0xFF) / 255f;
        final float g = ((color >> 8) & 0xFF) / 255f;
        final float b = (color & 0xFF) / 255f;

        if (isPrintableCharacter((char) character)) {
            final int x = character % TEXTURE_COLUMNS + (isBold ? TEXTURE_BOLD_SHIFT : 0);
            final int y = character / TEXTURE_COLUMNS;
            final float u0 = x * CHAR_WIDTH_IN_UV;
            final float u1 = (x + 1) * CHAR_WIDTH_IN_UV;
            final float v0 = y * CHAR_HEIGHT_IN_UV;
            final float v1 = (y + 1) * CHAR_HEIGHT_IN_UV;

            buffer.method_22918(matrix, offset, CHAR_HEIGHT, 0).method_22915(r, g, b, 1).method_22913(u0, v1);
            buffer.method_22918(matrix, offset + CHAR_WIDTH, CHAR_HEIGHT, 0).method_22915(r, g, b, 1).method_22913(u1, v1);
            buffer.method_22918(matrix, offset + CHAR_WIDTH, 0, 0).method_22915(r, g, b, 1).method_22913(u1, v0);
            buffer.method_22918(matrix, offset, 0, 0).method_22915(r, g, b, 1).method_22913(u0, v0);
        }

        if (isUnderline) {
            buffer.method_22918(matrix, offset, CHAR_HEIGHT - 3, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
            buffer.method_22918(matrix, offset + CHAR_WIDTH, CHAR_HEIGHT - 3, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
            buffer.method_22918(matrix, offset + CHAR_WIDTH, CHAR_HEIGHT - 2, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
            buffer.method_22918(matrix, offset, CHAR_HEIGHT - 2, 0).method_22915(r, g, b, 1).method_22913(WHITE_U, WHITE_V);
        }
    }

    private void renderCursor(final class_4587 stack) {
        final int cursorX = terminal.getCursorX();
        final int cursorY = terminal.getCursorY();

        RenderSystem.depthMask(false);
        RenderSystem.setShader(class_757::method_34540);

        stack.method_22903();
        stack.method_46416(cursorX * CHAR_WIDTH, cursorY * CHAR_HEIGHT, 0);

        final Matrix4f matrix = stack.method_23760().method_23761();
        final class_287 buffer = class_289.method_1348()
            .method_60827(class_293.class_5596.field_27382, class_290.field_1576);

        final float r = ((CURSOR_COLOR >> 16) & 0xFF) / 255f;
        final float g = ((CURSOR_COLOR >> 8) & 0xFF) / 255f;
        final float b = (CURSOR_COLOR & 0xFF) / 255f;

        buffer.method_22918(matrix, 0, CHAR_HEIGHT, 0).method_22915(r, g, b, 1);
        buffer.method_22918(matrix, CHAR_WIDTH, CHAR_HEIGHT, 0).method_22915(r, g, b, 1);
        buffer.method_22918(matrix, CHAR_WIDTH, 0, 0).method_22915(r, g, b, 1);
        buffer.method_22918(matrix, 0, 0, 0).method_22915(r, g, b, 1);

        class_286.method_43433(buffer.method_60800());

        stack.method_22909();

        RenderSystem.depthMask(true);
    }

    static boolean isPrintableCharacter(final char ch) {
        return ch > 0 && ch != ' ' && (ch < 0x7F || ch > 0xA0);
    }
}
