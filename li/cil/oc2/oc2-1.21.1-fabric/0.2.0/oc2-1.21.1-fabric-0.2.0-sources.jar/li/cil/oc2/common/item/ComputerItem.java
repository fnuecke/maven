/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.bus.device.data.BlockDeviceDataRegistry;
import li.cil.oc2.common.bus.device.data.FirmwareRegistry;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.NBTUtils;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_7225;

import static li.cil.oc2.common.Constants.ITEMS_TAG_NAME;
import static li.cil.oc2.common.bus.device.DeviceTypeRegistry.key;
import static li.cil.oc2.common.util.NBTUtils.makeInventoryTag;
import static li.cil.oc2.common.util.TranslationUtils.text;

public final class ComputerItem extends ModBlockItem implements CreativeTabItemProvider {
    public ComputerItem(final class_2248 block) {
        super(block);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void addCreativeTabItems(final class_1761.class_8128 parameters, final class_1761.class_7704 output) {
        output.method_45420(withFlash(parameters.comp_1253()));
        output.method_45420(preconfigured(parameters.comp_1253()));
    }

    // --------------------------------------------------------------------- //

    private class_1799 withFlash(final class_7225.class_7874 provider) {
        final class_1799 computer = new class_1799(this);

        ItemStackUtils.modifyBlockEntityDataTag(computer, BlockEntities.COMPUTER.get(), tag -> {
            final var itemsTag = NBTUtils.getOrCreateChildTag(tag, ITEMS_TAG_NAME);
            itemsTag.method_10566(key(DeviceTypes.CPU.get()), makeInventoryTag(provider,
                new class_1799(Items.CPU_RISCV.get())
            ));
            itemsTag.method_10566(key(DeviceTypes.FLASH_MEMORY.get()), makeInventoryTag(provider,
                Items.FLASH_MEMORY.get().withData(FirmwareRegistry.RISCV.getId())
            ));
        });

        return computer;
    }

    private class_1799 preconfigured(final class_7225.class_7874 provider) {
        final class_1799 computer = withFlash(provider);

        ItemStackUtils.modifyBlockEntityDataTag(computer, BlockEntities.COMPUTER.get(), tag -> {
            final var itemsTag = NBTUtils.getOrCreateChildTag(tag, ITEMS_TAG_NAME);
            itemsTag.method_10566(key(DeviceTypes.MEMORY.get()), makeInventoryTag(provider,
                new class_1799(Items.MEMORY_LARGE.get()),
                new class_1799(Items.MEMORY_LARGE.get()),
                new class_1799(Items.MEMORY_LARGE.get()),
                new class_1799(Items.MEMORY_LARGE.get())
            ));
            itemsTag.method_10566(key(DeviceTypes.HARD_DRIVE.get()), makeInventoryTag(provider,
                Items.HARD_DRIVE_LARGE.get().withData(BlockDeviceDataRegistry.BUILDROOT.getId())
            ));
            itemsTag.method_10566(key(DeviceTypes.CARD.get()), makeInventoryTag(provider,
                new class_1799(Items.NETWORK_INTERFACE_CARD.get())
            ));
        });

        computer.method_57379(net.minecraft.class_9334.field_49631, text("block.{mod}.computer.preconfigured"));

        return computer;
    }
}
