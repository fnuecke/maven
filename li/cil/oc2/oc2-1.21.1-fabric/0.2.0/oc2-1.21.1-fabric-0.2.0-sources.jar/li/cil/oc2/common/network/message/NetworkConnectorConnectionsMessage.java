/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.NetworkConnectorBlockEntity;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_2338;
import net.minecraft.class_9129;
import java.util.ArrayList;

public final class NetworkConnectorConnectionsMessage extends AbstractMessage {
    private class_2338 pos;
    private ArrayList<class_2338> connectedPositions;

    // --------------------------------------------------------------------- //

    public NetworkConnectorConnectionsMessage(final NetworkConnectorBlockEntity networkConnector) {
        this.pos = networkConnector.method_11016();
        this.connectedPositions = new ArrayList<>(networkConnector.getConnectedPositions());
    }

    public NetworkConnectorConnectionsMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        connectedPositions = new ArrayList<>();
        final int positionCount = buffer.method_10816();
        for (int i = 0; i < positionCount; i++) {
            final class_2338 pos = buffer.method_10811();
            connectedPositions.add(pos);
        }
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        buffer.method_10804(connectedPositions.size());
        for (final class_2338 pos : connectedPositions) {
            buffer.method_10807(pos);
        }
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        MessageUtils.withClientBlockEntityAt(pos, NetworkConnectorBlockEntity.class,
            networkConnector -> networkConnector.setConnectedPositionsClient(connectedPositions));
    }
}
