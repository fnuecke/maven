/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.common.container.NetworkTunnelContainer;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.TextFormatUtils;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3544;
import net.minecraft.class_5250;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static li.cil.oc2.common.util.TranslationUtils.key;

public final class NetworkTunnelItem extends ModItem {
    private static final String TUNNEL_ID_TAG_NAME = "tunnel";
    private static final String TUNNEL_ID_TEXT = key("tooltip.{mod}.network_tunnel_id");

    // --------------------------------------------------------------------- //

    public NetworkTunnelItem() {
        super(createProperties().method_7889(1));
    }

    // --------------------------------------------------------------------- //

    public static Optional<UUID> getTunnelId(final class_1799 stack) {
        final class_2487 tag = ItemStackUtils.getModDataTag(stack);
        if (tag.method_25928(TUNNEL_ID_TAG_NAME)) {
            return Optional.of(tag.method_25926(TUNNEL_ID_TAG_NAME));
        } else {
            return Optional.empty();
        }
    }

    public static void setTunnelId(final class_1799 stack, final UUID value) {
        ItemStackUtils.modifyModDataTag(stack, tag -> tag.method_25927(TUNNEL_ID_TAG_NAME, value));
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_7851(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        getTunnelId(stack).ifPresent(id -> {
            final String idString = class_3544.method_34963(id.toString(), 8 + 3, true);
            final class_5250 idComponent = TextFormatUtils.withFormat(idString, class_124.field_1060);
            tooltip.add(class_2561.method_43469(TUNNEL_ID_TEXT, idComponent).method_27692(class_124.field_1080));
        });
    }

    @Override
    public class_1271<class_1799> method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        if (!level.method_8608() && player instanceof class_3222 serverPlayer) {
            openContainerScreen(serverPlayer, hand);
        }

        return class_1271.method_29237(player.method_5998(hand), level.method_8608());
    }

    // --------------------------------------------------------------------- //

    private void openContainerScreen(final class_3222 player, final class_1268 hand) {
        NetworkTunnelContainer.createServer(player, hand);
    }
}
