/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import java.util.List;

public class ModBlockItem extends class_1747 {
    public ModBlockItem(final class_2248 block, final class_1793 properties) {
        super(block, properties);
    }

    public ModBlockItem(final class_2248 block) {
        this(block, createProperties());
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        TooltipUtils.tryAddDescription(stack, tooltip);
        super.method_7851(stack, context, tooltip, flag);
    }

    // --------------------------------------------------------------------- //

    protected static class_1793 createProperties() {
        return new class_1793();
    }
}
