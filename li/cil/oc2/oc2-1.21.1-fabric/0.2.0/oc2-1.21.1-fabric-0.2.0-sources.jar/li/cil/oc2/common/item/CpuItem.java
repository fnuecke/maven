/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.api.bus.device.vm.ArchitectureType;
import li.cil.oc2.common.Config;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import java.util.List;

public final class CpuItem extends ModItem {
    private final ArchitectureType architectureType;

    // --------------------------------------------------------------------- //

    public CpuItem(final ArchitectureType architectureType) {
        this.architectureType = architectureType;
    }

    // --------------------------------------------------------------------- //

    public ArchitectureType getArchitectureType() {
        return architectureType;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(final class_1799 stack, final class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.addEnergyConsumption(Config.cpuEnergyPerTick(architectureType), tooltip);
    }
}
