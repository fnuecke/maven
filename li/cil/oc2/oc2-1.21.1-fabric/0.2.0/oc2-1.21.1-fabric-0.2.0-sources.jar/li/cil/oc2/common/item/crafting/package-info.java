/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.item.crafting;

import javax.annotation.ParametersAreNonnullByDefault;
