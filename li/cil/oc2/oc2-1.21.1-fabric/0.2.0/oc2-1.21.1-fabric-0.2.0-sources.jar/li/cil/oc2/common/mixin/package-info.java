/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.common.mixin;

import javax.annotation.ParametersAreNonnullByDefault;
