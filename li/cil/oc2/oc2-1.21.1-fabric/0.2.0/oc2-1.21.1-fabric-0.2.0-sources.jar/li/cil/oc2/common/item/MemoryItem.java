/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.api.API;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import javax.annotation.Nullable;

public final class MemoryItem extends AbstractStorageItem {
    @Nullable
    private String descriptionId;

    // --------------------------------------------------------------------- //

    public MemoryItem(final int defaultCapacity) {
        super(defaultCapacity);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected String method_7869() {
        if (descriptionId == null) {
            descriptionId = class_156.method_646("item", class_2960.method_60655(API.MOD_ID, "memory"));
        }
        return descriptionId;
    }
}
