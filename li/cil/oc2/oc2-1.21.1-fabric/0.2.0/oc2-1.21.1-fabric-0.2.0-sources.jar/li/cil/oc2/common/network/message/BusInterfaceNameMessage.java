/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_9129;

public abstract class BusInterfaceNameMessage extends AbstractMessage {
    protected class_2338 pos;
    protected class_2350 side;
    protected String value;

    // --------------------------------------------------------------------- //

    protected BusInterfaceNameMessage(final BusCableBlockEntity busCable, final class_2350 side, final String value) {
        this.pos = busCable.method_11016();
        this.side = side;
        this.value = value;
    }

    protected BusInterfaceNameMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        side = buffer.method_10818(class_2350.class);
        value = buffer.method_10800(32);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        buffer.method_10817(side);
        buffer.method_10788(value, 32);
    }

    // --------------------------------------------------------------------- //

    public static final class ToClient extends BusInterfaceNameMessage {
        public ToClient(final BusCableBlockEntity busCable, final class_2350 side, final String value) {
            super(busCable, side, value);
        }

        public ToClient(final class_9129 buffer) {
            super(buffer);
        }

        @Override
        protected void handleMessage(final NetworkManager.PacketContext context) {
            MessageUtils.withClientBlockEntityAt(pos, BusCableBlockEntity.class,
                busCable -> busCable.setInterfaceName(side, value));
        }
    }

    public static final class ToServer extends BusInterfaceNameMessage {
        public ToServer(final BusCableBlockEntity busCable, final class_2350 side, final String value) {
            super(busCable, side, value);
        }

        public ToServer(final class_9129 buffer) {
            super(buffer);
        }

        @Override
        protected void handleMessage(final NetworkManager.PacketContext context) {
            MessageUtils.withNearbyServerBlockEntityForInteraction(context, pos, BusCableBlockEntity.class,
                (player, busCable) -> busCable.setInterfaceName(side, value));
        }
    }
}
