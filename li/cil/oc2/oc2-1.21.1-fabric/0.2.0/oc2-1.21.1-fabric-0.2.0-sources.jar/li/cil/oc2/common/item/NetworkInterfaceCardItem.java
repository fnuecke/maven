/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.client.gui.NetworkInterfaceCardScreen;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.NBTTagIds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.List;

import static li.cil.oc2.common.util.TextFormatUtils.withFormat;
import static li.cil.oc2.common.util.TranslationUtils.text;

public final class NetworkInterfaceCardItem extends ModItem {
    private static final String SIDE_CONFIGURATION_TAG_NAME = "sides";
    private static final class_2561 IS_CONFIGURED_TEXT = withFormat(text("item.{mod}.network_interface_card.is_configured"), class_124.field_1060);

    // --------------------------------------------------------------------- //

    public static void setSideConfiguration(final class_1799 stack, final class_2350 side, final boolean enabled) {
        final int index = side.method_10146();

        final class_2487 tag = ItemStackUtils.getModDataTag(stack);
        final byte[] values;
        if (tag.method_10573(SIDE_CONFIGURATION_TAG_NAME, NBTTagIds.TAG_BYTE_ARRAY) &&
            tag.method_10547(SIDE_CONFIGURATION_TAG_NAME).length == Constants.BLOCK_FACE_COUNT) {
            values = tag.method_10547(SIDE_CONFIGURATION_TAG_NAME);
        } else {
            values = new byte[Constants.BLOCK_FACE_COUNT];
            Arrays.fill(values, (byte) 1);
        }

        values[index] = (byte) (enabled ? 1 : 0);

        tag.method_10570(SIDE_CONFIGURATION_TAG_NAME, values);
    }

    public static boolean getSideConfiguration(final class_1799 stack, @Nullable final class_2350 side) {
        if (side == null) {
            return false;
        }

        final int index = side.method_10146();

        final class_2487 tag = ItemStackUtils.getModDataTag(stack);
        if (tag.method_10573(SIDE_CONFIGURATION_TAG_NAME, NBTTagIds.TAG_BYTE_ARRAY)) {
            final byte[] values = tag.method_10547(SIDE_CONFIGURATION_TAG_NAME);
            if (index < values.length) {
                return values[index] != 0;
            }
        }

        return true;
    }

    public static boolean hasConfiguration(final class_1799 stack) {
        final byte[] values = ItemStackUtils.getModDataTag(stack).method_10547(SIDE_CONFIGURATION_TAG_NAME);
        for (final byte value : values) {
            if (value == 0) {
                return true;
            }
        }

        return false;
    }

    // --------------------------------------------------------------------- //


    @Override
    public void method_7851(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        if (NetworkInterfaceCardItem.hasConfiguration(stack)) {
            tooltip.add(IS_CONFIGURED_TEXT);
        }
    }

    @Override
    public class_1271<class_1799> method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        final class_1799 itemStack = player.method_5998(hand);

        if (player.method_37908().method_8608()) {
            if (itemStack.method_31574(Items.NETWORK_INTERFACE_CARD.get())) {
                openConfigurationScreen(player, hand);
            }
        }

        return class_1271.method_29237(itemStack, player.method_37908().method_8608());
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    private void openConfigurationScreen(final class_1657 player, final class_1268 hand) {
        class_310.method_1551().method_1507(new NetworkInterfaceCardScreen(player, hand));
    }
}
