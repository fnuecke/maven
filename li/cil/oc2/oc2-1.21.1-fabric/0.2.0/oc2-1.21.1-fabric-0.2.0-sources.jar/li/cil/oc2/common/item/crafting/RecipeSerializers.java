/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item.crafting;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.common.util.RegistryUtils;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_7924;

public final class RecipeSerializers {
    private static final DeferredRegister<class_1865<?>> RECIPE_SERIALIZERS = RegistryUtils.getInitializerFor(class_7924.field_41216);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<ToolRecipe.Serializer> TOOL = RECIPE_SERIALIZERS.register("tool", ToolRecipe.Serializer::new);
    public static final RegistrySupplier<class_1866<ResetRecipe>> RESET = RECIPE_SERIALIZERS.register("reset", () -> new class_1866<>(ResetRecipe::new));

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }
}
