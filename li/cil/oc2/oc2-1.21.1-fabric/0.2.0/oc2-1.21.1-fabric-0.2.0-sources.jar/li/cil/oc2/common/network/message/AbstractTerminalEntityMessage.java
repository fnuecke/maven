/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import java.nio.ByteBuffer;
import net.minecraft.class_1297;
import net.minecraft.class_9129;

public abstract class AbstractTerminalEntityMessage extends AbstractMessage {
    protected int entityId;
    protected byte[] data;

    // --------------------------------------------------------------------- //

    protected AbstractTerminalEntityMessage(final class_1297 entity, final ByteBuffer data) {
        this.entityId = entity.method_5628();
        this.data = data.array();
    }

    protected AbstractTerminalEntityMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        entityId = buffer.method_10816();
        data = buffer.method_10795();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10804(entityId);
        buffer.method_10813(data);
    }
}
