/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.api.API;
import li.cil.oc2.common.util.RegistryUtils;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.Comparator;

public final class ItemGroup {
    private static final DeferredRegister<class_1761> TABS = RegistryUtils.getInitializerFor(class_7924.field_44688);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1761> COMMON = TABS.register("common", () ->
        CreativeTabRegistry.create(builder -> {
            builder.method_47320(() -> new class_1799(Items.COMPUTER.get()));
            builder.method_47321(class_2561.method_43471("itemGroup." + API.MOD_ID + ".common"));
            builder.method_47317((parameters, output) -> class_7923.field_41178.method_10220()
                .filter(item -> API.MOD_ID.equals(class_7923.field_41178.method_10221(item).method_12836()))
                .sorted(Comparator.comparing(item -> item.method_7848().getString(), String.CASE_INSENSITIVE_ORDER))
                .forEach(item -> addItem(item, parameters, output)));
        }));

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    // --------------------------------------------------------------------- //

    private static void addItem(final class_1792 item, final class_1761.class_8128 parameters, final class_1761.class_7704 output) {
        if (item instanceof final CreativeTabItemProvider provider) {
            provider.addCreativeTabItems(parameters, output);
        } else {
            output.method_45420(new class_1799(item));
        }
    }

    private ItemGroup() {
    }
}
