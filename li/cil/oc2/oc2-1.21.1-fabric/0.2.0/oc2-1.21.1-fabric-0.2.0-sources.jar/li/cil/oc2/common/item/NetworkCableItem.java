/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.api.API;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.NetworkConnectorBlockEntity;
import li.cil.oc2.common.blockentity.NetworkConnectorBlockEntity.ConnectionResult;
import li.cil.oc2.common.util.EntityUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import java.util.Objects;

public final class NetworkCableItem extends ModItem {
    private static final String LINK_START_TAG_NAME = API.MOD_ID + ":" + "network_cable_link_start";

    // --------------------------------------------------------------------- //

    @Override
    public class_1271<class_1799> method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        if (player.method_5715()) {
            if (player instanceof final class_3222 serverPlayer) {
                final class_2487 persistentData = EntityUtils.getPersistentData(serverPlayer);
                persistentData.method_10551(LINK_START_TAG_NAME);
            }

            return class_1271.method_22427(player.method_5998(hand));
        }

        return super.method_7836(level, player, hand);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1657 player = context.method_8036();
        if (player == null) {
            return super.method_7884(context);
        }

        final class_1799 stack = player.method_5998(context.method_20287());
        if (stack.method_7960() || stack.method_7909() != this) {
            return super.method_7884(context);
        }

        final class_1937 level = context.method_8045();
        final class_2338 currentPos = context.method_8037();

        final class_2586 currentBlockEntity = level.method_8321(currentPos);
        if (!(currentBlockEntity instanceof final NetworkConnectorBlockEntity currentConnector)) {
            return super.method_7884(context);
        }

        if (!level.method_8608() && player instanceof final class_3222 serverPlayer) {
            final class_2487 persistentData = EntityUtils.getPersistentData(serverPlayer);
            final class_2338 startPos = class_2512.method_10691(persistentData, LINK_START_TAG_NAME).orElse(null);
            persistentData.method_10551(LINK_START_TAG_NAME);
            if (startPos == null || Objects.equals(startPos, currentPos)) {
                if (currentConnector.canConnectMore()) {
                    persistentData.method_10566(LINK_START_TAG_NAME, class_2512.method_10692(currentPos));
                } else {
                    player.method_7353(class_2561.method_43471(Constants.CONNECTOR_ERROR_FULL), true);
                }
            } else {
                final class_2586 startBlockEntity = level.method_8321(startPos);
                if (!(startBlockEntity instanceof final NetworkConnectorBlockEntity startConnector)) {
                    // Starting connector was removed in the meantime.
                    return super.method_7884(context);
                }

                final ConnectionResult connectionResult = NetworkConnectorBlockEntity.connect(startConnector, currentConnector);
                switch (connectionResult) {
                    case SUCCESS:
                        if (!player.method_7337()) {
                            stack.method_7934(1);
                        }
                        break;

                    case FAILURE:
                        persistentData.method_10566(LINK_START_TAG_NAME, class_2512.method_10692(startPos));
                        break;
                    case FAILURE_FULL:
                        persistentData.method_10566(LINK_START_TAG_NAME, class_2512.method_10692(startPos));
                        player.method_7353(class_2561.method_43471(Constants.CONNECTOR_ERROR_FULL), true);
                        break;
                    case FAILURE_TOO_FAR:
                        persistentData.method_10566(LINK_START_TAG_NAME, class_2512.method_10692(startPos));
                        player.method_7353(class_2561.method_43471(Constants.CONNECTOR_ERROR_TOO_FAR), true);
                        break;
                    case FAILURE_OBSTRUCTED:
                        persistentData.method_10566(LINK_START_TAG_NAME, class_2512.method_10692(startPos));
                        player.method_7353(class_2561.method_43471(Constants.CONNECTOR_ERROR_OBSTRUCTED), true);
                        break;
                }
            }
        }

        return class_1269.method_29236(level.method_8608());
    }
}
