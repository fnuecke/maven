/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.api.bus.device.DeviceTypes;
import li.cil.oc2.common.bus.device.data.FirmwareRegistry;
import li.cil.oc2.common.entity.Entities;
import li.cil.oc2.common.entity.Robot;
import li.cil.oc2.common.entity.robot.RobotActions;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.LevelUtils;
import li.cil.oc2.common.util.NBTUtils;
import net.minecraft.class_1269;
import net.minecraft.class_1750;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_3468;
import net.minecraft.class_7225;
import java.util.List;

import static li.cil.oc2.common.Constants.ITEMS_TAG_NAME;
import static li.cil.oc2.common.bus.device.DeviceTypeRegistry.key;
import static li.cil.oc2.common.util.NBTUtils.makeInventoryTag;

public final class RobotItem extends ModItem implements CreativeTabItemProvider {
    @Override
    public void addCreativeTabItems(final class_1761.class_8128 parameters, final class_1761.class_7704 output) {
        output.method_45420(getRobotWithFlash(parameters.comp_1253()));
    }

    @Override
    public void method_7851(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.addEntityEnergyInformation(stack, tooltip);
        TooltipUtils.addEntityInventoryInformation(stack, tooltip);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1937 level = context.method_8045();
        final class_2338 pos = context.method_8037();

        final class_243 position;
        if (level.method_8320(pos).method_26166(new class_1750(context))) {
            position = class_243.method_24953(pos);
        } else {
            position = class_243.method_24953(pos.method_10093(context.method_8038()));
        }

        final Robot robot = Entities.ROBOT.get().method_5883(context.method_8045());
        if (robot == null) {
            return class_1269.field_5814;
        }

        robot.method_5808(position.field_1352, position.field_1351 - robot.method_17682() * 0.5f, position.field_1350,
            class_2350.method_10150(context.method_8044()).method_10153().method_10144(), 0);
        if (!level.method_17892(robot)) {
            return super.method_7884(context);
        }

        if (!level.method_8608()) {
            RobotActions.initializeData(robot);
            robot.importFromItemStack(context.method_8041());

            level.method_8649(robot);
            LevelUtils.playSound(level, class_2338.method_49638(position), class_2498.field_11533, class_2498::method_10598);

            if (context.method_8036() == null || !context.method_8036().method_7337()) {
                context.method_8041().method_7934(1);
            }
        }

        if (context.method_8036() != null) {
            context.method_8036().method_7259(class_3468.field_15372.method_14956(this));
        }

        return class_1269.method_29236(level.method_8608());
    }

    @Override
    public boolean method_31568() {
        return false;
    }


    // --------------------------------------------------------------------- //

    private class_1799 getRobotWithFlash(final class_7225.class_7874 provider) {
        final class_1799 robot = new class_1799(this);

        ItemStackUtils.modifyModDataTag(robot, tag -> {
            final class_2487 itemsTag = NBTUtils.getOrCreateChildTag(tag, ITEMS_TAG_NAME);
            itemsTag.method_10566(key(DeviceTypes.CPU.get()), makeInventoryTag(provider,
                new class_1799(Items.CPU_RISCV.get())
            ));
            itemsTag.method_10566(key(DeviceTypes.FLASH_MEMORY.get()), makeInventoryTag(provider,
                Items.FLASH_MEMORY.get().withData(FirmwareRegistry.RISCV.getId())
            ));
        });

        return robot;
    }
}
