/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item.crafting;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.integration.Wrenches;
import li.cil.oc2.common.tags.ItemTags;
import li.cil.oc2.common.util.StorageItemUtils;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9694;
import java.util.function.Function;

public final class ToolRecipe extends class_1867 {
    public ToolRecipe(final class_1867 recipe) {
        super(recipe.method_8112(), recipe.method_45441(), recipe.field_9050, recipe.method_8117());
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean method_17730(final class_9694 input, final class_1937 level) {
        if (!super.method_17730(input, level)) {
            return false;
        }

        for (int slot = 0; slot < input.method_59983(); slot++) {
            final class_1799 stack = input.method_59984(slot);
            if (StorageItemUtils.needsRepair(stack)) {
                return false;
            }
        }

        return true;
    }

    @Override
    public class_2371<class_1799> getRemainingItems(final class_9694 input) {
        final class_2371<class_1799> result = class_2371.method_10213(input.method_59983(), class_1799.field_8037);

        for (int slot = 0; slot < input.method_59983(); slot++) {
            final class_1799 stack = input.method_59984(slot);
            if (stack.method_7909().method_7857()) {
                result.set(slot, new class_1799(stack.method_7909().method_7858()));
            } else if (isTool(stack)) {
                final class_1799 copy = stack.method_7972();
                copy.method_7939(1);
                result.set(slot, copy);
            } else {
                // Eager cleanup of blob storage; we convert to something new, so
                // the old data is unreachable anyway.
                StorageItemUtils.clearBlobData(stack);
            }
        }

        return result;
    }

    @Override
    public class_1865<?> method_8119() {
        return RecipeSerializers.TOOL.get();
    }

    // --------------------------------------------------------------------- //

    private static boolean isTool(final class_1799 stack) {
        return Wrenches.isWrench(stack) || stack.method_31573(ItemTags.DEVICES_CPU);
    }

    // --------------------------------------------------------------------- //

    public static final class Serializer implements class_1865<ToolRecipe> {
        private static final MapCodec<ToolRecipe> CODEC = class_1865.field_9031.method_53736()
            .xmap(ToolRecipe::new, Function.identity());
        private static final class_9139<class_9129, ToolRecipe> STREAM_CODEC = class_1865.field_9031.method_56104()
            .method_56432(ToolRecipe::new, Function.identity());

        @Override
        public MapCodec<ToolRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, ToolRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
