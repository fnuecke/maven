/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.mixin;

import li.cil.oc2.common.util.ChunkUtils;
import net.minecraft.class_2802;
import net.minecraft.class_3215;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3215.class)
public abstract class ServerChunkCacheMixin extends class_2802 {
    @Inject(method = "save", at = @At("HEAD"))
    private void applyLazyUnsavedChunks(final CallbackInfo ci) {
        ChunkUtils.applyChunkLazyUnsaved();
    }
}
