/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import net.minecraft.class_1761;

public interface CreativeTabItemProvider {
    void addCreativeTabItems(final class_1761.class_8128 parameters, final class_1761.class_7704 output);
}
