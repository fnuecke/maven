/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.common.Config;
import li.cil.oc2.common.block.BusCableBlock;
import li.cil.oc2.common.util.LevelUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import java.util.List;

public final class BusCableItem extends ModBlockItem {
    public BusCableItem(final class_2248 block) {
        super(block);
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.addEnergyConsumption(Config.busCableEnergyPerTick, tooltip);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1269 result = tryAddToBlock(context);
        return result.method_23665() ? result : super.method_7884(context);
    }

    @Override
    public class_1269 method_7712(final class_1750 context) {
        final class_1269 result = tryAddToBlock(context);
        return result.method_23665() ? result : super.method_7712(context);
    }

    // --------------------------------------------------------------------- //

    private static class_1269 tryAddToBlock(final class_1838 context) {
        final class_1937 level = context.method_8045();
        final class_2338 pos = context.method_8037();
        final class_2680 state = level.method_8320(pos);

        if (!BusCableBlock.addCable(level, pos, state)) {
            return class_1269.field_5811;
        }

        final class_1657 player = context.method_8036();
        final class_1799 stack = context.method_8041();

        if (player instanceof final class_3222 serverPlayer) {
            class_174.field_1191.method_23889(serverPlayer, pos, stack);
        }

        LevelUtils.playSound(level, pos, state.method_26231(), class_2498::method_10598);

        if (player == null || !player.method_31549().field_7477) {
            stack.method_7934(1);
        }

        return class_1269.method_29236(level.method_8608());
    }
}
