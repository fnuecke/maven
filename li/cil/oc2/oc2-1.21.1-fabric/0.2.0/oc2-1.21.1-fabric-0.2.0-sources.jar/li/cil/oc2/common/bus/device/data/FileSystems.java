/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import dev.architectury.event.events.common.LifecycleEvent;
import dev.architectury.registry.ReloadListenerRegistry;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import li.cil.oc2.api.API;
import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.oc2.common.vm.fs.LayeredFileSystem;
import li.cil.sedna.fs.FileSystem;
import li.cil.sedna.fs.ZipStreamFileSystem;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import static li.cil.oc2.common.util.TextFormatUtils.formatSize;

public final class FileSystems {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final LayeredFileSystem LAYERED_FILE_SYSTEM = new LayeredFileSystem();
    private static final Map<class_2960, BlockDeviceData> BLOCK_DEVICE_DATA = new HashMap<>();

    // --------------------------------------------------------------------- //

    public static FileSystem getLayeredFileSystem() {
        return LAYERED_FILE_SYSTEM;
    }

    public static Map<class_2960, BlockDeviceData> getBlockData() {
        return BLOCK_DEVICE_DATA;
    }

    public static void reset() {
        LAYERED_FILE_SYSTEM.clear();

        for (final BlockDeviceData data : BLOCK_DEVICE_DATA.values()) {
            try {
                ((ResourceBlockDeviceData) data).close();
            } catch (final Exception e) {
                LOGGER.error(e);
            }
        }
        BLOCK_DEVICE_DATA.clear();
    }

    // --------------------------------------------------------------------- //

    public static void initialize() {
        ReloadListenerRegistry.register(class_3264.field_14190, ReloadListener.INSTANCE,
            class_2960.method_60655(API.MOD_ID, "file_systems"));
        LifecycleEvent.SERVER_STOPPED.register(server -> handleServerStopped());
    }

    private static void handleServerStopped() {
        reset();
    }

    // --------------------------------------------------------------------- //

    private static void reload(final class_3300 resourceManager) {
        reset();

        LOGGER.info("Searching for datapack filesystems...");
        final Map<class_2960, class_3298> fileSystemDescriptors = resourceManager
            .method_14488("file_systems", location -> location.method_12832().endsWith(".json"));

        final ArrayList<ZipStreamFileSystem> fileSystems = new ArrayList<>();
        final Object2IntArrayMap<ZipStreamFileSystem> fileSystemOrder = new Object2IntArrayMap<>();

        for (final Map.Entry<class_2960, class_3298> entry : fileSystemDescriptors.entrySet()) {
            final class_2960 fileSystemDescriptorLocation = entry.getKey();
            LOGGER.info("Found [{}]", fileSystemDescriptorLocation);
            try {
                final JsonObject json;
                try (Reader reader = entry.getValue().method_43039()) {
                    json = JsonParser.parseReader(reader).getAsJsonObject();
                }
                final String type = json.getAsJsonPrimitive("type").getAsString();
                switch (type) {
                    case "layer" -> {
                        final class_2960 location = class_2960.method_60654(json.getAsJsonPrimitive("location").getAsString());

                        final ZipStreamFileSystem fileSystem;
                        try (InputStream stream = resourceManager.getResourceOrThrow(location).method_14482()) {
                            fileSystem = new ZipStreamFileSystem(stream);
                        }

                        final long fileCount = fileSystem.statfs().fileCount;
                        if (fileCount > 0) {
                            LOGGER.info("  Adding layer with [{}] file(s).", fileCount);
                            fileSystems.add(fileSystem);
                        } else {
                            LOGGER.info("  Skipping empty layer.");
                        }

                        if (json.has("order")) {
                            final JsonPrimitive order = json.getAsJsonPrimitive("order");
                            fileSystemOrder.put(fileSystem, order.getAsInt());
                        } else {
                            fileSystemOrder.put(fileSystem, 0);
                        }
                    }
                    case "block" -> {
                        final class_2960 location = class_2960.method_60654(json.getAsJsonPrimitive("location").getAsString());
                        if (BlockDeviceDataRegistry.getValue(location) != null) {
                            LOGGER.error("Block device from datapack collides with already registered location [{}].", location);
                            continue;
                        }

                        final String name;
                        if (json.has("name")) {
                            name = json.getAsJsonPrimitive("name").getAsString();
                        } else {
                            name = "???";
                        }

                        final ResourceBlockDeviceData data = new ResourceBlockDeviceData(resourceManager, location, name);

                        LOGGER.info("  Adding block device [{}] with id [{}] and a size of [{}].", name, location, formatSize(data.getBlockDevice().getCapacity()));
                        BLOCK_DEVICE_DATA.put(location, data);
                    }
                    default -> LOGGER.error("Unsupported file system type [{}].", type);
                }
            } catch (final Throwable e) {
                LOGGER.error(e);
            }
        }

        fileSystems.sort(Comparator.comparingInt(fileSystemOrder::getInt));
        fileSystems.forEach(LAYERED_FILE_SYSTEM::addLayer);
    }

    // --------------------------------------------------------------------- //

    private static final class ReloadListener implements class_3302 {
        public static final ReloadListener INSTANCE = new ReloadListener();

        @Override
        public CompletableFuture<Void> method_25931(final class_3302.class_4045 stage, final class_3300 resourceManager, final class_3695 preparationsProfiler, final class_3695 reloadProfiler, final Executor backgroundExecutor, final Executor gameExecutor) {
            return CompletableFuture
                .runAsync(() -> FileSystems.reload(resourceManager), backgroundExecutor)
                .thenCompose(stage::method_18352);
        }
    }

}
