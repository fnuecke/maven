/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.common.Config;
import li.cil.oc2.common.block.Blocks;
import li.cil.oc2.common.block.BusCableBlock;
import li.cil.oc2.common.block.BusCableBlock.ConnectionType;
import li.cil.oc2.common.util.LevelUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1750;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_3222;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

public final class BusInterfaceItem extends ModBlockItem implements CreativeTabItemProvider {
    public BusInterfaceItem() {
        super(Blocks.BUS_CABLE.get());
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.addEnergyConsumption(Config.busInterfaceEnergyPerTick, tooltip);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_243 localHitPos = context.method_17698().method_1020(class_243.method_24953(context.method_8037()));
        final class_2350 side = class_2350.method_10142(localHitPos.field_1352, localHitPos.field_1351, localHitPos.field_1350);
        final class_1269 result = tryAddToBlock(context, side);
        return result.method_23665() ? result : super.method_7884(context);
    }

    @Override
    public class_1269 method_7712(final class_1750 context) {
        final class_1269 result = tryAddToBlock(context, context.method_8038().method_10153());
        return result.method_23665() ? result : super.method_7712(context);
    }

    @Override
    public String method_7876() {
        return method_7869();
    }

    @Override
    public void addCreativeTabItems(final class_1761.class_8128 parameters, final class_1761.class_7704 output) {
        output.method_45420(new class_1799(this));
    }

    @Override
    public void method_7713(final Map<class_2248, class_1792> map, final class_1792 item) {
    }

    // --------------------------------------------------------------------- //

    @Nullable
    @Override
    protected class_2680 method_7707(final class_1750 context) {
        final class_2680 state = super.method_7707(context);
        if (state == null) {
            return null;
        }

        final class_2754<ConnectionType> connectionTypeProperty =
            BusCableBlock.FACING_TO_CONNECTION_MAP.get(context.method_8038().method_10153());
        return state
            .method_11657(BusCableBlock.HAS_CABLE, false)
            .method_11657(connectionTypeProperty, ConnectionType.INTERFACE);
    }

    // --------------------------------------------------------------------- //

    private static class_1269 tryAddToBlock(final class_1838 context, final class_2350 side) {
        final class_1937 level = context.method_8045();
        final class_2338 pos = context.method_8037();
        final class_2680 state = level.method_8320(pos);

        if (!BusCableBlock.addInterface(level, pos, state, side)) {
            return class_1269.field_5811;
        }

        final class_1657 player = context.method_8036();
        final class_1799 stack = context.method_8041();

        if (player instanceof final class_3222 serverPlayer) {
            class_174.field_1191.method_23889(serverPlayer, pos, stack);
        }

        LevelUtils.playSound(level, pos, state.method_26231(), class_2498::method_10598);

        if (player == null || !player.method_31549().field_7477) {
            stack.method_7934(1);
        }

        return class_1269.method_29236(level.method_8608());
    }
}
