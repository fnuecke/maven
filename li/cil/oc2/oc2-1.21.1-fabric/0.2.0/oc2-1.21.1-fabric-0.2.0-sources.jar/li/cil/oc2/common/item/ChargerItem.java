/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.common.Config;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2248;

public final class ChargerItem extends ModBlockItem implements CreativeTabItemProvider {
    public ChargerItem(final class_2248 block) {
        super(block);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void addCreativeTabItems(final class_1761.class_8128 parameters, final class_1761.class_7704 output) {
        if (Config.chargerUseEnergy()) {
            output.method_45420(new class_1799(this));
        }
    }
}
