/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.network.Network;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import org.apache.commons.lang3.NotImplementedException;

public abstract class AbstractMessage implements class_8710 {
    protected AbstractMessage() {
    }

    protected AbstractMessage(final class_9129 buffer) {
        fromBytes(buffer);
    }

    // --------------------------------------------------------------------- //

    public abstract void fromBytes(final class_9129 buffer);

    public abstract void toBytes(final class_9129 buffer);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return Network.getMessageType(getClass());
    }

    // --------------------------------------------------------------------- //

    protected void handleMessage(final NetworkManager.PacketContext context) {
        throw new NotImplementedException("Message does not implement handleMessage().");
    }

    public void handle(final NetworkManager.PacketContext context) {
        handleMessage(context);
    }
}
