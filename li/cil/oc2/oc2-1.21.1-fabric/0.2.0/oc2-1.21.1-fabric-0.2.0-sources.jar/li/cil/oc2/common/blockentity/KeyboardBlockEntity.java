/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.bus.device.vm.block.KeyboardDevice;
import li.cil.oc2.common.capabilities.Capabilities;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public final class KeyboardBlockEntity extends ModBlockEntity {
    private final KeyboardDevice<class_2586> keyboardDevice = new KeyboardDevice<>(this);

    // --------------------------------------------------------------------- //

    public KeyboardBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.KEYBOARD.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    public void handleInput(final int keycode, final boolean isDown) {
        keyboardDevice.sendKeyEvent(keycode, isDown);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        if (direction == class_2350.field_11033) {
            collector.offer(Capabilities.DEVICE, keyboardDevice);
        }
    }
}
