/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.bus.CommonDeviceBusController;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_2338;
import net.minecraft.class_9129;

public final class ComputerBusStateMessage extends AbstractMessage {
    private class_2338 pos;
    private CommonDeviceBusController.BusState value;

    // --------------------------------------------------------------------- //

    public ComputerBusStateMessage(final ComputerBlockEntity computer, final CommonDeviceBusController.BusState value) {
        this.pos = computer.method_11016();
        this.value = value;
    }

    public ComputerBusStateMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        value = buffer.method_10818(CommonDeviceBusController.BusState.class);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        buffer.method_10817(value);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        MessageUtils.withClientBlockEntityAt(pos, ComputerBlockEntity.class,
            computer -> computer.getVirtualMachineClientState().setBusStateClient(value));
    }
}
