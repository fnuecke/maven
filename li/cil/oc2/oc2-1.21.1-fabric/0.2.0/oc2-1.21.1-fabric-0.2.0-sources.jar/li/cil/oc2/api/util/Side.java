/* SPDX-License-Identifier: MIT */

package li.cil.oc2.api.util;

import javax.annotation.Nullable;
import net.minecraft.class_2350;

/**
 * This enum indicates a side of a block device.
 * <p>
 * It is intended to be used by {@link li.cil.oc2.api.bus.device.rpc.RPCDevice} APIs,
 * providing both convenience for the caller by providing a range of aliases, and also
 * stability, in case Mojang decide to rename the enum fields of the {@link class_2350}
 * enum at some time in the future.
 */
public enum Side {
    DOWN(class_2350.field_11033),
    down(DOWN),
    d(DOWN),

    UP(class_2350.field_11036),
    up(UP),
    u(UP),

    NORTH(class_2350.field_11043),
    north(NORTH),
    n(NORTH),
    BACK(NORTH),
    back(NORTH),
    b(NORTH),

    SOUTH(class_2350.field_11035),
    south(SOUTH),
    s(SOUTH),
    FRONT(SOUTH),
    front(SOUTH),
    f(SOUTH),

    WEST(class_2350.field_11039),
    west(WEST),
    w(WEST),
    LEFT(WEST),
    left(WEST),
    l(WEST),

    EAST(class_2350.field_11034),
    east(EAST),
    e(EAST),
    RIGHT(EAST),
    right(EAST),
    r(EAST),
    ;

    private static final Side[] BY_INDEX = {DOWN, UP, NORTH, SOUTH, WEST, EAST};

    @Nullable
    private final Side base;
    private final class_2350 direction;

    Side(final class_2350 direction) {
        this.base = null;
        this.direction = direction;
    }

    Side(final Side side) {
        this.base = side;
        this.direction = side.direction;
    }

    public static Side byIndex(final int index) {
        if (index < 0 || index >= BY_INDEX.length) {
            throw new IllegalArgumentException("Side index [" + index + "] is outside [0, " + (BY_INDEX.length - 1) + "].");
        }
        return BY_INDEX[index];
    }

    public class_2350 getDirection() {
        return direction;
    }

    @Override
    public String toString() {
        return base != null ? base.toString() : super.toString();
    }
}
