/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.mixin;

import li.cil.oc2.client.renderer.ProjectorDepthRenderer;
import li.cil.oc2.common.ext.MinecraftExt;
import net.minecraft.class_276;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftMixin implements MinecraftExt {
    private class_276 mainRenderTargetOverride;

    @Override
    public void setMainRenderTargetOverride(@Nullable final class_276 renderTarget) {
        mainRenderTargetOverride = renderTarget;
    }

    /**
     * Redirect everything into the correct buffer while rendering projector depth.
     * <p>
     * Some things in level rendering may try to re-bind the main render target, so
     * we catch that and ensure we bind the projector depth buffer again.
     */
    @Inject(method = "getMainRenderTarget", at = @At("HEAD"), cancellable = true)
    private void getMainRenderTargetOverride(final CallbackInfoReturnable<class_276> cir) {
        if (mainRenderTargetOverride != null) {
            cir.setReturnValue(mainRenderTargetOverride);
        }
    }

    /**
     * Avoid access to render targets that are null while rendering projector depth to skip some work.
     */
    @Inject(method = "useShaderTransparency", at = @At("HEAD"), cancellable = true)
    private static void noTransparencyWhileRenderingProjectorDepth(final CallbackInfoReturnable<Boolean> cir) {
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()) {
            cir.setReturnValue(false);
        }
    }
}
