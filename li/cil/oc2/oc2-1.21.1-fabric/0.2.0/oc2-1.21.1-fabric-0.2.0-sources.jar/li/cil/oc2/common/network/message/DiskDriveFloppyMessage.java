/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.DiskDriveBlockEntity;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_9129;

public final class DiskDriveFloppyMessage extends AbstractMessage {
    private class_2338 pos;
    private class_1799 floppy;

    // --------------------------------------------------------------------- //

    public DiskDriveFloppyMessage(final DiskDriveBlockEntity diskDrive) {
        this.pos = diskDrive.method_11016();
        this.floppy = diskDrive.getFloppy().method_7972();
    }

    public DiskDriveFloppyMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        floppy = class_1799.field_49268.decode(buffer);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        class_1799.field_49268.encode(buffer, floppy);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        MessageUtils.withClientBlockEntityAt(pos, DiskDriveBlockEntity.class,
            diskDrive -> diskDrive.setFloppyClient(floppy));
    }
}
