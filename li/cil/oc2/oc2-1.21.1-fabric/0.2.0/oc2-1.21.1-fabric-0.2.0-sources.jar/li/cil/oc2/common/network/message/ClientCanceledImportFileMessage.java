/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.bus.device.rpc.item.FileImportExportCardItemDevice;
import net.minecraft.class_3222;
import net.minecraft.class_9129;


public final class ClientCanceledImportFileMessage extends AbstractMessage {
    private int id;

    // --------------------------------------------------------------------- //

    public ClientCanceledImportFileMessage(final int id) {
        this.id = id;
    }

    public ClientCanceledImportFileMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        id = buffer.method_10816();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10804(id);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        if (context.getPlayer() instanceof final class_3222 player) {
            FileImportExportCardItemDevice.cancelImport(player, id);
        }
    }
}
