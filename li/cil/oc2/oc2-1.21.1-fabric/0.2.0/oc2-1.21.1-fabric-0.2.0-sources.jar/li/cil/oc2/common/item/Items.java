/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.api.bus.device.vm.ArchitectureType;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.block.Blocks;
import li.cil.oc2.common.util.RegistryUtils;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_7924;
import java.util.function.Function;
import java.util.function.Supplier;

public final class Items {
    private static final DeferredRegister<class_1792> ITEMS = RegistryUtils.getInitializerFor(class_7924.field_41197);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1792> BUS_CABLE = register(Blocks.BUS_CABLE, BusCableItem::new);
    public static final RegistrySupplier<BusInterfaceItem> BUS_INTERFACE = register("bus_interface", BusInterfaceItem::new);
    public static final RegistrySupplier<class_1792> CHARGER = register(Blocks.CHARGER, ChargerItem::new);
    public static final RegistrySupplier<class_1792> COMPUTER = register(Blocks.COMPUTER, ComputerItem::new);
    public static final RegistrySupplier<class_1792> CREATIVE_ENERGY = register(Blocks.CREATIVE_ENERGY);
    public static final RegistrySupplier<class_1792> DISK_DRIVE = register(Blocks.DISK_DRIVE);
    public static final RegistrySupplier<class_1792> KEYBOARD = register(Blocks.KEYBOARD);
    public static final RegistrySupplier<class_1792> NETWORK_CONNECTOR = register(Blocks.NETWORK_CONNECTOR);
    public static final RegistrySupplier<class_1792> NETWORK_HUB = register(Blocks.NETWORK_HUB);
    public static final RegistrySupplier<class_1792> PROJECTOR = register(Blocks.PROJECTOR);
    public static final RegistrySupplier<class_1792> REDSTONE_INTERFACE = register(Blocks.REDSTONE_INTERFACE);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1792> WRENCH = register("wrench", WrenchItem::new);
    public static final RegistrySupplier<class_1792> MANUAL = register("manual", ManualItem::new);

    public static final RegistrySupplier<class_1792> ROBOT = register("robot", RobotItem::new);
    public static final RegistrySupplier<NetworkCableItem> NETWORK_CABLE = register("network_cable", NetworkCableItem::new);

    public static final RegistrySupplier<CpuItem> CPU_RISCV = register("cpu_riscv", () ->
        new CpuItem(ArchitectureType.RISCV));
    public static final RegistrySupplier<CpuItem> CPU_Z80 = register("cpu_z80", () ->
        new CpuItem(ArchitectureType.Z80));

    public static final RegistrySupplier<MemoryItem> MEMORY_SMALL = register("memory_small", () ->
        new MemoryItem(2 * Constants.MEGABYTE));
    public static final RegistrySupplier<MemoryItem> MEMORY_MEDIUM = register("memory_medium", () ->
        new MemoryItem(4 * Constants.MEGABYTE));
    public static final RegistrySupplier<MemoryItem> MEMORY_LARGE = register("memory_large", () ->
        new MemoryItem(8 * Constants.MEGABYTE));

    public static final RegistrySupplier<HardDriveItem> HARD_DRIVE_SMALL = register("hard_drive_small", () ->
        new HardDriveItem(2 * Constants.MEGABYTE, class_1767.field_7967));
    public static final RegistrySupplier<HardDriveItem> HARD_DRIVE_MEDIUM = register("hard_drive_medium", () ->
        new HardDriveItem(4 * Constants.MEGABYTE, class_1767.field_7942));
    public static final RegistrySupplier<HardDriveItem> HARD_DRIVE_LARGE = register("hard_drive_large", () ->
        new HardDriveItem(8 * Constants.MEGABYTE, class_1767.field_7955));

    public static final RegistrySupplier<FlashMemoryItem> FLASH_MEMORY = register("flash_memory", () ->
        new FlashMemoryItem(Constants.FLASH_MEMORY_SIZE));

    public static final RegistrySupplier<FloppyItem> FLOPPY = register("floppy", () ->
        new FloppyItem(FloppyItem.MAX_CAPACITY));

    public static final RegistrySupplier<class_1792> REDSTONE_INTERFACE_CARD = register("redstone_interface_card");
    public static final RegistrySupplier<class_1792> NETWORK_INTERFACE_CARD = register("network_interface_card", NetworkInterfaceCardItem::new);
    public static final RegistrySupplier<class_1792> NETWORK_TUNNEL_CARD = register("network_tunnel_card", NetworkTunnelItem::new);
    public static final RegistrySupplier<class_1792> FILE_IMPORT_EXPORT_CARD = register("file_import_export_card");
    public static final RegistrySupplier<class_1792> SOUND_CARD = register("sound_card");

    public static final RegistrySupplier<class_1792> INVENTORY_OPERATIONS_MODULE = register("inventory_operations_module");
    public static final RegistrySupplier<class_1792> BLOCK_OPERATIONS_MODULE = register("block_operations_module", BlockOperationsModule::new);
    public static final RegistrySupplier<class_1792> NETWORK_TUNNEL_MODULE = register("network_tunnel_module", NetworkTunnelItem::new);

    public static final RegistrySupplier<class_1792> TRANSISTOR = register("transistor", ModItem::new);
    public static final RegistrySupplier<class_1792> CIRCUIT_BOARD = register("circuit_board", ModItem::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    // --------------------------------------------------------------------- //

    private static RegistrySupplier<class_1792> register(final String name) {
        return register(name, ModItem::new);
    }

    private static <T extends class_1792> RegistrySupplier<T> register(final String name, final Supplier<T> factory) {
        return ITEMS.register(name, factory);
    }

    private static <T extends class_2248> RegistrySupplier<class_1792> register(final RegistrySupplier<T> block) {
        return register(block, ModBlockItem::new);
    }

    private static <TBlock extends class_2248, TItem extends class_1792> RegistrySupplier<TItem> register(final RegistrySupplier<TBlock> block, final Function<TBlock, TItem> factory) {
        return register(block.getId().method_12832(), () -> factory.apply(block.get()));
    }
}
