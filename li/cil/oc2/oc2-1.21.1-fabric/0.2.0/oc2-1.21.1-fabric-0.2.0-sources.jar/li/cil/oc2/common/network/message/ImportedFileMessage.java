/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.bus.device.rpc.item.FileImportExportCardItemDevice;
import net.minecraft.class_3222;
import net.minecraft.class_9129;


public final class ImportedFileMessage extends AbstractMessage {
    private static final int MAX_NAME_LENGTH = 256;

    // --------------------------------------------------------------------- //

    private int id;
    private String name;
    private byte[] data;

    // --------------------------------------------------------------------- //

    public ImportedFileMessage(final int id, final String name, final byte[] data) {
        this.id = id;
        this.name = name;
        this.data = data;
    }

    public ImportedFileMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        id = buffer.method_10816();
        name = buffer.method_10800(MAX_NAME_LENGTH);
        data = buffer.method_10803(FileImportExportCardItemDevice.MAX_TRANSFERRED_FILE_SIZE);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10804(id);
        buffer.method_10788(name, MAX_NAME_LENGTH);
        buffer.method_10813(data);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        if (context.getPlayer() instanceof final class_3222 sender) {
            FileImportExportCardItemDevice.setImportedFile(sender, id, name, data);
        }
    }
}
