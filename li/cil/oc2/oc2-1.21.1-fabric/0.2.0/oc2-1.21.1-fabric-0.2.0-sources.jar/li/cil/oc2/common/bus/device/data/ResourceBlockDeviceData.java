/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.sedna.api.device.BlockDevice;
import li.cil.sedna.device.block.ByteBufferBlockDevice;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import java.io.IOException;
import java.io.InputStream;

public final class ResourceBlockDeviceData implements BlockDeviceData, AutoCloseable {
    private final class_2960 location;
    private final String name;
    private final BlockDevice blockDevice;

    public ResourceBlockDeviceData(final class_3300 resourceManager, final class_2960 location, final String name) throws IOException {
        this.location = location;
        this.name = name;
        final InputStream stream = resourceManager.getResourceOrThrow(location).method_14482();
        this.blockDevice = ByteBufferBlockDevice.createFromStream(stream, true);
    }

    public class_2960 getLocation() {
        return location;
    }

    @Override
    public void close() throws IOException {
        blockDevice.close();
    }

    @Override
    public BlockDevice getBlockDevice() {
        return blockDevice;
    }

    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_43470(name);
    }
}
