/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item.crafting;

import li.cil.oc2.common.integration.Wrenches;
import li.cil.oc2.common.util.StorageItemUtils;
import li.cil.oc2.common.util.StorageItemUtils.State;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;

public final class ResetRecipe extends class_1852 {
    public ResetRecipe(final class_7710 category) {
        super(category);
    }

    // --------------------------------------------------------------------- //

    @Override
    public boolean matches(final class_9694 input, final class_1937 level) {
        int damagedCount = 0, wrenchCount = 0;

        for (int slot = 0; slot < input.method_59983(); slot++) {
            final class_1799 stack = input.method_59984(slot);
            if (stack.method_7960()) {
                continue;
            }

            if (StorageItemUtils.needsRepair(stack)) {
                damagedCount++;
            } else if (Wrenches.isWrench(stack)) {
                wrenchCount++;
            } else {
                return false;
            }
        }

        return damagedCount == 1 && wrenchCount == 1;
    }

    @Override
    public class_1799 assemble(final class_9694 input, final class_7225.class_7874 registries) {
        final class_1799 stack = findDamagedDataItem(input);
        if (stack.method_7960()) {
            return class_1799.field_8037;
        }

        final class_1799 result = stack.method_7972();
        result.method_7939(1);

        if (StorageItemUtils.getState(stack) == State.INCONSISTENT) {
            StorageItemUtils.setState(result, State.ACKNOWLEDGED);
        } else {
            StorageItemUtils.stripBlobData(result);
        }

        return result;
    }

    @Override
    public class_2371<class_1799> getRemainingItems(final class_9694 input) {
        final class_2371<class_1799> result = class_2371.method_10213(input.method_59983(), class_1799.field_8037);

        for (int slot = 0; slot < input.method_59983(); slot++) {
            final class_1799 stack = input.method_59984(slot);
            if (StorageItemUtils.getState(stack) == State.CORRUPTED) {
                StorageItemUtils.clearBlobData(stack);
            } else if (stack.method_7909().method_7857()) {
                result.set(slot, new class_1799(stack.method_7909().method_7858()));
            } else if (Wrenches.isWrench(stack)) {
                final class_1799 copy = stack.method_7972();
                copy.method_7939(1);
                result.set(slot, copy);
            }
        }

        return result;
    }

    @Override
    public boolean method_8113(final int width, final int height) {
        return width * height >= 2;
    }

    @Override
    public class_1865<?> method_8119() {
        return RecipeSerializers.RESET.get();
    }

    // --------------------------------------------------------------------- //

    private static class_1799 findDamagedDataItem(final class_9694 input) {
        for (int slot = 0; slot < input.method_59983(); slot++) {
            final class_1799 stack = input.method_59984(slot);
            if (!stack.method_7960() && StorageItemUtils.needsRepair(stack)) {
                return stack;
            }
        }

        return class_1799.field_8037;
    }
}
