/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network;

import dev.architectury.networking.NetworkManager;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import li.cil.oc2.api.API;
import li.cil.oc2.common.network.message.*;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_3215;
import net.minecraft.class_3222;
import net.minecraft.class_4076;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

public final class Network {
    private static final Map<Class<?>, class_8710.class_9154<? extends class_8710>> MESSAGE_TYPES = new HashMap<>();

    // --------------------------------------------------------------------- //

    public static void initialize() {
        registerMessage(ComputerTerminalOutputMessage.class, ComputerTerminalOutputMessage::new, NetworkManager.serverToClient());
        registerMessage(ComputerTerminalInputMessage.class, ComputerTerminalInputMessage::new, NetworkManager.clientToServer());
        registerMessage(ComputerRunStateMessage.class, ComputerRunStateMessage::new, NetworkManager.serverToClient());
        registerMessage(ComputerBusStateMessage.class, ComputerBusStateMessage::new, NetworkManager.serverToClient());
        registerMessage(ComputerBootErrorMessage.class, ComputerBootErrorMessage::new, NetworkManager.serverToClient());
        registerMessage(ComputerPowerMessage.class, ComputerPowerMessage::new, NetworkManager.clientToServer());
        registerMessage(OpenComputerInventoryMessage.class, OpenComputerInventoryMessage::new, NetworkManager.clientToServer());
        registerMessage(OpenComputerTerminalMessage.class, OpenComputerTerminalMessage::new, NetworkManager.clientToServer());

        registerMessage(NetworkConnectorConnectionsMessage.class, NetworkConnectorConnectionsMessage::new, NetworkManager.serverToClient());

        registerMessage(RobotTerminalOutputMessage.class, RobotTerminalOutputMessage::new, NetworkManager.serverToClient());
        registerMessage(RobotTerminalInputMessage.class, RobotTerminalInputMessage::new, NetworkManager.clientToServer());
        registerMessage(RobotRunStateMessage.class, RobotRunStateMessage::new, NetworkManager.serverToClient());
        registerMessage(RobotBusStateMessage.class, RobotBusStateMessage::new, NetworkManager.serverToClient());
        registerMessage(RobotBootErrorMessage.class, RobotBootErrorMessage::new, NetworkManager.serverToClient());
        registerMessage(RobotPowerMessage.class, RobotPowerMessage::new, NetworkManager.clientToServer());
        registerMessage(RobotInitializationRequestMessage.class, RobotInitializationRequestMessage::new, NetworkManager.clientToServer());
        registerMessage(RobotInitializationMessage.class, RobotInitializationMessage::new, NetworkManager.serverToClient());
        registerMessage(OpenRobotInventoryMessage.class, OpenRobotInventoryMessage::new, NetworkManager.clientToServer());
        registerMessage(OpenRobotTerminalMessage.class, OpenRobotTerminalMessage::new, NetworkManager.clientToServer());

        registerMessage(DiskDriveFloppyMessage.class, DiskDriveFloppyMessage::new, NetworkManager.serverToClient());

        registerMessage(BusInterfaceNameMessage.ToClient.class, BusInterfaceNameMessage.ToClient::new, NetworkManager.serverToClient());
        registerMessage(BusInterfaceNameMessage.ToServer.class, BusInterfaceNameMessage.ToServer::new, NetworkManager.clientToServer());

        registerMessage(ExportedFileMessage.class, ExportedFileMessage::new, NetworkManager.serverToClient());
        registerMessage(RequestImportedFileMessage.class, RequestImportedFileMessage::new, NetworkManager.serverToClient());
        registerMessage(ImportedFileMessage.class, ImportedFileMessage::new, NetworkManager.clientToServer());
        registerMessage(ServerCanceledImportFileMessage.class, ServerCanceledImportFileMessage::new, NetworkManager.serverToClient());
        registerMessage(ClientCanceledImportFileMessage.class, ClientCanceledImportFileMessage::new, NetworkManager.clientToServer());

        registerMessage(BusCableFacadeMessage.class, BusCableFacadeMessage::new, NetworkManager.serverToClient());

        registerMessage(NetworkInterfaceCardConfigurationMessage.class, NetworkInterfaceCardConfigurationMessage::new, NetworkManager.clientToServer());
        registerMessage(NetworkTunnelLinkMessage.class, NetworkTunnelLinkMessage::new, NetworkManager.clientToServer());

        registerMessage(ProjectorRequestFramebufferMessage.class, ProjectorRequestFramebufferMessage::new, NetworkManager.clientToServer());
        registerMessage(ProjectorFramebufferMessage.class, ProjectorFramebufferMessage::new, NetworkManager.serverToClient());
        registerMessage(ProjectorStateMessage.class, ProjectorStateMessage::new, NetworkManager.serverToClient());

        registerMessage(KeyboardInputMessage.class, KeyboardInputMessage::new, NetworkManager.clientToServer());

        registerMessage(MultipartMessage.class, MultipartMessage::new, NetworkManager.clientToServer());

        MultipartMessage.registerMessage(ImportedFileMessage.class, ImportedFileMessage::new);
    }

    @SuppressWarnings("unchecked")
    public static <T extends class_8710> class_8710.class_9154<T> getMessageType(final Class<?> type) {
        final class_8710.class_9154<? extends class_8710> messageType = MESSAGE_TYPES.get(type);
        if (messageType == null) {
            throw new IllegalStateException("Message type [" + type + "] was not registered in Network.initialize().");
        }
        return (class_8710.class_9154<T>) messageType;
    }

    // --------------------------------------------------------------------- //

    public static void sendToServer(final AbstractMessage message) {
        NetworkManager.sendToServer(message);
    }

    public static void sendToClient(final AbstractMessage message, final class_3222 player) {
        NetworkManager.sendToPlayer(player, message);
    }

    public static void sendToClientsTrackingChunk(final AbstractMessage message, final class_2818 chunk) {
        if (chunk.method_12200().method_8398() instanceof final class_3215 chunkCache) {
            NetworkManager.sendToPlayers(chunkCache.field_17254.method_17210(chunk.method_12004(), false), message);
        }
    }

    public static void sendToClientsTrackingBlockEntity(final AbstractMessage message, final class_2586 blockEntity) {
        final class_1937 level = blockEntity.method_10997();
        if (!checkServerThread(level)) {
            return;
        }

        final class_2338 blockPos = blockEntity.method_11016();
        final int chunkX = class_4076.method_18675(blockPos.method_10263());
        final int chunkZ = class_4076.method_18675(blockPos.method_10260());
        if (level.method_8393(chunkX, chunkZ)) {
            sendToClientsTrackingChunk(message, level.method_8497(chunkX, chunkZ));
        }
    }

    public static void sendToClientsTrackingEntity(final AbstractMessage message, final class_1297 entity) {
        final class_1937 level = entity.method_37908();
        if (!checkServerThread(level)) {
            return;
        }

        if (level.method_8398() instanceof final class_3215 chunkCache) {
            NetworkManager.sendToPlayers(chunkCache.field_17254.method_17210(entity.method_31476(), false), message);
        }
    }

    // --------------------------------------------------------------------- //

    private static String messageId(final Class<?> type) {
        final String name = type.getEnclosingClass() != null
            ? type.getEnclosingClass().getSimpleName().replaceAll("Message$", "") + "_" + type.getSimpleName()
            : type.getSimpleName().replaceAll("Message$", "");
        return name.replaceAll("(?<=[a-z0-9])(?=[A-Z])", "_").toLowerCase(Locale.ROOT);
    }

    private static <T extends AbstractMessage> void registerMessage(final Class<T> type,
                                                                    final Function<class_9129, T> decoder,
                                                                    final NetworkManager.Side side) {
        final class_2960 id = class_2960.method_60655(API.MOD_ID, messageId(type));
        final class_8710.class_9154<T> payloadType = new class_8710.class_9154<>(id);
        final class_9139<class_9129, T> codec =
            class_8710.method_56484(AbstractMessage::toBytes, decoder::apply);

        MESSAGE_TYPES.put(type, payloadType);

        if (side == NetworkManager.serverToClient() && Platform.getEnvironment() != Env.CLIENT) {
            NetworkManager.registerS2CPayloadType(payloadType, codec);
        } else {
            NetworkManager.registerReceiver(side, payloadType, codec,
                (message, context) -> context.queue(() -> message.handle(context)));
        }
    }

    private static boolean checkServerThread(@Nullable final class_1937 level) {
        if (level == null) {
            return false;
        }

        if (level.method_8503() == null) {
            return false;
        }

        if (!level.method_8503().method_18854()) {
            throw new IllegalStateException(
                "Attempting to send location aware network message to Entity from non-server " +
                    "thread [" + Thread.currentThread() + "]. This is not supported, " +
                    "because we need world state to figure out chunk/entity tracking. " +
                    "Queue this message send on the server thread, instead.");
        }

        return true;
    }
}
