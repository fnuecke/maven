/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_9129;

public final class BusCableFacadeMessage extends AbstractMessage {
    private class_2338 pos;
    private class_1799 stack;

    // --------------------------------------------------------------------- //

    public BusCableFacadeMessage(final class_2338 pos, final class_1799 stack) {
        this.pos = pos;
        this.stack = stack;
    }

    public BusCableFacadeMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        stack = class_1799.field_49268.decode(buffer);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        class_1799.field_49268.encode(buffer, stack);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        MessageUtils.withClientBlockEntityAt(pos, BusCableBlockEntity.class,
            busCable -> busCable.setFacade(stack));
    }
}
