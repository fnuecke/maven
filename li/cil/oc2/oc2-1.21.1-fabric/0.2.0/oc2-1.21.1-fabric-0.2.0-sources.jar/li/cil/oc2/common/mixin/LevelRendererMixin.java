/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.oc2.client.renderer.ProjectorDepthRenderer;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_4604;
import net.minecraft.class_4722;
import net.minecraft.class_5365;
import net.minecraft.class_757;
import net.minecraft.class_758;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import net.minecraft.client.renderer.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import javax.annotation.Nullable;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Shadow
    @Final
    private class_4599 renderBuffers;
    @Shadow
    @Final
    private class_310 minecraft;
    @Shadow
    private class_4604 cullingFrustum;

    @Shadow
    @Nullable
    private class_276 itemEntityTarget;
    @Nullable
    private class_276 itemEntityTargetBak;

    @Shadow
    @Nullable
    private class_276 weatherTarget;
    @Nullable
    private class_276 weatherTargetBak;

    @Shadow
    protected abstract void renderSnowAndRain(final class_765 lightTexture, final float partialTicks, final double cameraX, final double cameraY, final double cameraZ);

    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void prepareDepthRendering(final CallbackInfo ci) {
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()) {
            itemEntityTargetBak = itemEntityTarget;
            itemEntityTarget = null;
            weatherTargetBak = weatherTarget;
            weatherTarget = null;
        }
    }

    @Inject(method = "renderLevel", at = @At("TAIL"))
    private void cleanupDepthRendering(final CallbackInfo ci) {
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()) {
            cleanupDepthRendering();
        }
    }

    private void cleanupDepthRendering() {
        weatherTarget = weatherTargetBak;
        itemEntityTarget = itemEntityTargetBak;
    }

    @Inject(method = "renderLevel", at = @At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/lang/String;)V", args = {"ldc=destroyProgress"}), cancellable = true)
    private void captureDepthAndEarlyExit(
        final class_9779 deltaTracker,
        final boolean shouldRenderBlockOutline,
        final class_4184 camera,
        final class_757 gameRenderer,
        final class_765 lightTexture,
        final Matrix4f frustumMatrix,
        final Matrix4f projectionMatrix,
        final CallbackInfo ci
    ) {
        final float partialTicks = deltaTracker.method_60637(false);
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()) {
            // If we're rendering depth, we can skip most of the rest here: we don't need destruction progress,
            // transparency, hit result, debug stuff, clouds.
            cleanupDepthRendering();

            // We do want particles and weather (rain) though, because that's a neat effect.
            final class_4597.class_4598 bufferSource = renderBuffers.method_23000();
            minecraft.field_1713.method_3049(lightTexture, camera, partialTicks);
            bufferSource.method_22993();

            final class_243 cameraPosition = camera.method_19326();
            renderSnowAndRain(lightTexture, partialTicks, cameraPosition.method_10216(), cameraPosition.method_10214(), cameraPosition.method_10215());

            // Clean up anything regular return would also clean up.
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
            RenderSystem.getModelViewStack().popMatrix();
            RenderSystem.applyModelViewMatrix();
            class_758.method_23792();
            ci.cancel();
        } else if (ProjectorDepthRenderer.willRenderProjectorDepth()) {
            // Flush buffers that may write to depth buffer, e.g. when rendering item stacks.
            final class_4597.class_4598 bufferSource = renderBuffers.method_23000();
            bufferSource.method_22994(class_4722.method_24076());
            bufferSource.method_22994(class_4722.method_24059());
            bufferSource.method_22994(class_4722.method_24067());

            // Otherwise, we grab the depth buffer of the main render target here, before
            // fabulous shading breaks it.
            ProjectorDepthRenderer.captureMainCameraDepth();
        }
    }

    /**
     * Make sure weather effects are rendered with depth, so they cause "shadows" in our projection.
     */
    @Inject(method = "renderSnowAndRain", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;depthMask(Z)V", shift = At.Shift.AFTER, remap = false))
    private void enableDepthForWeatherInDepthBuffer(final CallbackInfo ci) {
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()
            && minecraft.field_1690.method_42534().method_41753().method_7362() >= class_5365.field_25429.method_7362()) {
            RenderSystem.depthMask(true);
        }
    }

    /**
     * Don't render outlines while rendering projector depth.
     */
    @Inject(method = "shouldShowEntityOutlines", at = @At("HEAD"), cancellable = true)
    private void skipOutlines(final CallbackInfoReturnable<Boolean> cir) {
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()) {
            cir.setReturnValue(false);
        }
    }

    /**
     * Skip rendering the sky when rendering projector depth.
     */
    @Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
    private void skipSky(final CallbackInfo ci) {
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()) {
            ci.cancel();
        }
    }

    @Inject(method = {"entityTarget", "getItemEntityTarget", "getWeatherTarget"}, at = @At("HEAD"), cancellable = true)
    private void redirectToMainTarget(final CallbackInfoReturnable<class_276> cir) {
        if (ProjectorDepthRenderer.isIsRenderingProjectorDepth()) {
            cir.setReturnValue(class_310.method_1551().method_1522());
        }
    }
}
