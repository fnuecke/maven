/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.sedna.api.device.BlockDevice;
import li.cil.sedna.device.block.ByteBufferBlockDevice;
import net.minecraft.class_1767;
import net.minecraft.class_2561;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.function.Supplier;

public final class FirmwareBlockDeviceData implements BlockDeviceData {
    private static final Logger LOGGER = LogManager.getLogger();

    // --------------------------------------------------------------------- //

    private final BlockDevice blockDevice;
    private final class_2561 displayName;
    private final class_1767 color;

    // --------------------------------------------------------------------- //

    public FirmwareBlockDeviceData(final Supplier<InputStream> source, final String name, final class_1767 color) {
        BlockDevice device;
        try (InputStream stream = source.get()) {
            device = ByteBufferBlockDevice.createFromStream(stream, true);
        } catch (final IOException e) {
            LOGGER.error(e);
            device = ByteBufferBlockDevice.create(0, true);
        }

        this.blockDevice = device;
        this.displayName = class_2561.method_43470(name);
        this.color = color;
    }

    // --------------------------------------------------------------------- //

    @Override
    public BlockDevice getBlockDevice() {
        return blockDevice;
    }

    @Override
    public class_2561 getDisplayName() {
        return displayName;
    }

    @Override
    public class_1767 getColor() {
        return color;
    }
}
