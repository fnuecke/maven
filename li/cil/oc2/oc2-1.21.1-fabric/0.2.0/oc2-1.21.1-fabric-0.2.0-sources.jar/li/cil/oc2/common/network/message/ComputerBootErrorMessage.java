/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import javax.annotation.Nullable;
import java.util.Optional;

public final class ComputerBootErrorMessage extends AbstractMessage {
    private class_2338 pos;
    @Nullable
    private class_2561 value;

    // --------------------------------------------------------------------- //

    public ComputerBootErrorMessage(final ComputerBlockEntity computer, @Nullable final class_2561 value) {
        this.pos = computer.method_11016();
        this.value = value;
    }

    public ComputerBootErrorMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        value = class_8824.field_48985.decode(buffer).orElse(null);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        class_8824.field_48985.encode(buffer, Optional.ofNullable(value));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        MessageUtils.withClientBlockEntityAt(pos, ComputerBlockEntity.class,
            computer -> computer.getVirtualMachineClientState().setBootErrorClient(value));
    }
}
