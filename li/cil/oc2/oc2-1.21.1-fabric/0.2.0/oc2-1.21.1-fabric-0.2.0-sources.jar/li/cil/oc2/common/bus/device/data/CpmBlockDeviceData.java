/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.oc2.common.vm.CpmSystemDisk;
import li.cil.sedna.api.device.BlockDevice;
import li.cil.sedna.device.block.ByteBufferBlockDevice;
import net.minecraft.class_1767;
import net.minecraft.class_2561;
import java.nio.ByteBuffer;

public final class CpmBlockDeviceData implements BlockDeviceData {
    @Override
    public BlockDevice getBlockDevice() {
        return ByteBufferBlockDevice.wrap(ByteBuffer.wrap(CpmSystemDisk.getImage()), true);
    }

    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_43470("CP/M 2.2");
    }

    @Override
    public class_1767 getColor() {
        return class_1767.field_7946;
    }
}
