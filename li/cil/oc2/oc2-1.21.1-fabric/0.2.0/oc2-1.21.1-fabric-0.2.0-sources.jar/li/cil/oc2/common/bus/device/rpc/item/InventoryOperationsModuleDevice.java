/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.rpc.item;

import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.Parameter;
import li.cil.oc2.api.capabilities.Robot;
import li.cil.oc2.api.inventory.ItemHandler;
import li.cil.oc2.api.util.RobotOperationSide;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.container.ItemHandlerUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class InventoryOperationsModuleDevice extends AbstractItemRPCDevice {
    private final class_1297 entity;
    private final Robot robot;

    // --------------------------------------------------------------------- //

    public InventoryOperationsModuleDevice(final class_1799 identity, final class_1297 entity, final Robot robot) {
        super(identity, "inventory_operations");
        this.entity = entity;
        this.robot = robot;
    }

    // --------------------------------------------------------------------- //

    @Callback
    public void move(@Parameter("fromSlot") final int fromSlot,
                     @Parameter("intoSlot") final int intoSlot,
                     @Parameter("count") final int count) {
        if (count <= 0) {
            return;
        }

        final ItemHandler inventory = robot.getInventory();

        // Do simulation run, validating slot indices and getting actual amount possible to move.
        class_1799 extracted = inventory.extractItem(fromSlot, count, true);
        class_1799 remaining = inventory.insertItem(intoSlot, extracted, true);

        // Do actual run, move as many as we know we can, based on simulation.
        extracted = inventory.extractItem(fromSlot, extracted.method_7947() - remaining.method_7947(), false);
        remaining = inventory.insertItem(intoSlot, extracted, false);

        // But don't trust simulation; if something is remaining after actual run, try to put it back.
        remaining = inventory.insertItem(fromSlot, remaining, false);

        // And if putting it back fails, just drop it. Avoid destroying items.
        if (!remaining.method_7960()) {
            entity.method_5775(remaining);
        }
    }

    @Callback
    public int drop(@Parameter("count") final int count) {
        return drop(count, null);
    }

    @Callback
    public int drop(@Parameter("count") final int count,
                    @Parameter("side") @Nullable final RobotOperationSide side) {
        if (count <= 0) {
            return 0;
        }

        final int selectedSlot = robot.getSelectedSlot(); // Get once to avoid change due to threading.

        class_1799 stack = robot.getInventory().extractItem(selectedSlot, count, false);
        if (stack.method_7960()) {
            return 0;
        }

        final int originalStackSize = stack.method_7947();
        final class_2350 direction = RobotOperationSide.toGlobal(entity, side);
        final List<ItemHandler> itemHandlers = getItemStackHandlersInDirection(direction).toList();
        for (final ItemHandler handler : itemHandlers) {
            stack = ItemHandlerUtils.insertItemStack(handler, stack, false);

            if (stack.method_7960()) {
                break;
            }
        }

        // When we have items left, but there was an inventory, do *not* drop into the world.
        // Instead, try to put items back where they came from. Only failing that drop them
        // into the world.
        int dropped = originalStackSize - stack.method_7947();
        if (!stack.method_7960() && !itemHandlers.isEmpty()) {
            stack = robot.getInventory().insertItem(selectedSlot, stack, false);
        }

        if (!stack.method_7960()) {
            dropped += stack.method_7947();
            entity.method_5775(stack);
        }

        return dropped;
    }

    @Callback
    public int dropInto(@Parameter("intoSlot") final int intoSlot,
                        @Parameter("count") final int count) {
        return dropInto(intoSlot, count, null);
    }

    @Callback
    public int dropInto(@Parameter("intoSlot") final int intoSlot,
                        @Parameter("count") final int count,
                        @Parameter("side") @Nullable final RobotOperationSide side) {
        if (count <= 0) {
            return 0;
        }

        final int selectedSlot = robot.getSelectedSlot(); // Get once to avoid change due to threading.

        class_1799 stack = robot.getInventory().extractItem(selectedSlot, count, false);
        if (stack.method_7960()) {
            return 0;
        }

        final int originalStackSize = stack.method_7947();
        final class_2350 direction = RobotOperationSide.toGlobal(entity, side);
        final Optional<ItemHandler> optional = getItemStackHandlersInDirection(direction).findFirst();
        if (optional.isPresent()) {
            stack = optional.get().insertItem(intoSlot, stack, false);
        }

        // Subtle difference to drop(), we always try to put the remainder back. This method
        // attempts to never drop anything into the world.
        int dropped = originalStackSize - stack.method_7947();
        if (!stack.method_7960()) {
            stack = robot.getInventory().insertItem(selectedSlot, stack, false);
        }

        if (!stack.method_7960()) {
            dropped += stack.method_7947();
            entity.method_5775(stack);
        }

        return dropped;
    }

    @Callback
    public int take(@Parameter("count") final int count) {
        return take(count, null);
    }

    @Callback
    public int take(@Parameter("count") final int count,
                    @Parameter("side") @Nullable final RobotOperationSide side) {
        if (count <= 0) {
            return 0;
        }

        final class_2350 direction = RobotOperationSide.toGlobal(entity, side);
        final List<ItemHandler> handlers = getItemStackHandlersInDirection(direction).collect(Collectors.toList());
        if (handlers.isEmpty()) {
            return takeFromWorld(count);
        } else {
            return takeFromInventories(count, handlers);
        }
    }

    @Callback
    public int takeFrom(@Parameter("fromSlot") final int fromSlot,
                        @Parameter("count") final int count) {
        return takeFrom(fromSlot, count, null);
    }

    @Callback
    public int takeFrom(@Parameter("fromSlot") final int fromSlot,
                        @Parameter("count") final int count,
                        @Parameter("side") @Nullable final RobotOperationSide side) {
        if (count <= 0) {
            return 0;
        }

        final class_2350 direction = RobotOperationSide.toGlobal(entity, side);
        return getItemStackHandlersInDirection(direction).findFirst().map(handler ->
            takeFromInventory(count, handler, fromSlot)).orElse(0);
    }

    // --------------------------------------------------------------------- //

    private class_1799 insertStartingAt(final ItemHandler handler, class_1799 stack, final int startSlot, final boolean simulate) {
        for (int i = 0; i < handler.getSlots(); i++) {
            final int slot = (startSlot + i) % handler.getSlots();
            stack = handler.insertItem(slot, stack, simulate);
            if (stack.method_7960()) {
                return class_1799.field_8037;
            }
        }

        return stack;
    }

    private Stream<ItemHandler> getItemStackHandlersInDirection(final class_2350 direction) {
        return getItemStackHandlersAt(class_243.method_24953(entity.method_24515().method_10093(direction)), direction.method_10153());
    }

    private Stream<ItemHandler> getItemStackHandlersAt(final class_243 position, final class_2350 side) {
        return Stream.concat(getEntityItemHandlersAt(position, side), getBlockItemHandlersAt(position, side));
    }

    private Stream<ItemHandler> getEntityItemHandlersAt(final class_243 position, final class_2350 side) {
        final class_238 bounds = class_238.method_29968(position.method_1023(0.5, 0.5, 0.5));
        return entity.method_37908().method_8335(entity, bounds).stream()
            .map(e -> Capabilities.get(e, Capabilities.ITEM_HANDLER, side))
            .filter(Objects::nonNull);
    }

    private Stream<ItemHandler> getBlockItemHandlersAt(final class_243 position, final class_2350 side) {
        final class_2338 pos = class_2338.method_49638(position);
        final class_2586 blockEntity = entity.method_37908().method_8321(pos);
        if (blockEntity == null) {
            return Stream.empty();
        }

        final ItemHandler itemHandler = Capabilities.get(blockEntity, Capabilities.ITEM_HANDLER, side);
        return itemHandler != null ? Stream.of(itemHandler) : Stream.empty();
    }

    private List<class_1542> getItemsInRange() {
        return entity.method_37908().method_18467(class_1542.class, entity.method_5829().method_1014(1));
    }

    private int takeFromWorld(final int count) {
        final int selectedSlot = robot.getSelectedSlot(); // Get once to avoid change due to threading.
        final ItemHandler inventory = robot.getInventory();

        int remaining = count;
        for (final class_1542 itemEntity : getItemsInRange()) {
            // NB: We make a copy of the original so that the setItem at the end sends an update to the client.
            final class_1799 original = itemEntity.method_6983().method_7972();

            final class_1799 stackToInsert = original.method_7972();
            if (stackToInsert.method_7947() > remaining) {
                stackToInsert.method_7939(remaining);
            }

            final class_1799 overflow = insertStartingAt(inventory, stackToInsert, selectedSlot, false);
            final int taken = stackToInsert.method_7947() - overflow.method_7947();

            remaining -= taken;
            original.method_7934(taken);
            itemEntity.method_6979(original);
        }

        return count - remaining;
    }

    private int takeFromInventories(final int count, final List<ItemHandler> handlers) {
        final int selectedSlot = robot.getSelectedSlot(); // Get once to avoid change due to threading.
        final ItemHandler inventory = robot.getInventory();

        int remaining = count;
        for (final ItemHandler handler : handlers) {
            for (int fromSlot = 0; fromSlot < handler.getSlots(); fromSlot++) {
                // Do simulation run, getting actual amount possible to take.
                class_1799 extracted = handler.extractItem(fromSlot, remaining, true);
                class_1799 overflow = insertStartingAt(inventory, extracted, selectedSlot, true);

                final int delta = extracted.method_7947() - overflow.method_7947();
                if (delta == 0) {
                    continue;
                }

                remaining -= delta;

                // Do actual run, take as many as we know we can, based on simulation.
                extracted = handler.extractItem(fromSlot, delta, false);
                overflow = insertStartingAt(inventory, extracted, selectedSlot, false);

                // But don't trust simulation; if something is remaining after actual run, try to put it back.
                remaining += overflow.method_7947();
                overflow = handler.insertItem(fromSlot, overflow, false);

                // And if putting it back fails, just drop it. Avoid destroying items.
                if (!overflow.method_7960()) {
                    remaining -= overflow.method_7947();
                    entity.method_5775(overflow);
                }
            }

            if (remaining <= 0) {
                break;
            }
        }

        return count - remaining;
    }

    private int takeFromInventory(final int count, final ItemHandler handler, final int slot) {
        final ItemHandler inventory = robot.getInventory();
        final int selectedSlot = robot.getSelectedSlot(); // Get once to avoid change due to threading.

        // Do simulation run, getting actual amount possible to take.
        class_1799 extracted = handler.extractItem(slot, count, true);
        class_1799 overflow = insertStartingAt(inventory, extracted, selectedSlot, true);

        int taken = extracted.method_7947() - overflow.method_7947();

        // Do actual run, take as many as we know we can, based on simulation.
        extracted = handler.extractItem(slot, taken, false);
        overflow = insertStartingAt(inventory, extracted, selectedSlot, false);

        // But don't trust simulation; if something is remaining after actual run, try to put it back.
        taken -= overflow.method_7947();
        overflow = handler.insertItem(slot, overflow, false);

        // And if putting it back fails, just drop it. Avoid destroying items.
        if (!overflow.method_7960()) {
            // NB: not counting this towards taken count since it did not end up in our inventory.
            entity.method_5775(overflow);
        }

        return taken;
    }
}
