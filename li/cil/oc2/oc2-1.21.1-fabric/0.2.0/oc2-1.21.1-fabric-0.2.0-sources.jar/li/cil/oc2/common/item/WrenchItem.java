/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.common.tags.BlockTags;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_636;
import java.util.Objects;

public final class WrenchItem extends ModItem {
    public class_1269 tryRotate(final class_1838 context) {
        final class_1937 level = context.method_8045();
        final class_2338 pos = context.method_8037();
        final class_2350 face = context.method_8038();
        if (face == class_2350.field_11036 || face == class_2350.field_11033) {
            final class_2680 blockState = level.method_8320(pos);
            final class_2680 rotatedState = blockState.method_26186(face == class_2350.field_11036 ? class_2470.field_11463 : class_2470.field_11465);
            if (!Objects.equals(blockState, rotatedState)) {
                level.method_8501(pos, rotatedState);
                return class_1269.method_29236(level.method_8608());
            }
        }

        return class_1269.field_5811;
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1657 player = context.method_8036();
        if (player == null) {
            return class_1269.field_5811;
        }

        if (!player.method_5715()) {
            return super.method_7884(context);
        }

        final class_1937 level = context.method_8045();
        final class_2338 pos = context.method_8037();
        final class_2680 state = level.method_8320(pos);
        if (!state.method_26164(BlockTags.WRENCH_BREAKABLE)) {
            return super.method_7884(context);
        }

        if (level.method_8608()) {
            destroyBlockOnClient(pos);
        } else if (player instanceof final class_3222 serverPlayer) {
            serverPlayer.field_13974.method_14266(pos);
        }

        return class_1269.method_29236(level.method_8608());
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    private static void destroyBlockOnClient(final class_2338 pos) {
        final class_636 gameMode = class_310.method_1551().field_1761;
        if (gameMode != null) {
            gameMode.method_2899(pos);
        }
    }
}
