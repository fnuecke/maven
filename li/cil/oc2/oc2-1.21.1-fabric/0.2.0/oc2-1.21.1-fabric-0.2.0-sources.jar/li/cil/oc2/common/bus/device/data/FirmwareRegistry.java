/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.data;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.Registrar;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.oc2.api.util.Registries;
import li.cil.oc2.common.util.RegistryUtils;
import li.cil.sedna.buildroot.Buildroot;
import li.cil.sedna.cpm.Cpm;
import net.minecraft.class_1767;
import net.minecraft.class_2960;
import javax.annotation.Nullable;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public final class FirmwareRegistry {
    private static final Registrar<BlockDeviceData> REGISTRY = RegistryUtils.builder(Registries.FIRMWARE).build();
    private static final DeferredRegister<BlockDeviceData> INITIALIZER = RegistryUtils.getInitializerFor(Registries.FIRMWARE);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<BlockDeviceData> RISCV = INITIALIZER.register("riscv",
        () -> new FirmwareBlockDeviceData(Buildroot::getSednaFirmware, "Sedna Linux", class_1767.field_7942));
    public static final RegistrySupplier<BlockDeviceData> Z80 = INITIALIZER.register("z80",
        () -> new FirmwareBlockDeviceData(Cpm::getBootRom, "CP/M 2.2", class_1767.field_7946));

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    @Nullable
    public static class_2960 getKey(final BlockDeviceData data) {
        return REGISTRY.getId(data);
    }

    @Nullable
    public static BlockDeviceData getValue(final class_2960 location) {
        return REGISTRY.get(location);
    }

    public static Stream<BlockDeviceData> values() {
        return StreamSupport.stream(REGISTRY.spliterator(), false);
    }
}
