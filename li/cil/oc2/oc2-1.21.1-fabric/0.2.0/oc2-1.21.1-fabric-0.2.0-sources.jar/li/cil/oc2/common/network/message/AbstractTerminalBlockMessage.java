/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_9129;
import java.nio.ByteBuffer;

public abstract class AbstractTerminalBlockMessage extends AbstractMessage {
    protected class_2338 pos;
    protected byte[] data;

    // --------------------------------------------------------------------- //

    protected AbstractTerminalBlockMessage(final ComputerBlockEntity computer, final ByteBuffer data) {
        this.pos = computer.method_11016();
        this.data = data.array();
    }

    protected AbstractTerminalBlockMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        data = buffer.method_10795();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        buffer.method_10813(data);
    }
}
