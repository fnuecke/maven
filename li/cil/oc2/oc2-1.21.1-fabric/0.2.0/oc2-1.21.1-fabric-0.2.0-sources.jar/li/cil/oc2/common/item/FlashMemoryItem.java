/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import li.cil.oc2.api.bus.device.data.BlockDeviceData;
import li.cil.oc2.common.bus.device.data.FirmwareRegistry;
import li.cil.oc2.common.util.ItemStackUtils;
import li.cil.oc2.common.util.StorageItemUtils;
import net.minecraft.class_151;
import net.minecraft.class_156;
import net.minecraft.class_1761;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3544;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import javax.annotation.Nullable;

public final class FlashMemoryItem extends AbstractStorageItem implements ColoredItem, CreativeTabItemProvider {
    private static final int BLANK_COLOR = 0xFF77B294; // green

    // --------------------------------------------------------------------- //

    @Nullable
    private String descriptionId;

    public FlashMemoryItem(final int defaultCapacity) {
        super(createProperties().method_7889(1), defaultCapacity);
    }

    // --------------------------------------------------------------------- //

    @Nullable
    public BlockDeviceData getData(final class_1799 stack) {
        if (stack.method_7960() || stack.method_7909() != this) {
            return null;
        }

        final String registryName = ItemStackUtils.getModDataTag(stack).method_10558(StorageItemUtils.IMAGE_TAG_NAME);
        if (class_3544.method_15438(registryName)) {
            return null;
        }

        try {
            return FirmwareRegistry.getValue(class_2960.method_60654(registryName));
        } catch (final class_151 ignored) {
            return null;
        }
    }

    public class_1799 withData(final class_1799 stack, final class_2960 key) {
        if (stack.method_7960() || stack.method_7909() != this) {
            return class_1799.field_8037;
        }

        ItemStackUtils.modifyModDataTag(stack, tag -> tag.method_10582(StorageItemUtils.IMAGE_TAG_NAME, key.toString()));

        return stack;
    }

    public class_1799 withData(final class_2960 key) {
        return withData(new class_1799(this), key);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void addCreativeTabItems(final class_1761.class_8128 parameters, final class_1761.class_7704 output) {
        output.method_45420(new class_1799(this));

        FirmwareRegistry.values().forEach(data -> {
            final class_2960 key = FirmwareRegistry.getKey(data);
            if (key == null) {
                return;
            }

            final class_1799 stack = withData(key);
            final class_1767 color = data.getColor();
            if (color != null) {
                stack.method_57379(class_9334.field_49644, new class_9282(color.method_7787(), true));
            }
            output.method_45420(stack);
        });
    }

    @Override
    public int getColor(final class_1799 stack) {
        return class_9282.method_57470(stack, BLANK_COLOR);
    }

    @Override
    public class_2561 method_7864(final class_1799 stack) {
        final BlockDeviceData data = getData(stack);
        if (data == null) {
            return super.method_7864(stack);
        }

        return class_2561.method_43470("")
            .method_10852(super.method_7864(stack))
            .method_27693(" (")
            .method_10852(data.getDisplayName())
            .method_27693(")");
    }

    // --------------------------------------------------------------------- //

    @Override
    protected String method_7869() {
        if (descriptionId == null) {
            descriptionId = class_156.method_646("item", Items.FLASH_MEMORY.getId());
        }
        return descriptionId;
    }
}
