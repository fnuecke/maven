/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import java.util.List;

public class ModItem extends class_1792 {
    public ModItem(final class_1793 properties) {
        super(properties);
    }

    public ModItem() {
        this(createProperties());
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(final class_1799 stack, final class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.tryAddDescription(stack, tooltip);
    }

    // --------------------------------------------------------------------- //

    protected static class_1793 createProperties() {
        return new class_1793();
    }
}
