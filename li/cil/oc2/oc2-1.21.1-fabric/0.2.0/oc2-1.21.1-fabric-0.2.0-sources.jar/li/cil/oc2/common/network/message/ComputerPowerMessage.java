/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.oc2.common.blockentity.ComputerBlockEntity;
import li.cil.oc2.common.network.MessageUtils;
import net.minecraft.class_2338;
import net.minecraft.class_9129;

public final class ComputerPowerMessage extends AbstractMessage {
    private class_2338 pos;
    private boolean power;

    // --------------------------------------------------------------------- //

    public ComputerPowerMessage(final ComputerBlockEntity computer, final boolean power) {
        this.pos = computer.method_11016();
        this.power = power;
    }

    public ComputerPowerMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void fromBytes(final class_9129 buffer) {
        pos = buffer.method_10811();
        power = buffer.readBoolean();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(pos);
        buffer.method_52964(power);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void handleMessage(final NetworkManager.PacketContext context) {
        MessageUtils.withNearbyServerBlockEntityForInteraction(context, pos, ComputerBlockEntity.class,
            (player, computer) -> {
                if (power) {
                    computer.start();
                } else {
                    computer.stop();
                }
            });
    }
}
