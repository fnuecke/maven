/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus;

import li.cil.oc2.api.bus.BlockDeviceBusElement;
import li.cil.oc2.api.bus.DeviceBusElement;
import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.bus.device.rpc.TypeNameRPCDevice;
import li.cil.oc2.common.bus.device.util.BlockDeviceInfo;
import li.cil.oc2.common.bus.device.util.Devices;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.util.LevelUtils;
import li.cil.oc2.common.util.ServerScheduler;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3218;
import javax.annotation.Nullable;
import java.util.*;

import static li.cil.oc2.common.bus.device.provider.Providers.optionalKey;

public abstract class AbstractBlockDeviceBusElement extends AbstractGroupingDeviceBusElement<AbstractBlockDeviceBusElement.BlockEntry> implements BlockDeviceBusElement {
    private final DeviceBusElement[] neighborElements = new DeviceBusElement[Constants.BLOCK_FACE_COUNT];
    private final Capabilities.InvalidationHandle[] neighborHandles = new Capabilities.InvalidationHandle[Constants.BLOCK_FACE_COUNT];
    private final boolean[] hasScheduledNeighborUpdate = new boolean[Constants.BLOCK_FACE_COUNT];

    // --------------------------------------------------------------------- //

    public AbstractBlockDeviceBusElement() {
        super(Constants.BLOCK_FACE_COUNT);
    }

    // --------------------------------------------------------------------- //
    // DeviceBusElement

    @Override
    public Optional<Collection<DeviceBusElement>> getNeighbors() {
        if (!(getLevel() instanceof final class_3218 level)) {
            return Optional.empty();
        }

        final ArrayList<DeviceBusElement> neighbors = new ArrayList<>();
        for (final class_2350 neighborDirection : Constants.DIRECTIONS) {
            if (!canScanContinueTowards(neighborDirection)) {
                continue;
            }

            final class_2338 neighborPos = getPosition().method_10093(neighborDirection);

            final class_1923 chunkPos = new class_1923(neighborPos);
            if (!level.method_8393(chunkPos.field_9181, chunkPos.field_9180)) {
                return Optional.empty();
            }

            listenToNeighbor(level, neighborDirection);

            final DeviceBusElement neighbor = Capabilities.get(level, neighborPos, Capabilities.DEVICE_BUS_ELEMENT, neighborDirection.method_10153());
            neighborElements[neighborDirection.method_10146()] = neighbor;
            if (neighbor != null) {
                neighbors.add(neighbor);
            }
        }

        return Optional.of(neighbors);
    }

    @Override
    public void invalidateDevices() {
        for (final class_2350 side : class_2350.values()) {
            updateDevicesForNeighbor(side);
        }
    }

    // --------------------------------------------------------------------- //

    public void updateDevicesForNeighbor(final class_2350 side) {
        if (!(getLevel() instanceof final class_3218 level)) {
            return;
        }

        final int index = side.method_10146();
        final class_2338 neighborPos = getPosition().method_10093(side);

        // Without a controller we have no architecture, which can result in some
        // providers returning nothing or something different to what's saved.
        // In this state, we might discard persisted data of devices that don't get
        // provided in the current state. When a controller is added, we re-run this
        // anyway, so it's fine to just skip it for now.
        if (getControllers().isEmpty()) {
            // BUT! If this is a neighbor chunk unloading, we have to save the device
            // state of the devices in it, or we'll lose it .
            final class_1923 neighborChunk = new class_1923(neighborPos);
            if (!level.method_8393(neighborChunk.field_9181, neighborChunk.field_9180)) {
                setEntriesForGroupUnloaded(index);
            }
        } else {
            if (canDetectDevicesTowards(side)) {
                listenToNeighbor(level, side);
            }
            collectDevices(level, neighborPos, side).ifPresentOrElse(
                entries -> setEntriesForGroup(index, entries),
                () -> setEntriesForGroupUnloaded(index)
            );
        }
    }

    public void dropNeighborHandles() {
        for (final Capabilities.InvalidationHandle handle : neighborHandles) {
            if (handle != null) {
                handle.drop();
            }
        }
        Arrays.fill(neighborHandles, null);
        Arrays.fill(hasScheduledNeighborUpdate, false);
        Arrays.fill(neighborElements, null);
    }

    public void setRemoved() {
        dropNeighborHandles();

        final class_1936 level = getLevel();
        if (level == null || level.method_8608()) {
            return;
        }

        for (final class_2350 side : class_2350.values()) {
            setEntriesForGroup(side.method_10146(), Collections.emptySet());
        }

        scheduleScan();
    }

    // --------------------------------------------------------------------- //

    protected boolean canScanContinueTowards(@Nullable final class_2350 direction) {
        return true;
    }

    protected boolean canDetectDevicesTowards(@Nullable final class_2350 direction) {
        return canScanContinueTowards(direction);
    }

    protected Optional<Set<BlockEntry>> collectDevices(final class_3218 level, final class_2338 pos, @Nullable final class_2350 side) {
        final BlockDeviceQuery query = Devices.makeQuery(getArchitectureType().orElse(null), level, pos, side != null ? side.method_10153() : null);
        final HashSet<BlockEntry> entries = new HashSet<>();

        if (canDetectDevicesTowards(side)) {
            final Optional<List<BlockDeviceInfo>> loadedDevices = Devices.getDevices(query);
            if (loadedDevices.isPresent()) {
                for (final BlockDeviceInfo deviceInfo : loadedDevices.get()) {
                    entries.add(new BlockEntry(deviceInfo, side));
                }
            } else {
                return Optional.empty();
            }

            collectSyntheticDevices(level, pos, side, entries);
        }

        return Optional.of(entries);
    }

    protected void collectSyntheticDevices(final class_3218 level, final class_2338 pos, @Nullable final class_2350 side, final HashSet<BlockEntry> entries) {
        if (entries.isEmpty()) {
            return;
        }

        final String blockName = LevelUtils.getBlockName(level, pos);
        if (blockName != null) {
            entries.add(new BlockEntry(new BlockDeviceInfo(null, new TypeNameRPCDevice(blockName)), side));
        }
    }

    // --------------------------------------------------------------------- //

    private void listenToNeighbor(final class_3218 level, final class_2350 side) {
        final int index = side.method_10146();
        if (neighborHandles[index] == null) {
            neighborHandles[index] = Capabilities.listen(level, getPosition().method_10093(side), () -> {
                neighborHandles[index] = null;
                scheduleNeighborUpdate(level, side);
            });
        }
    }

    // Deferred: callbacks run inside the loader's capability invalidation, which must not re-query capabilities.
    private void scheduleNeighborUpdate(final class_3218 level, final class_2350 side) {
        final int index = side.method_10146();
        if (hasScheduledNeighborUpdate[index]) {
            return;
        }

        hasScheduledNeighborUpdate[index] = true;
        final class_1923 chunk = new class_1923(getPosition());
        ServerScheduler.schedule(level, () -> {
            if (!hasScheduledNeighborUpdate[index] || !level.method_8393(chunk.field_9181, chunk.field_9180)) {
                return;
            }

            hasScheduledNeighborUpdate[index] = false;
            if (canScanContinueTowards(side)) {
                listenToNeighbor(level, side);

                final class_2338 neighborPos = getPosition().method_10093(side);
                final class_1923 neighborChunk = new class_1923(neighborPos);
                final DeviceBusElement neighbor = level.method_8393(neighborChunk.field_9181, neighborChunk.field_9180)
                    ? Capabilities.get(level, neighborPos, Capabilities.DEVICE_BUS_ELEMENT, side.method_10153())
                    : null;
                if (neighbor != neighborElements[index]) {
                    scheduleScan();
                }
            }
            updateDevicesForNeighbor(side);
        }, 1);
    }

    // --------------------------------------------------------------------- //

    protected static final class BlockEntry implements Entry {
        private final BlockDeviceInfo deviceInfo;
        @Nullable
        private final String dataKey;
        @Nullable
        private final class_2350 side;

        public BlockEntry(final BlockDeviceInfo deviceInfo, @Nullable final class_2350 side) {
            this.deviceInfo = deviceInfo;
            this.side = side;
            this.dataKey = optionalKey(deviceInfo.provider).orElse(null);
        }

        @Override
        public Optional<String> getDeviceDataKey() {
            return Optional.ofNullable(dataKey);
        }

        @Override
        public OptionalInt getDeviceEnergyConsumption() {
            return OptionalInt.of(deviceInfo.getEnergyConsumption());
        }

        @Override
        public Device getDevice() {
            return deviceInfo.device;
        }

        @Override
        public boolean equals(final Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            final BlockEntry that = (BlockEntry) o;
            return Objects.equals(dataKey, that.dataKey) && deviceInfo.device.equals(that.deviceInfo.device) && side == that.side;
        }

        @Override
        public int hashCode() {
            return Objects.hash(dataKey, deviceInfo.device, side);
        }

        @Override
        public String toString() {
            return deviceInfo.device.toString();
        }
    }
}
