/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.block;

import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.Callback;
import li.cil.oc2.api.bus.device.object.IOCallback;
import li.cil.oc2.api.bus.device.object.IODeviceDescription;
import li.cil.oc2.api.bus.device.object.RPCDeviceDescription;
import li.cil.oc2.common.util.BlockLocation;
import net.minecraft.class_1299;
import net.minecraft.class_1952;
import net.minecraft.class_2636;
import javax.annotation.Nullable;
import java.io.IOException;
import java.util.Objects;

@RPCDeviceDescription(typeNames = {"spawner"}, description = """
    Provided by monster spawners connected to a [bus interface](../block/bus_interface.md).""")
@IODeviceDescription(name = "SPAWNR")
public final class SpawnerDevice extends AbstractBlockDevice {
    private static final int GET_ENTITY_TYPE_CODE = 1;

    // --------------------------------------------------------------------- //

    public SpawnerDevice(final BlockLocation identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    @Callback(description = "Gets what the spawner spawns next.",
        returnValueDescription = "the name of the creature, such as `minecraft:zombie`, if any.")
    @Nullable
    public String getEntityType() {
        final class_1952 spawnData = getBlockEntity(class_2636.class).method_11390().field_9155;
        if (spawnData == null) {
            return null;
        }

        return class_1299.method_17684(spawnData.comp_64())
            .map(type -> class_1299.method_5890(type).toString())
            .orElse(null);
    }

    // --------------------------------------------------------------------- //

    @IOCallback(value = GET_ENTITY_TYPE_CODE,
        description = "Gets what the spawner spawns next.",
        resultsDescription = "the name of the creature, such as `minecraft:zombie`, if any. Read while `OCDAV` is set to read fully.")
    public void getEntityType(final IOOutputStream results) throws IOException {
        results.writeString(Objects.requireNonNullElse(getEntityType(), ""));
    }
}
