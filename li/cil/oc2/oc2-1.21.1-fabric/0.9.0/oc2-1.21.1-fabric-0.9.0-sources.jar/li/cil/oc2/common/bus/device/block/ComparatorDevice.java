/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.block;

import li.cil.oc2.api.bus.device.io.IOInputStream;
import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.*;
import li.cil.oc2.common.util.BlockLocation;
import net.minecraft.class_2246;
import net.minecraft.class_2286;
import net.minecraft.class_2599;
import net.minecraft.class_2680;
import net.minecraft.class_2747;
import javax.annotation.Nullable;
import java.io.IOException;

@RPCDeviceDescription(typeNames = {"comparator"}, description = """
    Provided by redstone comparators connected to a [bus interface](../block/bus_interface.md).""")
@IODeviceDescription(name = "CMPRTR")
public final class ComparatorDevice extends AbstractBlockDevice {
    private static final int GET_OUTPUT_SIGNAL_CODE = 1;
    private static final int GET_MODE_CODE = 2;
    private static final int SET_MODE_CODE = 3;

    // --------------------------------------------------------------------- //

    public ComparatorDevice(final BlockLocation identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    @Callback(description = "Gets the signal strength the comparator outputs.",
        returnValueDescription = "the signal strength, from `0` to `15`.")
    public int getOutputSignal() {
        return getBlockEntity(class_2599.class).method_11071();
    }

    @Callback(description = "Gets the mode the comparator is in.",
        returnValueDescription = "`compare` or `subtract`.")
    public String getMode() {
        return getBlockState(class_2246.field_10377).method_11654(class_2286.field_10789).method_15434();
    }

    @Callback(description = "Sets the mode the comparator is in.")
    public void setMode(@Nullable @Parameter(value = "mode", description = "`compare` or `subtract`.") final String mode) {
        for (final class_2747 value : class_2747.values()) {
            if (value.method_15434().equals(mode)) {
                setMode(value);
                return;
            }
        }

        throw new IllegalArgumentException("mode must be compare or subtract");
    }

    // --------------------------------------------------------------------- //

    @IOCallback(value = GET_OUTPUT_SIGNAL_CODE,
        description = "Gets the signal strength the comparator outputs.",
        resultsDescription = "one byte, the signal strength, from `0` to `15`.")
    public void getOutputSignal(final IOOutputStream results) throws IOException {
        results.writeU8(getOutputSignal());
    }

    @IOCallback(value = GET_MODE_CODE,
        description = "Gets the mode the comparator is in.",
        resultsDescription = "one byte, `0` is `compare`, `1` is `subtract`.")
    public void getMode(final IOOutputStream results) throws IOException {
        results.writeU8(getBlockState(class_2246.field_10377).method_11654(class_2286.field_10789).ordinal());
    }

    @IOCallback(value = SET_MODE_CODE,
        description = "Sets the mode the comparator is in.",
        argumentsDescription = "one byte, `0` is `compare`, `1` is `subtract`.")
    public void setMode(final IOInputStream arguments) throws IOException {
        final int mode = arguments.readU8();
        if (mode >= class_2747.values().length) {
            throw new IllegalArgumentException("mode must be 0 or 1");
        }

        setMode(class_2747.values()[mode]);
    }

    // --------------------------------------------------------------------- //

    private void setMode(final class_2747 mode) {
        final class_2680 blockState = getBlockState(class_2246.field_10377);
        if (blockState.method_11654(class_2286.field_10789) == mode) {
            return;
        }

        setBlockState(blockState.method_11657(class_2286.field_10789, mode));
        getServerLevel().method_39279(identity.blockPos(), class_2246.field_10377, 1);
    }
}
