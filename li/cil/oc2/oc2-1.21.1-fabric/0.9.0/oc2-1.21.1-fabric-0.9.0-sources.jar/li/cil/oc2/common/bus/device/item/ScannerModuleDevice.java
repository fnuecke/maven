/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.item;

import li.cil.oc2.api.bus.device.io.IOInputStream;
import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.*;
import li.cil.oc2.api.util.RobotOperationSide;
import li.cil.oc2.common.bus.device.SystemDevice;
import li.cil.oc2.common.util.TickUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2404;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4076;
import net.minecraft.class_7923;
import javax.annotation.Nullable;
import java.io.IOException;
import java.time.Duration;
import java.util.Comparator;

@RPCDeviceDescription(typeNames = {"scanner"}, description = """
    Provided by the [scanner module](../item/scanner_module.md) to robots.

    ### Sides
    The side parameter of `inspect()` represents a face of the robot. Valid values are: `front`, `up` and `down`.

    ### Scanning
    `scan()` measures the hardness of every block in a cube of seven by seven by seven blocks with the robot at its center. Positions use the axes of the robot's `getPosition()`: `x` grows towards east, `y` upward and `z` towards south.

    The result holds one byte per block. Blocks are ordered by `y`, then `z`, then `x`, each from `-3` to `3`, so the result is a stack of horizontal layers from bottom to top, and `x` changes fastest. The block at offset `x`, `y`, `z` from the robot is at index `(y + 3) * 7 * 7 + (z + 3) * 7 + (x + 3)`, counting from zero. Since Lua counts from one, this is equivalent to `string.byte(hardness, index + 1)`.

    Each byte encodes air as `0`, any fluid as `254` and unbreakable or unscannable blocks as `255`. Regular blocks are encoded as hardness mapped into the `1` to `253` range.

    After a scan, the scanner needs five seconds to recharge. Scanning while it recharges fails.

    ### Fluids
    Fluids are always reported by their source fluid, such as `minecraft:water`.

    ### Entities
    Entities are reported by identifier, such as `minecraft:sheep`, closest first. At most twenty are listed.""")
@IODeviceDescription(name = "SCANNR", description = """
    Sides are numbered: `0` front, `1` up and `2` down. Block and fluid ids are two bytes, low byte first; [`SYSTEM`](system.md) provides name lookup. Block `0` is air, fluid `0` is no fluid.

    A scan is read one layer at a time. Layers are horizontal and numbered `0` to `6` from bottom to top, each holds 49 bytes ordered from north to south, then from west to east. Byte values are as described for the high-level API.""")
public final class ScannerModuleDevice extends AbstractItemDevice {
    public record Inspection(@Nullable String block, @Nullable String fluid, String[] entities) {
    }

    public record ScanResult(byte[] hardness, String[] entities) {
    }

    // --------------------------------------------------------------------- //

    private static final String READY_AT_TAG_NAME = "ready_at";
    private static final String LAST_SCAN_TAG_NAME = "last_scan";

    private static final int INSPECT_CODE = 1;
    private static final int SCAN_CODE = 2;
    private static final int GET_SCAN_LAYER_CODE = 3;
    private static final int CAN_SEE_SKY_CODE = 4;

    private static final int SCAN_RADIUS = 3;
    private static final int SCAN_LENGTH = SCAN_RADIUS * 2 + 1;
    private static final int SCAN_LAYER_SIZE = SCAN_LENGTH * SCAN_LENGTH;
    private static final int SCAN_SIZE = SCAN_LAYER_SIZE * SCAN_LENGTH;
    private static final int SCAN_COOLDOWN = TickUtils.toTicks(Duration.ofSeconds(5));
    private static final int MAX_ENTITIES = 20;

    private static final int HARDNESS_AIR = 0;
    private static final int HARDNESS_MAX = 253;
    private static final int HARDNESS_FLUID = 254;
    private static final int HARDNESS_UNBREAKABLE = 255;

    private static final String INSPECT_DESCRIPTION = "Identifies the block, fluid and entities in the space on the specified side of the robot.";
    private static final String SCAN_DESCRIPTION = "Measures the hardness of the blocks around the robot and lists nearby entities.";
    private static final String CAN_SEE_SKY_DESCRIPTION = "Checks whether the robot's space gets full sky light.";

    // --------------------------------------------------------------------- //

    private final class_1297 entity;
    private long readyAt;
    @Nullable
    private byte[] lastScan;

    // --------------------------------------------------------------------- //

    public ScannerModuleDevice(final class_1799 identity, final class_1297 entity) {
        super(identity);
        this.entity = entity;
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2487 serializeNBT() {
        final class_2487 tag = new class_2487();
        tag.method_10544(READY_AT_TAG_NAME, readyAt);
        if (lastScan != null) {
            tag.method_10570(LAST_SCAN_TAG_NAME, lastScan);
        }
        return tag;
    }

    @Override
    public void deserializeNBT(final class_2487 tag) {
        readyAt = tag.method_10537(READY_AT_TAG_NAME);
        lastScan = tag.method_10545(LAST_SCAN_TAG_NAME) ? tag.method_10547(LAST_SCAN_TAG_NAME) : null;
    }

    // --------------------------------------------------------------------- //

    @Callback(description = INSPECT_DESCRIPTION, energy = 1,
        returnValueDescription = "a table with the `block` and `fluid`, if present, and a list of `entities`.")
    public Inspection inspect(@Parameter(value = "side", description = "the side to look at: `front`, `up` or `down`.") @Nullable final RobotOperationSide side) {
        final class_2338 pos = getAdjacent(side);
        final class_2680 state = getBlockState(pos);
        final class_3610 fluid = state.method_26227();
        return new Inspection(
            state.method_26215() ? null : class_7923.field_41175.method_10221(state.method_26204()).toString(),
            fluid.method_15769() ? null : class_7923.field_41173.method_10221(getSourceFluid(fluid)).toString(),
            getEntities(new class_238(pos)));
    }

    @Callback(description = SCAN_DESCRIPTION, energy = 10,
        returnValueDescription = "a table with the block `hardness` as binary data, see above, and the list of " +
            "`entities` in the scanned cube.")
    public ScanResult scan() {
        final class_1937 level = entity.method_37908();
        if (level.method_8510() < readyAt) {
            throw new IllegalStateException("scanner is recharging");
        }
        readyAt = level.method_8510() + SCAN_COOLDOWN;

        final class_2338 center = getCenter();
        final class_2338.class_2339 pos = new class_2338.class_2339();
        final byte[] hardness = new byte[SCAN_SIZE];
        int index = 0;
        for (int y = -SCAN_RADIUS; y <= SCAN_RADIUS; y++) {
            for (int z = -SCAN_RADIUS; z <= SCAN_RADIUS; z++) {
                for (int x = -SCAN_RADIUS; x <= SCAN_RADIUS; x++) {
                    pos.method_25504(center, x, y, z);
                    hardness[index++] = (byte) getHardness(level, pos);
                }
            }
        }

        lastScan = hardness;
        return new ScanResult(hardness, getEntities(new class_238(center).method_1014(SCAN_RADIUS)));
    }

    @Callback(description = CAN_SEE_SKY_DESCRIPTION,
        returnValueDescription = "whether the sky is visible.")
    public boolean canSeeSky() {
        return entity.method_37908().method_8311(getCenter());
    }

    // --------------------------------------------------------------------- //

    @IOCallback(value = INSPECT_CODE, energy = 1,
        description = INSPECT_DESCRIPTION,
        argumentsDescription = "one byte, the side.",
        resultsDescription = "five bytes: the block as two bytes, the fluid as two bytes, and the number of entities.")
    public void inspect(final IOInputStream arguments, final IOOutputStream results) throws IOException {
        final class_2338 pos = getAdjacent(RobotOperationSide.byIndex(arguments.readU8()));
        final class_2680 state = getBlockState(pos);
        results.writeU16(state.method_26215() ? 0 : SystemDevice.toId(class_7923.field_41175, state.method_26204()));
        results.writeU16(SystemDevice.toId(class_7923.field_41173, getSourceFluid(state.method_26227())));
        results.writeU8(getEntities(new class_238(pos)).length);
    }

    @IOCallback(value = SCAN_CODE, energy = 10,
        description = SCAN_DESCRIPTION + " Read the result with `getScanLayer`.",
        resultsDescription = "one byte, the number of entities in the scanned cube.")
    public void scan(final IOOutputStream results) throws IOException {
        results.writeU8(scan().entities().length);
    }

    @IOCallback(value = GET_SCAN_LAYER_CODE,
        description = "Reads one layer of the last scan. Fails if there was no scan yet.",
        argumentsDescription = "one byte, the layer.",
        resultsDescription = "49 bytes, the hardness of each block in the layer.")
    public void getScanLayer(final IOInputStream arguments, final IOOutputStream results) throws IOException {
        final int layer = arguments.readU8();
        if (layer >= SCAN_LENGTH) {
            throw new IllegalArgumentException("layer out of range: " + layer + " (expected 0 to " + (SCAN_LENGTH - 1) + ")");
        }
        if (lastScan == null) {
            throw new IllegalStateException("no scan yet");
        }
        results.write(lastScan, layer * SCAN_LAYER_SIZE, SCAN_LAYER_SIZE);
    }

    @IOCallback(value = CAN_SEE_SKY_CODE,
        description = CAN_SEE_SKY_DESCRIPTION,
        resultsDescription = "one byte, `1` if the sky is visible, `0` otherwise.")
    public void canSeeSky(final IOOutputStream results) throws IOException {
        results.writeU8(canSeeSky() ? 1 : 0);
    }

    // --------------------------------------------------------------------- //

    private class_2338 getCenter() {
        return class_2338.method_49638(entity.method_5829().method_1005());
    }

    private class_2338 getAdjacent(@Nullable final RobotOperationSide side) {
        if (side == null) throw new IllegalArgumentException();
        return entity.method_24515().method_10093(RobotOperationSide.toGlobal(entity, side));
    }

    private class_2680 getBlockState(final class_2338 pos) {
        final class_1937 level = entity.method_37908();
        return isLoaded(level, pos) ? level.method_8320(pos) : class_2246.field_10124.method_9564();
    }

    private String[] getEntities(final class_238 bounds) {
        return entity.method_37908().method_8333(entity, bounds, class_1301.field_6155).stream()
            .sorted(Comparator.comparingDouble(other -> other.method_5858(entity)))
            .limit(MAX_ENTITIES)
            .map(other -> class_7923.field_41177.method_10221(other.method_5864()).toString())
            .toArray(String[]::new);
    }

    @SuppressWarnings("deprecation")
    private static int getHardness(final class_1937 level, final class_2338 pos) {
        if (!isLoaded(level, pos)) {
            return HARDNESS_UNBREAKABLE;
        }

        final class_2680 state = level.method_8320(pos);
        if (state.method_26215()) {
            return HARDNESS_AIR;
        }
        if (state.method_51176() || state.method_26204() instanceof class_2404) {
            return HARDNESS_FLUID;
        }

        final float hardness = state.method_26214(level, pos);
        if (hardness < 0) {
            return HARDNESS_UNBREAKABLE;
        }
        return Math.clamp(Math.round(hardness * 10), 1, HARDNESS_MAX);
    }

    private static class_3611 getSourceFluid(final class_3610 fluid) {
        return fluid.method_15772() instanceof final class_3609 flowing ? flowing.method_15751() : fluid.method_15772();
    }

    private static boolean isLoaded(final class_1937 level, final class_2338 pos) {
        return level.method_8393(class_4076.method_18675(pos.method_10263()), class_4076.method_18675(pos.method_10260()));
    }
}
