/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.block;

import li.cil.oc2.api.bus.device.io.IOInputStream;
import li.cil.oc2.api.bus.device.io.IOOutputStream;
import li.cil.oc2.api.bus.device.object.*;
import li.cil.oc2.common.bus.device.SystemDevice;
import li.cil.oc2.common.util.BlockLocation;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.class_8886;
import net.minecraft.class_8887;
import net.minecraft.class_9694;
import java.io.IOException;

@RPCDeviceDescription(typeNames = {"crafter"}, description = """
    Provided by crafters connected to a [bus interface](../block/bus_interface.md). The grid slots are available through the [item handler](item_handler.md) device.""")
@IODeviceDescription(name = "CRAFTR", description = """
    Item ids are two bytes, low byte first; [`SYSTEM`](system.md) provides name lookup.""")
public final class CrafterDevice extends AbstractBlockDevice {
    private static final int IS_SLOT_ENABLED_CODE = 1;
    private static final int SET_SLOT_ENABLED_CODE = 2;
    private static final int GET_RESULT_CODE = 3;

    private static final int SLOT_COUNT = 9;

    // --------------------------------------------------------------------- //

    public CrafterDevice(final BlockLocation identity) {
        super(identity);
    }

    // --------------------------------------------------------------------- //

    @Callback(description = "Gets whether a slot of the grid is enabled.",
        returnValueDescription = "`true` if the slot is enabled.")
    public boolean isSlotEnabled(@Parameter(value = "slot", description = "the slot index.") final int slot) {
        return !getCrafter().method_54483(requireValidSlot(slot));
    }

    @Callback(description = "Sets whether a grid slot is enabled. Slot must be empty to be disabled.")
    public void setSlotEnabled(@Parameter(value = "slot", description = "the slot index.") final int slot,
                               @Parameter(value = "enabled", description = "whether to enable the slot.") final boolean enabled) {
        final class_8887 crafter = getCrafter();
        if (!enabled && !crafter.method_5438(requireValidSlot(slot)).method_7960()) {
            throw new IllegalStateException("slot is not empty");
        }

        checkPermission();
        crafter.method_54480(requireValidSlot(slot), enabled);
    }

    @Callback(description = "Gets what the crafter would currently craft.",
        returnValueDescription = "a table with the item information. Returns nothing if the grid matches no recipe.")
    public class_1799 getResult() {
        final class_8887 crafter = getCrafter();
        final class_3218 level = getServerLevel();
        final class_9694 input = crafter.method_59961();
        return class_8886.method_54475(level, input)
            .map(recipe -> recipe.comp_1933().method_8116(input, level.method_30349()))
            .orElse(class_1799.field_8037);
    }

    // --------------------------------------------------------------------- //

    @IOCallback(value = IS_SLOT_ENABLED_CODE,
        description = "Gets whether a slot of the grid is enabled.",
        argumentsDescription = "one byte, the slot index.",
        resultsDescription = "one byte, `1` if enabled, else `0`.")
    public void isSlotEnabled(final IOInputStream arguments, final IOOutputStream results) throws IOException {
        results.writeU8(isSlotEnabled(arguments.readU8()) ? 1 : 0);
    }

    @IOCallback(value = SET_SLOT_ENABLED_CODE,
        description = "Sets whether a grid slot is enabled. Slot must be empty to be disabled.",
        argumentsDescription = "two bytes, the slot index, and `0` to disable or `1` to enable it.")
    public void setSlotEnabled(final IOInputStream arguments) throws IOException {
        final int slot = arguments.readU8();
        setSlotEnabled(slot, arguments.readU8() != 0);
    }

    @IOCallback(value = GET_RESULT_CODE,
        description = "Gets what the crafter would currently craft.",
        resultsDescription = "three bytes: the item as two bytes, `0` if the grid matches no recipe, else the number of items.")
    public void getResult(final IOOutputStream results) throws IOException {
        final class_1799 result = getResult();
        results.writeU16(SystemDevice.toId(class_7923.field_41178, result.method_7909()));
        results.writeU8(Math.min(result.method_7947(), 0xFF));
    }

    // --------------------------------------------------------------------- //

    private static int requireValidSlot(final int slot) {
        if (slot < 0 || slot >= SLOT_COUNT) {
            throw new IllegalArgumentException("slot out of range: " + slot + " (expected 0 to " + (SLOT_COUNT - 1) + ")");
        }
        return slot;
    }

    private class_8887 getCrafter() {
        return getBlockEntity(class_8887.class);
    }
}
