/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.common.block.BusCableBlock;
import li.cil.oc2.common.blockentity.BusCableBlockEntity;
import li.cil.oc2.common.integration.Wrenches;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_898;
import org.joml.Matrix4f;

public enum BusInterfaceNameRenderer {
    INSTANCE;

    // Values mirror EntityRenderer.renderNameTag
    private static final double LABEL_HOVER = 0.5;
    private static final int SEE_THROUGH_COLOR = 0x20FFFFFF;
    private static final int COLOR = 0xFFFFFFFF;

    // --------------------------------------------------------------------- //

    public void render(final class_4587 stack) {
        final class_310 mc = class_310.method_1551();
        final class_1657 player = mc.field_1724;
        if (player == null) {
            return;
        }

        final class_1937 level = player.method_37908();

        if (!Wrenches.isHoldingWrench(player)) {
            return;
        }

        if (!(mc.field_1765 instanceof final class_3965 hit)) {
            return;
        }

        final class_2338 blockPos = hit.method_17777();
        final class_2586 blockEntity = level.method_8321(blockPos);
        if (!(blockEntity instanceof final BusCableBlockEntity busCable)) {
            return;
        }

        final class_2350 side = BusCableBlock.getHitSide(blockPos, hit);
        if (BusCableBlock.getConnectionType(level.method_8320(blockPos), side) != BusCableBlock.ConnectionType.INTERFACE) {
            return;
        }

        final String name = busCable.getInterfaceName(side);
        if (name.isEmpty()) {
            return;
        }

        stack.method_22903();

        final class_243 camera = mc.field_1773.method_19418().method_19326();
        stack.method_22904(
            blockPos.method_10263() + 0.5 + side.method_10148() * 0.5 - camera.field_1352,
            blockPos.method_10264() + 0.5 + side.method_10164() * 0.5 - camera.field_1351
                + (side == class_2350.field_11033 ? -LABEL_HOVER : LABEL_HOVER),
            blockPos.method_10260() + 0.5 + side.method_10165() * 0.5 - camera.field_1350);

        final class_898 renderManager = mc.method_1561();
        stack.method_22907(renderManager.method_24197());

        stack.method_22905(0.025f, -0.025f, 0.025f);

        final Matrix4f matrix = stack.method_23760().method_23761();

        final class_327 font = mc.field_1772;
        final class_4597.class_4598 buffer = mc.method_22940().method_23000();

        final float horizontalTextOffset = -font.method_1727(name) * 0.5f;
        final float backgroundOpacity = mc.field_1690.method_19343(0.25F);
        final int backgroundColor = (int) (backgroundOpacity * 255.0F) << 24;
        final int packedLight = class_765.method_23687(15, 15);

        font.method_27521(name, horizontalTextOffset, 0, SEE_THROUGH_COLOR,
            false, matrix, buffer, class_327.class_6415.field_33994, backgroundColor, packedLight);
        font.method_27521(name, horizontalTextOffset, 0, COLOR,
            false, matrix, buffer, class_327.class_6415.field_33993, 0, packedLight);

        buffer.method_22993();

        stack.method_22909();
    }
}
