/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.InternetGatewayBlockEntity;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import li.cil.oc2.common.inet.InternetConnection;
import li.cil.oc2.common.item.TooltipUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3532;
import net.minecraft.class_3620;
import net.minecraft.class_5251;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import javax.annotation.Nullable;
import java.util.List;

public final class InternetGatewayBlock extends class_2383 implements class_2343 {
    public static final MapCodec<InternetGatewayBlock> CODEC = MapCodec.unit(InternetGatewayBlock::new);
    private static final double PARTICLES_MIN = 3 / 16.0;
    private static final double PARTICLES_MAX = 13 / 16.0;

    // --------------------------------------------------------------------- //

    public InternetGatewayBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override
    protected MapCodec<? extends InternetGatewayBlock> method_53969() {
        return field_46280;
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2680 method_9605(final class_1750 context) {
        return super.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void method_9568(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_9568(stack, context, tooltip, flag);
        if (Config.internetGatewaysUseEnergy()) {
            TooltipUtils.addEnergyConsumption(0, InternetConnection.FRAME_QUEUE_SIZE * Config.internetGatewayEnergyPerPacket, tooltip);
        }
        if (!Config.internetEnabled) {
            tooltip.add(class_2561.method_43471(Constants.TOOLTIP_INTERNET_DISABLED)
                .method_27694(s -> s.method_27703(class_5251.method_27718(class_124.field_1061))));
        }
    }

    @Override
    public void method_9496(final class_2680 state, final class_1937 level, final class_2338 pos, final class_5819 random) {
        if (!(level.method_8321(pos) instanceof final InternetGatewayBlockEntity gateway) || !gateway.isOperational()) {
            return;
        }

        level.method_8406(class_2398.field_23190,
            pos.method_10263() + class_3532.method_16436(random.method_43058(), PARTICLES_MIN, PARTICLES_MAX),
            pos.method_10264() + 1.0,
            pos.method_10260() + class_3532.method_16436(random.method_43058(), PARTICLES_MIN, PARTICLES_MAX),
            0.0, 0.03, 0.0);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.INTERNET_GATEWAY.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createServerTicker(level, type, BlockEntities.INTERNET_GATEWAY.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(field_11177);
    }
}
