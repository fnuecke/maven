/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.block.FlashDriveBlock;
import li.cil.oc2.common.bus.device.vm.block.FlashDriveDevice;
import li.cil.oc2.common.network.message.AbstractMessage;
import li.cil.oc2.common.network.message.FlashDriveFlashMemoryMessage;
import li.cil.oc2.common.tags.ItemTags;
import li.cil.oc2.common.util.SoundEvents;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public final class FlashDriveBlockEntity extends AbstractRemovableMediaBlockEntity<FlashDriveDevice> {
    public FlashDriveBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.FLASH_DRIVE.get(), pos, state,
            ItemTags.DEVICES_FLASH_MEMORY,
            SoundEvents.FLASH_INSERT.get(),
            SoundEvents.FLASH_EJECT.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected class_2350 getEjectDirection() {
        return method_11010().method_11654(FlashDriveBlock.FACING);
    }

    @Override
    protected AbstractMessage createMediaMessage() {
        return new FlashDriveFlashMemoryMessage(this);
    }
}
