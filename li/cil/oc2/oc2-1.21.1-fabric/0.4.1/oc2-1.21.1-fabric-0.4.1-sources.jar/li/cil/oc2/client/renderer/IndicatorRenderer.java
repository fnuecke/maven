/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class IndicatorRenderer {
    private static final int PULSE_TICKS = 40;

    // --------------------------------------------------------------------- //

    public static void render(final class_4587 stack, final class_4597 bufferSource, final class_238 bounds, final Vector3f color, final Vector3f colorBright, final long gameTime, final float partialTicks) {
        final float phase = (gameTime % PULSE_TICKS + partialTicks) / PULSE_TICKS;
        final float blend = (1 + class_3532.method_15374(phase * (float) (Math.PI * 2))) * 0.5f;

        final float r = class_3532.method_16439(blend, color.x(), colorBright.x());
        final float g = class_3532.method_16439(blend, color.y(), colorBright.y());
        final float b = class_3532.method_16439(blend, color.z(), colorBright.z());

        addBoxVertices(stack.method_23760().method_23761(), bufferSource.getBuffer(ModRenderType.getIndicator()), bounds, r, g, b);
    }

    // --------------------------------------------------------------------- //

    private static void addBoxVertices(final Matrix4f matrix, final class_4588 consumer, final class_238 bounds, final float r, final float g, final float b) {
        final float x0 = (float) bounds.field_1323;
        final float y0 = (float) bounds.field_1322;
        final float z0 = (float) bounds.field_1321;
        final float x1 = (float) bounds.field_1320;
        final float y1 = (float) bounds.field_1325;
        final float z1 = (float) bounds.field_1324;

        // Wound counter-clockwise as seen from outside; the render type culls back faces.
        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x0, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z0, r, g, b);

        addVertex(matrix, consumer, x0, y0, z1, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x0, y0, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);
        addVertex(matrix, consumer, x0, y1, z0, r, g, b);

        addVertex(matrix, consumer, x1, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);

        addVertex(matrix, consumer, x0, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z0, r, g, b);
        addVertex(matrix, consumer, x1, y0, z1, r, g, b);
        addVertex(matrix, consumer, x0, y0, z1, r, g, b);

        addVertex(matrix, consumer, x0, y1, z0, r, g, b);
        addVertex(matrix, consumer, x0, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z1, r, g, b);
        addVertex(matrix, consumer, x1, y1, z0, r, g, b);
    }

    private static void addVertex(final Matrix4f matrix, final class_4588 consumer, final float x, final float y, final float z, final float r, final float g, final float b) {
        consumer.method_22918(matrix, x, y, z).method_22915(r, g, b, 1f);
    }

    private IndicatorRenderer() {
    }
}
