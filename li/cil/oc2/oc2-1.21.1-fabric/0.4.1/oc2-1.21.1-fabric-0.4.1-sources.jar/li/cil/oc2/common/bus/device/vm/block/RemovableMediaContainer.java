/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.vm.block;

import net.minecraft.class_1799;

public interface RemovableMediaContainer {
    class_1799 getMediaItemStack();

    void setChanged();

    default void handleDataAccess() {
    }
}
