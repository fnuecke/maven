/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.client.renderer.IndicatorRenderer;
import li.cil.oc2.common.block.NetworkConnectorBlock;
import li.cil.oc2.common.blockentity.NetworkConnectorBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import org.joml.Vector3f;

public final class NetworkConnectorRenderer implements class_827<NetworkConnectorBlockEntity> {
    private static final Vector3f INDICATOR_COLOR = new Vector3f(0.35f, 0.95f, 1f);
    private static final Vector3f INDICATOR_COLOR_BRIGHT = new Vector3f(0.6f, 1f, 1f);

    private static final double CAP_SIDE_MIN = 6 / 16.0;
    private static final double CAP_SIDE_MAX = 10 / 16.0;
    private static final double CAP_AXIS_MIN = 7 / 16.0;
    private static final double CAP_AXIS_MAX = 8 / 16.0;

    private static final class_238[] INDICATOR_BOUNDS = createIndicatorBounds();

    // --------------------------------------------------------------------- //

    public NetworkConnectorRenderer(final class_5614.class_5615 ignoredContext) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final NetworkConnectorBlockEntity connector, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        if (!connector.hasAdjacentInterface()) {
            return;
        }

        final class_1937 level = connector.method_10997();
        final long gameTime = level != null ? level.method_8510() : 0;
        final class_238 bounds = INDICATOR_BOUNDS[NetworkConnectorBlock.getFacing(connector.method_11010()).ordinal()];

        IndicatorRenderer.render(stack, bufferSource, bounds, INDICATOR_COLOR, INDICATOR_COLOR_BRIGHT, gameTime, partialTicks);
    }

    // --------------------------------------------------------------------- //

    private static class_238[] createIndicatorBounds() {
        final class_238[] bounds = new class_238[class_2350.values().length];

        for (final class_2350 direction : class_2350.values()) {
            final boolean isPositive = direction.method_10171() == class_2350.class_2352.field_11056;
            final double min = isPositive ? CAP_AXIS_MIN : 1 - CAP_AXIS_MAX;
            final double max = isPositive ? CAP_AXIS_MAX : 1 - CAP_AXIS_MIN;

            bounds[direction.ordinal()] = switch (direction.method_10166()) {
                case field_11048 -> new class_238(min, CAP_SIDE_MIN, CAP_SIDE_MIN, max, CAP_SIDE_MAX, CAP_SIDE_MAX);
                case field_11052 -> new class_238(CAP_SIDE_MIN, min, CAP_SIDE_MIN, CAP_SIDE_MAX, max, CAP_SIDE_MAX);
                case field_11051 -> new class_238(CAP_SIDE_MIN, CAP_SIDE_MIN, min, CAP_SIDE_MAX, CAP_SIDE_MAX, max);
            };
        }

        return bounds;
    }
}
