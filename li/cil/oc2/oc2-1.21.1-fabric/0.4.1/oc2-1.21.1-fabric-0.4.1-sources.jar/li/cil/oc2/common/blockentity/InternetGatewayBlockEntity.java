/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.api.capabilities.NetworkInterface;
import li.cil.oc2.common.Config;
import li.cil.oc2.common.Constants;
import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.energy.FixedEnergyStorage;
import li.cil.oc2.common.inet.InternetAdapter;
import li.cil.oc2.common.inet.InternetConnection;
import li.cil.oc2.common.inet.InternetManager;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.InternetGatewayStateMessage;
import li.cil.oc2.common.util.ChunkUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.Deque;

public final class InternetGatewayBlockEntity extends ModBlockEntity implements NetworkInterface, InternetAdapter, TickableBlockEntity {
    private static final String OPERATIONAL_TAG_NAME = "operational";

    private final Deque<byte[]> toNetwork = new ArrayDeque<>();
    private final Deque<byte[]> toInternet = new ArrayDeque<>();
    private final FixedEnergyStorage energy = new FixedEnergyStorage(Config.internetGatewayEnergyStorage);

    @Nullable
    private InternetConnection connection;
    private boolean isOperational;

    // --------------------------------------------------------------------- //

    public InternetGatewayBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.INTERNET_GATEWAY.get(), pos, state);
        setNeedsLevelUnloadEvent();
    }

    // --------------------------------------------------------------------- //

    public boolean isOperational() {
        return isOperational;
    }

    public void setOperationalClient(final boolean value) {
        isOperational = value;
    }

    @Override
    public void serverTick() {
        final boolean value = computeIsOperational();
        if (value != isOperational) {
            isOperational = value;
            Network.sendToClientsTrackingBlockEntity(new InternetGatewayStateMessage(this, isOperational), this);
        }
    }

    // --------------------------------------------------------------------- //
    // NetworkInterface

    @Nullable
    @Override
    public byte[] readEthernetFrame() {
        return toNetwork.pollFirst();
    }

    @Override
    public void writeEthernetFrame(final NetworkInterface source, final byte[] frame, final int timeToLive) {
        if (timeToLive <= 0) {
            return;
        }
        if (connection == null) {
            return;
        }
        enqueue(toInternet, frame);
    }

    // --------------------------------------------------------------------- //
    // InternetAdapter

    @Nullable
    @Override
    public byte[] readInternetFrame() {
        return toInternet.pollFirst();
    }

    @Override
    public void writeInternetFrame(final byte[] frame) {
        enqueue(toNetwork, frame);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void loadServer() {
        super.loadServer();
        InternetManager.getInstance().ifPresent(manager -> connection = manager.connect(this, describeOrigin()));
    }

    @Override
    protected void unloadServer(final boolean isRemove) {
        super.unloadServer(isRemove);
        final InternetConnection connection = this.connection;
        if (connection != null) {
            connection.stop();
            this.connection = null;
        }
        toNetwork.clear();
        toInternet.clear();
    }

    @Override
    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
        collector.offer(Capabilities.NETWORK_INTERFACE, this);
        collector.offer(Capabilities.ENERGY_STORAGE, energy);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);

        tag.method_10556(OPERATIONAL_TAG_NAME, isOperational);

        return tag;
    }

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        tag.method_10566(Constants.ENERGY_TAG_NAME, energy.serializeNBT());
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        energy.deserializeNBT(tag.method_10562(Constants.ENERGY_TAG_NAME));
        isOperational = tag.method_10577(OPERATIONAL_TAG_NAME);
    }

    // --------------------------------------------------------------------- //

    private void enqueue(final Deque<byte[]> queue, final byte[] frame) {
        if (frame.length > InternetConnection.MAX_FRAME_SIZE) {
            return;
        }
        if (queue.size() >= InternetConnection.FRAME_QUEUE_SIZE) {
            return;
        }
        if (!tryConsumeEnergy()) {
            return;
        }
        queue.addLast(frame);
    }

    private String describeOrigin() {
        final class_1937 level = method_10997();
        final String dimension = level != null ? level.method_27983().method_29177().toString() : "?";
        final class_2338 pos = method_11016();
        return dimension + " " + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
    }

    private boolean computeIsOperational() {
        if (connection == null) {
            // Internet access is switched off server-side, or the stack could not start. The block
            // is inert either way, and showing it as running would be a lie.
            return false;
        }
        if (!Config.internetGatewaysUseEnergy()) {
            return true;
        }
        final long stored = energy.getEnergyStored();
        if (stored >= Config.internetGatewayEnergyPerPacket) {
            return true;
        }
        return stored > 0 && isOperational;
    }

    private boolean tryConsumeEnergy() {
        if (!Config.internetGatewaysUseEnergy()) {
            return true;
        }
        if (energy.extractEnergy(Config.internetGatewayEnergyPerPacket, true)
            < Config.internetGatewayEnergyPerPacket) {
            return false;
        }
        energy.extractEnergy(Config.internetGatewayEnergyPerPacket, false);

        final class_1937 level = method_10997();
        if (level != null) {
            ChunkUtils.setLazyUnsaved(level, method_11016());
        }
        return true;
    }
}
