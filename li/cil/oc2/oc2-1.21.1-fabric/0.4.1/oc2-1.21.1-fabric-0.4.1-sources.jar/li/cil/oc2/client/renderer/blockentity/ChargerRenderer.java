/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer.blockentity;

import li.cil.oc2.api.API;
import li.cil.oc2.client.renderer.IndicatorRenderer;
import li.cil.oc2.client.renderer.ModRenderType;
import li.cil.oc2.common.blockentity.ChargerBlockEntity;
import net.minecraft.class_1723;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class ChargerRenderer implements class_827<ChargerBlockEntity> {
    public static final class_2960 EFFECT_LOCATION = class_2960.method_60655(API.MOD_ID, "block/charger/effect");

    private static final class_4730 TEXTURE_EFFECT = new class_4730(class_1723.field_21668, EFFECT_LOCATION);

    private static final int EFFECT_LAYERS = 3;
    private static final float EFFECT_HEIGHT = 0.5f;
    private static final float EFFECT_SPEED = 0.3f;
    private static final float EFFECT_SCALE_START = 0.6f;
    private static final float EFFECT_SCALE_END = 0.8f;

    private static final Vector3f INDICATOR_COLOR = new Vector3f(1f, 0.8f, 0.3f);
    private static final Vector3f INDICATOR_COLOR_BRIGHT = new Vector3f(1f, 1f, 0.7f);

    private static final class_238 INDICATOR_BOUNDS = new class_238(1 / 16.0, 12 / 16.0, 1 / 16.0, 15 / 16.0, 15 / 16.0, 15 / 16.0);

    // --------------------------------------------------------------------- //

    public ChargerRenderer(final class_5614.class_5615 ignoredContext) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public void render(final ChargerBlockEntity charger, final float partialTicks, final class_4587 stack, final class_4597 bufferSource, final int light, final int overlay) {
        if (!charger.hasEnergy()) {
            return;
        }

        final class_1937 level = charger.method_10997();
        final long gameTime = level != null ? level.method_8510() : 0;
        final float offset = (gameTime + partialTicks) * EFFECT_SPEED / 20f % (float) (Math.PI * 2);

        IndicatorRenderer.render(stack, bufferSource, INDICATOR_BOUNDS, INDICATOR_COLOR, INDICATOR_COLOR_BRIGHT, gameTime, partialTicks);

        stack.method_22903();
        stack.method_22904(0.5, 1.1, 0.5);

        final class_4588 consumer = TEXTURE_EFFECT.method_24145(bufferSource, ModRenderType::getUnlitBlock);

        for (int i = 0; i < EFFECT_LAYERS; i++) {
            final float relativeY = (1 + class_3532.method_15374(offset + ((float) Math.PI * 2f * i / EFFECT_LAYERS))) * 0.5f;
            final float y = relativeY * EFFECT_HEIGHT;
            final float scale = EFFECT_SCALE_START + relativeY * (EFFECT_SCALE_END - EFFECT_SCALE_START);

            stack.method_22903();
            stack.method_46416(0, y, 0);
            renderScaledQuad(stack, consumer, scale);
            stack.method_22909();
        }

        stack.method_22909();
    }

    private static void renderScaledQuad(final class_4587 stack, final class_4588 consumer, final float scale) {
        stack.method_22903();
        stack.method_22905(scale, scale, scale);
        renderQuad(stack.method_23760().method_23761(), consumer);
        stack.method_22909();
    }

    private static void renderQuad(final Matrix4f matrix, final class_4588 consumer) {
        // Not chained: vanilla's SpriteCoordinateExpander.addVertex returns the delegate, so a
        // chained setUv would bypass the sprite remap (NeoForge patches this, Fabric does not).
        consumer.method_22918(matrix, -0.5f, 0, -0.5f);
        consumer.method_22913(0, 0);

        consumer.method_22918(matrix, -0.5f, 0, 0.5f);
        consumer.method_22913(0, 1);

        consumer.method_22918(matrix, 0.5f, 0, 0.5f);
        consumer.method_22913(1, 1);

        consumer.method_22918(matrix, 0.5f, 0, -0.5f);
        consumer.method_22913(1, 0);
    }
}
