/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.blockentity;

import li.cil.oc2.common.capabilities.Capabilities;
import li.cil.oc2.common.capabilities.CapabilityType;
import li.cil.oc2.common.util.ServerScheduler;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import javax.annotation.Nullable;

public abstract class ModBlockEntity extends class_2586 {
    private final Runnable onWorldUnloaded = this::onWorldUnloaded;
    private boolean needsWorldUnloadEvent;
    private boolean isUnloaded;

    // --------------------------------------------------------------------- //

    protected ModBlockEntity(final class_2591<?> blockEntityType, final class_2338 pos, final class_2680 state) {
        super(blockEntityType, pos, state);
    }

    // --------------------------------------------------------------------- //

    @Nullable
    public <T> T getCapability(final CapabilityType<T> capability, @Nullable final class_2350 side) {
        if (!isValid()) {
            return null;
        }

        final SingleResultCollector<T> collector = new SingleResultCollector<>(capability);
        collectCapabilities(collector, side);

        return collector.result;
    }

    @Override
    public void method_10996() {
        super.method_10996();

        if (field_11863 == null) {
            return;
        }

        if (field_11863.method_8608()) {
            loadClient();
        } else {
            loadServer();

            ServerScheduler.schedule(field_11863, () -> {
                if (isValid()) {
                    loadServerInLoadedLevel();
                }
            });

            if (needsWorldUnloadEvent) {
                ServerScheduler.scheduleOnUnload(field_11863, onWorldUnloaded);
            }
        }
    }

    public void handleChunkUnloaded() {
        Capabilities.invalidate(this);
        onUnload(false);
        isUnloaded = true;
    }

    public void onWorldUnloaded() {
        Capabilities.invalidate(this);
        onUnload(false);
        isUnloaded = true;
    }

    @Override
    public void method_11012() {
        super.method_11012();
        Capabilities.invalidate(this);
        if (!isUnloaded) {
            onUnload(true);
        }
    }

    public boolean isValid() {
        return !method_11015() && !isUnloaded;
    }

    @Nullable
    public class_238 getExpandedRenderBoundingBox() {
        return null;
    }

    // --------------------------------------------------------------------- //

    protected void onUnload(final boolean isRemove) {
        if (field_11863 != null && !field_11863.method_8608()) {
            unloadServer(isRemove);
            ServerScheduler.cancelOnUnload(field_11863, onWorldUnloaded);
        }
    }

    protected void setNeedsLevelUnloadEvent() {
        needsWorldUnloadEvent = true;
    }

    protected void collectCapabilities(final CapabilityCollector collector, @Nullable final class_2350 direction) {
    }

    protected void loadClient() {
    }

    protected void loadServer() {
    }

    protected void loadServerInLoadedLevel() {
    }

    protected void unloadServer(final boolean isRemove) {
    }

    // --------------------------------------------------------------------- //

    @FunctionalInterface
    protected interface CapabilityCollector {
        <T> void offer(CapabilityType<T> capability, T instance);
    }

    private static final class SingleResultCollector<T> implements CapabilityCollector {
        private final CapabilityType<T> capability;
        @Nullable
        private T result;

        private SingleResultCollector(final CapabilityType<T> capability) {
            this.capability = capability;
        }

        @SuppressWarnings("unchecked")
        @Override
        public <TOffered> void offer(final CapabilityType<TOffered> offeredCapability, final TOffered instance) {
            if (result == null && offeredCapability == capability) {
                result = (T) instance;
            }
        }
    }
}
