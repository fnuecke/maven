/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.oc2.api.bus.device.io;

import javax.annotation.ParametersAreNonnullByDefault;
