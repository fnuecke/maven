/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.bus.device.provider.block;

import li.cil.oc2.api.bus.device.Device;
import li.cil.oc2.api.bus.device.provider.BlockDeviceProvider;
import li.cil.oc2.api.bus.device.provider.BlockDeviceQuery;
import li.cil.oc2.api.util.Invalidatable;
import li.cil.oc2.common.block.FlashDriveBlock;
import li.cil.oc2.common.blockentity.FlashDriveBlockEntity;
import li.cil.oc2.common.bus.device.vm.block.FlashDriveDevice;
import net.minecraft.class_2586;

public final class FlashDriveDeviceProvider implements BlockDeviceProvider {
    @Override
    public Invalidatable<Device> getDevice(final BlockDeviceQuery query) {
        final class_2586 blockEntity = query.getLevel().method_8321(query.getQueryPosition());
        if (!(blockEntity instanceof final FlashDriveBlockEntity drive)) {
            return Invalidatable.empty();
        }

        final boolean isMountingSide = query.getQuerySide() == drive.method_11010().method_11654(FlashDriveBlock.FACING).method_10153();
        if (!isMountingSide) {
            return Invalidatable.empty();
        }

        var device = drive.getDevice();
        if (device == null) {
            device = new FlashDriveDevice(drive);
            drive.setDevice(device);
        }

        return Invalidatable.of(device);
    }
}
