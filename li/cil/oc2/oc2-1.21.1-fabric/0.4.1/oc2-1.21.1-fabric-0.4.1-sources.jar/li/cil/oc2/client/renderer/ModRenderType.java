/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.renderer;

import li.cil.oc2.api.API;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public abstract class ModRenderType extends class_1921 {
    private static final class_1921 NETWORK_CABLE = method_24049(
        API.MOD_ID + "/network_cable",
        class_290.field_21468,
        class_293.class_5596.field_27382,
        256,
        false,
        false,
        class_4688.method_23598()
            .method_34578(field_29437)
            .method_34577(field_21378)
            .method_23615(field_21364)
            .method_23603(field_21345)
            .method_23608(field_21383)
            .method_23617(false));

    private static final class_1921 INDICATOR = method_24049(
        API.MOD_ID + "/indicator",
        class_290.field_1576,
        class_293.class_5596.field_27382,
        256,
        false,
        false,
        class_4688.method_23598()
            .method_34578(field_29442)
            .method_34577(field_21378)
            .method_23615(field_21364)
            .method_23607(field_21353)
            .method_23617(false));

    private static final class_1921 PROJECTOR_LIGHT = method_24049(
        API.MOD_ID + "/projector_light",
        class_290.field_1576,
        class_293.class_5596.field_27382,
        256,
        false,
        true,
        class_4688.method_23598()
            .method_34578(field_29429)
            .method_23615(field_21367)
            .method_23616(field_21350)
            .method_23603(field_21345)
            .method_23617(false));

    private static final Function<class_2960, class_1921> UNLIT_BLOCK = class_156.method_34866(location -> method_24049(
        API.MOD_ID + "/unlit_block/" + location,
        class_290.field_1585,
        class_293.class_5596.field_27382,
        256,
        false,
        true,
        class_4688.method_23598()
            .method_34578(field_29440)
            .method_34577(new class_4683(location, false, true))
            .method_23615(field_21366)
            .method_23603(field_21345)
            .method_23617(false)));

    private static final Function<class_2960, class_1921> OVERLAY = class_156.method_34866(location -> method_24049(
        API.MOD_ID + "/overlay/" + location,
        class_290.field_1585,
        class_293.class_5596.field_27382,
        256,
        false,
        true,
        class_4688.method_23598()
            .method_34578(field_29440)
            .method_34577(new class_4683(location, false, true))
            .method_23615(field_21366)
            .method_23617(false)));

    // --------------------------------------------------------------------- //

    public static class_1921 getNetworkCable() {
        return NETWORK_CABLE;
    }

    public static class_1921 getIndicator() {
        return INDICATOR;
    }

    public static class_1921 getProjectorLight() {
        return PROJECTOR_LIGHT;
    }

    public static class_1921 getUnlitBlock(final class_2960 location) {
        return UNLIT_BLOCK.apply(location);
    }

    public static class_1921 getOverlay(final class_2960 location) {
        return OVERLAY.apply(location);
    }

    // --------------------------------------------------------------------- //

    private ModRenderType(final String name, final class_293 format, final class_293.class_5596 drawMode, final int bufferSize, final boolean useDelegate, final boolean needsSorting, final Runnable setupTask, final Runnable clearTask) {
        super(name, format, drawMode, bufferSize, useDelegate, needsSorting, setupTask, clearTask);
    }
}
