/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import li.cil.oc2.common.Config;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.TickableBlockEntity;
import li.cil.oc2.common.item.TooltipUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2373;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3620;
import net.minecraft.class_5558;
import net.minecraft.world.level.block.*;
import javax.annotation.Nullable;
import java.util.List;

public final class ChargerBlock extends class_2373 implements class_2343 {
    public ChargerBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664().method_11657(class_2383.field_11177, class_2350.field_11043));
    }

    // --------------------------------------------------------------------- //

    @Environment(EnvType.CLIENT)
    @Override
    public void method_9568(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_9568(stack, context, tooltip, advanced);
        if (Config.chargersUseEnergy()) {
            TooltipUtils.addEnergyConsumption(0, Config.chargerEnergyPerTick, tooltip);
        }
    }

    @Override
    public class_2680 method_9598(final class_2680 state, final class_2470 rot) {
        return state.method_11657(class_2383.field_11177, rot.method_10503(state.method_11654(class_2383.field_11177)));
    }

    @Override
    public class_2680 method_9569(final class_2680 state, final class_2415 mirrorIn) {
        return state.method_26186(mirrorIn.method_10345(state.method_11654(class_2383.field_11177)));
    }

    @Override
    public class_2680 method_9605(final class_1750 context) {
        return super.method_9564().method_11657(class_2383.field_11177, context.method_8042().method_10153());
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.CHARGER.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        return TickableBlockEntity.createServerTicker(level, type, BlockEntities.CHARGER.get());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(class_2383.field_11177);
    }
}
