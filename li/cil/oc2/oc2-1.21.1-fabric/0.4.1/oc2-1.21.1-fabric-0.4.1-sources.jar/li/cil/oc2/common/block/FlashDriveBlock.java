/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.FlashDriveBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import javax.annotation.Nullable;
import java.util.Map;

public final class FlashDriveBlock extends class_2248 implements class_2343 {
    public static final MapCodec<FlashDriveBlock> CODEC = MapCodec.unit(FlashDriveBlock::new);

    public static final class_2753 FACING = class_2741.field_12525;
    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 3);

    private static final Map<class_2350, class_265> SHAPES = Map.of(
        class_2350.field_11036, method_9541(0, 0, 0, 16, 8, 16),
        class_2350.field_11033, method_9541(0, 8, 0, 16, 16, 16),
        class_2350.field_11043, method_9541(0, 0, 8, 16, 16, 16),
        class_2350.field_11035, method_9541(0, 0, 0, 16, 16, 8),
        class_2350.field_11034, method_9541(0, 0, 0, 8, 16, 16),
        class_2350.field_11039, method_9541(8, 0, 0, 16, 16, 16)
    );

    // --------------------------------------------------------------------- //

    public FlashDriveBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664()
            .method_11657(FACING, class_2350.field_11036)
            .method_11657(ROTATION, 0));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected MapCodec<? extends FlashDriveBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected class_265 method_9530(final class_2680 state, final class_1922 level, final class_2338 pos, final class_3726 context) {
        return SHAPES.get(state.method_11654(FACING));
    }

    @Override
    public class_2680 method_9605(final class_1750 context) {
        final class_2350 top = context.method_8038();
        return method_9564()
            .method_11657(FACING, top)
            .method_11657(ROTATION, getRotationForPlacement(top, context.method_8042()));
    }

    private static int getRotationForPlacement(final class_2350 top, final class_2350 horizontalDirection) {
        if (top.method_10166().method_10179()) {
            return 0;
        }

        final int away = (int) horizontalDirection.method_10144();
        final int degrees = top == class_2350.field_11036 ? away + 180 : away;
        return degrees % 360 / 90;
    }

    @Override
    protected class_9062 method_55765(final class_1799 heldStack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final FlashDriveBlockEntity drive) {
            final class_9062 result = drive.useWith(level, heldStack, player, hand);
            if (result != class_9062.field_47731) {
                return result;
            }
        }

        return super.method_55765(heldStack, state, level, pos, player, hand, hit);
    }

    @Override
    protected class_1269 method_55766(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final FlashDriveBlockEntity drive) {
            final class_1269 result = drive.useWithoutItem(level, player);
            if (result != class_1269.field_5811) {
                return result;
            }
        }

        return super.method_55766(state, level, pos, player, hit);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.FLASH_DRIVE.get().method_11032(pos, state);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING, ROTATION);
    }

    @Override
    protected void method_9536(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2680 newState, final boolean movedByPiston) {
        if (!state.method_27852(newState.method_26204())) {
            final class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof final FlashDriveBlockEntity drive) {
                drive.dropMedia();
            }
        }

        super.method_9536(state, level, pos, newState, movedByPiston);
    }
}
