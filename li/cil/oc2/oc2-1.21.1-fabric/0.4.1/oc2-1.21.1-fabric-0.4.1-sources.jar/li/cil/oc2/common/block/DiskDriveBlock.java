/* SPDX-License-Identifier: MIT */

package li.cil.oc2.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.oc2.common.blockentity.BlockEntities;
import li.cil.oc2.common.blockentity.DiskDriveBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import javax.annotation.Nullable;

public final class DiskDriveBlock extends class_2383 implements class_2343 {
    public static final MapCodec<DiskDriveBlock> CODEC = MapCodec.unit(DiskDriveBlock::new);

    // --------------------------------------------------------------------- //

    public DiskDriveBlock() {
        super(class_2251
            .method_9637()
            .method_31710(class_3620.field_16005)
            .method_9626(class_2498.field_11533)
            .method_9629(1.5f, 6.0f));
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    // --------------------------------------------------------------------- //

    @Override
    protected MapCodec<? extends DiskDriveBlock> method_53969() {
        return field_46280;
    }

    @Override
    public class_2680 method_9605(final class_1750 context) {
        return super.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    protected class_9062 method_55765(final class_1799 heldStack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final DiskDriveBlockEntity diskDrive) {
            final class_9062 result = diskDrive.useWith(level, heldStack, player, hand);
            if (result != class_9062.field_47731) {
                return result;
            }
        }

        return super.method_55765(heldStack, state, level, pos, player, hand, hit);
    }

    @Override
    protected class_1269 method_55766(final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final DiskDriveBlockEntity diskDrive) {
            final class_1269 result = diskDrive.useWithoutItem(level, player);
            if (result != class_1269.field_5811) {
                return result;
            }
        }

        return super.method_55766(state, level, pos, player, hit);
    }

    // --------------------------------------------------------------------- //
    // EntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.DISK_DRIVE.get().method_11032(pos, state);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(field_11177);
    }

    @Override
    protected void method_9536(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2680 newState, final boolean movedByPiston) {
        if (!state.method_27852(newState.method_26204())) {
            final class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof final DiskDriveBlockEntity drive) {
                drive.dropMedia();
            }
        }

        super.method_9536(state, level, pos, newState, movedByPiston);
    }
}
