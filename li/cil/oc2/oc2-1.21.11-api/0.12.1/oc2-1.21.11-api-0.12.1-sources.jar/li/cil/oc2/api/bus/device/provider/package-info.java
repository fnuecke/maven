/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@NullMarked
package li.cil.oc2.api.bus.device.provider;

import org.jspecify.annotations.NullMarked;

import javax.annotation.ParametersAreNonnullByDefault;
