/* SPDX-License-Identifier: MIT */

package li.cil.oc2.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import li.cil.oc2.client.ClientPlatform;
import li.cil.oc2.common.blockentity.KeyboardBlockEntity;
import li.cil.oc2.common.bus.device.block.KeyboardDevice;
import li.cil.oc2.common.item.Items;
import li.cil.oc2.common.network.Network;
import li.cil.oc2.common.network.message.KeyboardInputMessage;
import li.cil.oc2.common.network.message.KeyboardKeepAliveMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import org.lwjgl.glfw.GLFW;

public final class KeyboardScreen extends Screen {
    private static final int BORDER_SIZE = 4;
    private static final float ARM_SWING_RATE = 0.8f;
    private static final int BORDER_COLOR = 0xFFFFFFFF;

    private static final MutableComponent CLOSE_INFO = Component.translatable("gui.oc2.keyboard.close_info");

    // --------------------------------------------------------------------- //

    private final KeyboardBlockEntity keyboard;
    private final IntSet pressedKeys = new IntOpenHashSet();
    private int keepAliveCountdown;

    // --------------------------------------------------------------------- //

    public static void open(final KeyboardBlockEntity keyboard) {
        Minecraft.getInstance().setScreen(new KeyboardScreen(keyboard));
    }

    // --------------------------------------------------------------------- //

    public KeyboardScreen(final KeyboardBlockEntity keyboard) {
        super(Items.KEYBOARD.get().getName());
        this.keyboard = keyboard;
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void init() {
        super.init();

        // Grabbing the mouse allows us to let the player keep turning the camera (to get a better
        // look at the projection of a projector, e.g.), while still grabbing all keyboard input.
        grabMouse();

        // Disable hotbar since we don't need it here, and it just blocks screen space.
        ClientPlatform.setHotbarVisible(false);
    }

    @Override
    public void tick() {
        super.tick();

        if (AbstractBlockEntityScreen.isStillValid(keyboard)) {
            sendKeepAlive();
        } else {
            onClose();
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean keyPressed(final KeyEvent event) {
        if (pressedKeys.add(event.key())) {
            sendInputMessage(event.key(), true);
        }

        return true;
    }

    @Override
    public boolean keyReleased(final KeyEvent event) {
        if (pressedKeys.remove(event.key())) {
            sendInputMessage(event.key(), false);
        }

        return true;
    }

    @Override
    public boolean mouseClicked(final MouseButtonEvent event, final boolean isDoubleClick) {
        if (event.button() == GLFW.GLFW_MOUSE_BUTTON_2) {
            onClose();
            return true;
        } else {
            return super.mouseClicked(event, isDoubleClick);
        }
    }

    @Override
    public void renderBackground(final GuiGraphics graphics, final int mouseX, final int mouseY, final float partialTicks) {
        // This page intentionally left blank.
    }

    @Override
    public void render(final GuiGraphics graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.render(graphics, mouseX, mouseY, partialTicks);

        renderBorderOverlay(graphics);

        graphics.drawWordWrap(font, CLOSE_INFO,
            BORDER_SIZE * 3, height - BORDER_SIZE * 3 - font.lineHeight,
            width - BORDER_SIZE * 6, 0x88FFFFFF);
    }

    @Override
    public void removed() {
        super.removed();

        if (minecraft.getConnection() != null) {
            for (final int keycode : pressedKeys) {
                sendKeyState(keycode, false);
            }
        }
        pressedKeys.clear();

        ClientPlatform.setHotbarVisible(true);
    }

    // --------------------------------------------------------------------- //

    private void renderBorderOverlay(final GuiGraphics graphics) {
        graphics.fill(BORDER_SIZE, BORDER_SIZE, width - BORDER_SIZE, BORDER_SIZE * 2, BORDER_COLOR);
        graphics.fill(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE * 2, height - BORDER_SIZE, BORDER_COLOR);
        graphics.fill(BORDER_SIZE, height - BORDER_SIZE * 2, width - BORDER_SIZE, height - BORDER_SIZE, BORDER_COLOR);
        graphics.fill(width - BORDER_SIZE * 2, BORDER_SIZE, width - BORDER_SIZE, height - BORDER_SIZE, BORDER_COLOR);
    }

    private void grabMouse() {
        final MouseHandler mouseHandler = minecraft.mouseHandler;
        mouseHandler.mouseGrabbed = true;
        InputConstants.grabOrReleaseMouse(minecraft.getWindow(), InputConstants.CURSOR_DISABLED, mouseHandler.xpos(), mouseHandler.ypos());
    }

    private void sendKeepAlive() {
        if (--keepAliveCountdown <= 0) {
            keepAliveCountdown = KeyboardDevice.USER_KEEPALIVE_EVERY;
            Network.sendToServer(new KeyboardKeepAliveMessage(keyboard));
        }
    }

    private void sendInputMessage(final int keycode, final boolean isDown) {
        if (KeyCodeMapping.MAPPING.containsKey(keycode)) {
            swingArm();
            sendKeyState(keycode, isDown);
        }
    }

    private void sendKeyState(final int keycode, final boolean isDown) {
        if (KeyCodeMapping.MAPPING.containsKey(keycode)) {
            final int evdevCode = KeyCodeMapping.MAPPING.get(keycode);
            Network.sendToServer(new KeyboardInputMessage(keyboard, evdevCode, isDown));
        }
    }

    private void swingArm() {
        final LocalPlayer player = minecraft.player;
        if (player == null) {
            return;
        }

        final RandomSource random = player.getRandom();
        if (random.nextFloat() < ARM_SWING_RATE) {
            return;
        }

        final InteractionHand handToSwing;
        if (minecraft.options.getCameraType().isFirstPerson()) {
            handToSwing = InteractionHand.MAIN_HAND;
        } else {
            handToSwing = random.nextBoolean() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
        }

        player.swing(handToSwing);
    }
}
