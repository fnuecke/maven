@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client.util;

import javax.annotation.ParametersAreNonnullByDefault;
