/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.util;

import li.cil.manual.api.ManualModel;
import li.cil.manual.api.Tab;
import li.cil.manual.api.provider.DocumentProvider;
import li.cil.manual.api.provider.PathProvider;
import li.cil.manual.api.provider.RendererProvider;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public final class Constants {
    public static final String MOD_ID = "markdown_manual";

    // ----------------------------------------------------------------------- //

    public static final class_5321<class_2378<PathProvider>> PATH_PROVIDER_REGISTRY = key("path_provider");
    public static final class_5321<class_2378<DocumentProvider>> DOCUMENT_PROVIDER_REGISTRY = key("document_provider");
    public static final class_5321<class_2378<RendererProvider>> RENDERER_PROVIDER_REGISTRY = key("renderer_provider");
    public static final class_5321<class_2378<Tab>> TAB_REGISTRY = key("tab");
    public static final class_5321<class_2378<ManualModel>> MANUAL_REGISTRY = key("manual");

    // ----------------------------------------------------------------------- //

    private static <T> class_5321<class_2378<T>> key(final String name) {
        return class_5321.method_29180(class_2960.method_60655(MOD_ID, name));
    }

    // ----------------------------------------------------------------------- //

    private Constants() {
    }
}
