/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.content;

import javax.annotation.Nullable;
import net.minecraft.class_2960;
import java.util.List;

public final class Document {
    private final List<String> lines;
    @Nullable private final class_2960 location;

    public Document(final List<String> lines, @Nullable final class_2960 location) {
        this.location = location;
        this.lines = lines;
    }

    public Document(final List<String> lines) {
        this(lines, null);
    }

    public List<String> getLines() {
        return lines;
    }

    @Nullable
    public class_2960 getLocation() {
        return location;
    }
}
