@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.prefab;

import javax.annotation.ParametersAreNonnullByDefault;
