/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.render;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

/**
 * Base interface for font renderers.
 */
public interface FontRenderer {
    /**
     * Render up to the specified amount of characters of the specified string.
     *
     * @param value  the string to render.
     * @param argb   the color to render the string with.
     * @param matrix the current transform matrix.
     * @param buffer the buffer to render the string into.
     */
    void drawInBatch(final CharSequence value, final int argb, final Matrix4f matrix, final class_4597 buffer);

    /**
     * Draws a string in immediate mode.
     *
     * @param graphics the current graphics context.
     * @param value    the string to render.
     * @param argb     the color to render the string with.
     */
    default void draw(final class_332 graphics, final CharSequence value, final int argb) {
        final class_4597.class_4598 buffer = graphics.method_51450();
        drawInBatch(value, argb, graphics.method_51448().method_23760().method_23761(), buffer);
        buffer.method_22993();
    }

    /**
     * Computes the rendered width of the provided character sequence.
     *
     * @param value the value to get the render width for.
     * @return the render width of the specified value.
     */
    int width(final CharSequence value);

    /**
     * Computes the rendered width of the provided text component.
     *
     * @param value the value to get the render width for.
     * @return the render width of the specified value.
     */
    int width(final class_2561 value);

    /**
     * Get the height of the characters drawn with the font renderer, in pixels.
     *
     * @return the height of the drawn characters.
     */
    int lineHeight();
}
