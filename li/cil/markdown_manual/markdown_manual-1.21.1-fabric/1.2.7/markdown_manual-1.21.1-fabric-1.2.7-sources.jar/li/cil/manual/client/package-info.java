@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client;

import javax.annotation.ParametersAreNonnullByDefault;
