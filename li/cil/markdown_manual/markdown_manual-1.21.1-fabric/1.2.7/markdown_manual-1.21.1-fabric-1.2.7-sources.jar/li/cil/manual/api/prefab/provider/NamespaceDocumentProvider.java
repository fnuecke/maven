/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.prefab.provider;

import com.google.common.base.Charsets;
import li.cil.manual.api.content.Document;
import li.cil.manual.api.provider.DocumentProvider;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Optional;

/**
 * Basic implementation of a content provider based on Minecraft's resource
 * loading framework.
 * <p>
 * Beware that the manual is unaware of resource domains. In other words, two
 * paths that are identical except for their resource domain will be the same,
 * as seen from the manual.
 */
public class NamespaceDocumentProvider implements DocumentProvider {
    private final String namespace;
    private final String basePath;

    public NamespaceDocumentProvider(final String namespace, final String basePath) {
        this.namespace = namespace;
        this.basePath = basePath.endsWith("/") ? basePath : (basePath + "/");
    }

    public NamespaceDocumentProvider(final String namespace) {
        this(namespace, "");
    }

    @Override
    public Optional<Document> getDocument(final String path, final String language) {
        final class_3300 resourceManager = class_310.method_1551().method_1478();
        final class_2960 location = class_2960.method_60655(namespace, basePath + path);
        return resourceManager.method_14486(location).flatMap(resource -> {
            try (InputStream stream = resource.method_14482()) {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(stream, Charsets.UTF_8));
                final ArrayList<String> lines = new ArrayList<>();
                String line;
                while ((line = reader.readLine()) != null) {
                    lines.add(line);
                }
                return Optional.of(new Document(lines, location));
            } catch (final Throwable ignored) {
                return Optional.empty();
            }
        });
    }
}
