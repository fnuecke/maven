/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.prefab.tab;

import li.cil.manual.api.Tab;
import net.minecraft.class_2561;
import javax.annotation.Nullable;
import java.util.List;

public abstract class AbstractTab implements Tab {
    private final String path;
    @Nullable private final class_2561 tooltip;

    public AbstractTab(final String path, @Nullable final class_2561 tooltip) {
        this.path = path;
        this.tooltip = tooltip;
    }

    @Override
    public void getTooltip(final List<class_2561> tooltip) {
        if (this.tooltip != null) {
            tooltip.add(this.tooltip);
        }
    }

    @Override
    public String getPath() {
        return this.path;
    }
}
