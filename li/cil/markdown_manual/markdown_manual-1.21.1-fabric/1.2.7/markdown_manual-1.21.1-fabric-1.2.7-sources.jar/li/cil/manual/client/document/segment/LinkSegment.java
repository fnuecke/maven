/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document.segment;

import li.cil.manual.client.document.DocumentRenderer;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import java.util.Optional;

public final class LinkSegment extends TextSegment implements InteractiveSegment {
    private static final int FADE_TIME = 500;

    // --------------------------------------------------------------------- //

    private final String url;
    private final boolean isWebUrl;
    private final boolean isLinkValid;
    private boolean isHovered;
    private long lastHovered = System.currentTimeMillis() - FADE_TIME;

    // --------------------------------------------------------------------- //

    public LinkSegment(final DocumentRenderer document, final Segment parent, final String text, final String url) {
        super(document, parent, text);
        this.url = url;
        this.isWebUrl = url.startsWith("http://") || url.startsWith("https://");
        this.isLinkValid = isWebUrl || model.documentFor(model.resolve(url)).isPresent();
    }

    // --------------------------------------------------------------------- //

    @Override
    public Optional<class_2561> getTooltip() {
        if (style.showLinkTooltip()) {
            return Optional.of(class_2561.method_43470(url));
        } else {
            return Optional.empty();
        }
    }

    @Override
    public boolean mouseClicked() {
        if (isWebUrl) {
            class_156.method_668().method_670(url);
        } else {
            model.push(model.resolve(url));
        }
        return true;
    }

    @Override
    public void setMouseHovered(final boolean value) {
        isHovered = value;
        if (!value) {
            lastHovered = System.currentTimeMillis();
        }
    }

    @Override
    public String toString() {
        return String.format("[%s](%s)", super.toString(), url);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected int getColor() {
        final int color, hoverColor;
        if (isLinkValid) {
            color = style.getRegularLinkColor();
            hoverColor = style.getHoveredLinkColor();
        } else {
            color = style.getRegularDeadLinkColor();
            hoverColor = style.getHoveredDeadLinkColor();
        }

        final int timeSinceHover = isHovered ? 0 : (int) (System.currentTimeMillis() - lastHovered);
        if (timeSinceHover <= FADE_TIME) {
            return fadeColor(hoverColor, color, timeSinceHover / (float) FADE_TIME);
        } else {
            return color;
        }
    }

    @Override
    protected String getFormat() {
        if (isHovered) {
            return super.getFormat() + class_124.field_1073;
        } else {
            return super.getFormat();
        }
    }

    // --------------------------------------------------------------------- //

    private static int fadeColor(final int color1, final int color2, final float t) {
        final int a1 = (color1 >>> 24) & 0xFF;
        final int r1 = (color1 >>> 16) & 0xFF;
        final int g1 = (color1 >>> 8) & 0xFF;
        final int b1 = color1 & 0xFF;
        final int a2 = (color2 >>> 24) & 0xFF;
        final int r2 = (color2 >>> 16) & 0xFF;
        final int g2 = (color2 >>> 8) & 0xFF;
        final int b2 = color2 & 0xFF;
        final int a = (int) (a1 + (a2 - a1) * t);
        final int r = (int) (r1 + (r2 - r1) * t);
        final int g = (int) (g1 + (g2 - g1) * t);
        final int b = (int) (b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
