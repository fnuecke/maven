/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document.segment.render;

import li.cil.manual.api.render.InteractiveContentRenderer;
import li.cil.manual.api.util.Constants;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class MissingContentRenderer extends TextureContentRenderer implements InteractiveContentRenderer {
    private static final class_2960 LOCATION_GUI_MANUAL_MISSING = class_2960.method_60655(Constants.MOD_ID, "textures/gui/missing.png");

    private final class_2561 tooltip;

    // --------------------------------------------------------------------- //

    public MissingContentRenderer(final class_2561 tooltip) {
        super(LOCATION_GUI_MANUAL_MISSING);
        this.tooltip = tooltip;
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_2561 getTooltip(final class_2561 tooltip) {
        return this.tooltip;
    }
}
