/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.prefab.item;

import li.cil.manual.api.ManualModel;
import li.cil.manual.api.ManualScreenStyle;
import li.cil.manual.api.ManualStyle;
import li.cil.manual.api.util.ShowManualScreenEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import javax.annotation.Nullable;

/**
 * Base class that may be used for manual items, used as a representation of some manual and
 * to open said manual.
 */
public abstract class AbstractManualItem extends class_1792 {
    protected AbstractManualItem(final class_1793 properties) {
        super(properties);
    }

    // --------------------------------------------------------------------- //
    // Item

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1937 world = context.method_8045();
        if (world.method_8608()) {
            openManualFor(context, world);
        }
        return class_1269.method_29236(world.method_8608());
    }

    @Override
    public class_1271<class_1799> method_7836(final class_1937 world, final class_1657 player, final class_1268 hand) {
        if (world.method_8608()) {
            openManual(player);
        }
        return class_1271.method_29237(player.method_5998(hand), world.method_8608());
    }

    // --------------------------------------------------------------------- //

    /**
     * The manual instance represented by this item.
     *
     * @return the manual.
     */
    protected abstract ManualModel getManualModel();

    /**
     * The style used when displaying the manual.
     *
     * @return the style.
     */
    @Nullable
    protected ManualStyle getManualStyle() {
        return null;
    }

    /**
     * The style used for the default manual screen.
     *
     * @return the screen style.
     */
    @Nullable
    protected ManualScreenStyle getScreenStyle() {
        return null;
    }

    /**
     * Opens the {@link net.minecraft.class_437} used to display the manual represented by this item.
     * <p>
     * By default, this will open the built-in manual screen, which can be customized using the style returned by
     * {@link #getManualStyle()} and {@link #getScreenStyle()}. To use a custom screen implementation, override this
     * method.
     */
    protected void showManualScreen() {
        ShowManualScreenEvent.SHOW_MANUAL_SCREEN_EVENT.invoker()
            .accept(new ShowManualScreenEvent(getManualModel(), getManualStyle(), getScreenStyle()));
    }

    // --------------------------------------------------------------------- //

    private void openManualFor(final class_1838 context, final class_1937 world) {
        final ManualModel model = getManualModel();
        model.reset();
        model.pathFor(world, context.method_8037(), context.method_8038()).ifPresent(model::push);
        showManualScreen();
    }

    private void openManual(final class_1657 player) {
        final ManualModel manual = getManualModel();
        if (player.method_5715()) {
            manual.reset();
        }
        showManualScreen();
    }
}
