/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document.segment;

import li.cil.manual.api.render.ContentRenderer;
import li.cil.manual.api.render.InteractiveContentRenderer;
import li.cil.manual.api.util.PathUtils;
import li.cil.manual.client.document.DocumentRenderTypes;
import li.cil.manual.client.document.DocumentRenderer;
import li.cil.manual.client.document.Strings;
import li.cil.manual.client.document.segment.render.MissingContentRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import java.util.Optional;

public final class RenderSegment extends AbstractSegment implements InteractiveSegment {
    private final class_2561 title;
    private final ContentRenderer renderer;

    // --------------------------------------------------------------------- //

    public RenderSegment(final DocumentRenderer document, final Segment parent, final String title, final String url) {
        super(document, parent);
        this.title = class_2561.method_43470(title);

        final String path;
        if (url.contains(":")) {
            // Namespaced URL, don't try to resolve as relative.
            path = url;
        } else if (document.getLocation() != null) {
            // We know where we are, try to resolve path.
            path = PathUtils.resolve(document.getLocation().toString(), url);
        } else {
            // No reference, use as-is.
            path = url;
        }

        final Optional<ContentRenderer> renderer = model.imageFor(path);
        this.renderer = renderer.orElseGet(() -> new MissingContentRenderer(Strings.getMissingContentText(url)));
    }

    // --------------------------------------------------------------------- //

    @Override
    public Optional<class_2561> getTooltip() {
        if (renderer instanceof InteractiveContentRenderer interactiveRenderer) {
            return Optional.of(interactiveRenderer.getTooltip(title));
        } else {
            return Optional.of(title);
        }
    }

    @Override
    public boolean mouseClicked() {
        return renderer instanceof InteractiveContentRenderer interactiveRenderer && interactiveRenderer.mouseClicked();
    }

    @Override
    public int getLineHeight(final int segmentX, final int documentWidth) {
        return imageHeight(segmentX, documentWidth);
    }

    @Override
    public Optional<InteractiveSegment> render(final class_332 graphics, final int segmentX, final int lineHeight, final int documentWidth, final int mouseX, final int mouseY) {
        final int width = imageWidth(segmentX, documentWidth);
        final int height = imageHeight(segmentX, documentWidth);

        final boolean wrapBefore = segmentX >= documentWidth;
        final boolean centerAndWrapAfter = segmentX == 0 || wrapBefore;

        final int x = centerAndWrapAfter ? (documentWidth - width) / 2 : segmentX;
        final int y = wrapBefore ? lineHeight : 0;

        final float scale = scale(segmentX, documentWidth);

        final var pose = graphics.method_51448();
        pose.method_22903();
        pose.method_46416(x, y, 0);
        pose.method_22905(scale, scale, scale);

        final boolean isHovered = mouseX >= x && mouseX <= x + width &&
            mouseY >= y && mouseY <= y + height;
        if (isHovered) {
            DocumentRenderTypes.draw(graphics, DocumentRenderTypes.highlight(), (buffer) -> {
                final var matrix = pose.method_23760().method_23761();

                final float r = 0.2f, g = 0.4f, b = 0.6f, a = 0.25f;

                buffer.method_22918(matrix, 0, renderer.getHeight(), 0).method_22915(r, g, b, a);
                buffer.method_22918(matrix, renderer.getWidth(), renderer.getHeight(), 0).method_22915(r, g, b, a);
                buffer.method_22918(matrix, renderer.getWidth(), 0, 0).method_22915(r, g, b, a);
                buffer.method_22918(matrix, 0, 0, 0).method_22915(r, g, b, a);
            });
        }

        renderer.render(graphics, mouseX, mouseY);

        pose.method_22909();

        return isHovered ? Optional.of(this) : Optional.empty();
    }

    @Override
    public NextSegmentInfo getNext(final int segmentX, final int lineHeight, final int documentWidth) {
        final int width = imageWidth(segmentX, documentWidth);
        final int height = imageHeight(segmentX, documentWidth);

        final boolean wrapBefore = segmentX >= documentWidth;
        final boolean centerAndWrapAfter = segmentX == 0 || wrapBefore;

        final int localX = centerAndWrapAfter ? (documentWidth - width) / 2 : segmentX;
        final int localY = wrapBefore ? lineHeight : 0;

        final int absoluteX = centerAndWrapAfter ? 0 : (localX + width);
        final int relativeY = localY + (centerAndWrapAfter ? height + 1 : 0);
        return new NextSegmentInfo(next, absoluteX, relativeY);
    }

    @Override
    public String toString() {
        return String.format("![%s](%s)", title, renderer);
    }

    // --------------------------------------------------------------------- //

    private int imageWidth(final int segmentX, final int documentWidth) {
        if (segmentX >= documentWidth) {
            return Math.min(documentWidth, renderer.getWidth());
        } else {
            return Math.min(documentWidth - segmentX, renderer.getWidth());
        }
    }

    private int imageHeight(final int segmentX, final int documentWidth) {
        return class_3532.method_15386(renderer.getHeight() * scale(segmentX, documentWidth));
    }

    private float scale(final int segmentX, final int documentWidth) {
        // Only scale down; if necessary, scale down to fill remainder of current line.
        return Math.min(1, imageWidth(segmentX, documentWidth) / (float) renderer.getWidth());
    }
}
