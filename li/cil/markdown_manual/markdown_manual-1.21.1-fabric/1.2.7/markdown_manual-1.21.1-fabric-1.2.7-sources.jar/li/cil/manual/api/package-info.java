@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api;

import javax.annotation.ParametersAreNonnullByDefault;
