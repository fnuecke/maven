/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document.segment;


import li.cil.manual.client.document.DocumentRenderer;
import net.minecraft.class_124;

public final class BoldSegment extends TextSegment {
    public BoldSegment(final DocumentRenderer document, final Segment parent, final String text) {
        super(document, parent, text);
    }

    // --------------------------------------------------------------------- //

    @Override
    public String toString() {
        return String.format("**%s**", super.toString());
    }

    // --------------------------------------------------------------------- //

    @Override
    protected String getFormat() {
        return super.getFormat() + class_124.field_1067;
    }
}
