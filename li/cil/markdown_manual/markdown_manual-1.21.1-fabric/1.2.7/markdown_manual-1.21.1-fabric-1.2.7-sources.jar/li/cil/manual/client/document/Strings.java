/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document;

import li.cil.manual.api.util.Constants;
import net.minecraft.class_1074;
import net.minecraft.class_2561;

public final class Strings {
    public static final class_2561 NO_SUCH_IMAGE = class_2561.method_43471(Constants.MOD_ID + ".warning.missing.image");
    public static final class_2561 NO_SUCH_ITEM = class_2561.method_43471(Constants.MOD_ID + ".warning.missing.item");
    public static final class_2561 NO_SUCH_BLOCK = class_2561.method_43471(Constants.MOD_ID + ".warning.missing.block");
    public static final class_2561 NO_SUCH_TAG = class_2561.method_43471(Constants.MOD_ID + ".warning.missing.tag");

    public static class_2561 getMissingContentText(final String url) {
        return class_2561.method_43469(Constants.MOD_ID + ".warning.missing.content_renderer", url);
    }

    public static String getRedirectionLoopText() {
        return class_1074.method_4662(Constants.MOD_ID + ".warning.redirection_loop");
    }

    // --------------------------------------------------------------------- //

    private Strings() {
    }
}
