/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.prefab.provider;

import li.cil.manual.api.ManualModel;
import li.cil.manual.api.provider.PathProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.Optional;

public class NamespacePathProvider implements PathProvider {
    private static final String NAMESPACE = "%NAMESPACE%";
    private static final String PATH = "%PATH%";
    private static final String BLOCK_PATH_WITH_NAMESPACE = ManualModel.LANGUAGE_KEY + "/%NAMESPACE%/block/%PATH%.md";
    private static final String BLOCK_PATH = ManualModel.LANGUAGE_KEY + "/block/%PATH%.md";
    private static final String ITEM_PATH_WITH_NAMESPACE = ManualModel.LANGUAGE_KEY + "/%NAMESPACE%/item/%PATH%.md";
    private static final String ITEM_PATH = ManualModel.LANGUAGE_KEY + "/item/%PATH%.md";

    private final String namespace;
    private final boolean keepNamespaceInPath;

    public NamespacePathProvider(final String namespace) {
        this(namespace, false);
    }

    public NamespacePathProvider(final String namespace, final boolean keepNamespaceInPath) {
        this.namespace = namespace;
        this.keepNamespaceInPath = keepNamespaceInPath;
    }

    @Override
    public Optional<String> pathFor(final class_1799 stack) {
        if (stack.method_7960()) {
            return Optional.empty();
        }

        final class_1792 item = stack.method_7909();
        final class_2248 block = class_2248.method_9503(item);
        if (block != class_2246.field_10124) {
            final class_2960 blockId = class_7923.field_41175.method_10221(block);
            if (blockId.equals(class_7923.field_41175.method_10137())) {
                return Optional.empty();
            }

            final String blockNamespace = blockId.method_12836();
            if (namespace.equals(blockNamespace)) {
                final String template = keepNamespaceInPath ? BLOCK_PATH_WITH_NAMESPACE : BLOCK_PATH;
                return Optional.of(template
                    .replace(NAMESPACE, namespace)
                    .replace(PATH, blockId.method_12832()));
            }
        } else {
            final class_2960 itemId = class_7923.field_41178.method_10221(item);
            if (itemId.equals(class_7923.field_41178.method_10137())) {
                return Optional.empty();
            }

            final String itemNamespace = itemId.method_12836();
            if (namespace.equals(itemNamespace)) {
                final String template = keepNamespaceInPath ? ITEM_PATH_WITH_NAMESPACE : ITEM_PATH;
                return Optional.of(template
                    .replace(NAMESPACE, namespace)
                    .replace(PATH, itemId.method_12832()));
            }
        }

        return Optional.empty();
    }

    @Override
    public Optional<String> pathFor(final class_1937 world, final class_2338 pos, final class_2350 face) {
        final class_2248 block = world.method_8320(pos).method_26204();
        final class_2960 blockId = class_7923.field_41175.method_10221(block);
        if (blockId.equals(class_7923.field_41175.method_10137())) {
            return Optional.empty();
        }

        final String blockNamespace = blockId.method_12836();
        if (namespace.equals(blockNamespace)) {
            final String template = keepNamespaceInPath ? BLOCK_PATH_WITH_NAMESPACE : BLOCK_PATH;
            return Optional.of(template
                .replace(NAMESPACE, this.namespace)
                .replace(PATH, blockId.method_12832()));
        }

        return Optional.empty();
    }
}
