/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document.segment.render;

import li.cil.manual.api.render.ContentRenderer;
import li.cil.manual.client.document.DocumentRenderTypes;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_1049;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_332;
import java.io.IOException;

public class TextureContentRenderer implements ContentRenderer {
    private final class_2960 location;
    private final ImageTexture texture;

    // --------------------------------------------------------------------- //

    public TextureContentRenderer(final class_2960 location) {
        this.location = location;

        final class_1060 manager = class_310.method_1551().method_1531();
        final class_1044 image = manager.method_4619(location);
        if (image instanceof ImageTexture imageTexture) {
            this.texture = imageTexture;
        } else {
            this.texture = new ImageTexture(location);
            manager.method_4616(location, texture);
            if (!texture.isValid) {
                throw new IllegalArgumentException();
            }
        }
    }

    // --------------------------------------------------------------------- //

    @Override
    public int getWidth() {
        return texture.width;
    }

    @Override
    public int getHeight() {
        return texture.height;
    }

    @Override
    public void render(final class_332 graphics, final int mouseX, final int mouseY) {
        DocumentRenderTypes.draw(graphics, DocumentRenderTypes.texture(location), (buffer) -> {
            final var matrix = graphics.method_51448().method_23760().method_23761();
            buffer.method_22918(matrix, 0, texture.height, 0).method_22913(0, 1);
            buffer.method_22918(matrix, texture.width, texture.height, 0).method_22913(1, 1);
            buffer.method_22918(matrix, texture.width, 0, 0).method_22913(1, 0);
            buffer.method_22918(matrix, 0, 0, 0).method_22913(0, 0);
        });
    }

    // --------------------------------------------------------------------- //

    private static class ImageTexture extends class_1049 {
        private int width;
        private int height;
        private boolean isValid;

        ImageTexture(final class_2960 location) {
            super(location);
        }

        @Override
        public void method_4625(final class_3300 manager) throws IOException {
            super.method_4625(manager);
            final class_4006 textureData = method_18153(manager);
            try {
                final class_1011 nativeImage = textureData.method_18157();
                width = nativeImage.method_4307();
                height = nativeImage.method_4323();
                isValid = true;
            } finally {
                textureData.close();
            }
        }
    }
}
