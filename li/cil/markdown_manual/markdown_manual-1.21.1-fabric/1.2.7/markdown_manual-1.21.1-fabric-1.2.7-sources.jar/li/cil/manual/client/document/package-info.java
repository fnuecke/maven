@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client.document;

import javax.annotation.ParametersAreNonnullByDefault;
