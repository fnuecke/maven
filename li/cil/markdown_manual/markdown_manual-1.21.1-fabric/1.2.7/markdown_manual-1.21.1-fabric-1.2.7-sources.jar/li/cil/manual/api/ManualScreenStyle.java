/* SPDX-License-Identifier: MIT */

package li.cil.manual.api;

import li.cil.manual.api.util.Constants;
import net.minecraft.class_2960;
import net.minecraft.class_768;

/**
 * Style definition that may be used when using the built-in manual
 * screen and requiring the option for additional customizations.
 */
public interface ManualScreenStyle {
    /**
     * Default implementation of a screen style.
     */
    ManualScreenStyle DEFAULT = new ManualScreenStyle() {
    };

    default class_2960 getWindowBackground() {
        return class_2960.method_60655(Constants.MOD_ID, "textures/gui/manual.png");
    }

    default class_2960 getScrollButtonTexture() {
        return class_2960.method_60655(Constants.MOD_ID, "textures/gui/scroll_button.png");
    }

    default class_2960 getTabButtonTexture() {
        return class_2960.method_60655(Constants.MOD_ID, "textures/gui/tab_button.png");
    }

    default class_768 getWindowRect() {
        return new class_768(0, 0, 256, 256);
    }

    default class_768 getDocumentRect() {
        return new class_768(24, 16, 208, 216);
    }

    default class_768 getScrollBarRect() {
        return new class_768(250, 16, 20, 216);
    }

    default class_768 getScrollButtonRect() {
        return new class_768(0, 0, 20, 12);
    }

    default class_768 getTabAreaRect() {
        return new class_768(-52, 25, 64, 216);
    }

    default class_768 getTabRect() {
        return new class_768(0, 0, 64, 24);
    }

    default int getTabOverlap() {
        return 4;
    }

    default int getTabHoverShift() {
        return 20;
    }
}
