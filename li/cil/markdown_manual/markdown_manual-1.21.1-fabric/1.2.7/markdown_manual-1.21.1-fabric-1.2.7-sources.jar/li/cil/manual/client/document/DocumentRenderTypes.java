/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document;

import com.mojang.blaze3d.vertex.*;
import li.cil.manual.api.util.Constants;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import java.util.function.Consumer;

public final class DocumentRenderTypes extends class_1921 {
    private static final class_1921 HIGHLIGHT = method_24049(Constants.MOD_ID + "/highlight",
        class_290.field_1576,
        class_293.class_5596.field_27382, 4,
        false, false,
        class_4688.method_23598()
            .method_34578(field_29442)
            .method_23615(field_21370)
            .method_23616(field_21350)
            .method_23617(false));

    public static class_1921 highlight() {
        return HIGHLIGHT;
    }

    public static class_1921 texture(final class_2960 location) {
        return method_24049(Constants.MOD_ID + "/texture",
            class_290.field_1585,
            class_293.class_5596.field_27382, 4,
            false, false,
            class_4688.method_23598()
                .method_34578(field_29440)
                .method_34577(new class_4683(location, false, false))
                .method_23615(field_21370)
                .method_23616(field_21350)
                .method_23617(false));
    }

    public static void draw(final class_332 graphics, final class_1921 renderType, final Consumer<class_4588> callback) {
        final class_4597.class_4598 bufferSource = graphics.method_51450();
        final class_4588 buffer = bufferSource.getBuffer(renderType);

        callback.accept(buffer);

        bufferSource.method_22993();
    }

    // --------------------------------------------------------------------- //

    private DocumentRenderTypes() {
        super("", class_290.field_1592, class_293.class_5596.field_27382, 256, false, false, () -> {}, () -> {});
        throw new UnsupportedOperationException("No meant to be instantiated.");
    }
}
