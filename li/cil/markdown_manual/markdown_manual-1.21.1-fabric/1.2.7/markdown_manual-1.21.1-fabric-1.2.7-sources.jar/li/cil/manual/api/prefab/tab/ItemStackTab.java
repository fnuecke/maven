/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.prefab.tab;

import javax.annotation.Nullable;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * Simple implementation of a tab icon renderer using an item stack as its graphic.
 */
public final class ItemStackTab extends AbstractTab {
    private final class_1799 stack;

    public ItemStackTab(final String path, @Nullable final class_2561 tooltip, final class_1799 stack) {
        super(path, tooltip);
        this.stack = stack;
    }

    @Override
    public void renderIcon(final class_332 graphics) {
        graphics.method_51445(stack, 0, 0);
    }
}
