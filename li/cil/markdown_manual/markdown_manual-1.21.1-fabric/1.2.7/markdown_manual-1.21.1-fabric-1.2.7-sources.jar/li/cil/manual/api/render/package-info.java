@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.render;

import javax.annotation.ParametersAreNonnullByDefault;
