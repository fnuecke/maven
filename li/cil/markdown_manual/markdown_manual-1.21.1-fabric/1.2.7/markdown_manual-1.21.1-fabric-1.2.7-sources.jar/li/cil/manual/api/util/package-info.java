@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.util;

import javax.annotation.ParametersAreNonnullByDefault;
