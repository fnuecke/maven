/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api;

import javax.annotation.ParametersAreNonnullByDefault;
