/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client.document.segment.render;

import javax.annotation.ParametersAreNonnullByDefault;
