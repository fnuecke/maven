/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client.provider;

import javax.annotation.ParametersAreNonnullByDefault;
