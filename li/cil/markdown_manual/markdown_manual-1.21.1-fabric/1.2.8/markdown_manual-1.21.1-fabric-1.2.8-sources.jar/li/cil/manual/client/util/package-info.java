/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client.util;

import javax.annotation.ParametersAreNonnullByDefault;
