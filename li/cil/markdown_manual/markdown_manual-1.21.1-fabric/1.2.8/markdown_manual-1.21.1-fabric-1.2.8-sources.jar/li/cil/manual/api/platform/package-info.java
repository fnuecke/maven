/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.platform;

import javax.annotation.ParametersAreNonnullByDefault;
