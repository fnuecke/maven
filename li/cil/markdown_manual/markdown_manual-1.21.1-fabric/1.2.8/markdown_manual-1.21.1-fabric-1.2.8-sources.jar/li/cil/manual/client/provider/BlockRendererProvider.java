/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.provider;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import li.cil.manual.api.ManualModel;
import li.cil.manual.api.prefab.provider.AbstractRendererProvider;
import li.cil.manual.api.render.ContentRenderer;
import li.cil.manual.api.util.MatchResult;
import li.cil.manual.client.document.Strings;
import li.cil.manual.client.document.segment.render.ItemStackContentRenderer;
import li.cil.manual.client.document.segment.render.MissingContentRenderer;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2259;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public final class BlockRendererProvider extends AbstractRendererProvider {
    private static final Logger LOGGER = LogManager.getLogger(BlockRendererProvider.class);

    private static final Map<String, class_2680> BLOCK_STATE_CACHE = new HashMap<>();

    // --------------------------------------------------------------------- //

    public BlockRendererProvider() {
        super("block");
    }

    // --------------------------------------------------------------------- //

    @Override
    public MatchResult matches(final ManualModel manual) {
        return MatchResult.MATCH;
    }

    @Override
    protected Optional<ContentRenderer> doGetRenderer(final String data) {
        final class_2680 state = Objects.requireNonNull(BLOCK_STATE_CACHE.computeIfAbsent(data, (string) -> {
            try {
                return class_2259.method_41955(class_7923.field_41175.method_46771(), new StringReader(string), false).comp_622();
            } catch (final CommandSyntaxException e) {
                LOGGER.error("Failed parsing block state.", e);
                return class_2246.field_10124.method_9564();
            }
        }));

        if (state.method_26204() != class_2246.field_10124) {
            return Optional.of(new ItemStackContentRenderer(new class_1799(state.method_26204())));
        } else {
            return Optional.of(new MissingContentRenderer(Strings.NO_SUCH_BLOCK));
        }
    }
}
