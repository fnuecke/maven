/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.prefab.renderer;

import javax.annotation.ParametersAreNonnullByDefault;
