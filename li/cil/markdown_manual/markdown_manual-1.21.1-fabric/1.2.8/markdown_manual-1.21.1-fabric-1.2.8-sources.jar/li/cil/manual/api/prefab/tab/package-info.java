/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.prefab.tab;

import javax.annotation.ParametersAreNonnullByDefault;
