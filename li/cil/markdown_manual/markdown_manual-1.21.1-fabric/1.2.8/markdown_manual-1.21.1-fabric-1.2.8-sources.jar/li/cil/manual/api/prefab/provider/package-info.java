/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.prefab.provider;

import javax.annotation.ParametersAreNonnullByDefault;
