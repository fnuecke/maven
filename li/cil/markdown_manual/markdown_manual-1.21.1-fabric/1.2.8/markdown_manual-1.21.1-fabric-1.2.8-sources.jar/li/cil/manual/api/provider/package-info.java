/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.api.provider;

import javax.annotation.ParametersAreNonnullByDefault;
