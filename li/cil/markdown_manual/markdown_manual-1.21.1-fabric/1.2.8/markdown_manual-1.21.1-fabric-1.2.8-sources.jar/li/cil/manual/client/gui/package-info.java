/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client.gui;

import javax.annotation.ParametersAreNonnullByDefault;
