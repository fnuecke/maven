/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.manual.client.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
