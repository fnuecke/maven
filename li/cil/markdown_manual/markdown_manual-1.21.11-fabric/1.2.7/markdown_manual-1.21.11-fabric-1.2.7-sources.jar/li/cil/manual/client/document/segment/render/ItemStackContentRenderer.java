/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document.segment.render;

import li.cil.manual.api.render.ContentRenderer;
import net.minecraft.class_1799;
import net.minecraft.class_332;

public final class ItemStackContentRenderer implements ContentRenderer {
    /**
     * How long to show individual stacks, in milliseconds, before switching to the next.
     */
    private static final int CYCLE_SPEED = 1000;

    // --------------------------------------------------------------------- //

    private final class_1799[] stacks;

    // --------------------------------------------------------------------- //

    public ItemStackContentRenderer(final class_1799... stacks) {
        this.stacks = stacks;
    }

    // --------------------------------------------------------------------- //

    @Override
    public int getWidth() {
        return 32;
    }

    @Override
    public int getHeight() {
        return 32;
    }

    @Override
    public void render(final class_332 graphics, final int mouseX, final int mouseY) {
        final int index = (int) (System.currentTimeMillis() % (CYCLE_SPEED * stacks.length)) / CYCLE_SPEED;
        final class_1799 stack = stacks[index];

        final float scaleX = getWidth() / 16f;
        final float scaleY = getHeight() / 16f;

        final var pose = graphics.method_51448();

        pose.pushMatrix();
        pose.scale(scaleX, scaleY);

        graphics.method_51445(stack, 0, 0);

        pose.popMatrix();
    }
}
