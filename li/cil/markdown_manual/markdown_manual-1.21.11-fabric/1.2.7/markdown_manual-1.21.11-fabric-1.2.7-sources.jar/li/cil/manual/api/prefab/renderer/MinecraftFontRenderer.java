/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.prefab.renderer;

import li.cil.manual.api.render.FontRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import org.joml.Matrix4f;

/**
 * Implementation of the {@link FontRenderer} interface using the default Minecraft font renderer.
 */
public final class MinecraftFontRenderer implements FontRenderer {
    private final net.minecraft.class_327 font;

    public MinecraftFontRenderer(final net.minecraft.class_327 font) {
        this.font = font;
    }

    @Override
    public void drawInBatch(final CharSequence value, final int argb, final Matrix4f matrix, final class_4597 buffer) {
        font.method_27521(value.toString(), 0, 0, argb, false, matrix, buffer, class_327.class_6415.field_33993, 0, class_765.method_23687(0xF, 0xF));
    }

    @Override
    public void draw(final class_332 graphics, final CharSequence value, final int argb) {
        graphics.method_51433(font, value.toString(), 0, 0, argb, false);
    }

    @Override
    public int width(final CharSequence value) {
        return font.method_1727(value.toString());
    }

    @Override
    public int width(final class_2561 value) {
        return font.method_27525(value);
    }

    @Override
    public int lineHeight() {
        return font.field_2000;
    }
}
