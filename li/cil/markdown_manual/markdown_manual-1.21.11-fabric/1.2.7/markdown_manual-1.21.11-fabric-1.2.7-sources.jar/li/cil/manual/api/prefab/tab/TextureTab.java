/* SPDX-License-Identifier: MIT */

package li.cil.manual.api.prefab.tab;

import javax.annotation.Nullable;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

/**
 * Simple implementation of a tab icon renderer using a full texture as its graphic.
 */
public final class TextureTab extends AbstractTab {
    private final class_2960 location;

    public TextureTab(final String path, @Nullable final class_2561 tooltip, final class_2960 location) {
        super(path, tooltip);
        this.location = location;
    }

    @Override
    public void renderIcon(final class_332 graphics) {
        graphics.method_25290(class_10799.field_56883, location, 0, 0, 0, 0, 16, 16, 16, 16);
    }
}
