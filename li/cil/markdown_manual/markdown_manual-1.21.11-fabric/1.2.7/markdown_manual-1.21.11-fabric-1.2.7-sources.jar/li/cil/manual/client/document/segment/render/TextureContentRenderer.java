/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.document.segment.render;

import li.cil.manual.api.render.ContentRenderer;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_1049;
import net.minecraft.class_10539;
import net.minecraft.class_1060;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_332;
import java.io.IOException;

public class TextureContentRenderer implements ContentRenderer {
    private final class_2960 location;
    private final ImageTexture texture;

    // --------------------------------------------------------------------- //

    public TextureContentRenderer(final class_2960 location) {
        this.location = location;

        final class_1060 manager = class_310.method_1551().method_1531();
        final class_1044 image = manager.method_4619(location);
        if (image instanceof ImageTexture imageTexture) {
            this.texture = imageTexture;
        } else {
            this.texture = new ImageTexture(location);
            manager.method_65876(location, texture);
            if (!texture.isValid) {
                throw new IllegalArgumentException();
            }
        }
    }

    // --------------------------------------------------------------------- //

    @Override
    public int getWidth() {
        return texture.width;
    }

    @Override
    public int getHeight() {
        return texture.height;
    }

    @Override
    public void render(final class_332 graphics, final int mouseX, final int mouseY) {
        graphics.method_25290(class_10799.field_56883, location,
            0, 0, 0, 0,
            texture.width, texture.height,
            texture.width, texture.height);
    }

    // --------------------------------------------------------------------- //

    private static class ImageTexture extends class_1049 {
        private int width;
        private int height;
        private boolean isValid;

        ImageTexture(final class_2960 location) {
            super(location);
        }

        @Override
        public class_10539 method_65809(final class_3300 manager) throws IOException {
            final class_10539 contents = super.method_65809(manager);
            final class_1011 nativeImage = contents.comp_3447();
            width = nativeImage.method_4307();
            height = nativeImage.method_4323();
            isValid = true;
            return contents;
        }
    }
}
