/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.provider;

import li.cil.manual.api.ManualModel;
import li.cil.manual.api.prefab.provider.AbstractRendererProvider;
import li.cil.manual.api.render.ContentRenderer;
import li.cil.manual.api.util.MatchResult;
import li.cil.manual.client.document.Strings;
import li.cil.manual.client.document.segment.render.ItemStackContentRenderer;
import li.cil.manual.client.document.segment.render.MissingContentRenderer;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.Optional;

public final class TagRendererProvider extends AbstractRendererProvider {
    public TagRendererProvider() {
        super("tag");
    }

    // --------------------------------------------------------------------- //

    @Override
    public MatchResult matches(final ManualModel manual) {
        return MatchResult.MATCH;
    }

    @Override
    protected Optional<ContentRenderer> doGetRenderer(final String data) {
        final class_2960 location = class_2960.method_60654(data);
        return class_7923.field_41178.method_40272()
            .filter(tag -> tag.method_40251().comp_327().equals(location))
            .findFirst()
            .map(tag -> (ContentRenderer) new ItemStackContentRenderer(tag
                .method_40239()
                .map(class_1799::new)
                .toArray(class_1799[]::new)
            ))
            .or(() -> Optional.of(new MissingContentRenderer(Strings.NO_SUCH_TAG)));
    }
}
