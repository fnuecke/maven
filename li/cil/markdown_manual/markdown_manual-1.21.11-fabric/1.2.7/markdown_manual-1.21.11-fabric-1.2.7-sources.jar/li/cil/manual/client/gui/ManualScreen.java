/* SPDX-License-Identifier: MIT */

package li.cil.manual.client.gui;

import li.cil.manual.api.ManualModel;
import li.cil.manual.api.ManualScreenStyle;
import li.cil.manual.api.ManualStyle;
import li.cil.manual.api.Tab;
import li.cil.manual.api.content.Document;
import li.cil.manual.client.document.DocumentRenderer;
import li.cil.manual.client.document.segment.InteractiveSegment;
import li.cil.manual.client.util.IterableUtils;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_746;
import net.minecraft.class_768;
import net.minecraft.class_8000;
import org.joml.Vector2i;

import java.util.*;

@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
public final class ManualScreen extends class_437 {
    private final ManualModel model;
    private final ManualStyle manualStyle;
    private final ManualScreenStyle screenStyle;
    private final DocumentRenderer documentRenderer;
    private String currentPath;

    private int leftPos;
    private int topPos;
    private float scrollPos;

    private boolean isDraggingScrollButton;
    private int documentHeight;
    private Optional<InteractiveSegment> currentSegment = Optional.empty();

    private ScrollButton scrollButton;

    public ManualScreen(final ManualModel model, final ManualStyle manualStyle, final ManualScreenStyle screenStyle) {
        super(class_2561.method_43470("Manual"));
        this.model = model;
        this.manualStyle = manualStyle;
        this.screenStyle = screenStyle;
        this.documentRenderer = new DocumentRenderer(model, manualStyle);
    }

    @Override
    public void method_25426() {
        super.method_25426();

        this.leftPos = (field_22789 - screenStyle.getWindowRect().method_3319()) / 2 + screenStyle.getWindowRect().method_3321();
        this.topPos = (field_22790 - screenStyle.getWindowRect().method_3320()) / 2 + screenStyle.getWindowRect().method_3322();

        IterableUtils.forEachWithIndex(model.getTabs(), (i, tab) -> {
            final int x = screenStyle.getTabAreaRect().method_3321();
            final int y = screenStyle.getTabAreaRect().method_3322() + i * getTabClickableHeight();
            if (y + screenStyle.getTabRect().method_3320() > screenStyle.getTabAreaRect().method_3320()) return;
            method_37063(new TabButton(leftPos + x, topPos + y, tab, (button) -> pushManualPage(tab)));
        });

        scrollButton = method_25429(new ScrollButton(
            leftPos + screenStyle.getScrollBarRect().method_3321() + screenStyle.getScrollButtonRect().method_3321(),
            topPos + screenStyle.getScrollBarRect().method_3322() + screenStyle.getScrollButtonRect().method_3322(),
            screenStyle.getScrollButtonRect().method_3319(),
            screenStyle.getScrollButtonRect().method_3320()));
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        method_52752(graphics);

        if (!Objects.equals(currentPath, model.peek())) {
            refreshPage();
            currentPath = model.peek();

            final class_1144 soundHandler = class_310.method_1551().method_1483();
            soundHandler.method_4873(class_1109.method_4758(manualStyle.getPageChangeSound(), 1));
        }

        scrollPos = class_3532.method_16439(partialTicks * 0.5f, scrollPos, getScrollPosition());

        // Don't render scroll button behind manual.
        scrollButton.field_22763 = false;

        // Render tabs behind manual.
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        // Render manual background.
        final class_768 windowRect = screenStyle.getWindowRect();
        graphics.method_25290(class_10799.field_56883, screenStyle.getWindowBackground(), leftPos, topPos, 0, 0, windowRect.method_3319(), windowRect.method_3320(), windowRect.method_3319(), windowRect.method_3320());

        // Render scroll bar tooltip (button will override this tooltip if currently dragging).
        renderScrollbarTooltip(graphics, mouseX, mouseY);

        // Render scroll button in front of manual.
        scrollButton.field_22763 = canScroll();
        scrollButton.method_25394(graphics, mouseX, mouseY, partialTicks);

        final class_768 documentRect = screenStyle.getDocumentRect();
        final int documentX = leftPos + documentRect.method_3321();
        final int documentY = topPos + documentRect.method_3322();

        final var pose = graphics.method_51448();
        pose.pushMatrix();
        pose.translate(documentX, documentY);

        currentSegment = documentRenderer.render(graphics, getSmoothScrollPosition(),
            documentRect.method_3319(), documentRect.method_3320(),
            mouseX - documentX, mouseY - documentY);

        pose.popMatrix();

        currentSegment.flatMap(InteractiveSegment::getTooltip).ifPresent(t ->
            graphics.method_51434(field_22793, Collections.singletonList(t), mouseX, mouseY));
    }

    @Override
    public boolean method_25401(final double mouseX, final double mouseY, final double deltaX, final double deltaY) {
        if (super.method_25401(mouseX, mouseY, deltaX, deltaY)) {
            return true;
        }

        scrollBy(deltaY);
        return true;
    }

    @Override
    public boolean method_25404(final class_11908 event) {
        final class_310 mc = Objects.requireNonNull(field_22787);
        if (mc.field_1690.field_1903.method_1417(event)) {
            popManualPage();
            return true;
        } else if (mc.field_1690.field_1822.method_1417(event)) {
            final class_746 player = mc.field_1724;
            if (player != null) {
                player.method_7346();
            }
            return true;
        } else {
            return super.method_25404(event);
        }
    }

    @Override
    public boolean method_25402(final class_11909 event, final boolean isDoubleClick) {
        final int button = event.method_74245();

        if (canScroll() && button == 0 && isCoordinateOverScrollBar(event.comp_4798(), event.comp_4799())) {
            isDraggingScrollButton = true;
            scrollButton.method_25354(class_310.method_1551().method_1483());
            scrollTo(event.comp_4799());
            return true;
        }

        if (super.method_25402(event, isDoubleClick)) {
            return true;
        }

        if (button == 0) {
            return currentSegment.map(InteractiveSegment::mouseClicked).orElse(false);
        } else if (button == 1) {
            popManualPage();
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25403(final class_11909 event, final double dragX, final double dragY) {
        if (super.method_25403(event, dragX, dragY)) {
            return true;
        }

        if (isDraggingScrollButton) {
            scrollTo(event.comp_4799());
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25406(final class_11909 event) {
        super.method_25406(event);

        if (event.method_74245() == 0) {
            isDraggingScrollButton = false;
        }

        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --------------------------------------------------------------------- //

    private void renderScrollbarTooltip(final class_332 graphics, final int mouseX, final int mouseY) {
        if (isCoordinateOverScrollBar(mouseX, mouseY)) {
            scrollButton.applyTooltip(graphics, mouseX, mouseY, false);
        }
    }

    private void pushManualPage(final Tab tab) {
        model.push(tab.getPath());
    }

    private void popManualPage() {
        if (!model.pop()) {
            method_25419();
        }
    }

    private boolean canScroll() {
        return maxScrollPosition() > 0;
    }

    private int getScrollPosition() {
        return model.getUserData(ScrollOffset.class).
            map(offset -> offset.value).
            orElse(0);
    }

    private void setScrollPosition(final int value) {
        model.setUserData(new ScrollOffset(value));
    }

    private int maxScrollPosition() {
        return Math.max(0, documentHeight - screenStyle.getDocumentRect().method_3320());
    }

    private void refreshPage() {
        final Optional<Document> document = model.documentFor(model.peek());
        documentRenderer.parse(document.orElse(new Document(Collections.singletonList("Page not found: " + model.peek()))));
        documentHeight = documentRenderer.height(screenStyle.getDocumentRect().method_3319());
        scrollPos = getScrollPosition() - manualStyle.getLineHeight() * 3;
    }

    private void scrollTo(final double mouseY) {
        final int scrollButtonHeight = screenStyle.getScrollButtonRect().method_3320();
        final int halfScrollButtonHeight = (int) Math.ceil(scrollButtonHeight * 0.5);
        final int scrollMinY = topPos + screenStyle.getScrollBarRect().method_3322() + halfScrollButtonHeight;
        final int scrollHeight = screenStyle.getScrollBarRect().method_3320() - scrollButtonHeight; // Subtract half button top and bottom.
        final int localMouseY = (int) (mouseY - scrollMinY);
        scrollTo(maxScrollPosition() * localMouseY / scrollHeight, true);
    }

    private void scrollBy(final double amount) {
        scrollTo(getScrollPosition() - (int) Math.round(manualStyle.getLineHeight() * 3 * amount), false);
    }

    private void scrollTo(final int y, final boolean immediate) {
        setScrollPosition(Math.max(0, Math.min(maxScrollPosition(), y)));
        if (immediate) {
            scrollPos = getScrollPosition();
        }
    }

    private int getSmoothScrollPosition() {
        if (scrollPos < getScrollPosition()) {
            return (int) Math.ceil(scrollPos);
        } else {
            return (int) Math.floor(scrollPos);
        }
    }

    private int getScrollButtonY() {
        if (canScroll()) {
            final int yMax = screenStyle.getScrollBarRect().method_3320() - screenStyle.getScrollButtonRect().method_3320();
            return Math.max(0, Math.min(yMax, yMax * getSmoothScrollPosition() / maxScrollPosition()));
        } else {
            return 0;
        }
    }

    private boolean isCoordinateOverScrollBar(final double x, final double y) {
        return screenStyle.getScrollBarRect().method_3318((int) (x - leftPos), (int) (y - topPos));
    }

    private int getTabClickableHeight() {
        return screenStyle.getTabRect().method_3320() - screenStyle.getTabOverlap();
    }

    private record ScrollOffset(int value) {
    }

    private class TabButton extends class_4185 {
        private final Tab tab;
        private final int baseX;
        private float currentX;
        private int targetX;

        TabButton(final int x, final int y, final Tab tab, final class_4241 action) {
            super(x, y, screenStyle.getTabRect().method_3319(), getTabClickableHeight(), class_2561.method_43473(), action, field_40754);
            this.tab = tab;
            this.baseX = x;
            this.currentX = x + screenStyle.getTabHoverShift();
            this.targetX = (int) currentX;
        }

        @Override
        protected void method_75752(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
            if (isHoveredOrFocusedUsingKeyboard()) {
                targetX = baseX;
            } else {
                targetX = baseX + screenStyle.getTabHoverShift();
            }

            currentX = class_3532.method_16439(partialTicks * 0.5f, currentX, targetX);

            if (currentX < targetX) {
                method_46421((int) Math.ceil(currentX));
            } else {
                method_46421((int) Math.floor(currentX));
            }

            field_22758 = screenStyle.getTabAreaRect().method_3319() - (method_46426() - baseX);

            final int v0 = isHoveredOrFocusedUsingKeyboard() ? screenStyle.getTabRect().method_3320() : 0;
            final int visualWidth = screenStyle.getTabRect().method_3319();
            final int visualHeight = screenStyle.getTabRect().method_3320();
            final int textureWidth = screenStyle.getTabRect().method_3319();
            final int textureHeight = screenStyle.getTabRect().method_3320() * 2;

            graphics.method_25290(class_10799.field_56883, screenStyle.getTabButtonTexture(), method_46426(), method_46427(), 0, v0, visualWidth, visualHeight, textureWidth, textureHeight);

            final var pose = graphics.method_51448();
            pose.pushMatrix();
            pose.translate(method_46426() + 12, (float) (method_46427() + (screenStyle.getTabRect().method_3320() - 18) / 2));

            tab.renderIcon(graphics);

            pose.popMatrix();

            updateTooltip(graphics, mouseX, mouseY);
        }

        private void updateTooltip(final class_332 graphics, final int mouseX, final int mouseY) {
            if (!isHoveredOrFocusedUsingKeyboard() || isDraggingScrollButton) {
                return;
            }

            final var tooltip = new ArrayList<class_2561>();
            tab.getTooltip(tooltip);
            if (tooltip.isEmpty()) {
                return;
            }

            graphics.method_51447(field_22793, tooltip.stream().map(class_2561::method_30937).toList(), mouseX, mouseY);
        }

        @Override
        public void method_25354(final class_1144 soundHandler) {
        }

        private boolean isHoveredOrFocusedUsingKeyboard() {
            return method_49606() || method_25370() && class_310.method_1551().method_48186().method_48183();
        }
    }

    private class ScrollButton extends class_4185 {
        private static final int TOOLTIP_HEIGHT = 18;

        private final int baseY;

        ScrollButton(final int x, final int y, final int w, final int h) {
            super(x, y, w, h, class_2561.method_43473(), (button) -> {
            }, field_40754);
            this.baseY = y;
        }

        @Override
        protected void method_75752(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
            method_46419(baseY + getScrollButtonY());

            final int vOffset = (isDraggingScrollButton || isHoveredOrFocusedUsingKeyboard()) ? field_22759 : 0;
            graphics.method_25290(class_10799.field_56883, screenStyle.getScrollButtonTexture(), method_46426(), method_46427(), 0, vOffset, field_22758, field_22759, field_22758, field_22759 * 2);

            updateTooltip(graphics, mouseX, mouseY);
        }

        public void applyTooltip(final class_332 graphics, final int mouseX, final int mouseY, final boolean fixedY) {
            if (canScroll()) {
                graphics.method_51436(field_22793, getTooltipContent(), getClientTooltipPositioner(fixedY), mouseX, mouseY, true);
            }
        }

        private void updateTooltip(final class_332 graphics, final int mouseX, final int mouseY) {
            if (!isHoveredOrFocusedUsingKeyboard() && !isDraggingScrollButton) {
                return;
            }

            applyTooltip(graphics, mouseX, mouseY, true);
        }

        private List<class_5481> getTooltipContent() {
            return List.of(class_2561.method_43470(100 * getScrollPosition() / maxScrollPosition() + "%").method_30937());
        }

        private class_8000 getClientTooltipPositioner(final boolean fixedY) {
            return (screenWidth, screenHeight, mouseX, mouseY, tooltipWidth, tooltipHeight) -> new Vector2i(
                leftPos + screenStyle.getScrollBarRect().method_3321() + screenStyle.getScrollBarRect().method_3319(),
                fixedY ? method_46427() + (method_25364() + TOOLTIP_HEIGHT) / 2 : mouseY);
        }

        private boolean isHoveredOrFocusedUsingKeyboard() {
            return method_49606() || method_25370() && class_310.method_1551().method_48186().method_48183();
        }
    }
}
