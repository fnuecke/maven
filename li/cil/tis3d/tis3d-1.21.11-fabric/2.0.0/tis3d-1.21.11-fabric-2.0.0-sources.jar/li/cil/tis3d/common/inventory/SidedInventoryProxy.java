/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.inventory;

import javax.annotation.Nullable;
import net.minecraft.class_1278;
import net.minecraft.class_1799;
import net.minecraft.class_2350;

public interface SidedInventoryProxy extends InventoryProxy, class_1278 {
    @Override
    class_1278 getInventory();

    @Override
    default int[] method_5494(final class_2350 facing) {
        return getInventory().method_5494(facing);
    }

    @Override
    default boolean method_5492(final int slot, final class_1799 stack, @Nullable final class_2350 facing) {
        return getInventory().method_5492(slot, stack, facing);
    }

    @Override
    default boolean method_5493(final int slot, final class_1799 stack, final class_2350 facing) {
        return getInventory().method_5493(slot, stack, facing);
    }
}
