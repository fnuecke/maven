/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.entity;

import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.api.util.TransformUtil;
import li.cil.tis3d.client.renderer.RenderContextImpl;
import li.cil.tis3d.client.renderer.SubmitBufferSource;
import li.cil.tis3d.client.renderer.Textures;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.common.item.Items;
import li.cil.tis3d.common.network.Network;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_761;
import net.minecraft.class_827;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Tile entity renderer for casings, used to dynamically render stuff for
 * different modules (in particular to allow dynamic displayed content, but
 * also so as not to spam the model registry with potentially a gazillion
 * block states for static individual texturing).
 */
public final class CasingBlockEntityRenderer implements class_827<CasingBlockEntity, CasingRenderState> {
    private static final Logger LOGGER = LogManager.getLogger();

    private static final double Z_FIGHT_BUFFER = 0.001;
    private static final class_2350[] DIRECTIONS = class_2350.values();
    private static final Vector3f AXIS_X_POSITIVE = new Vector3f(1, 0, 0);
    private static final Vector3f AXIS_Y_POSITIVE = new Vector3f(0, 1, 0);
    private static final Vector3f AXIS_Z_POSITIVE = new Vector3f(0, 0, 1);
    private static final Set<Class<?>> BLACKLIST = new HashSet<>();

    private final SubmitBufferSource bufferSource = new SubmitBufferSource();

    public CasingBlockEntityRenderer(final class_5614.class_5615 context) {
    }

    @Override
    public int method_33893() {
        return Network.RANGE_HIGH;
    }

    @Override
    public CasingRenderState method_74335() {
        return new CasingRenderState();
    }

    @Override
    public void extractRenderState(final CasingBlockEntity casing, final CasingRenderState state,
                                   final float partialTicks, final class_243 cameraPosition,
                                   @Nullable final class_11683.class_11792 crumbling) {
        class_827.super.method_74331(casing, state, partialTicks, cameraPosition, crumbling);

        final class_310 minecraft = class_310.method_1551();

        state.casing = casing;
        state.partialTicks = partialTicks;
        state.cameraPosition = cameraPosition;
        state.cameraHitResult = minecraft.field_1765;

        // Grab neighbor lighting for module rendering because the casing itself is opaque and hence fully dark.
        if (casing.method_10997() != null) {
            for (final class_2350 side : DIRECTIONS) {
                final class_2338 neighborPos = casing.method_11016().method_10093(side);
                state.neighborLight[side.ordinal()] = class_761.method_23794(casing.method_10997(), neighborPos);
            }
        }

        state.observerHoldingKey = isObserverHoldingKey(minecraft);
        state.observerSneaking = minecraft.field_1724 != null && minecraft.field_1724.method_5715();
    }

    @Override
    public void submit(final CasingRenderState state, final class_4587 matrixStack,
                       final class_11659 collector, final class_12075 camera) {
        final CasingBlockEntity casing = state.casing;
        if (casing == null) {
            return;
        }

        matrixStack.method_22903();
        matrixStack.method_22904(0.5, 0.5, 0.5);

        final RenderContextImpl context = new RenderContextImpl(matrixStack, bufferSource,
            state.cameraPosition, state.cameraHitResult, state.partialTicks, state.field_62676, class_4608.field_21444);

        // Render all modules, adjust matrix stack to allow easily rendering an overlay in (0, 0, 0) to (1, 1, 0).
        for (final class_2350 side : DIRECTIONS) {
            if (isBackFace(state.cameraPosition, casing.getPosition(), side)) {
                continue;
            }

            matrixStack.method_22903();
            setupMatrix(side, matrixStack);

            if (!state.observerHoldingKey || !drawConfigOverlay(context, state, casing, side)) {
                drawModuleOverlay(new RenderContextImpl(context, state.neighborLight[side.ordinal()]), casing, side);
            }

            matrixStack.method_22909();
        }

        matrixStack.method_22909();

        bufferSource.submitTo(collector, matrixStack);
    }

    private boolean isBackFace(final class_243 cameraPosition, final class_2338 position, final class_2350 side) {
        final class_243 blockCenter = class_243.method_24953(position);
        final class_243 faceNormal = class_243.method_24954(side.method_62675());
        final class_243 faceCenter = blockCenter.method_1019(faceNormal.method_1021(0.5));
        final class_243 cameraToFaceCenter = faceCenter.method_1020(cameraPosition);
        return faceNormal.method_1026(cameraToFaceCenter) > 0;
    }

    private void setupMatrix(final class_2350 side, final class_4587 matrixStack) {
        final Vector3f axis = side.method_10166() == class_2350.class_2351.field_11052 ? AXIS_X_POSITIVE : AXIS_Y_POSITIVE;
        final int degree = switch (side) {
            case field_11033 -> -90;
            case field_11036 -> 90;
            case field_11043 -> 0;
            case field_11035 -> 180;
            case field_11039 -> 90;
            case field_11034 -> -90;
        };

        matrixStack.method_22907(new Quaternionf().fromAxisAngleDeg(axis, degree));
        matrixStack.method_22904(0.5, 0.5, -(0.5 + Z_FIGHT_BUFFER));
        matrixStack.method_22905(-1, -1, 1);
    }

    private boolean drawConfigOverlay(final RenderContext context, final CasingRenderState state,
                                      final CasingBlockEntity casing, final class_2350 side) {
        // Only bother rendering the overlay if the player is nearby.
        if (!casing.method_11016().method_19769(state.cameraPosition, 16)) {
            return false;
        }

        if (state.observerSneaking && !casing.isLocked()) {
            final Face face = casing.toLocal(side);
            final class_2960 closedSprite;
            final class_2960 openSprite;

            final Port lookingAtPort;
            final boolean isLookingAt = isObserverLookingAt(state.cameraHitResult, casing.getPosition(), side);
            if (isLookingAt) {
                closedSprite = Textures.LOCATION_OVERLAY_CASING_PORT_CLOSED;
                openSprite = Textures.LOCATION_OVERLAY_CASING_PORT_OPEN;

                final class_3965 blockHit = (class_3965) Objects.requireNonNull(state.cameraHitResult);
                final class_2338 pos = blockHit.method_17777();
                final class_243 uv = TransformUtil.hitToUV(side, blockHit.method_17784().method_1023(pos.method_10263(), pos.method_10264(), pos.method_10260()));
                lookingAtPort = Port.fromUVQuadrant(uv);
            } else {
                closedSprite = Textures.LOCATION_OVERLAY_CASING_PORT_CLOSED_SMALL;
                openSprite = null;

                lookingAtPort = null;
            }

            final class_4587 matrixStack = context.getMatrixStack();
            matrixStack.method_22903();
            for (final Port port : Port.CLOCKWISE) {
                final boolean isClosed = casing.isReceivingPipeLocked(face, casing.toLocal(side, port));
                final class_2960 sprite = isClosed ? closedSprite : openSprite;
                if (sprite != null) {
                    context.drawAtlasQuadUnlit(sprite);
                }

                if (port == lookingAtPort) {
                    context.drawAtlasQuadUnlit(Textures.LOCATION_OVERLAY_CASING_PORT_HIGHLIGHT);
                }

                matrixStack.method_22904(0.5, 0.5, 0.5);
                matrixStack.method_22907(new Quaternionf().fromAxisAngleDeg(AXIS_Z_POSITIVE, 90));
                matrixStack.method_22904(-0.5, -0.5, -0.5);
            }
            matrixStack.method_22909();

            return isLookingAt;
        } else {
            final class_2960 sprite;
            if (casing.isLocked()) {
                sprite = Textures.LOCATION_OVERLAY_CASING_LOCKED;
            } else {
                sprite = Textures.LOCATION_OVERLAY_CASING_UNLOCKED;
            }

            context.drawAtlasQuadUnlit(sprite);
        }

        return true;
    }

    private void drawModuleOverlay(final RenderContext context, final CasingBlockEntity casing, final class_2350 side) {
        final Face face = casing.toLocal(side);
        final class_4587 matrixStack = context.getMatrixStack();
        matrixStack.method_22903();
        for (final Port port : Port.CLOCKWISE) {
            final boolean isClosed = casing.isReceivingPipeLocked(face, casing.toLocal(side, port));
            if (isClosed) {
                context.drawAtlasQuadUnlit(Textures.LOCATION_OVERLAY_CASING_PORT_CLOSED_SMALL);
            }

            matrixStack.method_22904(0.5, 0.5, 0.5);
            matrixStack.method_22907(new Quaternionf().fromAxisAngleDeg(AXIS_Z_POSITIVE, 90));
            matrixStack.method_22904(-0.5, -0.5, -0.5);
        }
        matrixStack.method_22909();

        final Module module = casing.getModule(face);
        if (module == null) {
            return;
        }
        if (BLACKLIST.contains(module.getClass())) {
            return;
        }

        matrixStack.method_22903();
        try {
            module.render(context);
        } catch (final Exception e) {
            BLACKLIST.add(module.getClass());
            LOGGER.error("A module threw an exception while rendering, won't render again!", e);
        } finally {
            matrixStack.method_22909();
        }
    }

    private static boolean isObserverHoldingKey(final class_310 minecraft) {
        if (!(minecraft.method_1560() instanceof final class_1309 observer)) {
            return false;
        }

        for (final class_1268 hand : class_1268.values()) {
            final class_1799 stack = observer.method_5998(hand);
            if (Items.is(stack, Items.KEY) || Items.is(stack, Items.KEY_CREATIVE)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isObserverLookingAt(@Nullable final class_239 hit, final class_2338 pos, final class_2350 side) {
        if (!(hit instanceof final class_3965 blockHit)) {
            return false;
        }

        if (blockHit.method_17780() != side) {
            return false;
        }

        return Objects.equals(blockHit.method_17777(), pos);
    }
}
