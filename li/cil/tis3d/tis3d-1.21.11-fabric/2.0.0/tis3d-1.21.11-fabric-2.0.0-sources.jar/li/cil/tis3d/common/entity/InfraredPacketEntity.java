/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.entity;

import dev.architectury.extensions.network.EntitySpawnExtension;
import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.api.infrared.InfraredPacket;
import li.cil.tis3d.api.infrared.InfraredReceiver;
import li.cil.tis3d.common.event.InfraredPacketTickHandler;
import li.cil.tis3d.common.module.InfraredModule;
import li.cil.tis3d.util.Raytracing;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3231;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_9797;
import net.minecraft.world.phys.*;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Optional;

/**
 * Represents a single value in transmission, sent by an {@link InfraredModule}.
 */
public final class InfraredPacketEntity extends class_1297 implements EntitySpawnExtension, InfraredPacket {
    // --------------------------------------------------------------------- //
    // Computed data

    /**
     * No we don't move at the speed of light, even though we're infrared.
     * <p>
     * Don't ask. This is Minecraft.
     */
    private final static float TRAVEL_SPEED = 24f;

    /**
     * The default lifetime of a packet, in ticks, implicitly controlling how
     * far packets travel (that being <tt>TRAVEL_SPEED * DEFAULT_LIFETIME</tt>).
     */
    private static final int DEFAULT_LIFETIME = 2;

    // NBT tag names.
    private static final String TAG_VALUE = "value";
    private static final String TAG_LIFETIME = "lifetime";

    // Data watcher ids.
    private static final class_2940<Integer> DATA_VALUE = class_2945.method_12791(InfraredPacketEntity.class, class_2943.field_13327);

    // --------------------------------------------------------------------- //
    // Persisted data

    /**
     * The number of ticks that remain until the packet de-spawns.
     */
    private int lifetime;

    /**
     * The value carried by this packet.
     */
    private short value;

    public InfraredPacketEntity(final class_1299<?> type, final class_1937 level) {
        super(type, level);
        method_5875(true);
    }

    // --------------------------------------------------------------------- //

    /**
     * Sets up the packet's starting position, velocity and value carried.
     * <p>
     * Called from {@link InfraredModule} directly
     * after instantiation of a new infrared packet entity.
     *
     * @param start     the position of the block that spawned the packet.
     * @param direction the direction in which the packet was emitted.
     * @param value     the value the packet carries.
     */
    public void configure(final class_243 start, final class_243 direction, final short value) {
        method_5814(start.field_1352, start.field_1351, start.field_1350);
        method_18799(direction.method_1021(TRAVEL_SPEED));
        lifetime = DEFAULT_LIFETIME + 1; // First update in next frame.
        this.value = value;
        method_5841().method_12778(DATA_VALUE, value & 0xFFFF);
    }

    /**
     * Called from our watchdog each server tick to update our lifetime.
     */
    public void updateLifetime() {
        if (lifetime-- < 1) {
            method_31472();
        }
    }

    // --------------------------------------------------------------------- //

    @Override
    protected void method_5693(final class_2945.class_9222 builder) {
        builder.method_56912(DATA_VALUE, 0);
        if (!method_73183().method_8608()) {
            InfraredPacketTickHandler.watchPacket(this);
        }
    }

    @Override
    public void method_5650(final class_5529 reason) {
        super.method_5650(reason);
        if (!method_73183().method_8608()) {
            InfraredPacketTickHandler.unwatchPacket(this);
        }
    }

    @Override
    protected void method_31482() {
        super.method_31482();
        if (!method_73183().method_8608()) {
            InfraredPacketTickHandler.watchPacket(this);
        }
    }

    @Override
    public boolean method_64397(final class_3218 level, final class_1282 damageSource, final float amount) {
        return false;
    }

    @Override
    protected void method_5749(final class_11368 input) {
        lifetime = input.method_71424(TAG_LIFETIME, 0);
        value = (short) input.method_71432(TAG_VALUE, (short) 0);
    }

    @Override
    protected void method_5652(final class_11372 output) {
        output.method_71465(TAG_LIFETIME, lifetime);
        output.method_71471(TAG_VALUE, value);
    }

    @Override
    public class_2596<class_2602> method_18002(final class_3231 serverEntity) {
        return NetworkManager.createAddEntityPacket(this, serverEntity);
    }

    @Override
    public void method_5773() {
        // Enforce lifetime, fail-safe, should be tracked in updateLifetime().
        if (lifetime < 1) {
            method_31472();
            return;
        }

        // Do general update logic.
        super.method_5773();

        // Check for collisions and handle them.
        final class_239 hit = checkCollisions();

        // Emit some particles.
        emitParticles(hit);

        // Update position and bounding box
        setPositionAndUpdateBounds(method_73189().method_1019(method_18798()));
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_5675() {
        return false;
    }

    @Override
    public boolean method_5732() {
        return false;
    }

    @Override
    public boolean method_5659(class_1927 explosion) {
        return true;
    }

    @Override
    public boolean method_5640(final double distance) {
        return false;
    }

    // --------------------------------------------------------------------- //
    // EntitySpawnExtension

    @Override
    public void saveAdditionalSpawnData(class_2540 buf) {
    }

    @Override
    public void loadAdditionalSpawnData(class_2540 buf) {
    }

    // --------------------------------------------------------------------- //
    // InfraredPacket

    @Override
    public short getPacketValue() {
        return value;
    }

    @Override
    public class_243 getPacketPosition() {
        return method_73189();
    }

    @Override
    public class_243 getPacketDirection() {
        return method_18798().method_1029();
    }

    @Override
    public void redirectPacket(final class_243 position, final class_243 direction, final int addedLifetime) {
        lifetime += addedLifetime;
        if (lifetime > 0) {
            // Revive!
            method_31482();

            // Apply new position.
            setPositionAndUpdateBounds(position);

            // Apply new direction.
            method_18799(direction.method_1029().method_1021(TRAVEL_SPEED));
        }
    }

    // --------------------------------------------------------------------- //

    private void setPositionAndUpdateBounds(final class_243 pos) {
        method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
    }

    private void emitParticles(@Nullable final class_239 hit) {
        if (!(method_73183() instanceof final class_3218 serverLevel)) {
            // Entities regularly die too quickly for the client to have a
            // chance to simulate them, so we trigger the particles from
            // the server. Kinda meh, but whatever works.
            return;
        }

        // Spawn particle effect somewhere between current position and either the
        // position where the packet collided with something, or along the movement
        // direction (i.e. where the packet will be next).
        final double t = field_5974.method_43058();
        final class_243 delta = hit == null ? method_18798() : hit.method_17784().method_1020(method_73189());
        final class_243 pos = method_73189().method_1019(delta.method_1021(t));
        serverLevel.method_65096(class_2390.field_11188, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0, 0, 0, 0);
    }

    @Nullable
    private class_239 checkCollisions() {
        final class_239 hit = checkCollision();
        if (hit instanceof final class_3965 blockHit) {
            onBlockCollision(blockHit);
        } else if (hit instanceof final class_3966 entityHit) {
            onEntityCollision(entityHit);
        }
        return hit;
    }

    @Nullable
    private class_239 checkCollision() {
        final class_243 start = method_73189();
        final class_243 target = start.method_1019(method_18798());

        // Check for block collisions.
        final class_239 blockHit = Raytracing.raytrace(method_73183(), start, target, Raytracing::intersectIgnoringTransparent);

        // Check for entity collisions.
        final class_239 entityHit = checkEntityCollision(method_73183(), start, target);

        // If we have both, pick the closer one.
        if (blockHit != null && blockHit.method_17783() != class_239.class_240.field_1333 &&
            entityHit != null && entityHit.method_17783() != class_239.class_240.field_1333) {
            if (blockHit.method_17784().method_1025(start) < entityHit.method_17784().method_1025(start)) {
                return blockHit;
            } else {
                return entityHit;
            }
        }

        if (blockHit != null) {
            return blockHit;
        }

        if (entityHit != null) {
            return entityHit;
        }

        return null;
    }

    @Nullable
    private class_239 checkEntityCollision(final class_1937 level, final class_243 start, final class_243 target) {
        class_1297 entityHit = null;
        class_243 entityHitVec = null;
        double bestSqrDistance = Double.POSITIVE_INFINITY;

        final List<class_1297> collisions = level.method_8335(this, method_5829().method_18804(method_18798()));
        for (final class_1297 entity : collisions) {
            if (entity.method_5863()) {
                final class_238 entityBounds = entity.method_5829();
                final Optional<class_243> hit = entityBounds.method_992(start, target);
                if (hit.isPresent()) {
                    final double sqrDistance = start.method_1025(hit.get());
                    if (sqrDistance < bestSqrDistance) {
                        entityHit = entity;
                        entityHitVec = hit.get();
                        bestSqrDistance = sqrDistance;
                    }
                }
            }
        }

        return entityHit != null ? new class_3966(entityHit, entityHitVec) : null;
    }

    private void onBlockCollision(final class_3965 hit) {
        final class_2338 pos = hit.method_17777();
        final class_2680 blockState = method_73183().method_8320(pos);
        final class_2248 block = blockState.method_26204();

        // Traveling through a portal?
        final class_2586 blockEntity = method_73183().method_8321(pos);
        if (block instanceof final class_9797 portal) {
            method_60697(portal, pos);
            return;
        }

        // First things first, we ded.
        method_31472();

        // Next up, notify receiver, if any.
        if (block instanceof final InfraredReceiver receiver) {
            receiver.onInfraredPacket(this, hit);
        }
        if (blockEntity instanceof final InfraredReceiver receiver) {
            receiver.onInfraredPacket(this, hit);
        }
        onPlatformBlockCollision(this, hit, blockEntity);
    }

    private void onEntityCollision(final class_3966 hit) {
        // First things first, we ded.
        method_31472();

        // Next up, notify receiver, if any.
        if (hit.method_17782() instanceof final InfraredReceiver receiver) {
            receiver.onInfraredPacket(this, hit);
        }
        onPlatformEntityCollision(this, hit);
    }

    @ExpectPlatform
    private static void onPlatformBlockCollision(final InfraredPacketEntity packet, final class_3965 hit, @Nullable final class_2586 blockEntity) {
        throw new AssertionError();
    }

    @ExpectPlatform
    private static void onPlatformEntityCollision(final InfraredPacketEntity packet, final class_3966 hit) {
        throw new AssertionError();
    }
}
