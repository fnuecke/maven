/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.module;

import li.cil.tis3d.api.InfraredAPI;
import li.cil.tis3d.api.infrared.InfraredPacket;
import li.cil.tis3d.api.infrared.InfraredReceiver;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Pipe;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.traits.ModuleWithExclusiveWrites;
import li.cil.tis3d.api.prefab.module.AbstractModule;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.client.renderer.Textures;
import li.cil.tis3d.common.config.CommonConfig;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import java.util.Deque;
import java.util.LinkedList;

public final class InfraredModule extends AbstractModule implements InfraredReceiver, ModuleWithExclusiveWrites {
    // --------------------------------------------------------------------- //
    // Persisted data

    private final Deque<Short> receiveQueue = new LinkedList<>();

    // --------------------------------------------------------------------- //
    // Computed data

    // NBT tag names.
    private static final String TAG_RECEIVE_QUEUE = "receiveQueue";

    /**
     * The last tick we sent a packet. Used to avoid emitting multiple packets
     * per tick when overclocked, because that could quickly spam a lot of
     * entities, which is... not a great idea.
     */
    private long lastStep;

    // --------------------------------------------------------------------- //

    public InfraredModule(final Casing casing, final Face face) {
        super(casing, face);
    }

    // --------------------------------------------------------------------- //
    // Module

    @Override
    public void step() {
        final class_1937 level = getCasing().getCasingLevel();

        stepOutput();
        stepInput();

        lastStep = level.method_75260();
    }

    @Override
    public void onDisabled() {
        receiveQueue.clear();
    }

    @Override
    public void onBeforeWriteComplete(final Port port) {
        // Pop the top value (the one that was being written).
        receiveQueue.removeFirst();
        getCasing().setChanged();

        // If one completes, cancel all other writes to ensure a value is only
        // written once.
        cancelWrite();
    }

    @Override
    public void onWriteComplete(final Port port) {
        // Re-cancel in case step() was called after onBeforeWriteComplete() to
        // ensure all our writes are in sync.
        cancelWrite();

        // Start writing again right away to write as fast as possible.
        stepOutput();
    }

    @Override
    public void render(final RenderContext context) {
        if (!getCasing().isEnabled()) {
            return;
        }

        context.drawAtlasQuadUnlit(Textures.LOCATION_OVERLAY_MODULE_INFRARED);
    }

    @Override
    public void load(final class_2487 tag) {
        super.load(tag);

        receiveQueue.clear();
        final int[] receiveQueueTag = tag.method_10561(TAG_RECEIVE_QUEUE).orElse(new int[0]);
        for (final int value : receiveQueueTag) {
            receiveQueue.addLast((short) value);
        }
    }

    @Override
    public void save(final class_2487 tag) {
        super.save(tag);

        final int[] receiveQueueArray = new int[receiveQueue.size()];
        int i = 0;
        for (final int value : receiveQueue) {
            receiveQueueArray[i++] = value;
        }
        final class_2495 receiveQueueTag = new class_2495(receiveQueueArray);
        tag.method_10566(TAG_RECEIVE_QUEUE, receiveQueueTag);
    }

    // --------------------------------------------------------------------- //
    // InfraredReceiver

    @Override
    public void onInfraredPacket(final InfraredPacket packet, final class_239 hit) {
        if (!getCasing().isEnabled()) {
            return;
        }

        final class_1937 level = getCasing().getCasingLevel();
        if (level.method_8608()) {
            return;
        }

        final short value = packet.getPacketValue();
        if (receiveQueue.size() < CommonConfig.maxInfraredQueueLength) {
            receiveQueue.addLast(value);
            getCasing().setChanged();
        }
    }

    // --------------------------------------------------------------------- //

    /**
     * Update the outputs of the module, pushing the oldest received value.
     */
    private void stepOutput() {
        // Don't try to write if the queue is empty.
        if (receiveQueue.isEmpty()) {
            return;
        }

        for (final Port port : Port.VALUES) {
            final Pipe sendingPipe = getCasing().getSendingPipe(getFace(), port);
            if (!sendingPipe.isWriting()) {
                //noinspection ConstantConditions We're never pushing null values.
                sendingPipe.beginWrite(receiveQueue.peekFirst());
            }
        }
    }

    /**
     * Update the input of the module, pushing the current input to any pipe.
     */
    private void stepInput() {
        for (final Port port : Port.VALUES) {
            // Continuously read from all ports, emit packet when receiving a value.
            final Pipe receivingPipe = getCasing().getReceivingPipe(getFace(), port);
            if (!receivingPipe.isReading()) {
                receivingPipe.beginRead();
            }
            if (receivingPipe.canTransfer()) {
                // Don't actually read more values if we already sent a packet this tick.
                final class_1937 level = getCasing().getCasingLevel();
                if (level.method_75260() > lastStep) {
                    emitInfraredPacket(receivingPipe.read());
                }
            }
        }
    }

    /**
     * Fire a single infrared packet with the specified value.
     *
     * @param value the value to transmit.
     */
    private void emitInfraredPacket(final short value) {
        final class_2350 side = getWorldSide();
        final class_2338 blockPos = getCasing().getPosition().method_10093(side);

        final class_1937 level = getCasing().getCasingLevel();
        final class_243 position = new class_243(blockPos.method_10263() + 0.5, blockPos.method_10264() + 0.5, blockPos.method_10260() + 0.5);
        final class_243 direction = new class_243(side.method_10148(), side.method_10164(), side.method_10165());

        InfraredAPI.sendPacket(level, position, direction, value);
    }
}
