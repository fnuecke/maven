/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.mixin.fabric;

import li.cil.tis3d.api.module.traits.fabric.ModuleWithBakedModelFabric;
import li.cil.tis3d.common.module.FacadeModule;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.minecraft.class_10889;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.ArrayList;
import java.util.List;

@Mixin(FacadeModule.class)
public abstract class MixinFacadeModule implements ModuleWithBakedModelFabric {
    @Shadow
    private class_2680 facadeState;

    @Override
    public void emitBlockQuads(final class_1920 blockView, final class_2680 state, final class_2338 pos, final class_2350 direction, final class_5819 random, final QuadEmitter emitter) {
        final var model = class_310.method_1551().method_1541().method_3349(facadeState);
        final var layer = class_4696.method_23679(facadeState);
        final List<class_10889> parts = new ArrayList<>();
        model.method_68513(random, parts);
        for (final class_10889 part : parts) {
            for (final var quad : part.method_68509(direction)) {
                emitter.fromBakedQuad(quad);
                emitter.renderLayer(layer);
                emitter.emit();
            }
        }
    }
}
