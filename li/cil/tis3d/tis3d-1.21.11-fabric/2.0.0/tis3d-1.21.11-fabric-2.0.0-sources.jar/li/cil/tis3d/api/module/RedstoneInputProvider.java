/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.module;

import li.cil.tis3d.api.API;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

/**
 * Redstone input providers can be queried to compute simple redstone input into blocks.
 * <p>
 * This is used by the redstone module to compute its current input value. The default
 * implementation reads the regular Minecraft redstone signal, but other mods may want
 * to provide custom providers for custom redstone signal transportation methods, such
 * as cables.
 * <p>
 * Additional providers may be registered with the {@link net.minecraft.class_2378}
 * <tt>tis3d:redstone_inputs</tt>.
 */
public interface RedstoneInputProvider {
    /**
     * The registry name of the registry holding redstone input providers.
     */
    class_5321<class_2378<RedstoneInputProvider>> REGISTRY = class_5321.method_29180(class_2960.method_60655(API.MOD_ID, "redstone_input_provider"));

    /**
     * Get the redstone level provided to the specified side of a block at the specified position.
     *
     * @param level    the level containing the block in question.
     * @param position the position of the block.
     * @param side     the side of the block.
     * @return the redstone level going into the side of the block.
     */
    int getInput(final class_1937 level, final class_2338 position, final class_2350 side);
}
