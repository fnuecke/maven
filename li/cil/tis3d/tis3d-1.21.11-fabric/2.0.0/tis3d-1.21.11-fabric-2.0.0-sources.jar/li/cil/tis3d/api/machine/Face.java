/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.machine;

import net.minecraft.class_2350;

/**
 * Enumeration over the faces of a {@link Casing}, in that casing's local space.
 * <p>
 * Casings can be rotated, and store everything per face and per port as though they were not. World
 * space is {@link class_2350} throughout; this type is local space and nothing else. Map between the
 * two with {@link Casing#toWorld(Face)} and {@link Casing#toLocal(class_2350)}.
 */
public enum Face {
    Y_NEG,
    Y_POS,
    Z_NEG,
    Z_POS,
    X_NEG,
    X_POS;

    // --------------------------------------------------------------------- //

    /**
     * All possible enum values for quick indexing.
     */
    public static final Face[] VALUES = Face.values();

    /**
     * Cached because {@link class_2350#values()} clones its array and this is used in render logic.
     */
    private static final class_2350[] DIRECTIONS = class_2350.values();

    // --------------------------------------------------------------------- //

    /**
     * Convert a direction to a face, without applying any rotation.
     * <p>
     * This is the raw ordinal correspondence, not a world to local mapping: it is only correct for
     * an unrotated casing. Use {@link Casing#toLocal(class_2350)} instead.
     *
     * @param side the facing to convert.
     * @return the {@link Face} representing that facing.
     */
    public static Face fromDirection(final class_2350 side) {
        return VALUES[side.ordinal()];
    }

    /**
     * Convert a face to a direction, without applying any rotation.
     * <p>
     * This is the raw ordinal correspondence, not a local to world mapping: it is only correct for
     * an unrotated casing. Use {@link Casing#toWorld(Face)} instead.
     *
     * @param face the face to convert.
     * @return the {@link class_2350} representing that facing.
     */
    public static class_2350 toDirection(final Face face) {
        return DIRECTIONS[face.ordinal()];
    }
}
