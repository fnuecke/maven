/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.module;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import li.cil.manual.api.render.FontRenderer;
import li.cil.tis3d.api.API;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.traits.ModuleWithBlockChangeListener;
import li.cil.tis3d.api.module.traits.ModuleWithExclusiveWrites;
import li.cil.tis3d.api.prefab.module.AbstractModuleWithRotation;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.client.renderer.Textures;
import li.cil.tis3d.common.config.Constants;
import li.cil.tis3d.common.item.CodeBookItem;
import li.cil.tis3d.common.item.Items;
import li.cil.tis3d.common.module.execution.MachineImpl;
import li.cil.tis3d.common.module.execution.MachineState;
import li.cil.tis3d.common.module.execution.compiler.Compiler;
import li.cil.tis3d.common.module.execution.compiler.ParseException;
import li.cil.tis3d.common.module.execution.compiler.Strings;
import li.cil.tis3d.util.Color;
import li.cil.tis3d.util.EnumUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_9301;
import net.minecraft.class_9302;
import net.minecraft.class_9334;
import javax.annotation.Nullable;
import java.util.*;

/**
 * The programmable execution module.
 */
public final class ExecutionModule extends AbstractModuleWithRotation implements ModuleWithBlockChangeListener, ModuleWithExclusiveWrites {
    // --------------------------------------------------------------------- //
    // Persisted data

    private final MachineImpl machine;
    private ParseException compileError;
    private State state = State.IDLE;

    // --------------------------------------------------------------------- //
    // Computed data

    private enum State {
        IDLE,
        ERR,
        RUN,
        WAIT
    }

    private static final class RenderData {
        private static final class_2960[] STATE_LOCATIONS = new class_2960[]{
            Textures.LOCATION_OVERLAY_MODULE_EXECUTION_IDLE,
            Textures.LOCATION_OVERLAY_MODULE_EXECUTION_ERROR,
            Textures.LOCATION_OVERLAY_MODULE_EXECUTION_RUNNING,
            Textures.LOCATION_OVERLAY_MODULE_EXECUTION_WAITING
        };
    }

    // NBT tag names.
    private static final String TAG_STATE = "state";
    private static final String TAG_MACHINE = "machine";

    // Data packet types.
    private static final byte DATA_TYPE_FULL = 0;
    private static final byte DATA_TYPE_INCREMENTAL = 1;

    // --------------------------------------------------------------------- //

    public ExecutionModule(final Casing casing, final Face face) {
        super(casing, face);
        machine = new MachineImpl(this, face);
    }

    public MachineState getState() {
        return machine.getState();
    }

    public void onInstructionCompleted() {
        state = State.RUN;
        getCasing().setChanged();
        sendPartialState();
    }

    // --------------------------------------------------------------------- //
    // Module

    @Override
    public void step() {
        final State prevState = state;

        if (compileError != null) {
            state = State.ERR;
        } else if (getState().instructions.isEmpty()) {
            state = State.IDLE;
        } else if (machine.step()) {
            state = State.RUN;
            getCasing().setChanged();
            sendPartialState();
            return; // Don't send data twice.
        } else {
            state = State.WAIT;
        }

        if (prevState != state) {
            getCasing().setChanged();
            sendPartialState();
        }
    }

    @Override
    public void onEnabled() {
        sendFullState();
    }

    @Override
    public void onDisabled() {
        getState().reset();
        state = State.IDLE;

        sendPartialState();
    }

    @Override
    public void arbitrateWrites() {
        machine.onBeforeArbitrateWrites();
        ModuleWithExclusiveWrites.super.arbitrateWrites();
    }

    @Override
    public void onBeforeWriteComplete(final Port port) {
        if (compileError == null) {
            machine.onBeforeWriteComplete(port);
        }
    }

    @Override
    public void onWriteComplete(final Port port) {
        if (compileError == null) {
            machine.onWriteCompleted(port);
        }
    }

    @Override
    public boolean use(final class_1657 player, final class_1268 hand, final class_243 hit) {
        final class_1799 heldItem = player.method_5998(hand);

        // Vanilla book? If so, make that a code book.
        if (Items.is(heldItem, net.minecraft.class_1802.field_8529)) {
            if (!player.method_73183().method_8608()) {
                if (!player.method_31549().field_7477) {
                    heldItem.method_7971(1);
                }
                final class_1799 bookCode = new class_1799(Items.BOOK_CODE.get());
                if (player.method_31548().method_7394(bookCode)) {
                    player.field_7512.method_7623();
                }
                if (bookCode.method_7947() > 0) {
                    player.method_7329(bookCode, false, false);
                }
            }

            return true;
        }

        // Code book? Store current program on it if sneaking.
        if (Items.is(heldItem, Items.BOOK_CODE) && player.method_5715()) {
            final CodeBookItem.Data data = CodeBookItem.Data.loadFromStack(heldItem);
            if (getState().code != null && getState().code.length > 0) {
                data.addOrSelectProgram(Arrays.asList(getState().code));
                CodeBookItem.Data.saveToStack(heldItem, data);
            }

            return true;
        }

        // If sneaking otherwise, ignore interaction.
        if (player.method_5715()) {
            return false;
        }

        // Following is programming. If the casing is locked, don't allow changing code.
        if (getCasing().isLocked()) {
            return false;
        }

        // Get the provider for the item, if any.
        final SourceCodeProvider provider = providerFor(heldItem);
        if (provider == null) {
            return false;
        }

        // Get the code from the item, if any.
        final Iterable<String> code = provider.codeFor(heldItem);
        if (code == null || !code.iterator().hasNext()) {
            return true; // Handled, but does nothing.
        }

        // Compile the code into our machine state.
        final class_1937 level = getCasing().getCasingLevel();
        if (!level.method_8608()) {
            getState().reset();
            compile(code);
            if (compileError != null) {
                player.method_7353(Strings.getCompileError(compileError), false);
            }
            sendFullState();
        }

        return true;
    }

    @Override
    public void onData(final class_2487 data) {
        this.load(data);
    }

    @Override
    public void onData(final ByteBuf data) {
        final MachineState machineState = getState();
        machineState.pc = data.readShort();
        machineState.acc = data.readShort();
        machineState.bak = data.readShort();
        if (data.readBoolean()) {
            machineState.last = Optional.of(Port.values()[data.readByte()]);
        } else {
            machineState.last = Optional.empty();
        }
        state = State.values()[data.readByte()];
    }

    @Override
    public void render(final RenderContext context) {
        if ((!getCasing().isEnabled() || !isVisible()) && !this.isHitFace(context.getCameraHitResult())) {
            return;
        }

        final class_4587 matrixStack = context.getMatrixStack();
        matrixStack.method_22903();
        rotateForRendering(matrixStack);

        // Draw status texture.
        context.drawAtlasQuadUnlit(RenderData.STATE_LOCATIONS[state.ordinal()]);

        // Render detailed state when player is close.
        final MachineState machineState = getState();
        if (machineState.code != null && context.closeEnoughForDetails(getCasing().getPosition())) {
            renderState(context, machineState);
        }

        matrixStack.method_22909();
    }

    @Override
    public void load(final class_2487 tag) {
        super.load(tag);

        final class_2487 machineTag = tag.method_68568(TAG_MACHINE);
        getState().load(machineTag);
        state = EnumUtils.load(State.class, TAG_STATE, tag);

        if (getState().code != null) {
            compile(Arrays.asList(getState().code));
        }
    }

    @Override
    public void save(final class_2487 tag) {
        super.save(tag);

        final class_2487 machineTag = new class_2487();
        getState().save(machineTag);
        tag.method_10566(TAG_MACHINE, machineTag);
        EnumUtils.save(state, TAG_STATE, tag);
    }

    // --------------------------------------------------------------------- //
    // BlockChangeAware

    @Override
    public void onNeighborBlockChange(final class_2338 neighborPos, final boolean isModuleNeighbor) {
        if (isModuleNeighbor && isVisible()) {
            sendPartialState();
        }
    }

    // --------------------------------------------------------------------- //

    /**
     * Compile the specified lines of code, assuming this was issued by the
     * specified player (for notifications on errors). The code will be
     * compiled into the module's machine state. On errors, the state will
     * be left in a reset state.
     *
     * @param code the code to compile.
     */
    private void compile(final Iterable<String> code) {
        compileError = null;
        try {
            Compiler.compile(code, getState());
        } catch (final ParseException e) {
            compileError = e;
        }
    }

    /**
     * Send the full state to the client.
     */
    private void sendFullState() {
        final class_2487 tag = new class_2487();
        this.save(tag);
        getCasing().sendData(getFace(), tag, DATA_TYPE_FULL);
    }

    /**
     * Send the current execution state to the client.
     */
    private void sendPartialState() {
        if (!isVisible()) {
            return;
        }

        final ByteBuf data = Unpooled.buffer();

        data.writeShort((short) getState().pc);
        data.writeShort(getState().acc);
        data.writeShort(getState().bak);
        data.writeBoolean(getState().last.isPresent());
        getState().last.ifPresent(port -> data.writeByte((byte) port.ordinal()));
        data.writeByte(state.ordinal());

        getCasing().sendData(getFace(), data, DATA_TYPE_INCREMENTAL);
    }

    private void renderState(final RenderContext context, final MachineState machineState) {
        final class_4587 matrixStack = context.getMatrixStack();
        matrixStack.method_22903();

        // Offset to start drawing at top left of inner area, slightly inset.
        matrixStack.method_46416(3.5f / 16f, 3.5f / 16f, 0);
        matrixStack.method_22905(1 / 128f, 1 / 128f, 1);
        matrixStack.method_46416(1, 1, 0);

        final FontRenderer fontRenderer = API.smallFontRenderer;

        // Draw register info on top.
        final String accLast = String.format("ACC:%4X LAST:%s", machineState.acc, machineState.last.map(Enum::name).orElse("NONE"));
        context.drawString(fontRenderer, accLast, Color.WHITE);
        matrixStack.method_46416(0, fontRenderer.lineHeight() + 4, 0);

        final String bakState = String.format("BAK:%4X MODE:%s", machineState.bak, state.name());
        context.drawString(fontRenderer, bakState, Color.WHITE);
        matrixStack.method_46416(0, fontRenderer.lineHeight() + 4, 0);

        drawLine(context, 1, Color.WHITE);

        matrixStack.method_46416(0, 5, 0);

        // If we have more lines than fit on our "screen", offset so that the
        // current line is in the middle, but don't let last line scroll in.
        final int maxLines = 50 / (fontRenderer.lineHeight() + 1);
        final int totalLines = machineState.code.length;
        final int currentLine;
        if (!machineState.lineNumbers.isEmpty()) {
            currentLine = Optional.ofNullable(machineState.lineNumbers.get(machineState.pc)).orElse(-1);
        } else if (compileError != null) {
            currentLine = compileError.getLineNumber();
        } else {
            currentLine = -1;
        }
        final int page = currentLine / maxLines;
        final int offset = page * maxLines;

        for (int lineNumber = offset; lineNumber < Math.min(totalLines, offset + maxLines); lineNumber++) {
            final String line = machineState.code[lineNumber];
            final CharSequence charSequence = line.subSequence(0, Math.min(line.length(), 18));
            if (lineNumber == currentLine) {
                // Draw current line marker behind text
                if (state == State.WAIT) {
                    drawLine(context, fontRenderer.lineHeight(), Color.LIGHT_GRAY);
                } else if (state == State.ERR || compileError != null && compileError.getLineNumber() == currentLine) {
                    drawLine(context, fontRenderer.lineHeight(), Color.RED);
                } else {
                    drawLine(context, fontRenderer.lineHeight(), Color.WHITE);
                }

                context.drawString(fontRenderer, charSequence, Color.BLACK);
            } else {
                context.drawString(fontRenderer, charSequence, Color.WHITE);
            }

            matrixStack.method_46416(0, fontRenderer.lineHeight() + 1, 0);
        }

        matrixStack.method_22909();
    }

    /**
     * Draws a horizontal line of the specified height.
     *
     * @param height the height of the line to draw.
     */
    private static void drawLine(final RenderContext context, final int height, final int color) {
        context.drawQuadUnlit(-0.5f, -0.5f, 72, height + 1, color);
    }

    // --------------------------------------------------------------------- //

    private interface SourceCodeProvider {
        boolean worksFor(class_1799 stack);

        @Nullable
        Iterable<String> codeFor(final class_1799 stack);
    }

    private static final class SourceCodeProviderVanilla implements SourceCodeProvider {
        @Override
        public boolean worksFor(final class_1799 stack) {
            return Items.is(stack, net.minecraft.class_1802.field_8360) ||
                Items.is(stack, net.minecraft.class_1802.field_8674);
        }

        @Override
        public Iterable<String> codeFor(final class_1799 stack) {
            final List<String> pages = new ArrayList<>();

            final class_9301 writable = stack.method_58694(class_9334.field_49653);
            if (writable != null) {
                writable.method_57517(false).forEach(pages::add);
            }

            final class_9302 written = stack.method_58694(class_9334.field_49606);
            if (written != null) {
                written.method_57525(false).forEach(page -> pages.add(page.getString()));
            }

            if (pages.isEmpty()) {
                return null;
            }

            final List<String> code = new ArrayList<>();
            for (final String page : pages) {
                final String line = page.replaceAll("§[a-z0-9]", "");
                Collections.addAll(code, Constants.PATTERN_LINES.split(line));
            }
            return code;
        }
    }

    private static final class SourceCodeProviderBookCode implements SourceCodeProvider {
        @Override
        public boolean worksFor(final class_1799 stack) {
            return Items.is(stack, Items.BOOK_CODE);
        }

        @Override
        public Iterable<String> codeFor(final class_1799 stack) {
            final CodeBookItem.Data data = CodeBookItem.Data.loadFromStack(stack);
            if (data.getPageCount() < 1) {
                return null;
            }
            return data.getProgram();
        }
    }

    private static final List<SourceCodeProvider> providers = new ArrayList<>(Arrays.asList(
        new SourceCodeProviderVanilla(),
        new SourceCodeProviderBookCode()
    ));

    @Nullable
    private static SourceCodeProvider providerFor(final class_1799 stack) {
        if (!stack.method_7960()) {
            return providers.stream().filter(p -> p.worksFor(stack)).findFirst().orElse(null);
        }
        return null;
    }
}
