/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexFormat;
import li.cil.tis3d.api.API;
import net.minecraft.class_10799;
import net.minecraft.class_12247;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import java.util.function.Function;

public final class ModRenderType {
    public static final RenderPipeline UNLIT_PIPELINE = RenderPipeline
        .builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/module_overlay"))
        .withVertexShader("core/position_color")
        .withFragmentShader("core/position_color")
        .withBlend(BlendFunction.TRANSLUCENT)
        .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
        .withDepthWrite(false)
        .build();

    public static final RenderPipeline UNLIT_TEXTURED_PIPELINE = RenderPipeline
        .builder(class_10799.field_60125)
        .withLocation(class_2960.method_60655(API.MOD_ID, "pipeline/module_overlay_textured"))
        .withVertexShader("core/position_tex_color")
        .withFragmentShader("core/position_tex_color")
        .withSampler("Sampler0")
        .withBlend(BlendFunction.TRANSLUCENT)
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .withDepthWrite(false)
        .build();

    private static final class_1921 UNLIT = class_1921.method_75940(API.MOD_ID + "/module_overlay",
        class_12247.method_75927(UNLIT_PIPELINE).method_75938());

    private static final class_1921 UNLIT_ATLAS_TEXTURE = class_1921.method_75940(API.MOD_ID + "/atlas_module_overlay",
        class_12247.method_75927(UNLIT_TEXTURED_PIPELINE)
            .method_75934("Sampler0", Textures.LOCATION_BLOCK_ATLAS)
            .method_75938());

    private static final Function<class_2960, class_1921> UNLIT_TEXTURE = class_156.method_34866(texture ->
        class_1921.method_75940(API.MOD_ID + "/texture_module_overlay",
            class_12247.method_75927(UNLIT_TEXTURED_PIPELINE)
                .method_75934("Sampler0", texture)
                .method_75938()));

    // --------------------------------------------------------------------- //

    /**
     * Render layer intended for modules, intended for rendering layered, transparent overlays.
     * As such, depth write is disabled in this layer. Textures must be in the block texture
     * atlas.
     *
     * @return the {@link class_1921} instance.
     */
    public static class_1921 unlit() {
        return UNLIT;
    }

    /**
     * Render layer intended for modules, intended for rendering layered, transparent overlays.
     * As such, depth write is disabled in this layer. Textures must be in the block texture
     * atlas.
     *
     * @return the {@link class_1921} instance.
     */
    public static class_1921 unlitAtlasTexture() {
        return UNLIT_ATLAS_TEXTURE;
    }

    /**
     * Create a render layer that is identical to {@link net.minecraft.class_12249#method_75990(class_2960)},
     * except with diffuse lighting disabled.
     *
     * @param texture the id of the texture to be bound.
     * @return the {@link class_1921} instance.
     */
    public static class_1921 unlitTexture(final class_2960 texture) {
        return UNLIT_TEXTURE.apply(texture);
    }

    // --------------------------------------------------------------------- //

    private ModRenderType() {
        throw new UnsupportedOperationException("Not meant to be instantiated.");
    }
}
