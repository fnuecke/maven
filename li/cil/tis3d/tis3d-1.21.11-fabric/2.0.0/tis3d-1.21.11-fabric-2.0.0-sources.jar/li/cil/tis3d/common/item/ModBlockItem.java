/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

import li.cil.tis3d.util.TooltipUtils;
import net.minecraft.class_10712;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import java.util.function.Consumer;

public class ModBlockItem extends class_1747 {
    public ModBlockItem(final class_2248 block, final class_1793 properties) {
        super(block, properties);
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("deprecation")
    @Override
    public void method_67187(final class_1799 stack, final class_9635 context, final class_10712 display, final Consumer<class_2561> tooltip, final class_1836 flag) {
        super.method_67187(stack, context, display, tooltip, flag);
        TooltipUtils.tryAddDescription(stack, tooltip);
    }

    // --------------------------------------------------------------------- //

}
