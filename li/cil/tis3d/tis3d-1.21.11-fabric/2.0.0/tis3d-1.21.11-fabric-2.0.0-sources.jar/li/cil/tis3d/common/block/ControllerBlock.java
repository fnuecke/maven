/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.tis3d.common.block.entity.BlockEntities;
import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import li.cil.tis3d.common.item.Items;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9904;
import javax.annotation.Nullable;

/**
 * Block for the controller driving the casings.
 */
public final class ControllerBlock extends class_2237 {
    public static final MapCodec<ControllerBlock> CODEC = method_54094(ControllerBlock::new);

    // --------------------------------------------------------------------- //

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    public ControllerBlock(class_2251 properties) {
        super(properties);
    }

    // --------------------------------------------------------------------- //
    // BaseEntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.CONTROLLER.get().method_11032(pos, state);
    }

    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        if (level.method_8608()) {
            return null;
        } else {
            return method_31618(type, BlockEntities.CONTROLLER.get(), ControllerBlockEntity::serverTick);
        }
    }

    @Override
    public class_2464 method_9604(final class_2680 state) {
        return class_2464.field_11458;
    }

    // --------------------------------------------------------------------- //
    // Common

    @Override
    protected class_1269 method_55765(final class_1799 stack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_1269 result = useController(level, pos, player, hand);
        return result == class_1269.field_5811
            ? class_1269.field_52423
            : result;
    }

    private class_1269 useController(final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand) {
        final class_1799 heldItem = player.method_5998(hand);
        if (!heldItem.method_7960()) {
            final class_1792 item = heldItem.method_7909();
            if (item == net.minecraft.class_1802.field_8529) {
                if (!level.method_8608()) {
                    if (!player.method_31549().field_7477) {
                        heldItem.method_7971(1);
                    }
                    final class_1799 bookManual = new class_1799(Items.BOOK_MANUAL.get());
                    if (player.method_31548().method_7394(bookManual)) {
                        player.field_7512.method_7623();
                    }
                    if (bookManual.method_7947() > 0) {
                        player.method_7329(bookManual, false, false);
                    }
                }

                return class_1269.field_5812;
            }
        }

        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final ControllerBlockEntity controller) {
            if (!level.method_8608()) {
                controller.forceStep();
            }

            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    // --------------------------------------------------------------------- //
    // Redstone

    @Override
    public boolean method_9498(final class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2350 side) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final ControllerBlockEntity controller) {
            return controller.getState() == ControllerBlockEntity.ControllerState.READY ? 15 : 0;
        }
        return 0;
    }

    // --------------------------------------------------------------------- //
    // Networking

    @Override
    protected void method_9612(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2248 block, @Nullable final class_9904 orientation, final boolean isMoving) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final ControllerBlockEntity controller) {
            controller.checkNeighbors();
        }
        super.method_9612(state, level, pos, block, orientation, isMoving);
    }
}
