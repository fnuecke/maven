/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public final class LevelUtils {
    /**
     * Check whether a block is within a loaded chunk.
     * <p>
     * This differs from {@link class_1937#method_8477(class_2338)} in such that this treats out of bounds chunks as loaded.
     *
     * @param level the level to check in.
     * @param pos   the block position to check at.
     * @return whether the block is loaded.
     */
    public static boolean isLoaded(final class_1937 level, final class_2338 pos) {
        final class_1923 chunkPos = new class_1923(pos);
        return level.method_8398().method_12123(chunkPos.field_9181, chunkPos.field_9180);
    }

    // --------------------------------------------------------------------- //

    private LevelUtils() {
    }
}
