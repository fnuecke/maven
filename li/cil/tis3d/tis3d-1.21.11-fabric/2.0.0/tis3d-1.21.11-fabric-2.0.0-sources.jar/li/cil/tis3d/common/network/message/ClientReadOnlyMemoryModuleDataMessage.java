/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.common.item.Items;
import li.cil.tis3d.common.item.ReadOnlyMemoryModuleItem;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_9129;

public final class ClientReadOnlyMemoryModuleDataMessage extends AbstractReadOnlyMemoryModuleDataMessage {
    public ClientReadOnlyMemoryModuleDataMessage(final class_1268 hand, final byte[] data) {
        super(hand, data);
    }

    public ClientReadOnlyMemoryModuleDataMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final var player = context.getPlayer();
        if (player != null) {
            final class_1799 stack = player.method_5998(hand);
            if (Items.is(stack, Items.READ_ONLY_MEMORY_MODULE)) {
                ReadOnlyMemoryModuleItem.saveToStack(stack, data);
            }
        }
    }
}
