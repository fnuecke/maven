/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.mixin.fabric;

import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import li.cil.tis3d.common.block.entity.fabric.ChunkUnloadListener;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(ControllerBlockEntity.class)
public abstract class MixinControllerBlockEntity extends class_2586 implements ChunkUnloadListener {
    private MixinControllerBlockEntity(final class_2591<?> type, final class_2338 pos, final class_2680 state) {
        super(type, pos, state);
    }

    @SuppressWarnings("DataFlowIssue")
    private ControllerBlockEntity asControllerBlockEntity() {
        return (ControllerBlockEntity) (Object) this;
    }

    @Override
    public void onChunkUnloaded() {
        asControllerBlockEntity().dispose();
    }
}
