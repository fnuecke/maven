/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.machine;

import io.netty.buffer.ByteBuf;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Pipe;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.api.module.ModuleProvider;
import li.cil.tis3d.api.module.traits.ModuleWithBakedModel;
import li.cil.tis3d.api.module.traits.ModuleWithExclusiveWrites;
import li.cil.tis3d.api.module.traits.ModuleWithRedstone;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import li.cil.tis3d.common.item.Items;
import li.cil.tis3d.common.network.Network;
import li.cil.tis3d.common.provider.ModuleProviders;
import li.cil.tis3d.util.ItemStackUtils;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_4844;
import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;

/**
 * Implementation of a {@link Casing}, holding up to six {@link Module}s.
 */
public final class CasingImpl implements Casing {
    // --------------------------------------------------------------------- //
    // Persisted data.

    /**
     * The {@link Module}s currently installed in this {@link Casing}.
     */
    private final Module[] modules = new Module[Face.VALUES.length];

    /**
     * The key the casing is currently locked with. If this is set, players
     * cannot add or remove modules from the casing. A key with the correct
     * UUID in its tag is required to unlock a casing.
     */
    private UUID lock;

    // --------------------------------------------------------------------- //
    // Computed data.

    // NBT tag names.
    private static final String TAG_MODULES = "modules";
    private static final String TAG_KEY = "key";

    /**
     * The tile entity hosting this casing.
     */
    private final CasingBlockEntity blockEntity;

    // --------------------------------------------------------------------- //

    public CasingImpl(final CasingBlockEntity blockEntity) {
        this.blockEntity = blockEntity;
    }

    /**
     * Calls {@link Module#onEnabled()} on all modules.
     * <p>
     * Used by the controller when its state changes to {@link ControllerBlockEntity.ControllerState#RUNNING}.
     */
    public void onEnabled() {
        for (final Module module : modules) {
            if (module != null) {
                module.onEnabled();
            }
        }
        setChanged();
    }

    /**
     * Calls {@link Module#onDisabled()} on all modules and resets all pipes.
     * <p>
     * Used by the controller when its state changes from {@link ControllerBlockEntity.ControllerState#RUNNING},
     * or the controller is reset (scan scheduled), or the controller is unloaded.
     */
    public void onDisabled() {
        for (final Module module : modules) {
            if (module != null) {
                module.onDisabled();
            }
        }
        for (final Pipe pipe : blockEntity.getPipes()) {
            pipe.cancelRead();
            pipe.cancelWrite();
        }
        setChanged();
    }

    /**
     * Calls {@link Module#onDisposed()} on all modules.
     * <p>
     * Used by the casing when it is being unloaded.
     */
    public void onDisposed() {
        for (final Module module : modules) {
            if (module != null) {
                module.onDisposed();
            }
        }
    }

    /**
     * Advance the logic of all modules by calling {@link Module#step()} on them.
     */
    public void stepModules() {
        for (final Module module : modules) {
            if (module != null) {
                module.step();
            }
        }
    }

    /**
     * Give modules a chance to cancel redundant pending writes, after pipes advanced.
     */
    public void arbitrateWrites() {
        for (final Module module : modules) {
            if (module instanceof final ModuleWithExclusiveWrites moduleWithExclusiveWrites) {
                moduleWithExclusiveWrites.arbitrateWrites();
            }
        }
    }

    /**
     * Set the module for the specified face of the casing.
     * <p>
     * This is automatically called by the casing tile entity when items are
     * added or removed and as a special case directly for forwarder modules.
     * <p>
     * This calls {@link Module#onEnabled()} and {@link Module#onDisabled()}
     * appropriately if the casing is enabled or disabled, respectively.
     *
     * @param face   the face to install the module on.
     * @param module the module to install on the face, or {@code null} for none.
     */
    public void setModule(final Face face, @Nullable final Module module) {
        if (getModule(face) == module) {
            return;
        }

        // End-of-life notification for module if it was active.
        final Module oldModule = getModule(face);
        if (blockEntity.isEnabled() && oldModule != null && !getCasingLevel().method_8608()) {
            oldModule.onDisabled();
        }

        // Remember for below.
        final boolean hadRedstone = oldModule instanceof ModuleWithRedstone;

        // Apply new module before adjust remaining state.
        modules[face.ordinal()] = module;

        // Modules contributing to the casing's model require a re-render when they come and go.
        if (oldModule instanceof ModuleWithBakedModel || module instanceof ModuleWithBakedModel) {
            blockEntity.invalidateModel();
        }

        // Reset redstone output if the previous module was redstone capable.
        if (hadRedstone) {
            if (!getCasingLevel().method_8608()) {
                blockEntity.method_5431();
                getCasingLevel().method_8408(getPosition(), blockEntity.method_11010().method_26204());
            }
        }

        // Reset pipe state if module is removed. Don't reset when one is set,
        // because it might be set via a load or scan, in which case we
        // absolutely do not want to reset our state!
        if (module == null) {
            for (final Port port : Port.VALUES) {
                getReceivingPipe(face, port).cancelRead();
                getSendingPipe(face, port).cancelWrite();
            }
        }

        // Activate the module if the controller is active.
        if (blockEntity.isEnabled() && module != null && !getCasingLevel().method_8608()) {
            module.onEnabled();
        }

        blockEntity.method_5431();
    }

    public void setLocked(final boolean locked) {
        if (locked) {
            lock = UUID.randomUUID();
        } else {
            lock = null;
        }
    }

    /**
     * Locks the casing and returns the key for unlocking it.
     *
     * @param stack the item to store the key for unlocking on.
     * @throws IllegalStateException if the casing is already locked.
     */
    public void lock(final class_1799 stack) {
        if (isLocked()) {
            throw new IllegalStateException("Casing is already locked.");
        }
        if (Items.is(stack, Items.KEY_CREATIVE)) {
            lock = UUID.randomUUID();
        } else {
            final UUID key = getKeyFromStack(stack).orElse(UUID.randomUUID());
            setKeyForStack(stack, key);
            lock = key;
        }
    }

    /**
     * Try to unlock the casing with the key stored on the specified item.
     *
     * @param stack the item containing the key.
     * @return <code>true</code> if the casing was successfully unlocked; <code>false</code> otherwise.
     */
    public boolean unlock(final class_1799 stack) {
        if (Items.is(stack, Items.KEY_CREATIVE)) {
            lock = null;
            return true;
        } else {
            return getKeyFromStack(stack).map(this::unlock).orElse(false);
        }
    }

    /**
     * Try to unlock the casing with the specified key.
     *
     * @param key the key to use to unlock the casing.
     * @return <code>true</code> if the casing was successfully unlocked; <code>false</code> otherwise.
     */
    public boolean unlock(final UUID key) {
        if (key.equals(lock)) {
            lock = null;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Restore data of all modules and pipes from the specified input.
     *
     * @param input the data to load.
     */
    public void load(final class_11368 input) {
        for (int index = 0; index < blockEntity.method_5439(); index++) {
            // We replace *all* modules to be sure we have the right types in the right slots,
            // so make sure we dispose the old instances we may have, first.
            if (modules[index] != null) {
                modules[index].onDisposed();
            }

            final class_1799 stack = blockEntity.method_5438(index);
            if (stack.method_7960()) {
                modules[index] = null;
                continue;
            }

            final Face face = Face.VALUES[index];
            final Optional<ModuleProvider> provider = ModuleProviders.getProviderFor(stack, blockEntity, face);
            if (provider.isEmpty()) {
                modules[index] = null;
                continue;
            }

            final Module module = provider.get().createModule(stack, blockEntity, face);
            modules[index] = module;
        }

        int i = 0;
        for (final class_2487 moduleTag : input.method_71437(TAG_MODULES, class_2487.field_25128)) {
            if (i >= modules.length) {
                break;
            }
            if (modules[i] != null) {
                modules[i].load(moduleTag);
            }
            i++;
        }

        lock = input.method_71426(TAG_KEY, class_4844.field_25122).orElse(null);
    }

    /**
     * Write the state of all modules and pipes to the specified output.
     *
     * @param output the output to write the data to.
     */
    public void save(final class_11372 output) {
        final class_11372.class_11373<class_2487> modulesTag = output.method_71467(TAG_MODULES, class_2487.field_25128);
        for (final Module module : modules) {
            final class_2487 moduleTag = new class_2487();
            if (module != null) {
                module.save(moduleTag);
            }
            modulesTag.method_71484(moduleTag);
        }

        if (lock != null) {
            output.method_71468(TAG_KEY, class_4844.field_25122, lock);
        }
    }

    // --------------------------------------------------------------------- //
    // Casing

    @Override
    public class_1937 getCasingLevel() {
        return blockEntity.getBlockEntityLevel();
    }

    @Override
    public class_2338 getPosition() {
        return blockEntity.method_11016();
    }

    @Override
    public class_2470 getRotation() {
        return blockEntity.getRotation();
    }

    @Override
    public void setChanged() {
        blockEntity.method_5431();
    }

    @Override
    public boolean isEnabled() {
        return blockEntity.isCasingEnabled();
    }

    @Override
    public boolean isLocked() {
        return lock != null;
    }

    @Override
    @Nullable
    public Module getModule(final Face face) {
        return modules[face.ordinal()];
    }

    @Override
    public Pipe getReceivingPipe(final Face face, final Port port) {
        return blockEntity.getReceivingPipe(face, port);
    }

    @Override
    public Pipe getSendingPipe(final Face face, final Port port) {
        return blockEntity.getSendingPipe(face, port);
    }

    @Override
    public void sendData(final Face face, final class_2487 data, final byte type) {
        Network.sendModuleData(blockEntity, face, data, type);
    }

    @Override
    public void sendData(final Face face, final class_2487 data) {
        sendData(face, data, (byte) -1);
    }

    @Override
    public void sendData(final Face face, final ByteBuf data, final byte type) {
        Network.sendModuleData(blockEntity, face, data, type);
    }

    @Override
    public void sendData(final Face face, final ByteBuf data) {
        sendData(face, data, (byte) -1);
    }

    // --------------------------------------------------------------------- //

    /**
     * Read a stored key from the specified stack.
     *
     * @param stack the stack to get the key from.
     * @return the key, if present.
     */
    private static Optional<UUID> getKeyFromStack(final class_1799 stack) {
        return ItemStackUtils.getData(stack).method_67491(TAG_KEY, class_4844.field_25122);
    }

    /**
     * Store the specified key on the specified item stack.
     *
     * @param stack the stack to store the key on.
     * @param key   the key to store on the stack.
     */
    private static void setKeyForStack(final class_1799 stack, final UUID key) {
        ItemStackUtils.updateData(stack, tag -> tag.method_67494(TAG_KEY, class_4844.field_25122, key));
    }
}
