/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.api.API;
import li.cil.tis3d.common.block.Blocks;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.class_1792;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import java.util.function.BiFunction;
import java.util.function.Function;

public final class Items {
    private static final DeferredRegister<class_1792> ITEMS = RegistryUtils.get(class_7924.field_41197);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1792> CASING = register(Blocks.CASING);
    public static final RegistrySupplier<class_1792> CONTROLLER = register(Blocks.CONTROLLER);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1792> BOOK_CODE = register("code_book", CodeBookItem::new);
    public static final RegistrySupplier<class_1792> BOOK_MANUAL = register("manual", ManualItem::new);

    public static final RegistrySupplier<class_1792> KEY = register("key", KeyItem::new);
    public static final RegistrySupplier<class_1792> KEY_CREATIVE = register("skeleton_key", KeyItem::new);

    public static final RegistrySupplier<class_1792> PRISM = register("prism");

    public static final RegistrySupplier<ModuleItem> AUDIO_MODULE = register("audio_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> DISPLAY_MODULE = register("display_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> EXECUTION_MODULE = register("execution_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> FACADE_MODULE = register("facade_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> INFRARED_MODULE = register("infrared_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> KEYPAD_MODULE = register("keypad_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> QUEUE_MODULE = register("queue_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> RANDOM_MODULE = register("random_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> RANDOM_ACCESS_MEMORY_MODULE = register("random_access_memory_module", ModuleItem::new);
    public static final RegistrySupplier<ReadOnlyMemoryModuleItem> READ_ONLY_MEMORY_MODULE = register("read_only_memory_module", ReadOnlyMemoryModuleItem::new);
    public static final RegistrySupplier<ModuleItem> REDSTONE_MODULE = register("redstone_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> SEQUENCER_MODULE = register("sequencer_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> SERIAL_PORT_MODULE = register("serial_port_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> STACK_MODULE = register("stack_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> TERMINAL_MODULE = register("terminal_module", ModuleItem::new);
    public static final RegistrySupplier<ModuleItem> TIMER_MODULE = register("timer_module", ModuleItem::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        ITEMS.register();
    }

    public static <T extends class_1792> boolean is(final class_1799 stack, final RegistrySupplier<T> item) {
        return is(stack, item.get());
    }

    public static <T extends class_1792> boolean is(final class_1799 stack, final T item) {
        return !stack.method_7960() && stack.method_7909() == item;
    }

    // --------------------------------------------------------------------- //

    private static RegistrySupplier<class_1792> register(final String name) {
        return register(name, ModItem::new);
    }

    private static <T extends class_1792> RegistrySupplier<T> register(final String name, final Function<class_1793, T> factory) {
        return ITEMS.register(name, () -> factory.apply(createProperties(name)));
    }

    private static <T extends class_2248> RegistrySupplier<class_1792> register(final RegistrySupplier<T> block) {
        return register(block, ModBlockItem::new);
    }

    private static <TBlock extends class_2248, TItem extends class_1792> RegistrySupplier<TItem> register(final RegistrySupplier<TBlock> block, final BiFunction<TBlock, class_1793, TItem> factory) {
        final String name = block.getId().method_12832();
        return ITEMS.register(name, () -> factory.apply(block.get(), createProperties(name).method_63685()));
    }

    private static class_1793 createProperties(final String name) {
        return new class_1793().method_63686(class_5321.method_29179(class_7924.field_41197,
            class_2960.method_60655(API.MOD_ID, name)));
    }
}
