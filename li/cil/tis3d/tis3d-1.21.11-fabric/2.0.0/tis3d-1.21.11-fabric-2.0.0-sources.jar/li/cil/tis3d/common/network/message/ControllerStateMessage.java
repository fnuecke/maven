/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import net.minecraft.class_9129;

public final class ControllerStateMessage extends AbstractMessageWithPosition {
    private ControllerBlockEntity.ControllerState state;

    public ControllerStateMessage(final ControllerBlockEntity controller, final ControllerBlockEntity.ControllerState state) {
        super(controller.method_11016());
        this.state = state;
    }

    public ControllerStateMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final var level = getClientLevel();
        if (level != null) {
            withBlockEntity(level, ControllerBlockEntity.class, controller ->
                controller.setStateClient(state));
        }
    }

    @Override
    public void fromBytes(final class_9129 buffer) {
        super.fromBytes(buffer);

        state = buffer.method_10818(ControllerBlockEntity.ControllerState.class);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        super.toBytes(buffer);

        buffer.method_10817(state);
    }
}
