/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.provider.redstone;

import li.cil.tis3d.api.module.RedstoneInputProvider;
import li.cil.tis3d.util.LevelUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public final class MinecraftRedstoneInputProvider implements RedstoneInputProvider {
    @Override
    public int getInput(final class_1937 level, final class_2338 position, final class_2350 side) {
        final class_2338 inputPos = position.method_10093(side);
        if (!LevelUtils.isLoaded(level, inputPos)) {
            return 0;
        }

        return (short) level.method_49808(inputPos, side);
    }
}
