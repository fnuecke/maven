/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.module.execution.compiler;

import net.minecraft.class_2561;

public final class Strings {
    public static final class_2561 MESSAGE_TOO_MANY_LINES = class_2561.method_43471("tis3d.compiler.too_many_lines");
    public static final class_2561 MESSAGE_TOO_MANY_COLUMNS = class_2561.method_43471("tis3d.compiler.too_many_columns");
    public static final class_2561 MESSAGE_INVALID_FORMAT = class_2561.method_43471("tis3d.compiler.invalid_format");
    public static final class_2561 MESSAGE_LABEL_DUPLICATE = class_2561.method_43471("tis3d.compiler.label_duplicate");
    public static final class_2561 MESSAGE_PARAMETER_OVERFLOW = class_2561.method_43471("tis3d.compiler.parameter_overflow");
    public static final class_2561 MESSAGE_PARAMETER_UNDERFLOW = class_2561.method_43471("tis3d.compiler.parameter_underflow");
    public static final class_2561 MESSAGE_PARAMETER_INVALID = class_2561.method_43471("tis3d.compiler.parameter_invalid");
    public static final class_2561 MESSAGE_LABEL_NOT_FOUND = class_2561.method_43471("tis3d.compiler.label_not_found");
    public static final class_2561 MESSAGE_INVALID_INSTRUCTION = class_2561.method_43471("tis3d.compiler.invalid_instruction");

    public static class_2561 getCompileError(final ParseException e) {
        return class_2561.method_43469("tis3d.compiler.error", e.getLineNumber(), e.getStart(), e.getEnd(), e.getDisplayMessage());
    }

    // --------------------------------------------------------------------- //

    private Strings() {
    }
}
