/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.container;

import li.cil.tis3d.common.item.Items;
import li.cil.tis3d.common.item.ReadOnlyMemoryModuleItem;
import li.cil.tis3d.common.network.Network;
import li.cil.tis3d.common.network.message.ServerReadOnlyMemoryModuleDataMessage;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import java.util.Arrays;

public final class ReadOnlyMemoryModuleContainer extends class_1703 {
    public static ReadOnlyMemoryModuleContainer create(final int id, final class_1661 playerInventory, final class_2540 data) {
        final class_1268 hand = data.method_10818(class_1268.class);
        return new ReadOnlyMemoryModuleContainer(id, playerInventory.field_7546, hand);
    }

    // --------------------------------------------------------------------- //

    private final class_1657 player;
    private final class_1268 hand;

    private byte[] lastSentData;

    public ReadOnlyMemoryModuleContainer(final int id, final class_1657 player, final class_1268 hand) {
        super(Containers.READ_ONLY_MEMORY_MODULE.get(), id);
        this.player = player;
        this.hand = hand;
    }

    public class_1268 getHand() {
        return hand;
    }

    // --------------------------------------------------------------------- //
    // Container

    @Override
    public void method_7623() {
        super.method_7623();

        if (player instanceof final class_3222 serverPlayer) {
            final byte[] data = ReadOnlyMemoryModuleItem.loadFromStack(player.method_5998(hand));
            if (!Arrays.equals(data, lastSentData)) {
                lastSentData = data;
                final ServerReadOnlyMemoryModuleDataMessage message = new ServerReadOnlyMemoryModuleDataMessage(hand, data);
                Network.sendToPlayer(serverPlayer, message);
            }
        }
    }

    @Override
    public boolean method_7597(final class_1657 player) {
        return Items.is(player.method_5998(hand), Items.READ_ONLY_MEMORY_MODULE);
    }

    // --------------------------------------------------------------------- //
    // AbstractContainerMenu

    @Override
    public class_1799 method_7601(final class_1657 player, final int slot) {
        return class_1799.field_8037;
    }
}
