/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.tags;

import li.cil.tis3d.api.API;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class BlockTags {
    public static final class_6862<class_2248> COMPUTERS = tag("computers");

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    // --------------------------------------------------------------------- //

    private static class_6862<class_2248> tag(final String name) {
        return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(API.MOD_ID, name));
    }
}
