/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public final class ItemStackUtils {
    public static class_2487 getData(final class_1799 stack) {
        return stack.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461();
    }

    public static void updateData(final class_1799 stack, final Consumer<class_2487> updater) {
        class_9279.method_57452(class_9334.field_49628, stack, updater);
    }

    // --------------------------------------------------------------------- //

    private ItemStackUtils() {
    }
}
