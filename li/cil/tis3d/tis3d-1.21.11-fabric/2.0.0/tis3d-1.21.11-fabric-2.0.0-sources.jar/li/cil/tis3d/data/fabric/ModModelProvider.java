/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.data.fabric;

import li.cil.tis3d.api.API;
import li.cil.tis3d.client.renderer.block.fabric.ModuleUnbakedModel;
import li.cil.tis3d.common.block.Blocks;
import li.cil.tis3d.common.block.CasingBlock;
import li.cil.tis3d.common.item.Items;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_10410;
import net.minecraft.class_10804;
import net.minecraft.class_10821;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4917;
import net.minecraft.class_790;
import net.minecraft.class_807;
import net.minecraft.class_815;
import net.minecraft.class_818;
import net.minecraft.class_819;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class ModModelProvider extends FabricModelProvider {
    private static final class_2960 FULL_CASING_MODEL = modelLocation("block/casing_all");
    private static final class_2960 EMPTY_CASING_MODEL = modelLocation("block/casing_empty");
    private static final class_2960 MODULE_IN_CASING_MODEL = modelLocation("block/casing_module");
    private static final class_2960 CONTROLLER_MODEL = modelLocation("block/controller");


    public ModModelProvider(final FabricDataOutput output) {
        super(output);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void generateBlockStateModels(final class_4910 blocks) {
        blocks.field_22830.accept(casingDefinition());
        blocks.field_22830.accept(class_4910.method_25644(
            Blocks.CONTROLLER.get(), class_4910.method_67835(CONTROLLER_MODEL)));

        // The generator would otherwise default these to a model that does not exist.
        blocks.field_55238.method_75343(Items.CASING.get(), class_10410.method_65481(FULL_CASING_MODEL));
        blocks.field_55238.method_75343(Items.CONTROLLER.get(), class_10410.method_65481(CONTROLLER_MODEL));
    }

    @Override
    public void generateItemModels(final class_4915 items) {
        // Item models come from the NeoForge datagen; see fabric/build.gradle.kts.
    }

    // --------------------------------------------------------------------- //

    private static class_4917 casingDefinition() {
        final List<class_819> selectors = new ArrayList<>();
        CasingBlock.DIRECTION_TO_PROPERTY.forEach((direction, property) -> {
            final class_10804 rotation = rotationFor(direction);

            selectors.add(new class_819(Optional.of(condition(property.method_11899(), "false")),
                class_4910.method_67835(EMPTY_CASING_MODEL).method_67929(rotation).method_68471()));

            final class_807 proxy = class_4910.method_67835(MODULE_IN_CASING_MODEL).method_67929(rotation);
            selectors.add(new class_819(Optional.of(condition(property.method_11899(), "true")),
                new ModuleUnbakedModel(direction, proxy.method_68471())));
        });

        return new class_4917() {
            @Override
            public class_2248 method_25743() {
                return Blocks.CASING.get();
            }

            @Override
            public class_790 method_67844() {
                return new class_790(Optional.empty(),
                    Optional.of(new class_790.class_9982(selectors)));
            }
        };
    }

    private static class_815 condition(final String property, final String value) {
        return new class_818(Map.of(property, new class_818.class_10808(List.of(new class_818.class_10807(value, false)))));
    }

    private static class_10804 rotationFor(final class_2350 direction) {
        final class_10821 x = switch (direction) {
            case field_11036 -> class_10821.field_57030;
            case field_11033 -> class_10821.field_57032;
            default -> class_10821.field_57029;
        };
        final class_10821 y = class_10821.values()[Math.floorMod((int) direction.method_10144() / 90, 4)];
        return class_10804.field_56936.withValue(x).then(class_10804.field_56937.withValue(y));
    }

    private static class_2960 modelLocation(final String path) {
        return class_2960.method_60655(API.MOD_ID, path);
    }
}
