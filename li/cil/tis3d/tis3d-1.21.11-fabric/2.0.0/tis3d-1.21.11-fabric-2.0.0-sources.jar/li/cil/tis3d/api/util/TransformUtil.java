/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.util;

import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;

/**
 * Utility class for coordinate transformation related operations.
 */
public final class TransformUtil {
    /**
     * Project a hit position on the surface of a block to a UV coordinate on
     * the that side.
     *
     * @param side   the face to project the hit onto, in world space.
     * @param hitPos the hit position to project, in block local coordinates.
     * @return the projected UV coordinate, with the Z component being 0.
     */
    public static class_243 hitToUV(final class_2350 side, final class_243 hitPos) {
        return switch (side) {
            case field_11033 -> new class_243(1 - hitPos.field_1352, hitPos.field_1350, 0);
            case field_11036 -> new class_243(1 - hitPos.field_1352, 1 - hitPos.field_1350, 0);
            case field_11043 -> new class_243(1 - hitPos.field_1352, 1 - hitPos.field_1351, 0);
            case field_11035 -> new class_243(hitPos.field_1352, 1 - hitPos.field_1351, 0);
            case field_11039 -> new class_243(hitPos.field_1350, 1 - hitPos.field_1351, 0);
            case field_11034 -> new class_243(1 - hitPos.field_1350, 1 - hitPos.field_1351, 0);
        };
    }

    /**
     * Project a hit position on the surface of a block to a UV coordinate on
     * the that side, taking into account potential rotation of the block
     * around the Y axis (up being south).
     *
     * @param side   the face to project the hit onto, in world space.
     * @param facing the rotation of the block, in world space.
     * @param hitPos the hit position to project, in block local coordinates.
     * @return the projected UV coordinate, with the Z component being 0.
     * @see Port#fromDirection(class_2350)
     */
    public static class_243 hitToUV(final class_2350 side, final Port facing, final class_243 hitPos) {
        final class_243 uv = hitToUV(side, hitPos);
        return switch (side) {
            case field_11033 -> switch (facing) {
                case LEFT -> new class_243(uv.field_1351, 1 - uv.field_1352, 0);
                case RIGHT -> new class_243(1 - uv.field_1351, uv.field_1352, 0);
                case UP -> uv;
                case DOWN -> new class_243(1 - uv.field_1352, 1 - uv.field_1351, 0);
            };
            case field_11036 -> switch (facing) {
                case LEFT -> new class_243(1 - uv.field_1351, uv.field_1352, 0);
                case RIGHT -> new class_243(uv.field_1351, 1 - uv.field_1352, 0);
                case UP -> uv;
                case DOWN -> new class_243(1 - uv.field_1352, 1 - uv.field_1351, 0);
            };
            default -> uv;
        };
    }

    /**
     * Map a face from a casing's local space to world space.
     *
     * @param face     the face in the casing's local space.
     * @param rotation the rotation of the casing.
     * @return the direction the face points in, in world space.
     */
    public static class_2350 toWorld(final Face face, final class_2470 rotation) {
        return rotation.method_10503(Face.toDirection(face));
    }

    /**
     * Map a face from world space to a casing's local space.
     *
     * @param side     the face in world space.
     * @param rotation the rotation of the casing.
     * @return the face in the casing's local space.
     */
    public static Face toLocal(final class_2350 side, final class_2470 rotation) {
        return Face.fromDirection(inverse(rotation).method_10503(side));
    }

    /**
     * Map a port from a casing's local space to world space.
     *
     * @param face     the face the port is on, in the casing's local space.
     * @param port     the port in the casing's local space.
     * @param rotation the rotation of the casing.
     * @return the port in world space.
     */
    public static Port toWorld(final Face face, final Port port, final class_2470 rotation) {
        return switch (face) {
            case Y_POS -> port.rotated(steps(rotation));
            case Y_NEG -> port.rotated(-steps(rotation));
            default -> port;
        };
    }

    /**
     * Map a port from world space to a casing's local space.
     *
     * @param side     the face the port is on, in world space.
     * @param port     the port in world space.
     * @param rotation the rotation of the casing.
     * @return the port in the casing's local space.
     */
    public static Port toLocal(final class_2350 side, final Port port, final class_2470 rotation) {
        return switch (side) {
            case field_11036 -> port.rotated(-steps(rotation));
            case field_11033 -> port.rotated(steps(rotation));
            default -> port;
        };
    }

    // --------------------------------------------------------------------- //

    private static int steps(final class_2470 rotation) {
        return switch (rotation) {
            case field_11467 -> 0;
            case field_11463 -> 1;
            case field_11464 -> 2;
            case field_11465 -> 3;
        };
    }

    private static class_2470 inverse(final class_2470 rotation) {
        return switch (rotation) {
            case field_11463 -> class_2470.field_11465;
            case field_11465 -> class_2470.field_11463;
            default -> rotation;
        };
    }

    // --------------------------------------------------------------------- //

    private TransformUtil() {
    }
}
