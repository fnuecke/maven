/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client;

import li.cil.tis3d.client.gui.CodeBookScreen;
import li.cil.tis3d.client.gui.ReadOnlyMemoryModuleScreen;
import li.cil.tis3d.client.gui.TerminalModuleScreen;
import li.cil.tis3d.common.module.TerminalModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import javax.annotation.Nullable;

@Environment(EnvType.CLIENT)
public final class ClientHooks {
    public static void openCodeBookScreen(final class_1657 player, final class_1268 hand) {
        class_310.method_1551().method_1507(new CodeBookScreen(player, hand));
    }

    public static void openTerminalScreen(final TerminalModule module) {
        class_310.method_1551().method_1507(new TerminalModuleScreen(module));
    }

    public static void closeTerminalScreen(final TerminalModule module) {
        final class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1755 instanceof final TerminalModuleScreen screen && screen.isFor(module)) {
            minecraft.method_1507(null);
        }
    }

    public static boolean isTerminalScreenOpen(final TerminalModule module) {
        return class_310.method_1551().field_1755 instanceof final TerminalModuleScreen screen && screen.isFor(module);
    }

    public static void setReadOnlyMemoryModuleData(final byte[] data) {
        if (class_310.method_1551().field_1755 instanceof final ReadOnlyMemoryModuleScreen screen) {
            screen.setData(data);
        }
    }

    public static int getBlockTintColor(final class_2680 state, @Nullable final class_1920 level,
                                       @Nullable final class_2338 pos, final int tintIndex) {
        return class_310.method_1551().method_1505().method_1697(state, level, pos, tintIndex);
    }

    @Nullable
    public static class_1937 getLevel() {
        return class_310.method_1551().field_1687;
    }

    // --------------------------------------------------------------------- //

    private ClientHooks() {
    }
}
