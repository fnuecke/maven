/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.machine;

import io.netty.buffer.ByteBuf;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.api.util.TransformUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import javax.annotation.Nullable;

/**
 * A casing for TIS-3D modules.
 * <p>
 * This is implemented by the tile entity of TIS-3D casings.
 */
public interface Casing {
    /**
     * The level this casing resides in.
     *
     * @return the level the casing lives in.
     */
    class_1937 getCasingLevel();

    /**
     * The position of the casing in the level it exists in.
     *
     * @return the position of the casing.
     */
    class_2338 getPosition();

    /**
     * The rotation of this casing, mapping its local space to world space.
     * <p>
     * Casings store everything per face and per port as though they were unrotated. Anything
     * interacting with the world has to map through this, most conveniently using the helpers
     * below.
     *
     * @return the rotation of this casing.
     */
    class_2470 getRotation();

    /**
     * Flag the casing as dirty so it is saved when the chunk containing it
     * saved next.
     */
    void setChanged();

    // --------------------------------------------------------------------- //

    /**
     * Get whether the casing is currently enabled, i.e. whether it is
     * connected to a currently enabled controller.
     * <p>
     * A controller is considered active when a positive non-zero redstone
     * signal is applied to it. This in particular includes the paused state
     * at a signal strength one.
     * <p>
     * This is useful for contextual behavior in modules while rendering or in
     * the activation callback {@link Module#use(class_1657, class_1268, class_243)}.
     *
     * @return whether the casing is currently enabled.
     */
    boolean isEnabled();

    /**
     * Get whether the casing is locked.
     * <p>
     * Casings can be locked, preventing players to remove modules from the
     * casing or add modules to the casing. Some modules may choose to also
     * ignore {@link Module#use(class_1657, class_1268, class_243)}
     * calls while their casing is locks (such as the execution module to
     * prevent reprogramming).
     *
     * @return <tt>true</tt> if the casing is currently locked.
     */
    boolean isLocked();

    /**
     * Get the module installed on the specified face of the casing.
     *
     * @param face the face to get the module for.
     * @return the module installed on that face, or {@code null}.
     */
    @Nullable
    Module getModule(final Face face);

    /**
     * Get the receiving pipe on the specified port of a module in this casing.
     * <p>
     * There are two {@link Pipe}s between every pair of {@link Module}s
     * in a case. Specifically, each edge of a {@link Casing} has two
     * {@link Pipe}s, going into opposite directions. This method is used
     * to to get a {@link Pipe} based on its sink.
     *
     * @param face the face to get the port for.
     * @param port the port for which to get the port.
     * @return the input port on that port.
     */
    Pipe getReceivingPipe(final Face face, final Port port);

    /**
     * Get the sending pipe on the specified port of a module in this casing.
     * <p>
     * There are two {@link Pipe}s between every pair of {@link Module}s
     * in a case. Specifically, each edge of a {@link Casing} has two
     * {@link Pipe}s, going into opposite directions. This method is used
     * to to get a {@link Pipe} based on its source.
     *
     * @param face the face to get the port for.
     * @param port the port for which to get the port.
     * @return the output port on that port.
     */
    Pipe getSendingPipe(final Face face, final Port port);

    // --------------------------------------------------------------------- //

    /**
     * Call this to send some data from a module to it's other representation.
     * <p>
     * That is, when called from the client, it will send the data to the
     * instance representing the module on the specified face on the server,
     * when called on the server it will send the data to the client.
     * <p>
     * Data is collected each tick, and sent in one big packet. If more than
     * one send request is performed in one tick with the same type, the data
     * will replace the previously queued data. A negative value indicates
     * that no specific type is set and data should not be replaced in the
     * send queue.
     * <p>
     * Note that this is a convenience alternative for {@link #sendData(Face, ByteBuf, byte)}
     * that is meant to be used for <em>non-frequent</em> data, i.e. data
     * that's only sent every so often. For data you expect may be sent
     * each tick, prefer using the more light-weight {@link ByteBuf}.
     * <p>
     * <em>Important</em>: the passed tag is <em>not</em> copied, it is
     * stored by reference. If you intend to modify the tag after passing
     * it to this method, pass a copy of it instead.
     *
     * @param face the face the module is installed in.
     * @param data the data to send to the client.
     * @param type the type of the data being sent.
     */
    void sendData(final Face face, final class_2487 data, final byte type);

    /**
     * Call this to send some data from a module to it's other representation.
     * <p>
     * This behaves like {@link #sendData(Face, ByteBuf, byte)}, except
     * with no specific type associated, so new data will never replace old
     * data. Where at all possible, providing a type is strongly recommended,
     * to reduce generated network traffic.
     * <p>
     * Note that this is a convenience alternative for {@link #sendData(Face, ByteBuf)}
     * that is meant to be used for <em>non-frequent</em> data, i.e. data
     * that's only sent every so often. For data you expect may be sent
     * each tick, prefer using the more light-weight {@link ByteBuf}.
     * <p>
     * <em>Important</em>: the passed tag is <em>not</em> copied, it is
     * stored by reference. If you intend to modify the tag after passing
     * it to this method, pass a copy of it instead.
     *
     * @param face the face the module is installed in.
     * @param data the data to send to the client.
     */
    void sendData(final Face face, final class_2487 data);

    /**
     * Call this to send some data from a module to it's other representation.
     * <p>
     * That is, when called from the client, it will send the data to the
     * instance representing the module on the specified face on the server,
     * when called on the server it will send the data to the client.
     * <p>
     * Data is collected each tick, and sent in one big packet. If more than
     * one send request is performed in one tick with the same type, the data
     * will replace the previously queued data. A negative value indicates
     * that no specific type is set and data should not be replaced in the
     * send queue.
     * <p>
     * <em>Important</em>: the passed buffer is <em>not</em> copied, it is
     * stored by reference. If you intend to modify the buffer after passing
     * it to this method, pass a copy of it instead.
     *
     * @param face the face the module is installed in.
     * @param data the data to send to the client.
     * @param type the type of the data being sent.
     */
    void sendData(final Face face, final ByteBuf data, final byte type);

    /**
     * Call this to send some data from a module to it's other representation.
     * <p>
     * This behaves like {@link #sendData(Face, ByteBuf, byte)}, except
     * with no specific type associated, so new data will never replace old
     * data. Where at all possible, providing a type is strongly recommended,
     * to reduce generated network traffic.
     * <p>
     * <em>Important</em>: the passed buffer is <em>not</em> copied, it is
     * stored by reference. If you intend to modify the buffer after passing
     * it to this method, pass a copy of it instead.
     *
     * @param face the face the module is installed in.
     * @param data the data to send to the client.
     */
    void sendData(final Face face, final ByteBuf data);

    // --------------------------------------------------------------------- //

    /**
     * Map one of this casing's local faces to world space.
     *
     * @param face the face in this casing's local space.
     * @return the direction the face points in, in world space.
     */
    default class_2350 toWorld(final Face face) {
        return TransformUtil.toWorld(face, getRotation());
    }

    /**
     * Map a world space face to this casing's local space.
     *
     * @param side the face in world space.
     * @return the face in this casing's local space.
     */
    default Face toLocal(final class_2350 side) {
        return TransformUtil.toLocal(side, getRotation());
    }

    /**
     * Map one of this casing's local ports to world space.
     *
     * @param face the face the port is on, in this casing's local space.
     * @param port the port in this casing's local space.
     * @return the port in world space.
     */
    default Port toWorld(final Face face, final Port port) {
        return TransformUtil.toWorld(face, port, getRotation());
    }

    /**
     * Map a world space port to this casing's local space.
     *
     * @param side the face the port is on, in world space.
     * @param port the port in world space.
     * @return the port in this casing's local space.
     */
    default Port toLocal(final class_2350 side, final Port port) {
        return TransformUtil.toLocal(side, port, getRotation());
    }
}
