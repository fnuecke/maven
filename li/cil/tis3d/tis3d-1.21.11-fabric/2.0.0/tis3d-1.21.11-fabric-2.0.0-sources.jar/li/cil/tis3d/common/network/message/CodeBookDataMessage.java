/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.common.item.CodeBookItem;
import li.cil.tis3d.common.item.Items;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9129;

public final class CodeBookDataMessage extends AbstractMessage {
    private class_1268 hand;
    private class_2487 tag;

    public CodeBookDataMessage(final class_1268 hand, final class_2487 tag) {
        this.hand = hand;
        this.tag = tag;
    }

    public CodeBookDataMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final var player = context.getPlayer();
        if (player == null) {
            return;
        }

        final class_1799 stack = player.method_5998(hand);
        if (Items.is(stack, Items.BOOK_CODE)) {
            final CodeBookItem.Data data = CodeBookItem.Data.loadFromTag(tag);
            CodeBookItem.Data.saveToStack(stack, data);
        }
    }

    @Override
    public void fromBytes(final class_9129 buffer) {
        hand = buffer.method_10818(class_1268.class);
        tag = buffer.method_10798();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10817(hand);
        buffer.method_10794(tag);
    }
}
