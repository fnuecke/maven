/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_9129;
import java.io.IOException;

public abstract class AbstractCasingDataMessage extends AbstractMessageWithPosition {
    private ByteBuf data;

    public AbstractCasingDataMessage(final Casing casing, final ByteBuf data) {
        super(casing.getPosition());
        this.data = data;
    }

    public AbstractCasingDataMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    protected void handleMessage(final class_1937 level) {
        withBlockEntity(level, CasingBlockEntity.class, casing -> {
            while (data.readableBytes() > 0) {
                final Module module = casing.getModule(Face.VALUES[data.readByte()]);
                final ByteBuf moduleData = data.readBytes(data.readUnsignedShort());
                while (moduleData.readableBytes() > 0) {
                    final boolean isCompoundTag = moduleData.readBoolean();
                    final ByteBuf packet = moduleData.readBytes(moduleData.readUnsignedShort());
                    if (module != null) {
                        if (isCompoundTag) {
                            try {
                                final ByteBufInputStream bis = new ByteBufInputStream(packet);
                                final class_2487 tag = class_2507.method_10629(bis, class_2505.method_53898());
                                module.onData(tag);
                            } catch (final IOException e) {
                                LOGGER.warn("Invalid packet received.", e);
                            }
                        } else {
                            module.onData(packet);
                        }
                    }
                }
            }
        });
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void fromBytes(final class_9129 buffer) {
        super.fromBytes(buffer);

        final int count = buffer.readInt();
        data = buffer.readBytes(count);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        super.toBytes(buffer);

        final int oldReaderIndex = data.readerIndex();
        buffer.method_53002(data.readableBytes());
        buffer.method_52975(data);
        data.readerIndex(oldReaderIndex);
    }
}
