/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.fabric;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import li.cil.tis3d.api.API;
import net.fabricmc.fabric.api.client.model.loading.v1.CustomUnbakedBlockStateModel;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_7775;

public record ModuleUnbakedModel(class_2350 face,
                                 class_1087.class_10892 proxy) implements CustomUnbakedBlockStateModel {
    public static final class_2960 ID = class_2960.method_60655(API.MOD_ID, "casing_module");

    public static final MapCodec<ModuleUnbakedModel> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_2350.field_29502.fieldOf("face").forGetter(ModuleUnbakedModel::face),
        class_1087.class_10892.field_57944.fieldOf("proxy").forGetter(ModuleUnbakedModel::proxy)
    ).apply(instance, ModuleUnbakedModel::new));

    // --------------------------------------------------------------------- //
    // CustomUnbakedBlockStateModel

    @Override
    public MapCodec<? extends CustomUnbakedBlockStateModel> codec() {
        return CODEC;
    }

    @Override
    public class_1087 method_68521(final class_7775 baker) {
        return new ModuleBakedModel(proxy.method_68521(baker), face);
    }

    @Override
    public void method_62326(final class_10103 resolver) {
        proxy.method_62326(resolver);
    }
}
