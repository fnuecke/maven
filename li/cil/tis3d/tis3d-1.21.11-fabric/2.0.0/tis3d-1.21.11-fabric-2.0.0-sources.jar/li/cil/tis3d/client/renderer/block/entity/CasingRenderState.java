/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.entity;

import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.minecraft.class_11954;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import javax.annotation.Nullable;

public final class CasingRenderState extends class_11954 {
    @Nullable
    public CasingBlockEntity casing;

    public final int[] neighborLight = new int[class_2350.values().length];
    public class_243 cameraPosition = class_243.field_1353;
    @Nullable
    public class_239 cameraHitResult;
    public boolean observerHoldingKey;
    public boolean observerSneaking;
    public float partialTicks;
}
