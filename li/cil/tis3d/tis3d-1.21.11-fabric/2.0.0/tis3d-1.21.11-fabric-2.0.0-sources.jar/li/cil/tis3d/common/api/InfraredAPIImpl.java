/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.api;

import li.cil.tis3d.api.detail.InfraredAPI;
import li.cil.tis3d.api.infrared.InfraredPacket;
import li.cil.tis3d.common.entity.Entities;
import li.cil.tis3d.common.entity.InfraredPacketEntity;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3730;

/**
 * Allow spawning infrared packets externally, reusing our entity.
 */
public final class InfraredAPIImpl implements InfraredAPI {
    @Override
    public InfraredPacket sendPacket(final class_1937 level, final class_243 position, final class_243 direction, final short value) {
        final InfraredPacketEntity entity = Entities.INFRARED_PACKET.get().method_5883(level, class_3730.field_16461);
        if (entity != null) {
            entity.configure(position, direction.method_1029(), value);
            level.method_8649(entity);
        }
        return entity;
    }
}
