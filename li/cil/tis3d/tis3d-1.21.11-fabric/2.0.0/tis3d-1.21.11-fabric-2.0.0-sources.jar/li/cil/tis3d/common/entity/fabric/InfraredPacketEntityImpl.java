/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.entity.fabric;

import li.cil.tis3d.api.fabric.Lookups;
import li.cil.tis3d.common.entity.InfraredPacketEntity;
import net.minecraft.class_2586;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import javax.annotation.Nullable;

public final class InfraredPacketEntityImpl {
    public static void onPlatformBlockCollision(final InfraredPacketEntity packet, final class_3965 hit, @Nullable final class_2586 blockEntity) {
        if (blockEntity != null && blockEntity.method_10997() != null) {
            final var api = Lookups.INFRARED_RECEIVER_BLOCK.find(blockEntity.method_10997(), blockEntity.method_11016(), hit.method_17780());
            if (api != null) {
                api.onInfraredPacket(packet, hit);
            }
        }
    }

    public static void onPlatformEntityCollision(final InfraredPacketEntity packet, final class_3966 hit) {
        final var api = Lookups.INFRARED_RECEIVER_ENTITY.find(hit.method_17782(), null);
        if (api != null) {
            api.onInfraredPacket(packet, hit);
        }
    }
}
