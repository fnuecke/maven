/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.module.traits.fabric;

import li.cil.tis3d.api.module.traits.ModuleWithBakedModel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

/**
 * Fabric specific specialization of the {@link ModuleWithBakedModel} interface. Use this when using Fabric
 * to emit custom quads for a module.
 */
public interface ModuleWithBakedModelFabric extends ModuleWithBakedModel {
    @Environment(EnvType.CLIENT)
    void emitBlockQuads(final class_1920 blockView, final class_2680 state, final class_2338 pos, final class_2350 direction, final class_5819 random, final QuadEmitter emitter);
}
