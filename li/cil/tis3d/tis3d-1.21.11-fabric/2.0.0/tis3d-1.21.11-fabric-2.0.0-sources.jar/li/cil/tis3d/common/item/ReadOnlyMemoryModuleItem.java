/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

import dev.architectury.registry.menu.MenuRegistry;
import li.cil.tis3d.common.block.CasingBlock;
import li.cil.tis3d.common.container.ReadOnlyMemoryModuleContainer;
import li.cil.tis3d.util.ItemStackUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import javax.annotation.Nullable;

public final class ReadOnlyMemoryModuleItem extends ModuleItem {
    private static final String TAG_DATA = "data";
    private static final byte[] EMPTY_DATA = new byte[0];

    public ReadOnlyMemoryModuleItem(final class_1793 properties) {
        super(properties.method_7889(1));
    }

    // --------------------------------------------------------------------- //
    // Item

    @Override
    public class_1269 method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        if (!level.method_8608() && player instanceof final class_3222 serverPlayer) {
            MenuRegistry.openExtendedMenu(serverPlayer, new class_3908() {
                @Override
                public class_2561 method_5476() {
                    return class_2561.method_43473();
                }

                @Override
                public class_1703 createMenu(final int id, final class_1661 playerInventory, final class_1657 player) {
                    return new ReadOnlyMemoryModuleContainer(id, player, hand);
                }
            }, buffer -> buffer.method_10817(hand));
        }
        return class_1269.field_5812;
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        return CasingBlock.useIfCasing(context).orElseGet(() -> super.method_7884(context));
    }

    // --------------------------------------------------------------------- //

    /**
     * Load ROM data from the specified tag.
     *
     * @param tag the tag to load the data from.
     * @return the data loaded from the tag.
     */
    public static byte[] loadFromTag(@Nullable final class_2487 tag) {
        if (tag != null) {
            return tag.method_10547(TAG_DATA).orElse(EMPTY_DATA);
        }
        return EMPTY_DATA;
    }

    /**
     * Load ROM data from the specified item stack.
     *
     * @param stack the item stack to load the data from.
     * @return the data loaded from the stack.
     */
    public static byte[] loadFromStack(final class_1799 stack) {
        return loadFromTag(ItemStackUtils.getData(stack));
    }

    /**
     * Save the specified ROM data to the specified item stack.
     *
     * @param stack the item stack to save the data to.
     * @param data  the data to save to the item stack.
     */
    public static void saveToStack(final class_1799 stack, final byte[] data) {
        ItemStackUtils.updateData(stack, tag -> tag.method_10570(TAG_DATA, data.clone()));
    }
}
