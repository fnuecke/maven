/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_9129;
import javax.annotation.Nullable;

public final class CasingInventoryMessage extends AbstractMessageWithPosition {
    private int slot;
    private class_1799 stack;
    private class_2487 moduleData;

    public CasingInventoryMessage(final Casing casing, final int slot, final class_1799 stack, @Nullable final class_2487 moduleData) {
        super(casing.getPosition());
        this.slot = slot;
        this.stack = stack;
        this.moduleData = moduleData;
    }

    public CasingInventoryMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final class_1937 level = getClientLevel();
        if (level != null) {
            withBlockEntity(level, CasingBlockEntity.class, casing ->
                casing.setStackAndModuleClient(slot, stack, moduleData));
        }
    }

    @Override
    public void fromBytes(final class_9129 buffer) {
        super.fromBytes(buffer);

        slot = buffer.readUnsignedByte();
        stack = class_1799.field_49268.decode(buffer);
        moduleData = buffer.method_10798();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        super.toBytes(buffer);

        buffer.method_52997(slot);
        class_1799.field_49268.encode(buffer, stack);
        buffer.method_10794(moduleData);
    }
}
