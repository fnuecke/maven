/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.fabric;

import li.cil.tis3d.api.module.traits.fabric.ModuleWithBakedModelFabric;
import li.cil.tis3d.api.util.TransformUtil;
import li.cil.tis3d.common.block.CasingBlock;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBlockStateModel;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_10889;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import java.util.List;
import java.util.function.Predicate;

public final class ModuleBakedModel implements class_1087, FabricBlockStateModel {
    private final class_1087 proxy;
    private final class_2350 direction;

    // --------------------------------------------------------------------- //

    ModuleBakedModel(final class_1087 proxy, final class_2350 direction) {
        this.proxy = proxy;
        this.direction = direction;
    }

    // --------------------------------------------------------------------- //
    // FabricBlockStateModel

    @Override
    public void emitQuads(final QuadEmitter emitter, final class_1920 blockView, final class_2338 pos,
                          final class_2680 state, final class_5819 random, final Predicate<class_2350> cullTest) {
        if (blockView.method_8321(pos) instanceof final CasingBlockEntity casing) {
            final var module = casing.getModule(TransformUtil.toLocal(direction, CasingBlock.getRotation(state)));
            if (module instanceof final ModuleWithBakedModelFabric moduleWithModel && moduleWithModel.hasModel()) {
                moduleWithModel.emitBlockQuads(blockView, state, pos, direction, random, emitter);
                return;
            }
        }

        proxy.emitQuads(emitter, blockView, pos, state, random, cullTest);
    }

    // --------------------------------------------------------------------- //
    // BlockStateModel

    @Override
    public void method_68513(final class_5819 random, final List<class_10889> parts) {
        proxy.method_68513(random, parts);
    }

    @Override
    public class_1058 method_68511() {
        return proxy.method_68511();
    }
}
