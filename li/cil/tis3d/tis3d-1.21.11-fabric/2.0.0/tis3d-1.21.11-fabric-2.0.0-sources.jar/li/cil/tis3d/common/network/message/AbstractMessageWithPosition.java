/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import li.cil.tis3d.util.LevelUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_9129;
import java.util.function.Consumer;

public abstract class AbstractMessageWithPosition extends AbstractMessage {
    protected class_2338 position;

    AbstractMessageWithPosition(final class_2338 position) {
        this.position = position;
    }

    AbstractMessageWithPosition(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("unchecked")
    protected <T extends class_2586> void withBlockEntity(final class_1937 level, final Class<T> type, final Consumer<T> callback) {
        if (LevelUtils.isLoaded(level, position)) {
            final class_2586 blockEntity = level.method_8321(position);
            if (blockEntity != null && type.isAssignableFrom(blockEntity.getClass())) {
                callback.accept((T) blockEntity);
            }
        }
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void fromBytes(final class_9129 buffer) {
        position = buffer.method_10811();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10807(position);
    }
}
