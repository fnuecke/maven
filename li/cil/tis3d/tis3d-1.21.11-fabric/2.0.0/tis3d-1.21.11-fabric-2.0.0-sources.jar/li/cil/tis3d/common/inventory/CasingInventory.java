/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.inventory;

import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.api.module.ModuleProvider;
import li.cil.tis3d.api.module.traits.ModuleWithRotation;
import li.cil.tis3d.api.util.TransformUtil;
import li.cil.tis3d.common.block.CasingBlock;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.common.network.Network;
import li.cil.tis3d.common.network.message.CasingInventoryMessage;
import li.cil.tis3d.common.provider.ModuleProviders;
import net.minecraft.class_1278;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import javax.annotation.Nullable;
import java.util.Optional;

/**
 * Inventory implementation for casings, having six slots for modules, one per face.
 */
public final class CasingInventory extends Inventory implements class_1278 {
    private final CasingBlockEntity blockEntity;

    public CasingInventory(final CasingBlockEntity blockEntity) {
        super(Face.VALUES.length);
        this.blockEntity = blockEntity;
    }

    // Copy-paste of parent setInventorySlotContents, but allows passing along module facing.
    public void setInventorySlotContents(final int index, final class_1799 stack, final Port facing) {
        if (items[index] == stack) {
            return;
        }

        if (!items[index].method_7960()) {
            onItemRemoved(index);
        }

        items[index] = stack;

        if (!items[index].method_7960()) {
            onItemAdded(index, facing);
        }

        method_5431();
    }

    // --------------------------------------------------------------------- //
    // IInventory

    @Override
    public int method_5444() {
        return 1;
    }

    @Override
    public void method_5431() {
        blockEntity.method_5431();
        syncFaceProperties();
    }

    public void syncFaceProperties() {
        final class_1937 level = blockEntity.getBlockEntityLevel();
        if (level.method_8608()) {
            return;
        }

        final class_2338 position = blockEntity.method_11016();
        class_2680 state = level.method_8320(position);
        if (!(state.method_26204() instanceof CasingBlock)) {
            return;
        }

        final class_2470 rotation = CasingBlock.getRotation(state);
        for (final Face face : Face.VALUES) {
            final class_2746 property = CasingBlock.DIRECTION_TO_PROPERTY.get(TransformUtil.toWorld(face, rotation));
            state = state.method_11657(property, !items[face.ordinal()].method_7960());
        }

        if (state != level.method_8320(position)) {
            level.method_8501(position, state);
        }
    }

    // --------------------------------------------------------------------- //
    // ISidedInventory

    @Override
    public int[] method_5494(final class_2350 side) {
        return new int[]{blockEntity.toLocal(side).ordinal()};
    }

    @Override
    public boolean method_5492(final int index, final class_1799 stack, @Nullable final class_2350 side) {
        if (side == null || blockEntity.isLocked()) {
            return false;
        }

        final Face face = blockEntity.toLocal(side);
        return face.ordinal() == index &&
            method_5438(index).method_7960() &&
            blockEntity.getModule(face) == null && // Handles virtual modules.
            canInstall(stack, face);
    }

    @Override
    public boolean method_5493(final int index, final class_1799 stack, final class_2350 side) {
        return !blockEntity.isLocked() &&
            blockEntity.toLocal(side).ordinal() == index &&
            stack == method_5438(index);
    }

    private boolean canInstall(final class_1799 stack, final Face face) {
        return ModuleProviders.getProviderFor(stack, blockEntity, face).isPresent();
    }

    // --------------------------------------------------------------------- //
    // Inventory

    @Override
    protected void onItemAdded(final int index) {
        onItemAdded(index, Port.UP);
    }

    private void onItemAdded(final int index, final Port facing) {
        final class_1799 stack = method_5438(index);
        if (stack.method_7960()) {
            return;
        }

        final Face face = Face.VALUES[index];
        final Optional<ModuleProvider> provider = ModuleProviders.getProviderFor(stack, blockEntity, face);
        if (provider.isEmpty()) {
            return;
        }

        final Module module = provider.get().createModule(stack, blockEntity, face);

        if (module instanceof final ModuleWithRotation rotatableModule) {
            rotatableModule.setFacing(facing);
        }

        if (!blockEntity.getCasingLevel().method_8608()) {
            // Grab module data from newly created module, if any, don't rely on stack.
            // Rationale: module may initialize data from stack while contents of stack
            // are not synchronized to client, or do some fancy server-side only setup
            // based on the stack. The possibilities are endless. This is robust.
            final class_2487 moduleData;
            if (module != null) {
                module.onInstalled(stack);
                module.save(moduleData = new class_2487());
            } else {
                moduleData = null;
            }

            final CasingInventoryMessage message = new CasingInventoryMessage(blockEntity, index, stack, moduleData);
            Network.sendToTrackingPlayers(blockEntity, message);
        }

        blockEntity.setModule(Face.VALUES[index], module);
    }

    @Override
    protected void onItemRemoved(final int index) {
        final Face face = Face.VALUES[index];
        final Module module = blockEntity.getModule(face);
        blockEntity.setModule(face, null);
        if (!blockEntity.getCasingLevel().method_8608()) {
            if (module != null) {
                module.onUninstalled(method_5438(index));
                module.onDisposed();
            }

            final CasingInventoryMessage message = new CasingInventoryMessage(blockEntity, index, class_1799.field_8037, null);
            Network.sendToTrackingPlayers(blockEntity, message);
        } else {
            if (module != null) {
                module.onDisposed();
            }
        }
    }
}
