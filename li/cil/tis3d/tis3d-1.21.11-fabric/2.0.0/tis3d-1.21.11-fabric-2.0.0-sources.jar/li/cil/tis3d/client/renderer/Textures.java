/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer;

import li.cil.tis3d.api.API;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1059;
import net.minecraft.class_2960;

@Environment(EnvType.CLIENT)
public final class Textures {
    @SuppressWarnings("deprecation")
    public static final class_2960 LOCATION_BLOCK_ATLAS = class_1059.field_5275;

    public static final class_2960 LOCATION_GUI_BOOK_CODE_BACKGROUND = class_2960.method_60655(API.MOD_ID, "textures/gui/code_book.png");
    public static final class_2960 LOCATION_GUI_MANUAL_BACKGROUND = class_2960.method_60655(API.MOD_ID, "textures/gui/manual.png");
    public static final class_2960 LOCATION_GUI_MANUAL_TAB = class_2960.method_60655(API.MOD_ID, "textures/gui/manual_tab.png");
    public static final class_2960 LOCATION_GUI_MANUAL_SCROLL = class_2960.method_60655(API.MOD_ID, "textures/gui/manual_scroll.png");
    public static final class_2960 LOCATION_GUI_MEMORY = class_2960.method_60655(API.MOD_ID, "textures/gui/module_memory.png");

    public static final class_2960 LOCATION_OVERLAY_CASING_LOCKED = class_2960.method_60655(API.MOD_ID, "block/overlay/casing_locked");
    public static final class_2960 LOCATION_OVERLAY_CASING_UNLOCKED = class_2960.method_60655(API.MOD_ID, "block/overlay/casing_unlocked");
    public static final class_2960 LOCATION_OVERLAY_CASING_PORT_CLOSED = class_2960.method_60655(API.MOD_ID, "block/overlay/casing_port_closed");
    public static final class_2960 LOCATION_OVERLAY_CASING_PORT_OPEN = class_2960.method_60655(API.MOD_ID, "block/overlay/casing_port_open");
    public static final class_2960 LOCATION_OVERLAY_CASING_PORT_HIGHLIGHT = class_2960.method_60655(API.MOD_ID, "block/overlay/casing_port_highlight");
    public static final class_2960 LOCATION_OVERLAY_CASING_PORT_CLOSED_SMALL = class_2960.method_60655(API.MOD_ID, "block/overlay/casing_port_closed_small");

    public static final class_2960 LOCATION_OVERLAY_MODULE_AUDIO = class_2960.method_60655(API.MOD_ID, "block/overlay/audio_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_EXECUTION_ERROR = class_2960.method_60655(API.MOD_ID, "block/overlay/execution_module_error");
    public static final class_2960 LOCATION_OVERLAY_MODULE_EXECUTION_IDLE = class_2960.method_60655(API.MOD_ID, "block/overlay/execution_module_idle");
    public static final class_2960 LOCATION_OVERLAY_MODULE_EXECUTION_RUNNING = class_2960.method_60655(API.MOD_ID, "block/overlay/execution_module_running");
    public static final class_2960 LOCATION_OVERLAY_MODULE_EXECUTION_WAITING = class_2960.method_60655(API.MOD_ID, "block/overlay/execution_module_waiting");
    public static final class_2960 LOCATION_OVERLAY_MODULE_INFRARED = class_2960.method_60655(API.MOD_ID, "block/overlay/infrared_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_KEYPAD = class_2960.method_60655(API.MOD_ID, "block/overlay/keypad_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_QUEUE = class_2960.method_60655(API.MOD_ID, "block/overlay/queue_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_RANDOM = class_2960.method_60655(API.MOD_ID, "block/overlay/random_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_REDSTONE = class_2960.method_60655(API.MOD_ID, "block/overlay/redstone_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_REDSTONE_BARS = class_2960.method_60655(API.MOD_ID, "block/overlay/redstone_bars_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_SEQUENCER = class_2960.method_60655(API.MOD_ID, "block/overlay/sequencer_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_SERIAL_PORT = class_2960.method_60655(API.MOD_ID, "block/overlay/serial_port_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_STACK = class_2960.method_60655(API.MOD_ID, "block/overlay/stack_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_TERMINAL = class_2960.method_60655(API.MOD_ID, "block/overlay/terminal_module");
    public static final class_2960 LOCATION_OVERLAY_MODULE_TIMER = class_2960.method_60655(API.MOD_ID, "block/overlay/timer_module");

    // --------------------------------------------------------------------- //

    private Textures() {
    }
}
