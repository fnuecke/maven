/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.fabric;

import li.cil.tis3d.api.platform.FabricProviderInitializer;
import li.cil.tis3d.common.CommonBootstrap;
import li.cil.tis3d.common.CommonSetup;
import li.cil.tis3d.common.block.CasingBlock;
import li.cil.tis3d.common.block.entity.fabric.ChunkUnloadListener;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.player.PlayerPickItemEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2586;

public final class CommonBootstrapFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        CommonBootstrap.run();
        CommonSetup.run();

        PlayerPickItemEvents.BLOCK.register((player, pos, state, includeData) -> {
            final var stack = CasingBlock.getPickedModule(player.method_51469(), pos, player);
            return stack.method_7960() ? null : stack;
        });

        FabricLoader.getInstance()
            .getEntrypoints("tis3d:registration", FabricProviderInitializer.class)
            .forEach(FabricProviderInitializer::registerProviders);

        ServerChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> {
            for (final class_2586 blockEntity : chunk.method_12214().values()) {
                if (blockEntity instanceof final ChunkUnloadListener listener) {
                    listener.onChunkUnloaded();
                }
            }
        });
    }
}
