/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import net.minecraft.class_1268;
import net.minecraft.class_9129;

public abstract class AbstractReadOnlyMemoryModuleDataMessage extends AbstractMessage {
    protected class_1268 hand;
    protected byte[] data;

    protected AbstractReadOnlyMemoryModuleDataMessage(final class_1268 hand, final byte[] data) {
        this.hand = hand;
        this.data = data;
    }

    protected AbstractReadOnlyMemoryModuleDataMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void fromBytes(final class_9129 buffer) {
        hand = buffer.method_10818(class_1268.class);
        data = new byte[buffer.readInt()];
        buffer.method_52979(data);
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_10817(hand);
        buffer.method_53002(data.length);
        buffer.method_52983(data);
    }
}
