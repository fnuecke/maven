/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

import li.cil.tis3d.common.block.CasingBlock;
import net.minecraft.class_1269;
import net.minecraft.class_1838;

/**
 * Base item for all keys.
 */
public final class KeyItem extends ModItem {
    public KeyItem(final class_1793 properties) {
        super(properties.method_7889(1));
    }

    // --------------------------------------------------------------------- //
    // Item

    @Override
    public class_1269 method_7884(final class_1838 context) {
        return CasingBlock.useIfCasing(context).orElseGet(() -> super.method_7884(context));
    }
}
