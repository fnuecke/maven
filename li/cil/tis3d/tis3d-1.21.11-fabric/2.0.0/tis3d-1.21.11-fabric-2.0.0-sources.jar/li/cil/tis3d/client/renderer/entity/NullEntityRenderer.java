/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.entity;

import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public final class NullEntityRenderer<T extends class_1297> extends class_897<T, class_10017> {
    public NullEntityRenderer(final class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public boolean method_3933(final T entity, final class_4604 frustum, final double cameraX, final double cameraY, final double cameraZ) {
        return false;
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}
