/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer;

import li.cil.tis3d.api.API;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.common.module.DisplayModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_9848;
import java.util.Map;
import java.util.WeakHashMap;

@Environment(EnvType.CLIENT)
public final class DisplayModuleRenderer {
    private static final Map<DisplayModule, Entry> ENTRIES = new WeakHashMap<>();
    private static int nextTextureId;

    public static void render(final DisplayModule module, final RenderContext context) {
        final Entry entry = ENTRIES.computeIfAbsent(module, unused -> new Entry());
        entry.validate(module);
        context.drawQuad(context.getBuffer().method_73477(entry.getOrCreateRenderLayer()),
            DisplayModule.MARGIN / 32f, DisplayModule.MARGIN / 32f,
            DisplayModule.RESOLUTION / 32f, DisplayModule.RESOLUTION / 32f);
    }

    public static void dispose(final DisplayModule module) {
        final Entry entry = ENTRIES.remove(module);
        if (entry != null) {
            entry.delete();
        }
    }

    private static final class Entry {
        private class_1043 texture;
        private class_2960 textureId;
        private class_1921 renderLayer;

        private class_1043 getOrCreateTexture() {
            if (texture == null) {
                texture = new class_1043("tis3d/display_module", DisplayModule.RESOLUTION, DisplayModule.RESOLUTION, false);
            }
            return texture;
        }

        private class_1921 getOrCreateRenderLayer() {
            if (renderLayer == null) {
                final class_1043 texture = getOrCreateTexture();
                textureId = class_2960.method_60655(API.MOD_ID, "dynamic/display_module_" + (++nextTextureId));
                class_310.method_1551().method_1531().method_4616(textureId, texture);
                renderLayer = ModRenderType.unlitTexture(textureId);
            }
            return renderLayer;
        }

        private void validate(final DisplayModule module) {
            if (!module.consumeImageDirty()) {
                return;
            }

            final class_1043 texture = getOrCreateTexture();
            final class_1011 nativeImage = texture.method_4525();
            if (nativeImage == null) {
                return;
            }

            final int[] image = module.getImage();
            int ip = 0;
            for (int iy = 0; iy < DisplayModule.RESOLUTION; iy++) {
                for (int ix = 0; ix < DisplayModule.RESOLUTION; ix++, ip++) {
                    final int argb = image[ip];
                    nativeImage.method_4305(ix, iy, class_9848.method_61324(
                        class_9848.method_61320(argb), class_9848.method_61331(argb), class_9848.method_61329(argb), class_9848.method_61327(argb)));
                }
            }

            texture.method_4524();
        }

        private void delete() {
            final class_310 minecraft = class_310.method_1551();
            if (textureId != null) {
                final class_2960 id = textureId;
                minecraft.method_18859(() -> minecraft.method_1531().method_4615(id));
                textureId = null;
            }
            if (texture != null) {
                final class_1043 toClose = texture;
                minecraft.method_18859(toClose::close);
                texture = null;
            }
            renderLayer = null;
        }
    }

    // --------------------------------------------------------------------- //

    private DisplayModuleRenderer() {
    }
}
