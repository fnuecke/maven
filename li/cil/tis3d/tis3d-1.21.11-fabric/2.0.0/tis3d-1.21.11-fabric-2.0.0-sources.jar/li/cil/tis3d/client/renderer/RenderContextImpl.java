/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer;

import li.cil.manual.api.render.FontRenderer;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.util.Color;
import net.minecraft.class_1058;
import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class RenderContextImpl implements RenderContext {
    private static final int DETAIL_RENDER_RANGE = 8;

    private final class_4587 matrixStack;
    private final class_4597 buffer;
    private final class_243 cameraPosition;
    private final class_239 cameraHitResult;
    private final float partialTicks;
    private final int light;
    private final int overlay;

    // --------------------------------------------------------------------- //

    public RenderContextImpl(final class_4587 matrixStack, final class_4597 buffer,
                             final class_243 cameraPosition, final class_239 cameraHitResult,
                             final float partialTicks, final int light, final int overlay) {
        this.matrixStack = matrixStack;
        this.buffer = buffer;
        this.cameraPosition = cameraPosition;
        this.cameraHitResult = cameraHitResult;
        this.partialTicks = partialTicks;
        this.light = light;
        this.overlay = overlay;
    }

    public RenderContextImpl(final RenderContextImpl other, final int light) {
        this(other.matrixStack, other.buffer, other.cameraPosition, other.cameraHitResult,
            other.partialTicks, light, other.overlay);
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_239 getCameraHitResult() {
        return cameraHitResult;
    }

    @Override
    public class_4587 getMatrixStack() {
        return matrixStack;
    }

    @Override
    public float getPartialTicks() {
        return partialTicks;
    }

    @Override
    public class_4597 getBuffer() {
        return buffer;
    }

    @Override
    public boolean closeEnoughForDetails(final class_2338 position) {
        return position.method_19769(cameraPosition, DETAIL_RENDER_RANGE);
    }

    @Override
    public void drawString(final FontRenderer fontRenderer, final CharSequence value, final int argb) {
        fontRenderer.drawInBatch(value, argb, matrixStack.method_23760().method_23761(), buffer);
    }

    @Override
    public void drawAtlasQuadLit(final class_2960 location) {
        final class_4588 builder = buffer.method_73477(class_12249.method_76000(Textures.LOCATION_BLOCK_ATLAS));
        drawAtlasQuad(builder, getSprite(location), 0, 0, 1, 1, 0, 0, 1, 1, Color.WHITE);
    }

    @Override
    public void drawAtlasQuadUnlit(final class_2960 location) {
        drawAtlasQuadUnlit(location, 0, 0, 1, 1, 0, 0, 1, 1, Color.WHITE);
    }

    @Override
    public void drawAtlasQuadUnlit(final class_2960 location,
                                   final float x, final float y, final float width, final float height,
                                   final float u0, final float v0, final float u1, final float v1,
                                   final int argb) {
        final class_4588 builder = buffer.method_73477(ModRenderType.unlitAtlasTexture());
        drawAtlasQuad(builder, getSprite(location), x, y, width, height, u0, v0, u1, v1, argb);
    }

    @Override
    public void drawQuadUnlit(final float x, final float y, final float width, final float height, final int argb) {
        final class_4588 builder = buffer.method_73477(ModRenderType.unlit());
        drawQuad(builder, x, y, width, height, 0, 0, 1, 1, argb);
    }

    @Override
    public void drawQuad(final class_4588 builder, final float x, final float y, final float width, final float height) {
        drawQuad(builder, x, y, width, height, Color.WHITE);
    }

    @Override
    public void drawQuad(final class_4588 builder,
                         final float x, final float y, final float width, final float height,
                         final float u0, final float v0, final float u1, final float v1,
                         final int argb) {
        final var last = getMatrixStack().method_23760();
        final var pose = last.method_23761();
        final var up = new Vector3f(0, 0, -1);

        addVertex(builder, pose, last, up, x, y + height, u0, v1, argb);
        addVertex(builder, pose, last, up, x + width, y + height, u1, v1, argb);
        addVertex(builder, pose, last, up, x + width, y, u1, v0, argb);
        addVertex(builder, pose, last, up, x, y, u0, v0, argb);
    }

    // --------------------------------------------------------------------- //

    private void addVertex(final class_4588 builder, final Matrix4f pose, final class_4587.class_4665 last,
                           final Vector3f up, final float x, final float y,
                           final float u, final float v, final int argb) {
        builder.method_22918(pose, x, y, 0)
            .method_39415(argb)
            .method_22913(u, v)
            .method_22922(overlay)
            .method_60803(light)
            .method_60831(last, up.x(), up.y(), up.z());
    }

    // --------------------------------------------------------------------- //

    private static class_1058 getSprite(final class_2960 location) {
        return class_310.method_1551().method_72703().method_73030(new class_4730(Textures.LOCATION_BLOCK_ATLAS, location));
    }
}
