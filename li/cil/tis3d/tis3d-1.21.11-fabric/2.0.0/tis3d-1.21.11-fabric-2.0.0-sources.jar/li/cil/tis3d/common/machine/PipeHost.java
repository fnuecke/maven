/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.machine;

import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2470;

/**
 * Abstraction layer for pipe containers, provides positional awareness.
 */
public interface PipeHost {
    class_1937 getPipeHostLevel();

    class_2338 getPipeHostPosition();

    default class_2470 getPipeHostRotation() {
        return class_2470.field_11467;
    }

    void onPipeStateChanged();

    default void onBeforeWriteComplete(final Face sendingFace, final Port sendingPort) {
    }

    default void onWriteComplete(final Face sendingFace, final Port sendingPort) {
    }
}
