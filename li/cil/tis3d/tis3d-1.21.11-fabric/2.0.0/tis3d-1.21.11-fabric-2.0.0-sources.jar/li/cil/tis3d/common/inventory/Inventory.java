/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.inventory;

import java.util.Arrays;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

/**
 * Base implementation of an array based inventory.
 */
public class Inventory implements class_1263 {
    private static final String TAG_ITEMS = "inventory";

    protected final class_1799[] items;

    public Inventory(final int size) {
        Arrays.fill(items = new class_1799[size], class_1799.field_8037);
    }

    // --------------------------------------------------------------------- //

    public void load(final class_11368 input) {
        int index = 0;
        for (final class_1799 stack : input.method_71437(TAG_ITEMS, class_1799.field_49266)) {
            if (index >= items.length) {
                break;
            }
            items[index++] = stack;
        }
    }

    public void save(final class_11372 output) {
        final class_11372.class_11373<class_1799> itemList = output.method_71467(TAG_ITEMS, class_1799.field_49266);
        for (final class_1799 stack : items) {
            itemList.method_71484(stack == null ? class_1799.field_8037 : stack);
        }
    }

    // --------------------------------------------------------------------- //

    protected void onItemAdded(final int index) {
    }

    protected void onItemRemoved(final int index) {
    }

    // --------------------------------------------------------------------- //
    // IInventory

    @Override
    public int method_5439() {
        return items.length;
    }

    public boolean method_5442() {
        for (final class_1799 stack : items) {
            if (!stack.method_7960()) {
                return false;
            }
        }

        return true;
    }

    @Override
    public class_1799 method_5438(final int index) {
        return items[index];
    }

    @Override
    public class_1799 method_5434(final int index, final int count) {
        if (items[index].method_7947() <= count) {
            return method_5441(index);
        } else {
            final class_1799 stack = items[index].method_7971(count);
            assert items[index].method_7947() > 0;
            method_5431();
            return stack;
        }
    }

    @Override
    public class_1799 method_5441(final int index) {
        final class_1799 stack = items[index];
        method_5447(index, class_1799.field_8037);
        return stack;
    }

    @Override
    public void method_5447(final int index, final class_1799 stack) {
        if (items[index] == stack) {
            return;
        }

        if (!items[index].method_7960()) {
            onItemRemoved(index);
        }

        items[index] = stack;

        if (!items[index].method_7960()) {
            onItemAdded(index);
        }

        method_5431();
    }

    @Override
    public void method_5431() {
    }

    @Override
    public boolean method_5443(final class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
    }
}
