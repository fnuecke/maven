/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.gui;

import li.cil.tis3d.client.ClientConfig;
import li.cil.tis3d.common.module.TerminalModule;
import li.cil.tis3d.util.Color;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_1268;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import java.util.Objects;

/**
 * Invisible GUI for the terminal module, purely used to grab keyboard input.
 */
public final class TerminalModuleScreen extends class_437 {
    private final TerminalModule module;

    public TerminalModuleScreen(final TerminalModule module) {
        super(class_2561.method_43473());
        this.module = module;
    }

    public boolean isFor(final TerminalModule that) {
        return that == module;
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        // This page intentionally left blank.
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        graphics.method_25294(4, 4, field_22789 - 4, 8, Color.WHITE); // Top
        graphics.method_25294(4, 4, 8, field_22790 - 4, Color.WHITE); // Left
        graphics.method_25294(4, field_22790 - 8, field_22789 - 4, field_22790 - 4, Color.WHITE); // Bottom
        graphics.method_25294(field_22789 - 8, 4, field_22789 - 4, field_22790 - 4, Color.WHITE); // Right
    }

    @Override
    public boolean method_25404(final class_11908 event) {
        if (super.method_25404(event)) {
            return true;
        }

        final int keyCode = event.comp_4795();
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            return true;
        } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            writeToModule('\b');
            return true;
        } else if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            writeToModule('\n');
            return true;
        } else if (keyCode == GLFW.GLFW_KEY_TAB) {
            writeToModule('\t');
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25400(final class_11905 event) {
        if (super.method_25400(event)) {
            return true;
        }

        final int codepoint = event.comp_4793();
        if (codepoint != 0) {
            writeToModule((char) codepoint);
            return true;
        }

        return false;
    }

    private void writeToModule(final char value) {
        module.writeToInput(value);

        final class_746 player = getMinecraft().field_1724;
        if (ClientConfig.animateTypingHand && player != null) {
            player.method_6104(class_1268.field_5808);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --------------------------------------------------------------------- //

    private class_310 getMinecraft() {
        return Objects.requireNonNull(field_22787);
    }
}
