/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.manual.provider;

import li.cil.manual.api.ManualModel;
import li.cil.manual.api.prefab.provider.NamespacePathProvider;
import li.cil.manual.api.util.MatchResult;
import li.cil.tis3d.api.API;
import li.cil.tis3d.client.manual.Manuals;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import java.util.Objects;
import java.util.Optional;

public class ModPathProvider extends NamespacePathProvider {
    public ModPathProvider() {
        super(API.MOD_ID);
    }

    @Override
    public MatchResult matches(final ManualModel manual) {
        return Objects.equals(manual, Manuals.MANUAL.get()) ? MatchResult.MATCH : MatchResult.MISMATCH;
    }

    @Override
    public Optional<String> pathFor(final class_1937 level, final class_2338 pos, final class_2350 side) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final CasingBlockEntity casing) {
            final class_1799 moduleStack = casing.method_5438(casing.toLocal(side).ordinal());
            final Optional<String> path = pathFor(moduleStack);
            if (path.isPresent()) {
                return path;
            }
        }

        return super.pathFor(level, pos, side);
    }
}
