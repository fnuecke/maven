/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.tags;

import li.cil.tis3d.api.API;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class ItemTags {
    public static final class_6862<class_1792> COMPUTERS = tag("computers");
    public static final class_6862<class_1792> MODULES = tag("modules");
    public static final class_6862<class_1792> BOOKS = tag("books");
    public static final class_6862<class_1792> KEYS = tag("keys");

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    // --------------------------------------------------------------------- //

    private static class_6862<class_1792> tag(final String name) {
        return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(API.MOD_ID, name));
    }
}
