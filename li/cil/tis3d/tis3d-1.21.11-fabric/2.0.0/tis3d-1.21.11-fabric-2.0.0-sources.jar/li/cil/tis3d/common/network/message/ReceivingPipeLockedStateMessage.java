/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_9129;

public final class ReceivingPipeLockedStateMessage extends AbstractMessageWithPosition {
    private Face face;
    private Port port;
    private boolean isLocked;

    public ReceivingPipeLockedStateMessage(final Casing casing, final Face face, final Port port, final boolean isLocked) {
        super(casing.getPosition());
        this.face = face;
        this.port = port;
        this.isLocked = isLocked;
    }

    @SuppressWarnings("unused") // For deserialization.
    public ReceivingPipeLockedStateMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final class_1937 level = getClientLevel();
        if (level != null) {
            withBlockEntity(level, CasingBlockEntity.class, casing ->
                casing.setReceivingPipeLockedClient(face, port, isLocked));
        }
    }

    // We can nicely compress the data of this message into one byte:
    // - Face can have 6 values, needs 3 bits.
    // - Port can have 4 values, needs 2 bits.
    // - Locked can have 2 values, needs 1 bit.
    // It's an infrequent message, so this is totally overkill. But it's fun!

    @Override
    public void fromBytes(final class_9129 buffer) {
        super.fromBytes(buffer);

        final byte compressed = buffer.readByte();
        face = Face.VALUES[(compressed >>> 3) & 0b111];
        port = Port.VALUES[(compressed >>> 1) & 0b11];
        isLocked = (compressed & 0b1) == 1;
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        super.toBytes(buffer);

        final byte compressed = (byte) ((face.ordinal() << 3) |
                                        (port.ordinal() << 1) |
                                        (isLocked ? 1 : 0));
        buffer.method_52997(compressed);
    }
}
