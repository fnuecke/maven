/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_9129;

public final class RedstoneParticleEffectMessage extends AbstractMessage {
    private double x;
    private double y;
    private double z;

    public RedstoneParticleEffectMessage(final double x, final double y, final double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public RedstoneParticleEffectMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final class_1937 level = getClientLevel();
        if (level != null) {
            level.method_8406(class_2390.field_11188, x, y, z, 0, 0, 0);
        }
    }

    @Override
    public void fromBytes(final class_9129 buffer) {
        x = buffer.readDouble();
        y = buffer.readDouble();
        z = buffer.readDouble();
    }

    @Override
    public void toBytes(final class_9129 buffer) {
        buffer.method_52940(x);
        buffer.method_52940(y);
        buffer.method_52940(z);
    }
}
