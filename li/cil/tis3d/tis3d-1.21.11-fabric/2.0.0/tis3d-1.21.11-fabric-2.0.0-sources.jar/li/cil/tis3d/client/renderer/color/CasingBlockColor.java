/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.color;

import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.api.module.traits.ModuleWithBakedModel;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_322;
import javax.annotation.Nullable;
import java.util.OptionalInt;

public final class CasingBlockColor implements class_322 {
    @Override
    public int getColor(final class_2680 state, @Nullable final class_1920 level, @Nullable final class_2338 pos, final int tintIndex) {
        if (level == null || pos == null) {
            return 0;
        }

        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final CasingBlockEntity casing) {
            for (final Face face : Face.VALUES) {
                final Module module = casing.getModule(face);
                if (module instanceof final ModuleWithBakedModel moduleWithModel) {
                    if (moduleWithModel.hasModel()) {
                        final OptionalInt optional = moduleWithModel.getTintColor(level, pos, tintIndex);
                        if (optional.isPresent()) {
                            return optional.getAsInt();
                        }
                    }
                }
            }
        }

        return 0;
    }
}
