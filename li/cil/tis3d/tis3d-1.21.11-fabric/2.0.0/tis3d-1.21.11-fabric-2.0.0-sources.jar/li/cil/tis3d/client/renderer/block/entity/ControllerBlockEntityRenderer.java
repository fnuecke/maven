/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.entity;

import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_827;
import javax.annotation.Nullable;
import java.util.Objects;

public final class ControllerBlockEntityRenderer implements class_827<ControllerBlockEntity, ControllerRenderState> {
    private static final class_243 LABEL_ATTACHMENT = new class_243(0.5, 1.4, 0.5);

    public ControllerBlockEntityRenderer(final class_5614.class_5615 context) {
    }

    @Override
    public ControllerRenderState method_74335() {
        return new ControllerRenderState();
    }

    @Override
    public void extractRenderState(final ControllerBlockEntity controller, final ControllerRenderState state,
                                   final float partialTicks, final class_243 cameraPosition,
                                   @Nullable final class_11683.class_11792 crumbling) {
        class_827.super.method_74331(controller, state, partialTicks, cameraPosition, crumbling);

        state.controllerState = controller.getState();
        state.distanceToCameraSq = cameraPosition.method_1025(class_243.method_24953(controller.method_11016()));

        final class_239 hit = class_310.method_1551().field_1765;
        state.isObserverLookingAt = hit instanceof final class_3965 blockHit
            && Objects.equals(blockHit.method_17777(), controller.method_11016());
    }

    @Override
    public void submit(final ControllerRenderState state, final class_4587 matrixStack,
                       final class_11659 collector, final class_12075 camera) {
        if (state.controllerState == null || !state.controllerState.isError || !state.isObserverLookingAt) {
            return;
        }

        // submitNameTag handles the billboarding and background for us.
        collector.method_73482(matrixStack, LABEL_ATTACHMENT, 0, state.controllerState.message,
            true, class_765.method_23687(0xF, 0xF), state.distanceToCameraSq, camera);
    }
}
