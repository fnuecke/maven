/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.container;

import dev.architectury.registry.menu.MenuRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.class_3917;
import net.minecraft.class_7924;

public final class Containers {
    private static final DeferredRegister<class_3917<?>> MENU_TYPES = RegistryUtils.get(class_7924.field_41207);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_3917<ReadOnlyMemoryModuleContainer>> READ_ONLY_MEMORY_MODULE = MENU_TYPES.register("read_only_memory_module", () -> MenuRegistry.ofExtended(ReadOnlyMemoryModuleContainer::create));

    // --------------------------------------------------------------------- //

    public static void initialize() {
        MENU_TYPES.register();
    }
}
