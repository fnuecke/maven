/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import javax.annotation.Nullable;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public final class BlockStateUtils {
    @Nullable
    public static class_2680 getBlockStateFromItemStack(final class_1799 stack) {
        if (stack.method_7960()) {
            return null;
        }

        final class_2248 block = class_2248.method_9503(stack.method_7909());
        if (block == class_2246.field_10124) {
            return null;
        }

        return block.method_9564();
    }

    // --------------------------------------------------------------------- //

    private BlockStateUtils() {
    }
}
