/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import javax.annotation.Nullable;
import net.minecraft.class_1263;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_5819;

/**
 * Utility class for interacting with inventories.
 */
public final class InventoryUtils {
    /**
     * Drop some items from an inventory into a level.
     *
     * @param level     the level to drop the item into.
     * @param pos       the position in the level to drop the item at.
     * @param inventory the inventory to drop the item from.
     * @param index     the slot of the inventory to drop the item from.
     * @param count     the number of items to drop from the stack in that slot.
     * @param towards   the direction in which to drop the item.
     * @return the entity representing the dropped item stack, or {@code null} if the stack was null or empty.
     */
    @Nullable
    public static class_1542 drop(final class_1937 level, final class_2338 pos, final class_1263 inventory, final int index, final int count, final class_2350 towards) {
        final class_1799 stack = inventory.method_5434(index, count);
        return spawnStackInLevel(level, pos, stack, towards);
    }

    /**
     * Spawns an item stack in the level.
     *
     * @param level   the level to spawn the item stack in.
     * @param pos     the position to spawn the item stack at.
     * @param stack   the item stack to spawn in the level.
     * @param towards the direction in which to drop the item.
     * @return the entity representing the dropped item stack, or {@code null} if the stack was null or empty.
     */
    @Nullable
    public static class_1542 spawnStackInLevel(final class_1937 level, final class_2338 pos, final class_1799 stack, final class_2350 towards) {
        if (stack.method_7960()) {
            return null;
        }

        final class_5819 rng = level.field_9229;

        final double ox = towards.method_10148();
        final double oy = towards.method_10164();
        final double oz = towards.method_10165();
        final double tx = 0.1 * (rng.method_43058() - 0.5) + ox * 0.65;
        final double ty = 0.1 * (rng.method_43058() - 0.5) + oy * 0.75 + (ox + oz) * 0.25;
        final double tz = 0.1 * (rng.method_43058() - 0.5) + oz * 0.65;
        final double px = pos.method_10263() + 0.5 + tx;
        final double py = pos.method_10264() + 0.5 + ty;
        final double pz = pos.method_10260() + 0.5 + tz;

        final class_1542 entity = new class_1542(level, px, py, pz, stack.method_7972());

        entity.method_18800(
            0.0125 * (rng.method_43058() - 0.5) + ox * 0.03,
            0.0125 * (rng.method_43058() - 0.5) + oy * 0.08 + (ox + oz) * 0.03,
            0.0125 * (rng.method_43058() - 0.5) + oz * 0.03
        );
        entity.method_6982(15);
        level.method_8649(entity);

        return entity;
    }

    // --------------------------------------------------------------------- //

    private InventoryUtils() {
    }
}
