/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.module.traits;

import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.module.Module;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * Modules implementing this interface will be notified when the block adjacent
 * to the module's {@link Casing} changes.
 * <p>
 * Specifically, this is called from the {@link Casing}'s
 * {@link class_2248#method_9612(class_2680, class_1937, class_2338, class_2248, class_2338, boolean)} method.
 */
public interface ModuleWithBlockChangeListener extends Module {
    /**
     * Called when a block adjacent to the hosting {@link Casing} changes.
     *
     * @param neighborPos      the position of the block that changed.
     * @param isModuleNeighbor whether the block that changed is the one in front of the module, for convenience.
     */
    void onNeighborBlockChange(final class_2338 neighborPos, final boolean isModuleNeighbor);
}
