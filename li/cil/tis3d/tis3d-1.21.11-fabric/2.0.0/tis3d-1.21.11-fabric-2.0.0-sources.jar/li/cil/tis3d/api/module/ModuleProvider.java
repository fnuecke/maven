/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.module;

import li.cil.tis3d.api.API;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import javax.annotation.Nullable;

/**
 * Creates a module instance for a specified item stack.
 * <p>
 * Providers should be as specific as possible in the implementation of their
 * {@link #matches(class_1799, Casing, Face)} method. The first provider claiming to support
 * the specified parameters will be used to create a {@link Module} instance via its
 * {@link #createModule(class_1799, Casing, Face)} method and the order in which providers are
 * queried is not guaranteed to be deterministic. As such, there should be no two providers
 * that can support the same {@link class_1799}.
 * <p>
 * Additional providers may be registered with the {@link net.minecraft.class_2378}
 * <tt>tis3d:modules</tt>.
 */
public interface ModuleProvider {
    /**
     * The registry name of the registry holding module providers.
     */
    class_5321<class_2378<ModuleProvider>> REGISTRY = class_5321.method_29180(class_2960.method_60655(API.MOD_ID, "module_provider"));

    /**
     * Checks whether the provider supports the specified stack.
     *
     * @param stack  the stack to check for.
     * @param casing the casing the module would be installed in.
     * @param face   the face the module would be installed on.
     * @return <tt>true</tt> if the stack is supported, <tt>false</tt> otherwise.
     */
    boolean matches(final class_1799 stack, final Casing casing, final Face face);

    /**
     * Creates a new module instance for the specified item stack.
     * <p>
     * Returns {@code null} if the specified item type is not supported.
     *
     * @param stack  the stack to get the module instance for.
     * @param casing the casing the module will be installed in.
     * @param face   the face the module will be installed on.
     * @return a new module instance, or {@code null}.
     */
    @Nullable
    Module createModule(final class_1799 stack, final Casing casing, final Face face);
}
