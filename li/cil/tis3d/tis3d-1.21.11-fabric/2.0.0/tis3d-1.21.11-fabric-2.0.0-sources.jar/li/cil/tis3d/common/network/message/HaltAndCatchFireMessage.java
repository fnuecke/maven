/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_9129;

public final class HaltAndCatchFireMessage extends AbstractMessageWithPosition {
    public HaltAndCatchFireMessage(final class_2338 position) {
        super(position);
    }

    public HaltAndCatchFireMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final class_1937 level = getClientLevel();
        if (level != null) {
            withBlockEntity(level, ControllerBlockEntity.class, ControllerBlockEntity::haltAndCatchFire);
        }
    }
}
