/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.block;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.api.API;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import java.util.function.Function;

public final class Blocks {
    private static final DeferredRegister<class_2248> BLOCKS = RegistryUtils.get(class_7924.field_41254);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<CasingBlock> CASING = register("casing", CasingBlock::new);
    public static final RegistrySupplier<ControllerBlock> CONTROLLER = register("controller", ControllerBlock::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        BLOCKS.register();
    }

    // --------------------------------------------------------------------- //

    private static <T extends class_2248> RegistrySupplier<T> register(final String name, final Function<class_2251, T> factory) {
        final class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254,
            class_2960.method_60655(API.MOD_ID, name));
        return BLOCKS.register(name, () -> factory.apply(createProperties().method_63500(key)));
    }

    private static class_2251 createProperties() {
        return class_2251.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9629(1.5f, 6f);
    }
}
