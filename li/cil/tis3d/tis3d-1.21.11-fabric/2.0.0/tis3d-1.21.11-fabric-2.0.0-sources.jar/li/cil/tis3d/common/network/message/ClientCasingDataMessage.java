/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import io.netty.buffer.ByteBuf;
import li.cil.tis3d.api.machine.Casing;
import net.minecraft.class_1937;
import net.minecraft.class_9129;

public final class ClientCasingDataMessage extends AbstractCasingDataMessage {
    public ClientCasingDataMessage(final Casing casing, final ByteBuf data) {
        super(casing, data);
    }

    public ClientCasingDataMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final class_1937 level = getServerLevel(context);
        if (level != null) {
            handleMessage(level);
        }
    }
}
