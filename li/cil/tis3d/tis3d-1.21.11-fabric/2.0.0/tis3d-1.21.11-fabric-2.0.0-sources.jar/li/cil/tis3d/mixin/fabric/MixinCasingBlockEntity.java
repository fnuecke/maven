/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.mixin.fabric;

import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.common.block.entity.fabric.ChunkUnloadListener;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(CasingBlockEntity.class)
public abstract class MixinCasingBlockEntity extends class_2586 implements ChunkUnloadListener {
    private MixinCasingBlockEntity(final class_2591<?> type, final class_2338 pos, final class_2680 state) {
        super(type, pos, state);
    }

    @Unique
    @SuppressWarnings("DataFlowIssue")
    private CasingBlockEntity tis3d$asCasingBlockEntity() {
        return (CasingBlockEntity) (Object) this;
    }

    @Override
    public void onChunkUnloaded() {
        tis3d$asCasingBlockEntity().dispose();
    }
}
