/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11659;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public final class SubmitBufferSource implements class_4597 {
    private final List<Segment> segments = new ArrayList<>();

    private record Segment(class_1921 renderType, Recorder recorder) {
    }

    @Override
    public class_4588 method_73477(final class_1921 renderType) {
        if (!segments.isEmpty()) {
            final Segment last = segments.get(segments.size() - 1);
            if (last.renderType().equals(renderType)) {
                return last.recorder();
            }
        }
        final Segment segment = new Segment(renderType, new Recorder());
        segments.add(segment);
        return segment.recorder();
    }

    public void submitTo(final class_11659 collector, final class_4587 poseStack) {
        for (int i = 0; i < segments.size(); i++) {
            final Segment segment = segments.get(i);
            if (segment.recorder().vertexCount == 0) {
                continue;
            }
            final Recorder replay = segment.recorder().copy();
            collector.method_73529(i).method_73483(poseStack, segment.renderType(),
                (pose, consumer) -> replay.replay(consumer));
        }
        segments.clear();
    }

    // --------------------------------------------------------------------- //

    private static final int HAS_COLOR = 1;
    private static final int HAS_UV = 1 << 1;
    private static final int HAS_UV1 = 1 << 2;
    private static final int HAS_UV2 = 1 << 3;
    private static final int HAS_NORMAL = 1 << 4;

    private static final class Recorder implements class_4588 {
        private float[] positions = new float[3 * 16];
        private int[] colors = new int[16];
        private float[] uvs = new float[2 * 16];
        private int[] uv1s = new int[2 * 16];
        private int[] uv2s = new int[2 * 16];
        private float[] normals = new float[3 * 16];
        private int[] masks = new int[16];
        private int vertexCount;

        private Recorder copy() {
            final Recorder other = new Recorder();
            other.positions = positions.clone();
            other.colors = colors.clone();
            other.uvs = uvs.clone();
            other.uv1s = uv1s.clone();
            other.uv2s = uv2s.clone();
            other.normals = normals.clone();
            other.masks = masks.clone();
            other.vertexCount = vertexCount;
            return other;
        }

        private void replay(final class_4588 consumer) {
            for (int i = 0; i < vertexCount; i++) {
                consumer.method_22912(positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2]);
                final int mask = masks[i];
                if ((mask & HAS_COLOR) != 0) {
                    consumer.method_39415(colors[i]);
                }
                if ((mask & HAS_UV) != 0) {
                    consumer.method_22913(uvs[i * 2], uvs[i * 2 + 1]);
                }
                if ((mask & HAS_UV1) != 0) {
                    consumer.method_60796(uv1s[i * 2], uv1s[i * 2 + 1]);
                }
                if ((mask & HAS_UV2) != 0) {
                    consumer.method_22921(uv2s[i * 2], uv2s[i * 2 + 1]);
                }
                if ((mask & HAS_NORMAL) != 0) {
                    consumer.method_22914(normals[i * 3], normals[i * 3 + 1], normals[i * 3 + 2]);
                }
            }
        }

        private void grow() {
            if (vertexCount < masks.length) {
                return;
            }
            final int capacity = masks.length * 2;
            positions = java.util.Arrays.copyOf(positions, capacity * 3);
            colors = java.util.Arrays.copyOf(colors, capacity);
            uvs = java.util.Arrays.copyOf(uvs, capacity * 2);
            uv1s = java.util.Arrays.copyOf(uv1s, capacity * 2);
            uv2s = java.util.Arrays.copyOf(uv2s, capacity * 2);
            normals = java.util.Arrays.copyOf(normals, capacity * 3);
            masks = java.util.Arrays.copyOf(masks, capacity);
        }

        @Override
        public class_4588 method_22912(final float x, final float y, final float z) {
            grow();
            positions[vertexCount * 3] = x;
            positions[vertexCount * 3 + 1] = y;
            positions[vertexCount * 3 + 2] = z;
            masks[vertexCount] = 0;
            vertexCount++;
            return this;
        }

        @Override
        public class_4588 method_1336(final int red, final int green, final int blue, final int alpha) {
            return method_39415(alpha << 24 | red << 16 | green << 8 | blue);
        }

        @Override
        public class_4588 method_39415(final int argb) {
            final int index = vertexCount - 1;
            colors[index] = argb;
            masks[index] |= HAS_COLOR;
            return this;
        }

        @Override
        public class_4588 method_22913(final float u, final float v) {
            final int index = vertexCount - 1;
            uvs[index * 2] = u;
            uvs[index * 2 + 1] = v;
            masks[index] |= HAS_UV;
            return this;
        }

        @Override
        public class_4588 method_60796(final int u, final int v) {
            final int index = vertexCount - 1;
            uv1s[index * 2] = u;
            uv1s[index * 2 + 1] = v;
            masks[index] |= HAS_UV1;
            return this;
        }

        @Override
        public class_4588 method_22921(final int u, final int v) {
            final int index = vertexCount - 1;
            uv2s[index * 2] = u;
            uv2s[index * 2 + 1] = v;
            masks[index] |= HAS_UV2;
            return this;
        }

        @Override
        public class_4588 method_22914(final float x, final float y, final float z) {
            final int index = vertexCount - 1;
            normals[index * 3] = x;
            normals[index * 3 + 1] = y;
            normals[index * 3 + 2] = z;
            masks[index] |= HAS_NORMAL;
            return this;
        }

        @Override
        public class_4588 method_75298(final float width) {
            return this;
        }
    }
}
