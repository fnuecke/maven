/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.api.API;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.Map;

public final class ModCreativeTabs {
    public static final DeferredRegister<class_1761> TABS = DeferredRegister.create(API.MOD_ID, class_7924.field_44688);

    public static final RegistrySupplier<class_1761> COMMON = TABS.register("common", () ->
        CreativeTabRegistry.create(builder -> {
            builder.method_47320(() -> new class_1799(Items.CONTROLLER.get()));
            builder.method_47321(class_2561.method_43471("itemGroup.tis3d.common"));
            builder.method_47317((parameters, output) -> {
                class_7923.field_41178.method_29722().stream()
                    .filter(entry -> entry.getKey().method_29177().method_12836().equals(API.MOD_ID))
                    .map(Map.Entry::getValue)
                    .forEach(item -> output.method_45420(new class_1799(item)));
            });
        }));

    public static void initialize() {
        TABS.register();
    }
}
