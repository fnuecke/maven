/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api;

import li.cil.manual.api.render.FontRenderer;
import net.minecraft.class_1761;
import java.util.function.Supplier;

/**
 * Glue / actual references for the TIS-3D API.
 */
public final class API {
    /**
     * The ID of the mod, i.e. the internal string it is identified by.
     */
    public static final String MOD_ID = "tis3d";

    // --------------------------------------------------------------------- //

    // Set in TIS-3D constructor, prefer using static entry point classes instead where possible.
    public static Supplier<class_1761> itemGroup;
    public static li.cil.tis3d.api.detail.InfraredAPI infraredAPI;

    public static FontRenderer normalFontRenderer;
    public static FontRenderer smallFontRenderer;

    private API() {
    }
}
