/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.entity;

import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import net.minecraft.class_11954;
import javax.annotation.Nullable;

public final class ControllerRenderState extends class_11954 {
    @Nullable
    public ControllerBlockEntity.ControllerState controllerState;
    public boolean isObserverLookingAt;
    public double distanceToCameraSq;
}
