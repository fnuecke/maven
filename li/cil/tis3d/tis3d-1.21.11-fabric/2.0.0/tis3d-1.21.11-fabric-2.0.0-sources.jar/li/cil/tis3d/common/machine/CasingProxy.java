/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.machine;

import io.netty.buffer.ByteBuf;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Pipe;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.Module;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import javax.annotation.Nullable;

public interface CasingProxy extends Casing {
    Casing getCasing();

    @Override
    default class_1937 getCasingLevel() {
        return getCasing().getCasingLevel();
    }

    @Override
    default class_2338 getPosition() {
        return getCasing().getPosition();
    }

    @Override
    default class_2470 getRotation() {
        return getCasing().getRotation();
    }

    @Override
    default void setChanged() {
        getCasing().setChanged();
    }

    @Override
    default boolean isEnabled() {
        return getCasing().isEnabled();
    }

    @Override
    default boolean isLocked() {
        return getCasing().isLocked();
    }

    @Override
    @Nullable
    default Module getModule(final Face face) {
        return getCasing().getModule(face);
    }

    @Override
    default Pipe getReceivingPipe(final Face face, final Port port) {
        return getCasing().getReceivingPipe(face, port);
    }

    @Override
    default Pipe getSendingPipe(final Face face, final Port port) {
        return getCasing().getSendingPipe(face, port);
    }

    @Override
    default void sendData(final Face face, final class_2487 data, final byte type) {
        getCasing().sendData(face, data, type);
    }

    @Override
    default void sendData(final Face face, final class_2487 data) {
        getCasing().sendData(face, data);
    }

    @Override
    default void sendData(final Face face, final ByteBuf data, final byte type) {
        getCasing().sendData(face, data, type);
    }

    @Override
    default void sendData(final Face face, final ByteBuf data) {
        getCasing().sendData(face, data);
    }
}
