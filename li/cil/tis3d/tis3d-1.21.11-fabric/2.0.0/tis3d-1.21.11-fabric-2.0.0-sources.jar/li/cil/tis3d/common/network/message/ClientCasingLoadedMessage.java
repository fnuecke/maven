/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.common.network.Network;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3222;
import net.minecraft.class_9129;

public final class ClientCasingLoadedMessage extends AbstractMessageWithPosition {
    public ClientCasingLoadedMessage(final Casing casing) {
        super(casing.getPosition());
    }

    public ClientCasingLoadedMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(NetworkManager.PacketContext context) {
        final var level = getServerLevel(context);
        if (level != null && context.getPlayer() instanceof class_3222 player) {
            withBlockEntity(level, CasingBlockEntity.class, casing -> {
                final var listTag = new class_2499();
                for (var face : Face.VALUES) {
                    final var module = casing.getModule(face);
                    final var moduleTag = new class_2487();
                    if (module != null) {
                        module.save(moduleTag);
                    }
                    listTag.add(moduleTag);
                }
                Network.sendToPlayer(player, new ServerCasingInitializeMessage(casing, listTag));
            });
        }
    }
}
