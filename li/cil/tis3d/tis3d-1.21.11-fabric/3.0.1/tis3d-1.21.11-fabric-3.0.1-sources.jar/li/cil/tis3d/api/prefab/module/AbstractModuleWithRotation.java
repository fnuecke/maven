/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.prefab.module;

import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.traits.ModuleWithRotation;
import li.cil.tis3d.api.util.TransformUtil;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import org.joml.Quaternionf;

/**
 * This is a utility implementation of a rotatable module.
 * <p>
 * Rotatable modules can face one of four directions, the default being
 * {@link Port#UP}. Most modules will either not need
 * this at all, or only use this when installed in the top or bottom faces
 * of casings. In some cases you may also merely want to use this for
 * graphical purposes (e.g. the built-in redstone and stack modules do
 * this).
 */
public abstract class AbstractModuleWithRotation extends AbstractModule implements ModuleWithRotation {
    // --------------------------------------------------------------------- //
    // Persisted data

    private Port facing = Port.UP;

    // --------------------------------------------------------------------- //
    // Computed data

    // NBT tag names.
    private static final String FACING_TAG = "facing";

    // --------------------------------------------------------------------- //

    protected AbstractModuleWithRotation(final Casing casing, final Face face) {
        super(casing, face);
    }

    // --------------------------------------------------------------------- //
    // Rendering utility

    /**
     * Apply the module's rotation to the OpenGL state.
     *
     * @param matrixStack the current matrix stack.
     */
    protected void rotateForRendering(final class_4587 matrixStack) {
        final int rotation = Port.ROTATION[getWorldFacing().ordinal()];
        matrixStack.method_46416(0.5f, 0.5f, 0);
        matrixStack.method_22907(new Quaternionf().fromAxisAngleDeg(0, 0, 1, 90 * rotation * getWorldSide().method_10164()));
        matrixStack.method_46416(-0.5f, -0.5f, 0);
    }

    // --------------------------------------------------------------------- //
    // General utility

    @Override
    protected class_243 hitToUV(final class_243 hitPos) {
        return TransformUtil.hitToUV(getWorldSide(), getWorldFacing(), hitPos);
    }

    protected final Port getWorldFacing() {
        return getCasing().toWorld(getFace(), getFacing());
    }

    // --------------------------------------------------------------------- //
    // Module

    @Override
    public void load(final class_11368 input) {
        super.load(input);

        facing = Port.VALUES[Math.max(0, input.method_71421(FACING_TAG, (byte) 0)) % Port.VALUES.length];
    }

    @Override
    public void save(final class_11372 output) {
        super.save(output);

        output.method_71462(FACING_TAG, (byte) facing.ordinal());
    }

    // --------------------------------------------------------------------- //
    // Rotatable

    @Override
    public Port getFacing() {
        return facing;
    }

    @Override
    public void setFacing(final Port facing) {
        this.facing = facing;
    }
}
