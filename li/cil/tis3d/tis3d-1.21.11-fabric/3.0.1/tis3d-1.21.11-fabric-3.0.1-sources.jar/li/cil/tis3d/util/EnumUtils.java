/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import net.minecraft.class_11368;
import net.minecraft.class_11372;

/**
 * Utility methods for enum serialization by ordinal.
 */
public final class EnumUtils {
    public static <T extends Enum<T>> T load(final Class<T> clazz, final String tagName, final class_11368 input) {
        return clazz.getEnumConstants()[input.method_71421(tagName, (byte) 0)];
    }

    public static <T extends Enum<T>> void save(final Enum<T> value, final String tagName, final class_11372 output) {
        output.method_71462(tagName, (byte) value.ordinal());
    }

    // --------------------------------------------------------------------- //

    private EnumUtils() {
    }
}
