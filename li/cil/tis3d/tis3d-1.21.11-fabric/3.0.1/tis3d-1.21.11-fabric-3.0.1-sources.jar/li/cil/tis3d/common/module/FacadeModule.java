/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.module;

import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.module.traits.ModuleWithBakedModel;
import li.cil.tis3d.api.module.traits.ModuleWithBlockChangeListener;
import li.cil.tis3d.api.prefab.module.AbstractModule;
import li.cil.tis3d.client.ClientHooks;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.util.BlockStateUtils;
import li.cil.tis3d.util.NBTUtils;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_8942;
import javax.annotation.Nullable;
import java.util.OptionalInt;

public final class FacadeModule extends AbstractModule implements ModuleWithBlockChangeListener, ModuleWithBakedModel {
    // --------------------------------------------------------------------- //
    // Persisted data

    private class_2680 facadeState;

    // --------------------------------------------------------------------- //
    // Computed data

    // Error message when trying to configure with an incompatible block.
    public static final class_2561 MESSAGE_FACADE_INVALID_TARGET = class_2561.method_43471("tis3d.facade.invalid_target");

    // Data packet types.
    private static final byte DATA_TYPE_FULL = 0;

    // NBT tag names.
    private static final String TAG_STATE = "state";

    // --------------------------------------------------------------------- //

    public FacadeModule(final Casing casing, final Face face) {
        super(casing, face);
    }

    // --------------------------------------------------------------------- //
    // Module

    @Override
    public boolean use(final class_1657 player, final class_1268 hand, final class_243 hit) {
        if (getCasing().isLocked()) {
            return false;
        }

        final class_2680 state = BlockStateUtils.getBlockStateFromItemStack(player.method_5998(hand));
        if (state == null) {
            return false;
        }

        if (!trySetFacadeState(state)) {
            if (!getCasing().getCasingLevel().method_8608()) {
                player.method_7353(MESSAGE_FACADE_INVALID_TARGET, true);
            }

            // No return false here to avoid popping out module due to invalid block.
        }

        return true;
    }

    @Override
    public void onData(final class_2487 data) {
        NBTUtils.loadFromTag(class_8942.class_8943.field_60349, getCasing().getCasingLevel().method_30349(), data, this::load);

        // Force re-render to make change of facade configuration visible.
        if (getCasing() instanceof final CasingBlockEntity casing) {
            casing.invalidateModel();
        }
    }

    @Override
    public void load(final class_11368 input) {
        super.load(input);

        facadeState = input.method_71426(TAG_STATE, class_2680.field_24734).orElse(null);
        if (facadeState == class_2246.field_10124.method_9564()) {
            facadeState = null;
        }
    }

    @Override
    public void save(final class_11372 output) {
        super.save(output);

        output.method_71477(TAG_STATE, class_2680.field_24734, facadeState);
    }

    // --------------------------------------------------------------------- //
    // BlockChangeAware

    @Override
    public void onNeighborBlockChange(final class_2338 neighborPos, final boolean isModuleNeighbor) {
        if (!isModuleNeighbor) {
            return;
        }

        if (getCasing().isLocked()) {
            return;
        }

        trySetFacadeState(getCasing().getCasingLevel().method_8320(neighborPos));
    }

    // --------------------------------------------------------------------- //
    // CasingFaceQuadOverride

    @Override
    public boolean hasModel() {
        return facadeState != null;
    }

    @Override
    public OptionalInt getTintColor(@Nullable final class_1920 level, @Nullable final class_2338 pos, final int tintIndex) {
        return OptionalInt.of(ClientHooks.getBlockTintColor(facadeState, level, pos, tintIndex));
    }

    // --------------------------------------------------------------------- //

    private boolean trySetFacadeState(final class_2680 state) {
        if (state.method_26217() != class_2464.field_11458 ||
            !state.method_26216() ||
            state.method_26204() instanceof class_2343) {
            return false;
        }

        if (!getCasing().getCasingLevel().method_8608()) {
            facadeState = state;
            sendState();
            getCasing().setChanged();
        }

        return true;
    }

    private void sendState() {
        final class_2487 tag = NBTUtils.saveToTag(class_8942.class_8943.field_60349, getCasing().getCasingLevel().method_30349(), this::save);
        getCasing().sendData(getFace(), tag, DATA_TYPE_FULL);
    }
}
