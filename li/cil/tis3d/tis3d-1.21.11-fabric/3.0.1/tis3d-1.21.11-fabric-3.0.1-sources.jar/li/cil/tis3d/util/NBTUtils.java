/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import li.cil.tis3d.api.API;
import net.minecraft.class_11352;
import net.minecraft.class_11362;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.minecraft.class_8942;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public final class NBTUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(API.MOD_ID);

    // --------------------------------------------------------------------- //

    public static class_2487 saveToTag(final class_8942.class_11336 path, final class_7225.class_7874 registries, final Consumer<class_11372> saver) {
        try (class_8942.class_11340 reporter = new class_8942.class_11340(path, LOGGER)) {
            final class_11362 output = class_11362.method_71459(reporter, registries);
            saver.accept(output);
            return output.method_71475();
        }
    }

    public static void loadFromTag(final class_8942.class_11336 path, final class_7225.class_7874 registries, final class_2487 tag, final Consumer<class_11368> loader) {
        try (class_8942.class_11340 reporter = new class_8942.class_11340(path, LOGGER)) {
            loader.accept(class_11352.method_71417(reporter, registries, tag));
        }
    }

    // --------------------------------------------------------------------- //

    private NBTUtils() {
    }
}
