/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.provider;

import com.google.common.base.Suppliers;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.Registrar;
import dev.architectury.registry.registries.RegistrarManager;
import li.cil.tis3d.api.API;
import li.cil.tis3d.api.serial.SerialInterfaceProvider;
import li.cil.tis3d.common.provider.serial.SerialInterfaceProviderFurnace;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import java.util.Optional;
import java.util.function.Supplier;

public final class SerialInterfaceProviders {
    private static final DeferredRegister<SerialInterfaceProvider> MODULE_PROVIDERS = RegistryUtils.get(SerialInterfaceProvider.REGISTRY);

    // --------------------------------------------------------------------- //

    public static final Supplier<Registrar<SerialInterfaceProvider>> REGISTRAR = Suppliers.memoize(() -> RegistrarManager.get(API.MOD_ID).get(SerialInterfaceProvider.REGISTRY));

    // --------------------------------------------------------------------- //

    public static void initialize() {
        RegistryUtils.builder(SerialInterfaceProvider.REGISTRY).build();

        MODULE_PROVIDERS.register("furnace", SerialInterfaceProviderFurnace::new);

        MODULE_PROVIDERS.register();
    }

    public static Optional<SerialInterfaceProvider> getProviderFor(final class_1937 level, final class_2338 position, final class_2350 side) {
        for (final SerialInterfaceProvider provider : REGISTRAR.get()) {
            if (provider.matches(level, position, side)) {
                return Optional.of(provider);
            }
        }
        return Optional.empty();
    }
}
