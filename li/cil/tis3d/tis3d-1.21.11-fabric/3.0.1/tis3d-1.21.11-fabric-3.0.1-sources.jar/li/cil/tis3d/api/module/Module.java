/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.module;

import io.netty.buffer.ByteBuf;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.util.RenderContext;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2487;

/**
 * A module that can be installed in a TIS-3D {@link Casing}.
 * <p>
 * Instantiated by {@link ModuleProvider}s for {@link class_1799}s inserted into {@link Casing}.
 */
public interface Module {
    /**
     * The {@link Casing} the {@link Module} is installed in.
     *
     * @return the casing the module is installed in.
     */
    Casing getCasing();

    /**
     * The {@link Face} the {@link Module} is installed on in its {@link Casing}.
     * <p>
     * This is in the casing's local space. Use {@link Casing#toWorld(Face)}
     * for anything that touches the world.
     *
     * @return the face the module is installed on.
     */
    Face getFace();

    // --------------------------------------------------------------------- //

    /**
     * Advance the state of the module.
     * <p>
     * This is called by the controller of the system the module is part of
     * each tick the system is running.
     */
    void step();

    /**
     * Called when the module is being installed into a {@link Casing}.
     * <p>
     * This is mainly for convenience and having things in one place, you could
     * just as well restore state in your {@link ModuleProvider}'s
     * {@link ModuleProvider#createModule(class_1799, Casing, Face)} method.
     * <p>
     * This is called before the first {@link #onEnabled()}, and also <em>before
     * it is actually set in the containing {@link Casing}</em>. Particularly
     * this means {@link Casing#getModule(Face)} for the module's {@link Face}
     * will still return {@code null} in this callback.
     * <p>
     * Note that this is only called on the server.
     *
     * @param stack the item stack the module was created from.
     */
    void onInstalled(final class_1799 stack);

    /**
     * Called after the module was uninstalled from a {@link Casing}.
     * <p>
     * This allows storing any data that should be persisted onto the module's
     * item representation. For most modules this will not apply, since they
     * are generally stateless / reset state when the computer shuts down.
     * <p>
     * This is called after the last {@link #onDisabled()} and is equivalent
     * to a <tt>dispose</tt> method (i.e. the module will not be used again
     * after this).
     * <p>
     * Note that this is only called on the server.
     *
     * @param stack the stack representing the module.
     */
    void onUninstalled(final class_1799 stack);

    /**
     * Called when the multi-block of casings the module is installed in is
     * enabled, or when the module was installed into an enabled casing.
     * <p>
     * Note that this is only called on the server.
     */
    void onEnabled();

    /**
     * Called when the multi-block of casings the module is installed in is
     * disabled, or when the module was removed from an enabled casing.
     * <p>
     * Modules should use this to reset their state, so that cycling power of
     * a controller resets the whole multi-block system.
     * <p>
     * Note that this is only called on the server.
     */
    void onDisabled();

    /**
     * Called when the {@link Casing} housing the module is being disposed,
     * e.g. due to a chunk being unloaded.
     * <p>
     * This is intended for freeing up resources (e.g. allocated texture or
     * audio memory). Unlike {@link #onDisabled()} this is only called once
     * on a module, at the very end of its life. Avoid level interaction in
     * this callback to avoid loading the chunk again.
     * <p>
     * This is called on the server <em>and</em> the client.
     */
    void onDisposed();

    /**
     * Called from a pipe this module is writing to when the data is being read.
     * <p>
     * The key difference to {@link #onWriteComplete(Port)} is that this is called
     * directly during the read operation, so this may be called before or after
     * the module's {@link #step()} for the current cycle. As such, no operations
     * which might influence number of required cycles for the current transfer
     * operation should be performed in this method. It may be used to cancel
     * other write operations to write a value only once, for example, or to update
     * some other internal state before a read operation completes (used by the
     * stack module for example, to ensure the correct value is being popped).
     *
     * @param port the port on which the write operation will be completed.
     */
    void onBeforeWriteComplete(final Port port);

    /**
     * Called from a pipe this module is writing to when the data was read.
     * <p>
     * This allows completing the operation in the same tick in which the
     * read operation was completed. This is particularly useful when writing
     * to multiple ports at a time but the written value may only be read once;
     * in this case the remaining writes can be canceled in this callback.
     *
     * @param port the port on which the write operation was completed.
     */
    void onWriteComplete(final Port port);

    /**
     * Called when a player right-clicks the module while installed in a casing.
     * <p>
     * The face is implicitly given by the face the module is installed in,
     * as is the level via the casing's level.
     * <p>
     * Note that there should be some way in which a click can be ignored, e.g.
     * by a player sneaking, otherwise the module cannot be removed from the
     * casing by hand.
     *
     * @param player the player that clicked the module.
     * @param hand   the hand the player used to activate the module.
     * @param hit    the relative position that was clicked.
     * @return <tt>true</tt> if the click was handled, <tt>false</tt> otherwise.
     */
    boolean use(final class_1657 player, final class_1268 hand, final class_243 hit);

    /**
     * Called with data sent from the remote instance of the module.
     * <p>
     * This can be called on both the server and the client, depending on which
     * side sent the message (i.e. the client can send messages to the server
     * this way and vice versa).
     *
     * @param data the received data.
     * @see Casing#sendData(Face, class_2487, byte)
     * @see Casing#sendData(Face, class_2487)
     */
    void onData(final class_2487 data);

    /**
     * Called with data sent from the remote instance of the module.
     * <p>
     * This can be called on both the server and the client, depending on which
     * side sent the message (i.e. the client can send messages to the server
     * this way and vice versa).
     *
     * @param data the received data.
     * @see Casing#sendData(Face, ByteBuf, byte)
     * @see Casing#sendData(Face, ByteBuf)
     */
    void onData(final ByteBuf data);

    // --------------------------------------------------------------------- //

    /**
     * Called to allow the module to render dynamic content on the casing it
     * is installed in.
     * <p>
     * The render state will be adjusted to take into account the face the
     * module is installed in, i.e. rendering from (0, 0, 0) to (1, 1, 0) will
     * render the full quad of face of the casing the module is installed in.
     *
     * @param context the current render context.
     */
    void render(final RenderContext context);

    // --------------------------------------------------------------------- //

    /**
     * Restore the state of the module from the specified input.
     *
     * @param input the input to load the state from.
     */
    void load(final class_11368 input);

    /**
     * Save the state of the module to the specified output.
     *
     * @param output the output to save the state to.
     */
    void save(final class_11372 output);
}
