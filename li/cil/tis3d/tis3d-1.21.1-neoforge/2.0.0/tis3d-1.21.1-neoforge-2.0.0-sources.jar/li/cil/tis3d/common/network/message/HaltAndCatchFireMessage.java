/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.level.Level;

public final class HaltAndCatchFireMessage extends AbstractMessageWithPosition {
    public HaltAndCatchFireMessage(final BlockPos position) {
        super(position);
    }

    public HaltAndCatchFireMessage(final RegistryFriendlyByteBuf buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final Level level = getClientLevel();
        if (level != null) {
            withBlockEntity(level, ControllerBlockEntity.class, ControllerBlockEntity::haltAndCatchFire);
        }
    }
}
