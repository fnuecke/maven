/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrarBuilder;
import dev.architectury.registry.registries.RegistrarManager;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;

public abstract class RegistryUtils {
    private static String modId;

    @SafeVarargs
    @SuppressWarnings("varargs")
    public static <T> RegistrarBuilder<T> builder(ResourceKey<Registry<T>> registryKey, T... typeGetter) {
        if (modId == null) throw new IllegalStateException();
        return RegistrarManager.get(modId).builder(registryKey.location(), typeGetter);
    }

    public static <T> DeferredRegister<T> get(ResourceKey<Registry<T>> registryKey) {
        if (modId == null) throw new IllegalStateException();
        return DeferredRegister.create(modId, registryKey);
    }

    public static void initialize(final String modId) {
        if (modId.equals(RegistryUtils.modId)) return;
        RegistryUtils.modId = modId;
    }

    // --------------------------------------------------------------------- //

    private RegistryUtils() {
    }
}
