/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@NullMarked
package li.cil.tis3d.client.manual.provider;

import org.jspecify.annotations.NullMarked;

import javax.annotation.ParametersAreNonnullByDefault;
