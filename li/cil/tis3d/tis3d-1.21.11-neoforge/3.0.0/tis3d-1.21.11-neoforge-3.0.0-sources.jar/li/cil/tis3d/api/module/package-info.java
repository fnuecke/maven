/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@NullMarked
package li.cil.tis3d.api.module;

import org.jspecify.annotations.NullMarked;

import javax.annotation.ParametersAreNonnullByDefault;
