/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@NullMarked
package li.cil.tis3d.api.prefab.module;

import org.jspecify.annotations.NullMarked;

import javax.annotation.ParametersAreNonnullByDefault;
