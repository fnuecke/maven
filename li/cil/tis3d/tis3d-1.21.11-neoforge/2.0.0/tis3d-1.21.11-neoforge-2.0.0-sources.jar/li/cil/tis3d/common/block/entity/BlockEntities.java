/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.block.entity;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.common.block.Blocks;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

import java.util.Set;

public final class BlockEntities {
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES = RegistryUtils.get(Registries.BLOCK_ENTITY_TYPE);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<BlockEntityType<CasingBlockEntity>> CASING = register(Blocks.CASING, CasingBlockEntity::new);
    public static final RegistrySupplier<BlockEntityType<ControllerBlockEntity>> CONTROLLER = register(Blocks.CONTROLLER, ControllerBlockEntity::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        BLOCK_ENTITY_TYPES.register();
    }

    // --------------------------------------------------------------------- //

    private static <B extends Block, T extends BlockEntity> RegistrySupplier<BlockEntityType<T>> register(final RegistrySupplier<B> block, final BlockEntityType.BlockEntitySupplier<T> factory) {
        return BLOCK_ENTITY_TYPES.register(block.getId().getPath(), () -> new BlockEntityType<>(factory, Set.of(block.get())));
    }
}
