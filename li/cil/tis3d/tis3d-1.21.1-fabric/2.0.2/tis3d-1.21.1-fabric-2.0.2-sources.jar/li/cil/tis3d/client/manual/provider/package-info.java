/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.client.manual.provider;

import javax.annotation.ParametersAreNonnullByDefault;
