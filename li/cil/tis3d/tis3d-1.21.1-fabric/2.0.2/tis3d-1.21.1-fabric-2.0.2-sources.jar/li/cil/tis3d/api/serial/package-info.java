/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.api.serial;

import javax.annotation.ParametersAreNonnullByDefault;
