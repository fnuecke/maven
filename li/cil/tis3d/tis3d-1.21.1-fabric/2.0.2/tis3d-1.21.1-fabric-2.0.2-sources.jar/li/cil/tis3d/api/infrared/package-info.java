/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.api.infrared;

import javax.annotation.ParametersAreNonnullByDefault;
