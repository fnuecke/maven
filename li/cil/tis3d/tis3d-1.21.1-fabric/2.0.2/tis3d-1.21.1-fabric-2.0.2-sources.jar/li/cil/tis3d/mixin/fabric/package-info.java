/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.mixin.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
