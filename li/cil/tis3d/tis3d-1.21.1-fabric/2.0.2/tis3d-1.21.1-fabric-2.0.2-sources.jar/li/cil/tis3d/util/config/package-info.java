/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.util.config;

import javax.annotation.ParametersAreNonnullByDefault;
