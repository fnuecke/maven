/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.client.renderer.entity;

import javax.annotation.ParametersAreNonnullByDefault;
