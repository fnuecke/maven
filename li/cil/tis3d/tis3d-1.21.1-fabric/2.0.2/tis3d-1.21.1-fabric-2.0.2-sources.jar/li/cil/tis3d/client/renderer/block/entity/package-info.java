/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.client.renderer.block.entity;

import javax.annotation.ParametersAreNonnullByDefault;
