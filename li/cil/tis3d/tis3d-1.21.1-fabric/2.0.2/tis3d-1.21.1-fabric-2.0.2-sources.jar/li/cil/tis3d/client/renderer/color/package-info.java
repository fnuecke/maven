/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.client.renderer.color;

import javax.annotation.ParametersAreNonnullByDefault;
