/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

/**
 * Base item for all modules.
 */
public class ModuleItem extends ModItem {
    public ModuleItem() {
    }

    public ModuleItem(final class_1793 properties) {
        super(properties);
    }
}
