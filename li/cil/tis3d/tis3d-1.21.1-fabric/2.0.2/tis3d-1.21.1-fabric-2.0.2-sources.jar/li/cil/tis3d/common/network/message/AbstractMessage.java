/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.common.network.Network;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nullable;

public abstract class AbstractMessage implements class_8710 {
    protected static final Logger LOGGER = LogManager.getLogger(AbstractMessage.class);

    protected AbstractMessage() {
    }

    protected AbstractMessage(final class_9129 buffer) {
        fromBytes(buffer);
    }

    // --------------------------------------------------------------------- //
    // CustomPacketPayload

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return Network.getMessageType(getClass());
    }

    // --------------------------------------------------------------------- //

    public abstract void handleMessage(final NetworkManager.PacketContext context);

    public abstract void fromBytes(final class_9129 buffer);

    public abstract void toBytes(final class_9129 buffer);

    @Nullable
    protected class_1937 getServerLevel(final NetworkManager.PacketContext context) {
        final var sender = context.getPlayer();
        return sender != null ? sender.method_37908() : null;
    }

    @Environment(EnvType.CLIENT)
    @Nullable
    protected class_1937 getClientLevel() {
        return class_310.method_1551().field_1687;
    }
}
