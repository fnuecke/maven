/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.common.entity;

import javax.annotation.ParametersAreNonnullByDefault;
