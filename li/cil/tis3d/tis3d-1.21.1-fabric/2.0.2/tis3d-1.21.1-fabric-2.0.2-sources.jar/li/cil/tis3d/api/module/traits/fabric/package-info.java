/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.api.module.traits.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
