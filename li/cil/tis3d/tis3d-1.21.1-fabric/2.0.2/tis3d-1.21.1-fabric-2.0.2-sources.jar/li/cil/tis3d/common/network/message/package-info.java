/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.common.network.message;

import javax.annotation.ParametersAreNonnullByDefault;
