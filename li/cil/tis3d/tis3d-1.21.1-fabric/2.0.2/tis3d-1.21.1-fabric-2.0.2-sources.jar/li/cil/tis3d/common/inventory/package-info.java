/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.common.inventory;

import javax.annotation.ParametersAreNonnullByDefault;
