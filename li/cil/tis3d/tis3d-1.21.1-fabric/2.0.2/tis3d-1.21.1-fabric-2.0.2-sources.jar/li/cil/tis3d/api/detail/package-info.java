/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.api.detail;

import javax.annotation.ParametersAreNonnullByDefault;
