/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.api.platform;

import javax.annotation.ParametersAreNonnullByDefault;
