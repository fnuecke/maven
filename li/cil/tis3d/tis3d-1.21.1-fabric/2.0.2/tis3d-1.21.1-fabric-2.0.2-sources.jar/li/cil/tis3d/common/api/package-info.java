/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.common.api;

import javax.annotation.ParametersAreNonnullByDefault;
