/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.client.gui.ReadOnlyMemoryModuleScreen;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_9129;

public final class ServerReadOnlyMemoryModuleDataMessage extends AbstractReadOnlyMemoryModuleDataMessage {
    public ServerReadOnlyMemoryModuleDataMessage(final class_1268 hand, final byte[] data) {
        super(hand, data);
    }

    public ServerReadOnlyMemoryModuleDataMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(final NetworkManager.PacketContext context) {
        final class_437 screen = class_310.method_1551().field_1755;
        if (screen instanceof final ReadOnlyMemoryModuleScreen moduleScreen) {
            moduleScreen.setData(data);
        }
    }
}
