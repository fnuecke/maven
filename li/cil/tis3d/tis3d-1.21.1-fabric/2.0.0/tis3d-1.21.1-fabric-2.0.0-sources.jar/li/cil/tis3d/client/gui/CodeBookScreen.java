/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.gui;

import li.cil.tis3d.client.ClientConfig;
import li.cil.tis3d.client.renderer.Textures;
import li.cil.tis3d.common.config.Constants;
import li.cil.tis3d.common.item.CodeBookItem;
import li.cil.tis3d.common.item.Items;
import li.cil.tis3d.common.module.execution.MachineState;
import li.cil.tis3d.common.module.execution.compiler.Compiler;
import li.cil.tis3d.common.module.execution.compiler.ParseException;
import li.cil.tis3d.common.network.Network;
import li.cil.tis3d.common.network.message.CodeBookDataMessage;
import li.cil.tis3d.util.Color;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import org.lwjgl.glfw.GLFW;

import javax.annotation.Nullable;
import java.util.*;
import java.util.stream.Collectors;

/**
 * GUI for the code book, used to write and manage ASM programs.
 */
@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
public final class CodeBookScreen extends class_437 {
    private static final class_2561 ERROR_ON_PREVIOUS_PAGE_TOOLTIP = class_2561.method_43471("tis3d.code_book.error_on_previous_page");
    private static final class_2561 ERROR_ON_NEXT_PAGE_TOOLTIP = class_2561.method_43471("tis3d.code_book.error_on_next_page");
    private static final class_2561 PREVIOUS_PAGE_TOOLTIP = class_2561.method_43471("tis3d.code_book.previous_page");
    private static final class_2561 NEXT_PAGE_TOOLTIP = class_2561.method_43471("tis3d.code_book.next_page");
    private static final class_2561 DELETE_PAGE_TOOLTIP = class_2561.method_43471("tis3d.code_book.delete_page");

    private static final int GUI_WIDTH = 218;
    private static final int GUI_HEIGHT = 230;
    private static final int BUTTON_PAGE_CHANGE_PREV_X = 8;
    private static final int BUTTON_PAGE_CHANGE_NEXT_X = 186;
    private static final int BUTTON_PAGE_CHANGE_Y = 224;
    private static final int BUTTON_PAGE_DELETE_X = 101;
    private static final int BUTTON_PAGE_DELETE_Y = 224;
    private static final int CODE_POS_X = 18;
    private static final int CODE_POS_Y = 16;
    private static final int CODE_WIDTH = 190;
    private static final int CODE_MARGIN = 10;
    private static final int PAGE_NUMBER_X = 109;
    private static final int PAGE_NUMBER_Y = 212;

    private static final int COLOR_CODE = 0xFF333333;
    private static final int COLOR_CODE_SELECTED = 0xFFEEEEEE;
    private static final int COLOR_SELECTION = 0xCC333399;

    private ButtonChangePage buttonNextPage;
    private ButtonChangePage buttonPreviousPage;
    private ButtonDeletePage buttonDeletePage;

    private final class_1657 player;
    private final class_1268 hand;
    private final CodeBookItem.Data data;
    private final List<StringBuilder> lines = new ArrayList<>();

    private int guiX;
    private int guiY;
    private int selectionStart;
    private int selectionEnd;
    private Optional<ParseException> compileError = Optional.empty();

    // --------------------------------------------------------------------- //

    public CodeBookScreen(final class_1657 player, final class_1268 hand) {
        super(class_2561.method_43470("Code Book"));
        this.player = player;
        this.hand = hand;
        this.data = CodeBookItem.Data.loadFromStack(player.method_5998(class_1268.field_5808));

        rebuildLines();
    }

    // --------------------------------------------------------------------- //
    // GuiScreen

    @Override
    public void method_25426() {
        super.method_25426();

        guiX = (field_22789 - GUI_WIDTH) / 2;
        guiY = 2;

        // Buttons for next / previous page of pages.
        buttonPreviousPage = method_37063(new ButtonChangePage(guiX + BUTTON_PAGE_CHANGE_PREV_X, guiY + BUTTON_PAGE_CHANGE_Y, PageChangeType.Previous, button -> changePage(-1)));
        buttonNextPage = method_37063(new ButtonChangePage(guiX + BUTTON_PAGE_CHANGE_NEXT_X, guiY + BUTTON_PAGE_CHANGE_Y, PageChangeType.Next, button -> changePage(1)));
        buttonDeletePage = method_37063(new ButtonDeletePage(guiX + BUTTON_PAGE_DELETE_X, guiY + BUTTON_PAGE_DELETE_Y, button -> deletePage()));
    }

    @Override
    public void method_25432() {
        super.method_25432();

        // Write changes back to our data tag.
        saveProgram();

        // Save any changes made and send them to the server.
        final class_2487 tag = new class_2487();
        data.save(tag);
        Network.sendToServer(new CodeBookDataMessage(hand, tag));
    }

    @Override
    public void method_25420(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.method_25420(graphics, mouseX, mouseY, partialTicks);

        graphics.method_25302(Textures.LOCATION_GUI_BOOK_CODE_BACKGROUND, guiX, guiY, 0, 0, GUI_WIDTH, GUI_HEIGHT);
    }

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        if (!player.method_5805() || !Items.is(player.method_5998(hand), Items.BOOK_CODE)) {
            class_310.method_1551().method_1507(null);
            return;
        }

        // Background.
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        // Check page change button availability.
        buttonPreviousPage.field_22764 = data.getSelectedPage() > 0 && data.getPageCount() > 0;
        buttonNextPage.field_22764 = (data.getSelectedPage() < data.getPageCount() - 1) ||
            (data.getSelectedPage() == data.getPageCount() - 1 && isCurrentProgramNonEmpty());
        buttonDeletePage.field_22764 = data.getPageCount() > 1 || isCurrentProgramNonEmpty();

        // Draw current program.
        drawProgram(graphics, mouseX, mouseY);

        // Draw page number.
        final String pageInfo = String.format("%d/%d", data.getSelectedPage() + 1, data.getPageCount());
        final int x = guiX + PAGE_NUMBER_X - getFontRenderer().method_1727(pageInfo) / 2;
        final int y = guiY + PAGE_NUMBER_Y;
        graphics.method_51433(getFontRenderer(), pageInfo, x, y, COLOR_CODE, false);
    }

    @Override
    public boolean method_25402(final double mouseX, final double mouseY, final int mouseButton) {
        if (super.method_25402(mouseX, mouseY, mouseButton)) {
            return true;
        }

        if (isInCodeArea(mouseX, mouseY)) {
            final int line = cursorToLine(mouseY);
            final int column = cursorToColumn(mouseX + 2, mouseY);
            selectionStart = selectionEnd = positionToIndex(line, column);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25403(final double mouseX, final double mouseY, final int button, final double dragX, final double dragY) {
        if (super.method_25403(mouseX, mouseY, button, dragX, dragY)) {
            return true;
        }

        if (isInCodeArea(mouseX, mouseY)) {
            final int line = cursorToLine(mouseY);
            final int column = cursorToColumn(mouseX + 2, mouseY);
            selectionEnd = positionToIndex(line, column);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25404(final int keyCode, final int scanCode, final int modifiers) {
        if (keyCode == class_3675.field_31958 && this.method_25422()) {
            this.method_25419();
            return true;
        }

        final int line = indexToLine(getSelectionStart());
        final int column = indexToColumn(getSelectionStart());

        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            if (column > 0 || line > 0) {
                if (method_25442()) {
                    selectionEnd = selectionEnd - 1;
                } else {
                    selectionStart = selectionEnd = selectionEnd - 1;
                }
            }

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            if (column < lines.get(line).length() || line < lines.size() - 1) {
                if (method_25442()) {
                    selectionEnd = selectionEnd + 1;
                } else {
                    selectionStart = selectionEnd = selectionEnd + 1;
                }
            }

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_UP) {
            final int currLine = indexToLine(selectionEnd);
            if (currLine > 0) {
                final int currColumn = indexToColumn(selectionEnd);
                final int x = columnToX(currLine, currColumn) + 2;
                final int prevLine = currLine - 1;
                final int prevColumn = xToColumn(x, prevLine);
                final int index = positionToIndex(prevLine, prevColumn);

                if (method_25442()) {
                    selectionEnd = index;
                } else {
                    selectionStart = selectionEnd = index;
                }
            }

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_DOWN) {
            final int currLine = indexToLine(selectionEnd);
            if (currLine < lines.size() - 1) {
                final int currColumn = indexToColumn(selectionEnd);
                final int x = columnToX(currLine, currColumn) + 2;
                final int nextLine = currLine + 1;
                final int nextColumn = xToColumn(x, nextLine);
                final int index = positionToIndex(nextLine, nextColumn);

                if (method_25442()) {
                    selectionEnd = index;
                } else {
                    selectionStart = selectionEnd = index;
                }
            }

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_HOME) {
            final int currLine = indexToLine(selectionEnd);
            if (method_25442()) {
                selectionEnd = positionToIndex(currLine, 0);
            } else {
                selectionStart = selectionEnd = positionToIndex(currLine, 0);
            }

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_END) {
            final int currLine = indexToLine(selectionEnd);
            if (method_25442()) {
                selectionEnd = positionToIndex(currLine, lines.get(currLine).length());
            } else {
                selectionStart = selectionEnd = positionToIndex(currLine, lines.get(currLine).length());
            }

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_DELETE) {
            if (!deleteSelection()) {
                if (method_25442()) {
                    if (lines.size() > 1) {
                        lines.remove(line);
                    } else {
                        lines.get(0).setLength(0);
                    }
                    selectionStart = selectionEnd = positionToIndex(Math.min(lines.size() - 1, line), 0);
                } else if (column < lines.get(line).length()) {
                    lines.get(line).deleteCharAt(column);
                } else if (line < lines.size() - 1) {
                    final StringBuilder currLine = lines.get(line);
                    final StringBuilder nextLine = lines.get(line + 1);

                    if (currLine.length() + nextLine.length() < Constants.MAX_CHARS_PER_LINE) {
                        currLine.append(nextLine);
                        lines.remove(line + 1);
                    }
                }
            }

            recompile();

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (!deleteSelection()) {
                if (column > 0) {
                    lines.get(line).deleteCharAt(column - 1);
                } else if (line > 0) {
                    final StringBuilder prevLine = lines.get(line - 1);
                    final StringBuilder currLine = lines.get(line);

                    if (prevLine.length() + currLine.length() < Constants.MAX_CHARS_PER_LINE) {
                        prevLine.append(currLine);
                        lines.remove(line);
                    }
                }

                selectionStart = selectionEnd = Math.max(0, selectionEnd - 1);
            }

            recompile();

            return true;
        } else if (keyCode == GLFW.GLFW_KEY_ENTER) {
            deleteSelection();
            if (lines.size() < Constants.MAX_LINES_PER_PAGE) {
                final StringBuilder oldLine = lines.get(line);
                final StringBuilder newLine = new StringBuilder();
                if (column < oldLine.length()) {
                    newLine.append(oldLine.substring(column));
                    oldLine.setLength(column);
                }
                lines.add(line + 1, newLine);

                selectionStart = selectionEnd = selectionEnd + 1;
            }

            recompile();

            return true;
        } else if (method_25441()) {
            if (keyCode == GLFW.GLFW_KEY_A) {
                selectionStart = 0;
                selectionEnd = positionToIndex(Integer.MAX_VALUE, Integer.MAX_VALUE);
            } else if (keyCode == GLFW.GLFW_KEY_C) {
                getMinecraft().field_1774.method_1455(selectionToString());
            } else if (keyCode == GLFW.GLFW_KEY_X) {
                getMinecraft().field_1774.method_1455(selectionToString());
                deleteSelection();

                recompile();
            } else if (keyCode == GLFW.GLFW_KEY_V) {
                deleteSelection();

                final String[] pastedLines = Constants.PATTERN_LINES.split(getMinecraft().field_1774.method_1460());
                if (!isValidPaste(pastedLines)) {
                    return true;
                }

                lines.get(line).insert(indexToColumn(column), applyCodeStyle(pastedLines[0]));
                lines.addAll(line + 1, Arrays.stream(pastedLines).
                    skip(1).
                    map(CodeBookScreen::applyCodeStyle).
                    map(StringBuilder::new).
                    toList());

                selectionStart = selectionEnd = selectionEnd + pastedLines[0].length();
                for (int i = 1; i < pastedLines.length; i++) {
                    selectionStart = selectionEnd = selectionEnd + 1 + pastedLines[i].length();
                }

                recompile();
            }

            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(final char codePoint, final int modifiers) {
        if (super.method_25400(codePoint, modifiers)) {
            return true;
        }
        if (Character.isISOControl(codePoint)) {
            return false;
        }

        deleteSelection();

        final int line = indexToLine(getSelectionStart());
        final int column = indexToColumn(getSelectionStart());

        if (lines.get(line).length() < Constants.MAX_CHARS_PER_LINE) {
            lines.get(line).insert(column, applyCodeStyle(String.valueOf(codePoint)));
            selectionStart = selectionEnd = selectionEnd + 1;
        }

        recompile();

        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Nullable
    @Override
    public class_364 method_25399() {
        // We don't want space to trigger buttons, all input is interpreted as text input in this UI.
        return null;
    }

    // --------------------------------------------------------------------- //

    private static String applyCodeStyle(final String value) {
        if (ClientConfig.autoCodeUpperCase) {
            return value.toUpperCase(Locale.US);
        } else {
            return value;
        }
    }

    private class_310 getMinecraft() {
        return Objects.requireNonNull(field_22787);
    }

    private class_327 getFontRenderer() {
        return field_22793;
    }

    private int getSelectionStart() {
        return Math.min(selectionStart, selectionEnd);
    }

    private int getSelectionEnd() {
        return Math.max(selectionStart, selectionEnd);
    }

    private boolean intersectsSelection(final int start, final int end) {
        return start < getSelectionEnd() && end > getSelectionStart();
    }

    private String selectionToString() {
        final int startLine = indexToLine(getSelectionStart());
        final int endLine = indexToLine(getSelectionEnd());
        if (selectionStart == selectionEnd) {
            return lines.get(startLine).toString();
        } else {
            final int startColumn = indexToColumn(getSelectionStart());
            final int endColumn = indexToColumn(getSelectionEnd());

            if (startLine == endLine) {
                return lines.get(startLine).substring(startColumn, endColumn);
            } else {
                final StringBuilder selection = new StringBuilder();
                selection.append(lines.get(startLine).subSequence(startColumn, lines.get(startLine).length())).append('\n');
                for (int line = startLine + 1; line < endLine; line++) {
                    selection.append(lines.get(line).toString()).append('\n');
                }
                selection.append(lines.get(endLine).subSequence(0, endColumn)).append('\n');
                return selection.toString();
            }
        }
    }

    private int cursorToLine(final double y) {
        return (int) Math.max(0, Math.min(Math.min(lines.size() - 1, Constants.MAX_LINES_PER_PAGE), (y - guiY - CODE_POS_Y) / getFontRenderer().field_2000));
    }

    private int cursorToColumn(final double x, final double y) {
        return xToColumn(x, cursorToLine(y));
    }

    private int xToColumn(final double x, final int line) {
        final int relX = (int) Math.max(0, x - guiX - CODE_POS_X);
        return getFontRenderer().method_27523(lines.get(line).toString(), relX).length();
    }

    private int columnToX(final int line, final int column) {
        return guiX + CODE_POS_X + getFontRenderer().method_1727(lines.get(line).substring(0, Math.min(column, lines.get(line).length())));
    }

    private int positionToIndex(final int line, final int column) {
        int index = 0;
        for (int l = 0; l < Math.min(line, lines.size()); l++) {
            index += lines.get(l).length() + 1;
        }
        index += Math.min(column, lines.get(Math.min(line, lines.size() - 1)).length());
        return index;
    }

    private int indexToLine(final int index) {
        int position = 0;
        for (int line = 0; line < lines.size(); line++) {
            position += lines.get(line).length() + 1;
            if (position > index) {
                return line;
            }
        }
        return lines.size() - 1; // Out of bounds, clamp.
    }

    private int indexToColumn(final int index) {
        int position = 0;
        for (final StringBuilder line : lines) {
            if (position + line.length() + 1 > index) {
                return index - position;
            }
            position += line.length() + 1;
        }
        return lines.get(lines.size() - 1).length(); // Out of bounds, clamp.
    }

    private boolean isInCodeArea(final double mouseX, final double mouseY) {
        return mouseX >= guiX + CODE_POS_X - CODE_MARGIN && mouseX <= guiX + CODE_POS_X + CODE_WIDTH + CODE_MARGIN &&
            mouseY >= guiY + CODE_POS_Y - CODE_MARGIN && mouseY <= guiY + CODE_POS_Y + getFontRenderer().field_2000 * Constants.MAX_LINES_PER_PAGE + CODE_MARGIN;
    }

    private boolean isCurrentProgramNonEmpty() {
        return lines.size() > 1 || !lines.get(0).isEmpty();
    }

    private void recompile() {
        compileError = Optional.empty();

        final List<String> program = lines.stream().map(StringBuilder::toString).collect(Collectors.toList());

        final List<String> leadingCode = new ArrayList<>();
        final List<String> trailingCode = new ArrayList<>();
        data.getExtendedProgram(data.getSelectedPage(), program, leadingCode, trailingCode);
        program.addAll(0, leadingCode);
        program.addAll(trailingCode);

        try {
            Compiler.compile(program, new MachineState());
        } catch (final ParseException e) {
            // Adjust line number for current page.
            final int lineNumber = e.getLineNumber() - leadingCode.size();
            compileError = Optional.of(new ParseException(e.getDisplayMessage(), lineNumber, e.getStart(), e.getEnd()));
        }
    }

    private boolean deleteSelection() {
        if (selectionStart != selectionEnd) {
            // Delete selection first.
            final int startLine = indexToLine(getSelectionStart());
            final int endLine = indexToLine(getSelectionEnd());

            final int startColumn = indexToColumn(getSelectionStart());
            final int endColumn = indexToColumn(getSelectionEnd());

            if (startLine == endLine) {
                lines.get(startLine).delete(startColumn, endColumn);
            } else {
                lines.get(startLine).delete(startColumn, lines.get(startLine).length());
                lines.get(endLine).delete(0, endColumn);
                lines.get(startLine).append(lines.get(endLine));
                lines.subList(startLine + 1, endLine + 1).clear();
            }

            selectionStart = selectionEnd = getSelectionStart();

            return true;
        }

        return false;
    }

    private boolean isValidPaste(final String[] pastedLines) {
        final int selectedLine = indexToLine(selectionEnd);

        if (pastedLines.length == 0) {
            return false; // Invalid paste, nothing to paste (this shouldn't even be possible).
        }
        if (pastedLines.length - 1 + lines.size() > Constants.MAX_LINES_PER_PAGE) {
            return false; // Invalid paste, too many resulting lines.
        }
        if (pastedLines[0].length() + lines.get(selectedLine).length() > Constants.MAX_CHARS_PER_LINE) {
            return false; // Invalid paste, combined first line and current line too long.
        }
        for (final String pastedLine : pastedLines) {
            if (pastedLine.length() > Constants.MAX_CHARS_PER_LINE) {
                return false; // Invalid paste, a line is too long.
            }
        }


        return true;
    }

    private void changePage(final int delta) {
        saveProgram();

        if (data.getSelectedPage() + delta == data.getPageCount()) {
            data.addPage();
        }
        data.setSelectedPage(data.getSelectedPage() + delta);
        selectionStart = selectionEnd = 0;

        rebuildLines();
    }

    private void deletePage() {
        data.removePage(data.getSelectedPage());
        rebuildLines();
    }

    private void saveProgram() {
        data.setPage(data.getSelectedPage(), lines.stream().map(StringBuilder::toString).collect(Collectors.toList()));
    }

    private void rebuildLines() {
        if (data.getPageCount() < 1) {
            data.addPage();
        }

        final List<String> program = data.getPage(data.getSelectedPage());
        lines.clear();
        program.forEach(line -> lines.add(new StringBuilder(applyCodeStyle(line))));

        recompile();
    }

    private void drawProgram(final class_332 graphics, final int mouseX, final int mouseY) {
        int position = 0;
        for (int lineNumber = 0; lineNumber < lines.size(); lineNumber++) {
            final StringBuilder line = lines.get(lineNumber);
            final int end = position + line.length();
            final int offsetY = lineNumber * getFontRenderer().field_2000;
            final int lineX = guiX + CODE_POS_X;
            final int lineY = guiY + CODE_POS_Y + offsetY;
            if (selectionStart != selectionEnd && intersectsSelection(position, end)) {
                // Line contains selection, highlight appropriately.
                int currX = lineX;
                // Number of chars before the selection in this line.
                final int prefix = Math.max(0, getSelectionStart() - position);
                // Number of chars selected in this line.
                final int selected = Math.min(line.length() - prefix, getSelectionEnd() - (position + prefix));

                final String prefixText = line.substring(0, prefix);
                graphics.method_51433(getFontRenderer(), prefixText, currX, lineY, COLOR_CODE, false);
                currX += getFontRenderer().method_1727(prefixText);

                final String selectedText = line.substring(prefix, prefix + selected);
                final int selectedWidth = getFontRenderer().method_1727(selectedText);
                graphics.method_25294(currX - 1, lineY - 1, currX + selectedWidth, lineY + getFontRenderer().field_2000 - 1, COLOR_SELECTION);
                graphics.method_51433(getFontRenderer(), selectedText, currX, lineY, COLOR_CODE_SELECTED, false);
                currX += selectedWidth;

                final String postfixString = line.substring(prefix + selected);
                graphics.method_51433(getFontRenderer(), postfixString, currX, lineY, COLOR_CODE, false);
            } else {
                // No selection here, just draw the line. Get it? "draw the line"?
                graphics.method_51433(getFontRenderer(), line.toString(), lineX, lineY, COLOR_CODE, false);
            }

            position += line.length() + 1;
        }

        // Part one of error handling, draw red underline, *behind* the blinking cursor.
        if (compileError.isPresent()) {
            final ParseException exception = compileError.get();
            final int localLineNumber, startX, rawEndX;
            final boolean isErrorOnPreviousPage = exception.getLineNumber() < 0;
            final boolean isErrorOnNextPage = exception.getLineNumber() >= lines.size();
            if (isErrorOnPreviousPage) {
                localLineNumber = 0;
                startX = columnToX(localLineNumber, 0);
                rawEndX = columnToX(localLineNumber, Constants.MAX_CHARS_PER_LINE);
            } else if (isErrorOnNextPage) {
                localLineNumber = lines.size() - 1;
                startX = columnToX(localLineNumber, 0);
                rawEndX = columnToX(localLineNumber, Constants.MAX_CHARS_PER_LINE);
            } else {
                localLineNumber = exception.getLineNumber();
                startX = columnToX(localLineNumber, exception.getStart());
                rawEndX = columnToX(localLineNumber, exception.getEnd());
            }
            final int startY = guiY + CODE_POS_Y + localLineNumber * getFontRenderer().field_2000 - 1;
            final int endX = Math.max(rawEndX, startX + getFontRenderer().method_1727(" "));

            graphics.method_25294(startX - 1, startY + getFontRenderer().field_2000 - 1, endX, startY + getFontRenderer().field_2000, Color.RED);

            // Draw selection position in text.
            drawTextCursor(graphics);

            // Part two of error handling, draw tooltip, *on top* of blinking cursor.
            if (mouseX >= startX && mouseX <= endX && mouseY >= startY && mouseY <= startY + getFontRenderer().field_2000) {
                final List<class_2561> tooltip = new ArrayList<>();
                if (isErrorOnPreviousPage) {
                    tooltip.add(ERROR_ON_PREVIOUS_PAGE_TOOLTIP);
                } else if (isErrorOnNextPage) {
                    tooltip.add(ERROR_ON_NEXT_PAGE_TOOLTIP);
                }
                tooltip.add(exception.getDisplayMessage());
                graphics.method_51434(getFontRenderer(), tooltip, mouseX, mouseY);
            }
        } else {
            // Draw selection position in text.
            drawTextCursor(graphics);
        }
    }

    private void drawTextCursor(final class_332 graphics) {
        if (System.currentTimeMillis() % 800 <= 400) {
            final int line = indexToLine(selectionEnd);
            final int column = indexToColumn(selectionEnd);
            final StringBuilder sb = lines.get(line);
            final int x = guiX + CODE_POS_X + getFontRenderer().method_1727(sb.substring(0, column)) - 1;
            final int y = guiY + CODE_POS_Y + line * getFontRenderer().field_2000 - 1;
            graphics.method_25294(x + 1, y + 1, x + 2 + 1, y + getFontRenderer().field_2000 + 1, Color.GRAY);
            graphics.method_25294(x, y, x + 2, y + getFontRenderer().field_2000, COLOR_CODE_SELECTED);
        }
    }

    // --------------------------------------------------------------------- //

    private enum PageChangeType {
        Previous,
        Next
    }

    private static final class ButtonChangePage extends class_4185 {
        private static final int TEXTURE_X = 110;
        private static final int TEXTURE_Y = 231;
        private static final int BUTTON_WIDTH = 23;
        private static final int BUTTON_HEIGHT = 12;

        private final PageChangeType type;

        ButtonChangePage(final int x, final int y, final PageChangeType type, final class_4241 action) {
            super(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, class_2561.method_43473(), action, field_40754);
            this.type = type;
            method_47400(class_7919.method_47407(type == PageChangeType.Previous
                ? PREVIOUS_PAGE_TOOLTIP
                : NEXT_PAGE_TOOLTIP));
        }

        @Override
        public void method_48579(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
            final int offsetX = isHoveredOrFocusedUsingKeyboard() ? BUTTON_WIDTH : 0;
            final int offsetY = type == PageChangeType.Previous ? BUTTON_HEIGHT : 0;
            graphics.method_25302(Textures.LOCATION_GUI_BOOK_CODE_BACKGROUND, method_46426(), method_46427(), TEXTURE_X + offsetX, TEXTURE_Y + offsetY, BUTTON_WIDTH, BUTTON_HEIGHT);
        }

        private boolean isHoveredOrFocusedUsingKeyboard() {
            return this.method_49606() || this.method_25370() && class_310.method_1551().method_48186().method_48183();
        }
    }

    private static final class ButtonDeletePage extends class_4185 {
        private static final int TEXTURE_X = 158;
        private static final int TEXTURE_Y = 231;
        private static final int BUTTON_WIDTH = 14;
        private static final int BUTTON_HEIGHT = 14;

        ButtonDeletePage(final int x, final int y, final class_4241 action) {
            super(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, class_2561.method_43473(), action, field_40754);
            method_47400(class_7919.method_47407(DELETE_PAGE_TOOLTIP));
        }

        @Override
        public void method_48579(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
            final int offsetX = isHoveredOrFocusedUsingKeyboard() ? BUTTON_WIDTH : 0;
            graphics.method_25302(Textures.LOCATION_GUI_BOOK_CODE_BACKGROUND, method_46426(), method_46427(), TEXTURE_X + offsetX, TEXTURE_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
        }

        private boolean isHoveredOrFocusedUsingKeyboard() {
            return this.method_49606() || this.method_25370() && class_310.method_1551().method_48186().method_48183();
        }
    }
}
