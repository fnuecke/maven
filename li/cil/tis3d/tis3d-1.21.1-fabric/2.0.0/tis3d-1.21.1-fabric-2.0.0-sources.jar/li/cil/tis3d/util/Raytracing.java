/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import javax.annotation.Nullable;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3532;

/**
 * Custom ray-tracing implementation for ray-block tests, to allow custom
 * filter methods for blocks to take into account.
 */
public final class Raytracing {
    @FunctionalInterface
    public interface CollisionDetector {
        @Nullable
        class_239 intersect(final class_1937 level, final class_2338 position, final class_243 start, final class_243 end);
    }

    /**
     * Checks only blocks that have a bounding box and are not see-through.
     *
     * @param level    the level to perform the intersection check in.
     * @param position the position of the block to perform the intersection check with.
     * @param start    the start of the line to intersect the block with.
     * @param end      the end of the line to intersect the block with.
     * @return hit information on the intersect, or {@code null} if there was none.
     */
    @Nullable
    public static class_239 intersectIgnoringTransparent(final class_1937 level, final class_2338 position, final class_243 start, final class_243 end) {
        final class_2680 state = level.method_8320(position);
        if (state.method_26216(level, position)) {
            final class_265 shape = state.method_26201(level, position);
            if (!shape.method_1110()) {
                return shape.method_1092(start, end, position);
            }
        }
        return null;
    }

    // --------------------------------------------------------------------- //

    /**
     * Trace along the specified line, testing for collision with blocks along the way.
     *
     * @param level    the level to shoot the ray in.
     * @param start    the start of the line to trace.
     * @param end      the end of the line to trace.
     * @param callback the method to call for each potential hit to perform collision logic.
     * @return the first detected hit, or {@code null} if there was none.
     */
    @Nullable
    public static class_239 raytrace(final class_1937 level, final class_243 start, final class_243 end, final CollisionDetector callback) {
        // Adapted from http://jsfiddle.net/wivlaro/mkaWf/6/

        final int startPosX = class_3532.method_15357(start.field_1352);
        final int startPosY = class_3532.method_15357(start.field_1351);
        final int startPosZ = class_3532.method_15357(start.field_1350);

        final int endPosX = class_3532.method_15357(end.field_1352);
        final int endPosY = class_3532.method_15357(end.field_1351);
        final int endPosZ = class_3532.method_15357(end.field_1350);

        final int stepX = Integer.compare(endPosX, startPosX);
        final int stepY = Integer.compare(endPosY, startPosY);
        final int stepZ = Integer.compare(endPosZ, startPosZ);

        // Planes for each axis that we will next cross.
        final int gxp = startPosX + (endPosX > startPosX ? 1 : 0);
        final int gyp = startPosY + (endPosY > startPosY ? 1 : 0);
        final int gzp = startPosZ + (endPosZ > startPosZ ? 1 : 0);

        // Only used for multiplying up the error margins.
        final double vx = end.field_1352 == start.field_1352 ? 1 : end.field_1352 - start.field_1352;
        final double vy = end.field_1351 == start.field_1351 ? 1 : end.field_1351 - start.field_1351;
        final double vz = end.field_1350 == start.field_1350 ? 1 : end.field_1350 - start.field_1350;

        // Error is normalized to vx * vy * vz so we only have to multiply up.
        final double vxvy = vx * vy;
        final double vxvz = vx * vz;
        final double vyvz = vy * vz;

        // Error from the next plane accumulators, scaled up by vx*vy*vz.
        final double scaledErrorX = stepX * vyvz;
        final double scaledErrorY = stepY * vxvz;
        final double scaledErrorZ = stepZ * vxvy;

        double errorX = (gxp - start.field_1352) * vyvz;
        double errorY = (gyp - start.field_1351) * vxvz;
        double errorZ = (gzp - start.field_1350) * vxvy;

        int currentPosX = startPosX;
        int currentPosY = startPosY;
        int currentPosZ = startPosZ;

        int emergencyExit = 200;
        while (--emergencyExit > 0) {
            // Check if we're colliding with the block.
            final class_2338 position = new class_2338(currentPosX, currentPosY, currentPosZ);
            final class_239 hit = callback.intersect(level, position, start, end);
            if (hit != null && hit.method_17783() != class_239.class_240.field_1333) {
                return hit;
            }

            // Have we reached the end point without hitting anything?
            if (currentPosX == endPosX && currentPosY == endPosY && currentPosZ == endPosZ) {
                return null;
            }

            // Which plane do we cross first?
            final double xr = Math.abs(errorX);
            final double yr = Math.abs(errorY);
            final double zr = Math.abs(errorZ);

            if (stepX != 0 && (stepY == 0 || xr < yr) && (stepZ == 0 || xr < zr)) {
                currentPosX += stepX;
                errorX += scaledErrorX;
            } else if (stepY != 0 && (stepZ == 0 || yr < zr)) {
                currentPosY += stepY;
                errorY += scaledErrorY;
            } else if (stepZ != 0) {
                currentPosZ += stepZ;
                errorZ += scaledErrorZ;
            }
        }

        return null;
    }

    // --------------------------------------------------------------------- //

    private Raytracing() {
    }
}
