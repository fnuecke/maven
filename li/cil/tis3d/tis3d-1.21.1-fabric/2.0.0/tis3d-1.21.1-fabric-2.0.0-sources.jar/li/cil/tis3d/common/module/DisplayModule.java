/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.module;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import li.cil.tis3d.api.API;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Pipe;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.prefab.module.AbstractModuleWithRotation;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.client.renderer.ModRenderType;
import li.cil.tis3d.util.Color;
import li.cil.tis3d.util.EnumUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_1921;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5253.class_5254;
import net.minecraft.class_5253.class_8045;
import java.util.Arrays;

public final class DisplayModule extends AbstractModuleWithRotation {
    // --------------------------------------------------------------------- //
    // Persisted data

    /**
     * The uncompressed image as RGBA, for faster application of draw calls
     * and uploading to the GPU. Also kept on the server to allow sending
     * current state to newly connected/coming closer clients.
     */
    private final int[] image = new int[RESOLUTION * RESOLUTION];

    /**
     * Whether the image data changed and needs to be re-uploaded to the GPU.
     */
    private boolean imageDirty;

    /**
     * The current input state, i.e. what value we're currently reading.
     */
    private State state = State.COLOR;

    /**
     * The currently being-built draw call. Stored as byte-array for more
     * convenient saving and loading (and sending to clients).
     */
    private final byte[] drawCall = new byte[State.values().length];

    // --------------------------------------------------------------------- //
    // Computed data

    /**
     * Current state of the display module, decides what happens with the next
     * value read on any of the ports.
     */
    private enum State {
        COLOR, X, Y, W, H;

        public static final State[] VALUES = State.values();

        public State getNext() {
            return VALUES[(ordinal() + 1) % VALUES.length];
        }
    }

    // Resolution of the screen in pixels, width = height.
    private static final int RESOLUTION = 24;

    // Don't allow displaying stuff on the edge of the casing. I mean we could,
    // technically, but that'd usually look pretty weird. Also it's more
    // intuitive that the usable area start in the inner, black part.
    private static final int MARGIN = 4;

    // NBT tag names.
    private static final String TAG_IMAGE = "image";
    private static final String TAG_STATE = "state";
    private static final String TAG_DRAW_CALL = "drawCall";

    // Data packet types.
    private static final byte DATA_TYPE_CLEAR = 0;

    // Running counter for unique dynamic texture ids.
    @Environment(EnvType.CLIENT)
    private static int nextTextureId;

    // Backing texture used to render the module data.
    @Environment(EnvType.CLIENT)
    private class_1043 texture;

    // Id of the backing texture, required by MC dynamic texture system.
    @Environment(EnvType.CLIENT)
    private class_2960 textureId;

    // Render layer we render our texture in.
    @Environment(EnvType.CLIENT)
    private class_1921 renderLayer;

    // --------------------------------------------------------------------- //

    public DisplayModule(final Casing casing, final Face face) {
        super(casing, face);
    }

    // --------------------------------------------------------------------- //
    // Module

    @Override
    public void step() {
        for (final Port port : Port.VALUES) {
            stepInput(port);
        }
    }

    @Override
    public void onDisabled() {
        Arrays.fill(image, 0);
        state = State.COLOR;
        imageDirty = true;

        sendClear();
    }

    @Override
    public void onDisposed() {
        super.onDisposed();
        if (getCasing().getCasingLevel().method_8608()) {
            deleteTexture();
        }
    }

    @Override
    public void onData(final ByteBuf data) {
        if (data.readBoolean()) {
            Arrays.fill(image, 0);
        } else {
            data.readBytes(drawCall);
            applyDrawCall(drawCall);
        }

        imageDirty = true;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void render(final RenderContext context) {
        if (!getCasing().isEnabled()) {
            return;
        }

        final class_4587 matrixStack = context.getMatrixStack();
        matrixStack.method_22903();
        rotateForRendering(matrixStack);

        validateTexture();

        final class_4588 builder = context.getBuffer().getBuffer(getOrCreateRenderLayer());
        context.drawQuad(builder, MARGIN / 32f, MARGIN / 32f, RESOLUTION / 32f, RESOLUTION / 32f);

        matrixStack.method_22909();
    }

    @Override
    public void load(final class_2487 tag) {
        super.load(tag);

        final int[] imageTag = tag.method_10561(TAG_IMAGE);
        System.arraycopy(imageTag, 0, image, 0, Math.min(imageTag.length, image.length));
        imageDirty = true;

        state = EnumUtils.load(State.class, TAG_STATE, tag);

        final byte[] drawCallTag = tag.method_10547(TAG_DRAW_CALL);
        System.arraycopy(drawCallTag, 0, drawCall, 0, Math.min(drawCallTag.length, drawCall.length));
    }

    @Override
    public void save(final class_2487 tag) {
        super.save(tag);

        tag.method_10539(TAG_IMAGE, image.clone());
        EnumUtils.save(state, TAG_STATE, tag);
        tag.method_10570(TAG_DRAW_CALL, drawCall.clone());
    }

    // --------------------------------------------------------------------- //

    /**
     * Update the input of the module, adding any read value to our draw call.
     */
    private void stepInput(final Port port) {
        // Continuously read from all ports, set output to last received value.
        final Pipe receivingPipe = getCasing().getReceivingPipe(getFace(), port);
        if (!receivingPipe.isReading()) {
            receivingPipe.beginRead();
        }
        if (receivingPipe.canTransfer()) {
            process(receivingPipe.read());
        }
    }

    /**
     * Process a value read from any port.
     *
     * @param value the value that was read.
     */
    private void process(final short value) {
        drawCall[state.ordinal()] = (byte) value;
        state = state.getNext();
        if (state == State.COLOR) {
            // Draw call completed, apply and send to client.
            applyDrawCall(drawCall);
            sendDrawCall();
        }
        getCasing().setChanged();
    }

    /**
     * Apply a draw call encoded in the specified byte array to our data array.
     *
     * @param drawCall the draw call to apply.
     */
    private void applyDrawCall(final byte[] drawCall) {
        final byte color = drawCall[State.COLOR.ordinal()];
        final byte xin = drawCall[State.X.ordinal()];
        final byte yin = drawCall[State.Y.ordinal()];
        final byte w = drawCall[State.W.ordinal()];
        final byte h = drawCall[State.H.ordinal()];

        final int argb = Color.getColorByIndex(color & 0xFF);
        final int x0 = Math.max(0, xin);
        final int x1 = Math.min(RESOLUTION, xin + w);
        final int y0 = Math.max(0, yin);
        final int y1 = Math.min(RESOLUTION, yin + h);

        for (int y = y0; y < y1; y++) {
            final int offset = y * RESOLUTION;
            for (int x = x0; x < x1; x++) {
                final int index = offset + x;
                image[index] = argb;
            }
        }
    }

    /**
     * Gets the texture used for uploading module data to the GPU, creates one if necessary.
     *
     * @return the texture used to upload data to the GPU.
     */
    @Environment(EnvType.CLIENT)
    private class_1043 getOrCreateTexture() {
        if (texture == null) {
            texture = new class_1043(RESOLUTION, RESOLUTION, false);
        }

        return texture;
    }

    @Environment(EnvType.CLIENT)
    private class_1921 getOrCreateRenderLayer() {
        if (renderLayer == null) {
            final class_1060 textureManager = class_310.method_1551().method_1531();
            final class_1043 texture = getOrCreateTexture();
            textureId = class_2960.method_60655(API.MOD_ID, "dynamic/display_module_" + (++nextTextureId));
            textureManager.method_4616(textureId, texture);
            renderLayer = ModRenderType.unlitTexture(textureId);
        }

        return renderLayer;
    }

    /**
     * Deletes our texture from the GPU, if we have one.
     */
    @Environment(EnvType.CLIENT)
    private void deleteTexture() {
        if (textureId != null) {
            class_310.method_1551().method_18859(() -> {
                class_310.method_1551().method_1531().method_4615(textureId);
            });
        }

        if (texture != null) {
            class_310.method_1551().method_18859(() -> {
                texture.close();
                texture = null;
            });
        }
    }

    /**
     * Uploads new image data if it changed, creates texture if necessary.
     */
    @Environment(EnvType.CLIENT)
    private void validateTexture() {
        if (!imageDirty) {
            return;
        }

        imageDirty = false;

        final class_1043 texture = getOrCreateTexture();
        final class_1011 nativeImage = texture.method_4525();
        if (nativeImage == null) {
            return;
        }

        int ip = 0;
        for (int iy = 0; iy < RESOLUTION; iy++) {
            for (int ix = 0; ix < RESOLUTION; ix++, ip++) {
                final int argb = image[ip];
                final int a = class_5254.method_27762(argb);
                final int b = class_5254.method_27767(argb);
                final int g = class_5254.method_27766(argb);
                final int r = class_5254.method_27765(argb);
                nativeImage.method_4305(ix, iy, class_8045.method_48344(a, b, g, r));
            }
        }

        texture.method_4524();
    }

    /**
     * Indicate to our client representation to clear the image data.
     */
    private void sendClear() {
        final ByteBuf data = Unpooled.buffer();
        data.writeBoolean(true);
        getCasing().sendData(getFace(), data, DATA_TYPE_CLEAR);
    }

    /**
     * Send a draw call to our client representation.
     */
    private void sendDrawCall() {
        final ByteBuf data = Unpooled.buffer();
        data.writeBoolean(false);
        data.writeBytes(drawCall);
        getCasing().sendData(getFace(), data);
    }
}
