/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.block.entity;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.common.block.Blocks;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_7924;

public final class BlockEntities {
    private static final DeferredRegister<class_2591<?>> BLOCK_ENTITY_TYPES = RegistryUtils.get(class_7924.field_41255);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_2591<CasingBlockEntity>> CASING = register(Blocks.CASING, CasingBlockEntity::new);
    public static final RegistrySupplier<class_2591<ControllerBlockEntity>> CONTROLLER = register(Blocks.CONTROLLER, ControllerBlockEntity::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        BLOCK_ENTITY_TYPES.register();
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("ConstantConditions") // .build(null) is fine
    private static <B extends class_2248, T extends class_2586> RegistrySupplier<class_2591<T>> register(final RegistrySupplier<B> block, final class_2591.class_5559<T> factory) {
        return BLOCK_ENTITY_TYPES.register(block.getId().method_12832(), () -> class_2591.class_2592.method_20528(factory, block.get()).method_11034(null));
    }
}
