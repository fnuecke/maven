/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class TooltipUtils {
    public static void tryAddDescription(final class_1799 stack, final List<class_2561> tooltip) {
        if (stack.method_7960()) {
            return;
        }

        final String translationKey = stack.method_7922() + ".desc";
        final class_2477 language = class_2477.method_10517();
        if (language.method_4678(translationKey)) {
            final class_5250 description = class_2561.method_43471(translationKey);
            tooltip.add(makeGray(description));
        }
    }

    private static class_5250 makeGray(final class_5250 text) {
        return text.method_27694(s -> s.method_10977(class_124.field_1080));
    }
}
