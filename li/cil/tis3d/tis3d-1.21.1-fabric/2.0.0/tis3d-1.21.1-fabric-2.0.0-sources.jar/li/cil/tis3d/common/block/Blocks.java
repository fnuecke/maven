/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.block;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_3620;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_7924;

public final class Blocks {
    private static final DeferredRegister<class_2248> BLOCKS = RegistryUtils.get(class_7924.field_41254);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<CasingBlock> CASING = BLOCKS.register("casing", () -> new CasingBlock(class_2251.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9629(1.5f, 6f)));
    public static final RegistrySupplier<ControllerBlock> CONTROLLER = BLOCKS.register("controller", () -> new ControllerBlock(class_2251.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9629(1.5f, 6f)));

    // --------------------------------------------------------------------- //

    public static void initialize() {
        BLOCKS.register();
    }
}
