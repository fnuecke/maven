/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.mixin.fabric;

import li.cil.tis3d.api.module.traits.fabric.ModuleWithBakedModelFabric;
import li.cil.tis3d.common.module.FacadeModule;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.impl.client.indigo.renderer.IndigoRenderer;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.function.Supplier;

@Mixin(FacadeModule.class)
public abstract class MixinFacadeModule implements ModuleWithBakedModelFabric {
    @Shadow
    private class_2680 facadeState;

    @Override
    public void emitBlockQuads(final class_1920 blockView, final class_2680 state, final class_2338 pos, final class_2350 direction, final Supplier<class_5819> randomSupplier, final RenderContext context) {
        final var emitter = context.getEmitter();
        final var model = class_310.method_1551().method_1541().method_3349(facadeState);
        final var quads = model.method_4707(facadeState, direction, randomSupplier.get());
        for (final class_777 quad : quads) {
            emitter.fromVanilla(quad, IndigoRenderer.INSTANCE.materialFinder().blendMode(BlendMode.CUTOUT_MIPPED).find(), direction);
            emitter.emit();
        }
    }
}
