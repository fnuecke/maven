/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer;

import li.cil.tis3d.api.API;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.minecraft.class_757;
import java.util.function.Function;

public abstract class ModRenderType extends class_1921 {
    private static final class_5942 POSITION_TEX_COLOR_SHADER =
        new class_5942(class_757::method_34543);

    private static final class_1921 UNLIT_ATLAS_TEXTURE = create("atlas_module_overlay",
        class_290.field_1575,
        builder -> builder
            .method_34578(POSITION_TEX_COLOR_SHADER)
            .method_34577(field_21376));

    private static final class_1921 UNLIT = create("module_overlay",
        class_290.field_1576,
        builder -> builder
            .method_34578(class_4668.field_29442));

    // --------------------------------------------------------------------- //

    /**
     * Render layer intended for modules, intended for rendering layered, transparent overlays.
     * As such, depth write is disabled in this layer. Textures must be in the block texture
     * atlas.
     *
     * @return the {@link class_1921} instance.
     */
    public static class_1921 unlit() {
        return UNLIT;
    }

    /**
     * Render layer intended for modules, intended for rendering layered, transparent overlays.
     * As such, depth write is disabled in this layer. Textures must be in the block texture
     * atlas.
     *
     * @return the {@link class_1921} instance.
     */
    public static class_1921 unlitAtlasTexture() {
        return UNLIT_ATLAS_TEXTURE;
    }

    /**
     * Create a render layer that is identical to {@link class_1921#method_23576(class_2960)},
     * except with diffuse lighting disabled.
     *
     * @param texture the id of the texture to be bound.
     * @return the {@link class_1921} instance.
     */
    public static class_1921 unlitTexture(final class_2960 texture) {
        return create("texture_module_overlay",
            class_290.field_1575,
            builder -> builder
                .method_34578(POSITION_TEX_COLOR_SHADER)
                .method_34577(new class_4683(texture, false, false)));
    }

    // --------------------------------------------------------------------- //

    private static class_1921 create(final String name, final class_293 format, final Function<class_4688.class_4689, class_4688.class_4689> parameters) {
        return method_24049(API.MOD_ID + "/" + name,
            format,
            class_293.class_5596.field_27382, 256,
            false,
            false,
            parameters.apply(class_4688.method_23598())
                .method_23615(field_21370)
                .method_23616(field_21350)
                .method_23617(false));
    }

    // --------------------------------------------------------------------- //

    private ModRenderType() {
        super("", class_290.field_1592, class_293.class_5596.field_27382, 256, false, false, () -> {}, () -> {});
        throw new UnsupportedOperationException("Not meant to be instantiated.");
    }
}
