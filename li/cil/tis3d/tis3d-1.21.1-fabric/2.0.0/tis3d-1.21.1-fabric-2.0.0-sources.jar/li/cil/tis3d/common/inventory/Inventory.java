/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.inventory;

import java.util.Arrays;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_7225;

/**
 * Base implementation of an array based inventory.
 */
public class Inventory implements class_1263 {
    private static final String TAG_ITEMS = "inventory";

    protected final class_1799[] items;

    public Inventory(final int size) {
        Arrays.fill(items = new class_1799[size], class_1799.field_8037);
    }

    // --------------------------------------------------------------------- //

    public void load(final class_2487 tag, final class_7225.class_7874 registries) {
        final class_2499 itemList = tag.method_10554(TAG_ITEMS, class_2520.field_33260);
        final int count = Math.min(itemList.size(), items.length);
        for (int index = 0; index < count; index++) {
            items[index] = class_1799.method_57359(registries, itemList.method_10602(index));
        }
    }

    public void save(final class_2487 tag, final class_7225.class_7874 registries) {
        final class_2499 itemList = new class_2499();
        for (final class_1799 stack : items) {
            itemList.add(stack == null ? new class_2487() : stack.method_57375(registries));
        }
        tag.method_10566(TAG_ITEMS, itemList);
    }

    // --------------------------------------------------------------------- //

    protected void onItemAdded(final int index) {
    }

    protected void onItemRemoved(final int index) {
    }

    // --------------------------------------------------------------------- //
    // IInventory

    @Override
    public int method_5439() {
        return items.length;
    }

    public boolean method_5442() {
        for (final class_1799 stack : items) {
            if (!stack.method_7960()) {
                return false;
            }
        }

        return true;
    }

    @Override
    public class_1799 method_5438(final int index) {
        return items[index];
    }

    @Override
    public class_1799 method_5434(final int index, final int count) {
        if (items[index].method_7947() <= count) {
            return method_5441(index);
        } else {
            final class_1799 stack = items[index].method_7971(count);
            assert items[index].method_7947() > 0;
            method_5431();
            return stack;
        }
    }

    @Override
    public class_1799 method_5441(final int index) {
        final class_1799 stack = items[index];
        method_5447(index, class_1799.field_8037);
        return stack;
    }

    @Override
    public void method_5447(final int index, final class_1799 stack) {
        if (items[index] == stack) {
            return;
        }

        if (!items[index].method_7960()) {
            onItemRemoved(index);
        }

        items[index] = stack;

        if (!items[index].method_7960()) {
            onItemAdded(index);
        }

        method_5431();
    }

    @Override
    public void method_5431() {
    }

    @Override
    public boolean method_5443(final class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
    }
}
