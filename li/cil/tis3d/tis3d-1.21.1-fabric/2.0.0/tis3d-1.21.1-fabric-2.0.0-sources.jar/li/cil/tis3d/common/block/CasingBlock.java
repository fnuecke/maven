/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.api.module.traits.ModuleWithRedstone;
import li.cil.tis3d.api.util.TransformUtil;
import li.cil.tis3d.common.block.entity.BlockEntities;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.common.item.Items;
import li.cil.tis3d.util.InventoryUtils;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_9062;
import net.minecraft.world.level.block.*;
import javax.annotation.Nullable;
import java.util.EnumMap;
import java.util.Optional;

/**
 * Block for the module casings.
 */
public class CasingBlock extends class_2237 {
    public static final MapCodec<CasingBlock> field_46280 = method_54094(CasingBlock::new);

    public static final class_2753 FACING = class_2383.field_11177;
    public static final class_2746 MODULE_X_NEG = class_2746.method_11825("xneg");
    public static final class_2746 MODULE_X_POS = class_2746.method_11825("xpos");
    public static final class_2746 MODULE_Y_NEG = class_2746.method_11825("yneg");
    public static final class_2746 MODULE_Y_POS = class_2746.method_11825("ypos");
    public static final class_2746 MODULE_Z_NEG = class_2746.method_11825("zneg");
    public static final class_2746 MODULE_Z_POS = class_2746.method_11825("zpos");

    public static final EnumMap<class_2350, class_2746> DIRECTION_TO_PROPERTY = class_156.method_656(() -> {
        final EnumMap<class_2350, class_2746> map = new EnumMap<>(class_2350.class);
        map.put(class_2350.field_11039, MODULE_X_NEG);
        map.put(class_2350.field_11034, MODULE_X_POS);
        map.put(class_2350.field_11033, MODULE_Y_NEG);
        map.put(class_2350.field_11036, MODULE_Y_POS);
        map.put(class_2350.field_11043, MODULE_Z_NEG);
        map.put(class_2350.field_11035, MODULE_Z_POS);
        return map;
    });

    // --------------------------------------------------------------------- //

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    public CasingBlock(class_4970.class_2251 properties) {
        super(properties);

        class_2680 defaultState = method_9595().method_11664().method_11657(FACING, class_2350.field_11043);
        for (final class_2746 value : DIRECTION_TO_PROPERTY.values()) {
            defaultState = defaultState.method_11657(value, false);
        }
        method_9590(defaultState);
    }

    // --------------------------------------------------------------------- //
    // State

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING);
        for (final class_2746 value : DIRECTION_TO_PROPERTY.values()) {
            builder.method_11667(value);
        }
    }

    @Override
    protected class_2680 method_9598(final class_2680 state, final class_2470 rotation) {
        class_2680 result = state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
        for (final class_2350 direction : class_2350.values()) {
            final var oldKey = DIRECTION_TO_PROPERTY.get(direction);
            final var newKey = DIRECTION_TO_PROPERTY.get(rotation.method_10503(direction));
            result = result.method_11657(newKey, state.method_11654(oldKey));
        }
        return result;
    }

    public static class_2470 getRotation(final class_2680 state) {
        return switch (state.method_11654(FACING)) {
            case field_11034 -> class_2470.field_11463;
            case field_11035 -> class_2470.field_11464;
            case field_11039 -> class_2470.field_11465;
            default -> class_2470.field_11467;
        };
    }

    // --------------------------------------------------------------------- //
    // BaseEntityBlock

    @Nullable
    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.CASING.get().method_11032(pos, state);
    }

    @Override
    public class_2464 method_9604(final class_2680 state) {
        return class_2464.field_11458;
    }

    // --------------------------------------------------------------------- //
    // Common

    public static Optional<class_1269> useIfCasing(final class_1838 context) {
        final var player = context.method_8036();
        if (player != null) {
            final var state = context.method_8045().method_8320(context.method_8037());
            if (state.method_26204() instanceof final CasingBlock casing) {
                final var hit = new class_3965(context.method_17698(), context.method_8038(), context.method_8037(), context.method_17699());
                return Optional.of(casing.useCasing(context.method_8045(), context.method_8037(), player, context.method_20287(), hit));
            }
        }
        return Optional.empty();
    }

    @Override
    protected class_9062 method_55765(final class_1799 stack, final class_2680 state, final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_1269 result = useCasing(level, pos, player, hand, hit);
        return result == class_1269.field_5811
            ? class_9062.field_47731
            : class_9062.method_55644(level.method_8608());
    }

    private class_1269 useCasing(final class_1937 level, final class_2338 pos, final class_1657 player, final class_1268 hand, final class_3965 hit) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof final CasingBlockEntity casing)) {
            return class_1269.field_5811;
        }

        final class_2338 hitPos = hit.method_17777();
        final class_243 localHitPos = hit.method_17784().method_1023(hitPos.method_10263(), hitPos.method_10264(), hitPos.method_10260());
        final class_2350 side = hit.method_17780();
        final Face face = casing.toLocal(side);
        final class_1799 heldItem = player.method_5998(hand);

        // Locking or unlocking the casing or a port?
        if (Items.is(heldItem, Items.KEY) || Items.is(heldItem, Items.KEY_CREATIVE)) {
            if (!level.method_8608()) {
                if (casing.isLocked()) {
                    casing.unlock(heldItem);
                } else {
                    if (!player.method_5715()) {
                        casing.lock(heldItem);
                    } else {
                        final class_243 uv = TransformUtil.hitToUV(side, localHitPos);
                        final Port port = casing.toLocal(side, Port.fromUVQuadrant(uv));

                        casing.setReceivingPipeLocked(face, port, !casing.isReceivingPipeLocked(face, port));
                    }
                }
            }
            return class_1269.method_29236(level.method_8608());
        }

        // Let the module handle the activation.
        final Module module = casing.getModule(face);
        if (module != null && module.use(player, hand, localHitPos)) {
            return class_1269.method_29236(level.method_8608());
        }

        // Don't allow changing modules while casing is locked.
        if (casing.isLocked()) {
            return class_1269.field_5811;
        }

        // Remove old module or install new one.
        final class_1799 oldModule = casing.method_5438(face.ordinal());
        if (!oldModule.method_7960()) {
            // Removing a present module from the casing.
            if (!level.method_8608()) {
                final class_1542 entity = InventoryUtils.drop(level, pos, casing, face.ordinal(), 1, side);
                if (entity != null) {
                    entity.method_6975();
                    entity.method_5694(player);
                    level.method_43128(null, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, class_3417.field_15228, class_3419.field_15245, 0.2f, 0.8f + level.field_9229.method_43057() * 0.1f);
                }
            }
            return class_1269.method_29236(level.method_8608());
        } else if (!heldItem.method_7960()) {
            // Installing a new module in the casing.
            if (casing.method_5492(face.ordinal(), heldItem, side)) {
                if (!level.method_8608()) {
                    final class_1799 insertedStack;
                    if (player.method_31549().field_7477) {
                        insertedStack = heldItem.method_7972().method_7971(1);
                    } else {
                        insertedStack = heldItem.method_7971(1);
                    }
                    if (side.method_10166() == class_2350.class_2351.field_11052) {
                        final Port orientation = casing.toLocal(side, Port.fromDirection(player.method_5735()));
                        casing.setInventorySlotContents(face.ordinal(), insertedStack, orientation);
                    } else {
                        casing.method_5447(face.ordinal(), insertedStack);
                    }
                    level.method_43128(null, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, class_3417.field_15134, class_3419.field_15245, 0.2f, 0.8f + level.field_9229.method_43057() * 0.1f);
                }
                return class_1269.method_29236(level.method_8608());
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_9536(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2680 newState, final boolean isMoving) {
        if (!state.method_27852(newState.method_26204())) {
            final class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof final CasingBlockEntity casing) {
                class_1264.method_5451(level, pos, casing);
                level.method_8455(pos, this);
            }
            super.method_9536(state, level, pos, newState, isMoving);
        }
    }

    // --------------------------------------------------------------------- //
    // Redstone

    @Override
    public boolean method_9498(final class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(final class_2680 state, final class_1937 level, final class_2338 pos) {
        return class_1703.method_7608(level.method_8321(pos));
    }

    @Override
    public int method_9524(final class_2680 blockState, final class_1922 level, final class_2338 pos, final class_2350 side) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final CasingBlockEntity casing) {
            final Module module = casing.getModule(casing.toLocal(side.method_10153()));
            if (module instanceof final ModuleWithRedstone redstoneModule) {
                return redstoneModule.getRedstoneOutput();
            }
        }
        return super.method_9524(blockState, level, pos, side);
    }

    @Override
    public boolean method_9506(final class_2680 state) {
        return true;
    }

    // --------------------------------------------------------------------- //
    // Networking

    @Override
    public void method_9612(final class_2680 state, final class_1937 level, final class_2338 pos, final class_2248 block, final class_2338 fromPos, final boolean isMoving) {
        final class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof final CasingBlockEntity casing) {
            casing.checkNeighbors();
            casing.notifyModulesOfBlockChange(fromPos);
            casing.markRedstoneDirty();
        }
        super.method_9612(state, level, pos, block, fromPos, isMoving);
    }
}
