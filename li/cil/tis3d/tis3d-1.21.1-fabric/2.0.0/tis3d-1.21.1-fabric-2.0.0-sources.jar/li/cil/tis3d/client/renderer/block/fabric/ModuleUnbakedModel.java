/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.fabric;

import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.client.resources.model.*;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.function.Function;

public final class ModuleUnbakedModel implements class_1100 {
    private final class_1100 proxy;

    // --------------------------------------------------------------------- //

    ModuleUnbakedModel(final class_1100 proxy) {
        this.proxy = proxy;
    }

    // --------------------------------------------------------------------- //
    // UnbakedModel

    @Override
    public Collection<class_2960> method_4755() {
        return proxy.method_4755();
    }

    @Override
    public void method_45785(final Function<class_2960, class_1100> function) {
        proxy.method_45785(function);
    }

    @Nullable
    @Override
    public class_1087 method_4753(final class_7775 modelBaker, final Function<class_4730, class_1058> function, final class_3665 modelState) {
        final var bakedProxy = this.proxy.method_4753(modelBaker, function, modelState);
        if (bakedProxy != null) {
            return new ModuleBakedModel(bakedProxy, class_2350.method_23225(modelState.method_3509().method_22936(), class_2350.field_11035));
        } else {
            return null;
        }
    }
}
