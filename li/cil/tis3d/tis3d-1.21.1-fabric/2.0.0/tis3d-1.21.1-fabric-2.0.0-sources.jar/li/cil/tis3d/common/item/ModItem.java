/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

import li.cil.tis3d.util.TooltipUtils;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import java.util.List;

public class ModItem extends class_1792 {
    public ModItem(final class_1793 properties) {
        super(properties);
    }

    public ModItem() {
        this(createProperties());
    }

    // --------------------------------------------------------------------- //
    // Item

    @Override
    public void method_7851(final class_1799 stack, final class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.tryAddDescription(stack, tooltip);
    }

    @Override
    public boolean method_7870(final class_1799 stack) {
        return false;
    }

    // --------------------------------------------------------------------- //

    protected static class_1793 createProperties() {
        return new class_1793();
    }
}
