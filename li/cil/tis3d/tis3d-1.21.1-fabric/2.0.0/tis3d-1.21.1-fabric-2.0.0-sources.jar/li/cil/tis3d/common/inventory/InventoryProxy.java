/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.inventory;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public interface InventoryProxy extends class_1263 {
    class_1263 getInventory();

    @Override
    default int method_5439() {
        return getInventory().method_5439();
    }

    @Override
    default boolean method_5442() {
        return getInventory().method_5442();
    }

    @Override
    default class_1799 method_5438(final int slot) {
        return getInventory().method_5438(slot);
    }

    @Override
    default class_1799 method_5434(final int slot, final int count) {
        return getInventory().method_5434(slot, count);
    }

    @Override
    default class_1799 method_5441(final int slot) {
        return getInventory().method_5441(slot);
    }

    @Override
    default void method_5447(final int slot, final class_1799 stack) {
        getInventory().method_5447(slot, stack);
    }

    @Override
    default int method_5444() {
        return getInventory().method_5444();
    }

    @Override
    default void method_5431() {
        getInventory().method_5431();
    }

    @Override
    default boolean method_5443(final class_1657 player) {
        return getInventory().method_5443(player);
    }

    @Override
    default void method_5435(final class_1657 player) {
        getInventory().method_5435(player);
    }

    @Override
    default void method_5432(final class_1657 player) {
        getInventory().method_5432(player);
    }

    @Override
    default boolean method_5437(final int slot, final class_1799 stack) {
        return getInventory().method_5437(slot, stack);
    }

    @Override
    default void method_5448() {
        getInventory().method_5448();
    }
}
