/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.item;

import li.cil.manual.api.ManualModel;
import li.cil.manual.api.ManualScreenStyle;
import li.cil.manual.api.ManualStyle;
import li.cil.manual.api.prefab.item.AbstractManualItem;
import li.cil.tis3d.client.manual.Manuals;
import li.cil.tis3d.client.renderer.Textures;
import li.cil.tis3d.client.renderer.font.NormalFontRenderer;
import li.cil.tis3d.util.TooltipUtils;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_768;
import java.util.List;

/**
 * The manual!
 */
public final class ManualItem extends AbstractManualItem {
    public ManualItem() {
        super(new class_1793());
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_7851(final class_1799 stack, final class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);
        TooltipUtils.tryAddDescription(stack, tooltip);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected ManualModel getManualModel() {
        return Manuals.MANUAL.get();
    }

    @Override
    protected ManualStyle getManualStyle() {
        return new ManualStyle() {
            @Override
            public li.cil.manual.api.render.FontRenderer getMonospaceFont() {
                return NormalFontRenderer.INSTANCE;
            }
        };
    }

    @Override
    protected ManualScreenStyle getScreenStyle() {
        return new ManualScreenStyle() {
            @Override
            public class_2960 getWindowBackground() {
                return Textures.LOCATION_GUI_MANUAL_BACKGROUND;
            }

            @Override
            public class_2960 getScrollButtonTexture() {
                return Textures.LOCATION_GUI_MANUAL_SCROLL;
            }

            @Override
            public class_2960 getTabButtonTexture() {
                return Textures.LOCATION_GUI_MANUAL_TAB;
            }

            @Override
            public class_768 getDocumentRect() {
                return new class_768(16, 48, 220, 176);
            }

            @Override
            public class_768 getScrollBarRect() {
                return new class_768(250, 48, 20, 180);
            }

            @Override
            public class_768 getScrollButtonRect() {
                return new class_768(0, 0, 26, 13);
            }

            @Override
            public class_768 getTabAreaRect() {
                return new class_768(-52, 40, 64, 224);
            }

            @Override
            public class_768 getTabRect() {
                return new class_768(0, 0, 64, 32);
            }

            @Override
            public int getTabOverlap() {
                return 8;
            }
        };
    }
}
