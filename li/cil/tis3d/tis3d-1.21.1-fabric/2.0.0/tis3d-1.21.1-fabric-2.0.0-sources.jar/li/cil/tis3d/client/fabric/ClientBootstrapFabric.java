/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.fabric;

import dev.architectury.registry.client.level.entity.EntityRendererRegistry;
import li.cil.tis3d.client.ClientBootstrap;
import li.cil.tis3d.client.ClientSetup;
import li.cil.tis3d.client.renderer.block.fabric.ModuleModelLoader;
import li.cil.tis3d.client.renderer.entity.NullEntityRenderer;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import li.cil.tis3d.common.block.entity.fabric.ChunkUnloadListener;
import li.cil.tis3d.common.entity.Entities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockGatherCallback;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import net.minecraft.class_3965;

public final class ClientBootstrapFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientBootstrap.run();
        ClientSetup.run();

        EntityRendererRegistry.register(Entities.INFRARED_PACKET, NullEntityRenderer::new);

        ClientChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> {
            for (final class_2586 blockEntity : chunk.method_12214().values()) {
                if (blockEntity instanceof final ChunkUnloadListener listener) {
                    listener.onChunkUnloaded();
                }
            }
        });

        ClientPickBlockGatherCallback.EVENT.register((player, result) -> {
            // Allow picking modules installed in the casing.
            if (result instanceof final class_3965 hit) {
                final class_2586 blockEntity = player.method_37908().method_8321(hit.method_17777());
                if (blockEntity instanceof final CasingBlockEntity casing) {
                    final var stack = casing.method_5438(casing.toLocal(hit.method_17780()).ordinal());
                    if (!stack.method_7960()) {
                        return stack.method_7972();
                    }
                }
            }
            return class_1799.field_8037;
        });

        ModuleModelLoader.initialize();
    }
}
