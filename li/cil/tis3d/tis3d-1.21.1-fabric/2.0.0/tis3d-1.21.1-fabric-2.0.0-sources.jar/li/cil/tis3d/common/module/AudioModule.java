/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.module;

import dev.architectury.injectables.annotations.ExpectPlatform;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Pipe;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.prefab.module.AbstractModule;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.client.renderer.Textures;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2766;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import javax.annotation.Nullable;

/**
 * The audio module, emitting sounds like none other.
 */
public final class AudioModule extends AbstractModule {
    // --------------------------------------------------------------------- //
    // Computed data

    /**
     * The last tick we made a sound. Used to avoid emitting multiple sounds
     * per tick when overclocked, because that could quickly spam a lot of
     * packets, and sound horrible, too.
     */
    private long lastStep;

    // --------------------------------------------------------------------- //

    public AudioModule(final Casing casing, final Face face) {
        super(casing, face);
    }

    // --------------------------------------------------------------------- //
    // Module

    @Override
    public void step() {
        final class_1937 level = getCasing().getCasingLevel();

        stepInput();

        lastStep = level.method_8510();
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void render(final RenderContext context) {
        if (!getCasing().isEnabled()) {
            return;
        }

        context.drawAtlasQuadLit(Textures.LOCATION_OVERLAY_MODULE_AUDIO);
    }

    // --------------------------------------------------------------------- //

    /**
     * Update the input of the module, reading the type of note to play.
     */
    private void stepInput() {
        for (final Port port : Port.VALUES) {
            // Continuously read from all ports, play sound when receiving a value.
            final Pipe receivingPipe = getCasing().getReceivingPipe(getFace(), port);
            if (!receivingPipe.isReading()) {
                receivingPipe.beginRead();
            }
            if (receivingPipe.canTransfer()) {
                // Don't actually read more values if we already sent a packet this tick.
                final class_1937 level = getCasing().getCasingLevel();
                if (level.method_8510() > lastStep) {
                    playNote(receivingPipe.read());
                }
            }
        }
    }

    /**
     * Decode the specified value into instrument, note and volume and play it.
     *
     * @param value the value defining the sound to play.
     */
    private void playNote(final int value) {
        final int noteId = (value & 0xFF00) >>> 8;
        final int volume = Math.min(4, (value & 0x00F0) >>> 4);
        if (volume < 1) {
            return; // Skip mute sounds.
        }

        int instrumentId = value & 0x000F;
        if (instrumentId >= class_2766.values().length) instrumentId = 0;

        // Send event to check if the sound may be played / should be modulated.
        final var note = transformNote(this, new Note(noteId, class_2766.values()[instrumentId]));
        if (note != null) {
            // Offset to have the actual origin be in front of the module.
            final class_2350 side = getWorldSide();
            final class_2338 pos = getCasing().getPosition();
            final double x = pos.method_10263() + 0.5 + side.method_10148() * 0.6;
            final double y = pos.method_10264() + 0.5 + side.method_10164() * 0.6;
            final double z = pos.method_10260() + 0.5 + side.method_10165() * 0.6;

            final float pitch = (float) Math.pow(2, (note.id() - 12) / 12.0);

            // Let there be sound!
            final class_1937 level = getCasing().getCasingLevel();
            level.method_43128(null, x, y, z, note.instrument().method_11886().comp_349(), class_3419.field_15245, volume, pitch);
            if (level instanceof final class_3218 serverLevel) {
                serverLevel.method_14199(class_2398.field_11224, x, y, z, 1, 0, 0, 0, 0);
            }
        }
    }

    public record Note(int id, class_2766 instrument) { }

    @ExpectPlatform
    @Nullable
    private static Note transformNote(final AudioModule module, final Note note) {
        throw new AssertionError();
    }
}
