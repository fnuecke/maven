/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.entity;

import li.cil.tis3d.common.block.entity.ControllerBlockEntity;
import li.cil.tis3d.util.Color;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_824;
import net.minecraft.class_827;
import java.util.Objects;

public final class ControllerBlockEntityRenderer implements class_827<ControllerBlockEntity> {
    private final class_824 renderer;
    private final class_327 font;

    public ControllerBlockEntityRenderer(final class_5614.class_5615 context) {
        renderer = context.method_32139();
        font = context.method_32143();
    }

    @Override
    public void render(final ControllerBlockEntity controller, final float partialTicks, final class_4587 matrixStack, final class_4597 bufferFactory, final int light, final int overlay) {
        final ControllerBlockEntity.ControllerState state = controller.getState();
        if (!state.isError) {
            return;
        }

        final class_239 hit = renderer.field_4350;
        if (hit instanceof final class_3965 blockHit) {
            if (Objects.equals(blockHit.method_17777(), controller.method_11016())) {
                renderState(matrixStack, bufferFactory, state);
            }
        }
    }

    private void renderState(final class_4587 matrixStack, final class_4597 bufferFactory, final ControllerBlockEntity.ControllerState state) {
        matrixStack.method_22903();
        matrixStack.method_22904(0.5, 1.4, 0.5);
        matrixStack.method_22907(renderer.field_4344.method_23767());
        matrixStack.method_22905(-0.025f, -0.025f, 0.025f);

        final class_2561 message = state.message;
        final float x = -font.method_27525(message) / 2.0f;
        final var matrix = matrixStack.method_23760().method_23761();
        final int backgroundColor = class_310.method_1551().field_1690.method_19345(0.25f);
        final int maxBrightness = class_765.method_23687(0xF, 0xF);
        font.method_30882(message, x, 0, Color.withAlpha(Color.WHITE, 0.125f), false, matrix, bufferFactory, class_327.class_6415.field_33994, backgroundColor, maxBrightness);
        font.method_30882(message, x, 0, Color.WHITE, false, matrix, bufferFactory, class_327.class_6415.field_33993, 0, maxBrightness);

        matrixStack.method_22909();
    }
}
