/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.entity;

import net.minecraft.class_1047;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public final class NullEntityRenderer<T extends class_1297> extends class_897<T> {
    public NullEntityRenderer(final class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public boolean method_3933(final T entity, final class_4604 frustum, final double cameraX, final double cameraY, final double cameraZ) {
        return false;
    }

    @Override
    public class_2960 method_3931(final T entity) {
        return class_1047.method_4539();
    }
}
