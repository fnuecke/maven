/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.entity;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.tis3d.util.RegistryUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_7924;
import java.util.function.Function;

public final class Entities {
    private static final DeferredRegister<class_1299<?>> ENTITY_TYPES = RegistryUtils.get(class_7924.field_41266);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1299<InfraredPacketEntity>> INFRARED_PACKET = register("infrared_packet", InfraredPacketEntity::new, class_1311.field_17715, b -> b
        .method_17687(0.25f, 0.25f)
        .method_27299(16)
        .method_27300(1)
        .method_20815()
        .method_19947()
        .method_5901());

    // --------------------------------------------------------------------- //

    public static void initialize() {
        ENTITY_TYPES.register();
    }

    // --------------------------------------------------------------------- //

    private static <T extends class_1297> RegistrySupplier<class_1299<T>> register(final String name, final class_1299.class_4049<T> factory, final class_1311 classification, final Function<class_1299.class_1300<T>, class_1299.class_1300<T>> customizer) {
        return ENTITY_TYPES.register(name, () -> customizer.apply(class_1299.class_1300.method_5903(factory, classification)).method_5905(name));
    }
}
