/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.block.entity;

import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Pipe;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.util.TransformUtil;
import li.cil.tis3d.common.machine.PipeHost;
import li.cil.tis3d.common.machine.PipeImpl;
import li.cil.tis3d.util.LevelUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.util.Objects;

public abstract class ComputerBlockEntity extends class_2586 implements PipeHost {
    // --------------------------------------------------------------------- //
    // Persisted data.

    /**
     * The flat list of all {@link Pipe}s on this casing.
     * <p>
     * Indexed by face and port using {@link #pack(Face, Port)}.
     */
    private final PipeImpl[] pipes = new PipeImpl[Face.VALUES.length * Port.VALUES.length];

    // --------------------------------------------------------------------- //
    // Computed data.

    // Mapping for faces and ports around edges, i.e. to get the other side
    // of an edge specified by a face and port.
    private static final Face[][] FACE_MAPPING;
    private static final Port[][] PORT_MAPPING;

    static {
        FACE_MAPPING = new Face[][]{
            {Face.X_POS, Face.X_NEG, Face.Z_NEG, Face.Z_POS}, // Y_NEG
            {Face.X_POS, Face.X_NEG, Face.Z_POS, Face.Z_NEG}, // Y_POS
            {Face.X_POS, Face.X_NEG, Face.Y_POS, Face.Y_NEG}, // Z_NEG
            {Face.X_NEG, Face.X_POS, Face.Y_POS, Face.Y_NEG}, // Z_POS
            {Face.Z_NEG, Face.Z_POS, Face.Y_POS, Face.Y_NEG}, // X_NEG
            {Face.Z_POS, Face.Z_NEG, Face.Y_POS, Face.Y_NEG}  // X_POS
            //    LEFT        RIGHT       UP          DOWN
        };
        PORT_MAPPING = new Port[][]{
            {Port.DOWN, Port.DOWN, Port.DOWN, Port.DOWN},     // Y_NEG
            {Port.UP, Port.UP, Port.UP, Port.UP},             // Y_POS
            {Port.RIGHT, Port.LEFT, Port.DOWN, Port.UP},      // Z_NEG
            {Port.RIGHT, Port.LEFT, Port.UP, Port.DOWN},      // Z_POS
            {Port.RIGHT, Port.LEFT, Port.RIGHT, Port.RIGHT},  // X_NEG
            {Port.RIGHT, Port.LEFT, Port.LEFT, Port.LEFT}     // X_POS
            //    LEFT        RIGHT       UP          DOWN
        };
    }

    // NBT tag names.
    private static final String TAG_PIPES = "pipes";
    private static final String TAG_IS_UPDATE_TAG = "is_update_tag";

    private final ComputerBlockEntity[] neighbors = new ComputerBlockEntity[Face.VALUES.length];
    private final PipeImpl[] pipeOverride = new PipeImpl[pipes.length];

    // --------------------------------------------------------------------- //

    protected ComputerBlockEntity(final class_2591<?> type, final class_2338 pos, final class_2680 state) {
        super(type, pos, state);

        for (final Face face : Face.VALUES) {
            for (final Port port : Port.VALUES) {
                final int pipeIndex = pack(face, port);
                pipeOverride[pipeIndex] = pipes[pipeIndex] = new PipeImpl(this, face, mapFace(face, port), mapPort(face, port));
            }
        }
    }

    public class_1937 getBlockEntityLevel() {
        return Objects.requireNonNull(method_10997());
    }

    public abstract class_2470 getRotation();

    /**
     * Advances the logic of all pipes by calling {@link PipeImpl#step()} on them.
     * <p>
     * This will advance pipes with both an active read and write operation to
     * transferring mode, if they're not already in transferring mode.
     */
    void stepPipes() {
        for (final PipeImpl pipe : pipes) {
            pipe.step();
        }
    }

    /**
     * Get the list of all pipes managed by this computer part.
     *
     * @return the array of pipes.
     */
    public Pipe[] getPipes() {
        return pipes;
    }

    /**
     * Receiving pipe for the specified face and port.
     *
     * @param face the face to get the port for.
     * @param port the port for which to get the port.
     * @return the input port on that port.
     * @see li.cil.tis3d.api.machine.Casing#getReceivingPipe(Face, Port)
     */
    public Pipe getReceivingPipe(final Face face, final Port port) {
        return pipeOverride[pack(face, port)];
    }

    /**
     * Sending pipe for the specified face and port.
     *
     * @param face the face to get the port for.
     * @param port the port for which to get the port.
     * @return the output port on that port.
     * @see li.cil.tis3d.api.machine.Casing#getSendingPipe(Face, Port)
     */
    public Pipe getSendingPipe(final Face face, final Port port) {
        return pipeOverride[packMapped(face, port)];
    }

    // --------------------------------------------------------------------- //
    // PipeHost

    @Override
    public class_1937 getPipeHostLevel() {
        return getBlockEntityLevel();
    }

    @Override
    public class_2338 getPipeHostPosition() {
        return method_11016();
    }

    @Override
    public class_2470 getPipeHostRotation() {
        return getRotation();
    }

    @Override
    public void onPipeStateChanged() {
        method_5431();
    }

    // --------------------------------------------------------------------- //
    // BlockEntity

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        if (tag.method_10545(TAG_IS_UPDATE_TAG)) {
            loadClient(tag, registries);
        } else {
            loadServer(tag, registries);
        }
    }

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        saveServer(tag, registries);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final class_2487 tag = super.method_16887(registries);
        tag.method_10556(TAG_IS_UPDATE_TAG, true);
        saveClient(tag, registries);
        return tag;
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    // --------------------------------------------------------------------- //

    public void checkNeighbors() {
        final class_1937 level = getBlockEntityLevel();

        // When a neighbor changed, check all neighbors and register them in
        // our tile entity.
        for (final class_2350 side : class_2350.values()) {
            final class_2338 neighborPos = method_11016().method_10093(side);
            if (LevelUtils.isLoaded(level, neighborPos)) {
                // If we have a casing, set it as our neighbor.
                final class_2586 blockEntity = level.method_8321(neighborPos);
                if (blockEntity instanceof final ComputerBlockEntity computerPart) {
                    setNeighbor(toLocal(side), computerPart);
                } else {
                    setNeighbor(toLocal(side), null);
                }
            } else {
                // Neighbor is in unloaded area.
                setNeighbor(toLocal(side), null);
            }
        }
    }

    protected abstract void scheduleScan();

    protected void setNeighbor(final Face face, @Nullable final ComputerBlockEntity neighbor) {
        // If a neighbor changed, do a rescan in the controller.
        final ComputerBlockEntity oldNeighbor = neighbors[face.ordinal()];
        if (neighbor != oldNeighbor) {
            neighbors[face.ordinal()] = neighbor;
            scheduleScan();
        }
    }

    protected void loadServer(final class_2487 tag, final class_7225.class_7874 registries) {
        final class_2499 pipesTag = tag.method_10554(TAG_PIPES, class_2520.field_33260);
        final int pipeCount = Math.min(pipesTag.size(), pipes.length);
        for (int i = 0; i < pipeCount; i++) {
            pipes[i].load(pipesTag.method_10602(i));
        }

        loadCommon(tag, registries);
    }

    protected void saveServer(final class_2487 tag, final class_7225.class_7874 registries) {
        final class_2499 pipesTag = new class_2499();
        for (final PipeImpl pipe : pipes) {
            final class_2487 portTag = new class_2487();
            pipe.save(portTag);
            pipesTag.add(portTag);
        }
        tag.method_10566(TAG_PIPES, pipesTag);

        saveCommon(tag, registries);
    }

    protected void loadClient(final class_2487 tag, final class_7225.class_7874 registries) {
        loadCommon(tag, registries);
    }

    protected void saveClient(final class_2487 tag, final class_7225.class_7874 registries) {
        saveCommon(tag, registries);
    }

    protected void loadCommon(final class_2487 tag, final class_7225.class_7874 registries) {
    }

    protected void saveCommon(final class_2487 tag, final class_7225.class_7874 registries) {
    }

    boolean hasNeighbor(final Face face) {
        return neighbors[face.ordinal()] != null;
    }

    void rebuildOverrides() {
        // Reset to initial state before checking for inter-block connections.
        System.arraycopy(pipes, 0, pipeOverride, 0, pipes.length);

        // Check each open face's neighbors, if they're in front of another
        // computer block, start connecting the pipe to where that leads us.
        for (final Face face : Face.VALUES) {
            if (neighbors[face.ordinal()] != null) {
                continue;
            }

            for (final Port port : Port.VALUES) {
                final Face otherFace = mapFace(face, port);
                final Port otherPort = mapPort(face, port);

                final ComputerBlockEntity neighbor = neighbors[otherFace.ordinal()];
                if (neighbor != null) {
                    final Face neighborFace = toNeighborFace(neighbor, otherFace);
                    final Port neighborPort = toNeighborPort(neighbor, otherFace, otherPort);
                    neighbor.computePipeOverrides(neighborFace, neighborPort, this, face, port);
                }
            }
        }
    }

    // --------------------------------------------------------------------- //

    /**
     * Get the the face on the other side of an edge.
     *
     * @param face the face defining the edge.
     * @param port the port defining the edge.
     * @return the face on the other side of the edge.
     */
    public static Face mapFace(final Face face, final Port port) {
        return FACE_MAPPING[face.ordinal()][port.ordinal()];
    }

    /**
     * Get the the port on the other side of an edge, relative to the face on
     * the other side of the edge.
     *
     * @param face the face defining the edge.
     * @param port the port defining the edge.
     * @return the port on the other side of the edge.
     */
    public static Port mapPort(final Face face, final Port port) {
        return PORT_MAPPING[face.ordinal()][port.ordinal()];
    }

    /**
     * Convert a face-port tuple to a unique number.
     *
     * @param face the face to pack into the number.
     * @param port the port to pack into the number.
     * @return the compressed representation of the face-port tuple.
     */
    private static int pack(final Face face, final Port port) {
        return face.ordinal() * Port.VALUES.length + port.ordinal();
    }

    /**
     * Map a face-port tuple to the face-tuple representing its opposite (i.e.
     * the face-port tuple defining the same edge but from the other side),
     * then convert it to a unique number.
     *
     * @param face the face defining the edge to the face to pack.
     * @param port the port defining the edge to the port to pack.
     * @return the compressed representation of the mapped face-port tuple.
     */
    private static int packMapped(final Face face, final Port port) {
        return mapFace(face, port).ordinal() * Port.VALUES.length + mapPort(face, port).ordinal();
    }

    /**
     * Get the port opposite to the specified port in a casing opposite to the
     * the specified facing. Used when connecting across multiple casings.
     *
     * @param side the face opposite to which to get the port for, in world space.
     * @param port the port opposite to which to get the port for, in world space.
     * @return the port opposite to the specified port on the specified face.
     */
    private static Port flipSide(final class_2350 side, final Port port) {
        if (side.method_10166() == class_2350.class_2351.field_11052) {
            return (port == Port.UP || port == Port.DOWN) ? port.getOpposite() : port;
        } else {
            return (port == Port.LEFT || port == Port.RIGHT) ? port.getOpposite() : port;
        }
    }

    /**
     * Populates the {@link #pipeOverride} array for the specified computer's
     * face and port by traversing the computer multi-block until an open face
     * is found that at face and port connects to. Used to bridge casings so
     * that we can write values to modules of other casings without latency.
     *
     * @param face      the face of <em>this</em> casing to search from.
     * @param port      the port of <em>this</em> casing to search from.
     * @param start     the computer we're searching for.
     * @param startFace the face on the computer we're searching for.
     * @param startPort the port on the computer we're searching for.
     */
    private void computePipeOverrides(final Face face, final Port port, final ComputerBlockEntity start, final Face startFace, final Port startPort) {
        // Avoid cycles for inner faces of 2x2 structures.
        if (start == this) {
            return;
        }

        final Face otherFace = mapFace(face, port);
        final Port otherPort = mapPort(face, port);

        final ComputerBlockEntity neighbor = neighbors[otherFace.ordinal()];
        if (neighbor != null) {
            // Got a neighbor, continue searching through it. This can continue
            // only two times before we run into the early exit above.
            final Face neighborFace = toNeighborFace(neighbor, otherFace);
            final Port neighborPort = toNeighborPort(neighbor, otherFace, otherPort);
            neighbor.computePipeOverrides(neighborFace, neighborPort, start, startFace, startPort);
        } else {
            // No neighbor, we have an open face. Use as target for the pipe.
            // override in the original computer. Setting this up in one
            // direction suffices as this is performed in both directions.
            final int receivingIndex = pack(startFace, startPort);
            final int mySendingIndex = packMapped(otherFace, otherPort);
            start.pipeOverride[receivingIndex] = pipes[mySendingIndex];
        }
    }

    private Face toNeighborFace(final ComputerBlockEntity neighbor, final Face face) {
        return neighbor.toLocal(toWorld(face).method_10153());
    }

    private Port toNeighborPort(final ComputerBlockEntity neighbor, final Face face, final Port port) {
        final class_2350 side = toWorld(face);
        final Port worldPort = TransformUtil.toWorld(face, port, getRotation());
        return TransformUtil.toLocal(side.method_10153(), flipSide(side, worldPort), neighbor.getRotation());
    }

    public final class_2350 toWorld(final Face face) {
        return TransformUtil.toWorld(face, getRotation());
    }

    public final Face toLocal(final class_2350 side) {
        return TransformUtil.toLocal(side, getRotation());
    }
}
