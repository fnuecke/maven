/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_9129;

import static java.util.Objects.requireNonNull;

public final class ServerCasingInitializeMessage extends AbstractMessageWithPosition {
    private static final String MODULES_TAG = "modules";

    private class_2499 tag;

    public ServerCasingInitializeMessage(final Casing casing, final class_2499 tag) {
        super(casing.getPosition());
        this.tag = tag;
    }

    public ServerCasingInitializeMessage(final class_9129 buffer) {
        super(buffer);
    }

    // --------------------------------------------------------------------- //
    // AbstractMessage

    @Override
    public void handleMessage(NetworkManager.PacketContext context) {
        final var level = getClientLevel();
        if (level != null) {
            withBlockEntity(level, CasingBlockEntity.class, casing -> {
                for (int i = 0; i < Face.VALUES.length; i++) {
                    final var face = Face.VALUES[i];
                    final var moduleTag = tag.method_10602(i);
                    final var module = casing.getModule(face);
                    if (module != null) {
                        module.load(moduleTag);
                    }
                }
            });
        }
    }

    @Override
    public void fromBytes(class_9129 buffer) {
        super.fromBytes(buffer);

        final var wrapper = requireNonNull(buffer.method_10798());
        tag = wrapper.method_10554(MODULES_TAG, class_2520.field_33260);
    }

    @Override
    public void toBytes(class_9129 buffer) {
        super.toBytes(buffer);

        final var wrapper = new class_2487();
        wrapper.method_10566(MODULES_TAG, tag);
        buffer.method_10794(wrapper);
    }
}
