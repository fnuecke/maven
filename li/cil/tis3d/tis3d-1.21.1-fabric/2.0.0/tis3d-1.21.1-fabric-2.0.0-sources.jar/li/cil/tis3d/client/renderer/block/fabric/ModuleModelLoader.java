/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.fabric;

import li.cil.tis3d.api.API;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.minecraft.class_1100;
import net.minecraft.class_2960;

public final class ModuleModelLoader implements ModelLoadingPlugin, ModelModifier.OnLoad {
    private static final class_2960 BLOCK_CASING_MODULE_MODEL_LOCATION = class_2960.method_60655(API.MOD_ID, "block/casing_module");

    public static void initialize() {
        ModelLoadingPlugin.register(new ModuleModelLoader());
    }

    @Override
    public void onInitializeModelLoader(ModelLoadingPlugin.Context context) {
        context.modifyModelOnLoad().register(this);
    }

    @Override
    public class_1100 modifyModelOnLoad(class_1100 model, ModelModifier.OnLoad.Context context) {
        final class_2960 id = context.resourceId();
        if (id == null || !id.equals(BLOCK_CASING_MODULE_MODEL_LOCATION)) {
            return model;
        }

        return new ModuleUnbakedModel(context.getOrLoadModel(
            class_2960.method_60655(id.method_12836(), id.method_12832() + "_proxy")));
    }
}
