@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.tis3d.api.module.traits;

import javax.annotation.ParametersAreNonnullByDefault;
