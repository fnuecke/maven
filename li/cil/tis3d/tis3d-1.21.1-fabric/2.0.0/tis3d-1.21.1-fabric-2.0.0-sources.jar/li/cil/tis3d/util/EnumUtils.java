/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.util;

import li.cil.tis3d.api.API;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import org.apache.logging.log4j.LogManager;

/**
 * Utility method for wrapping enum serialization against exceptions.
 */
public final class EnumUtils {
    public static <T extends Enum<T>> T load(final Class<T> clazz, final String tagName, final class_2487 tag) {
        if (tag.method_10573(tagName, class_2520.field_33258)) {
            // Backwards compatibility.
            try {
                return Enum.valueOf(clazz, tag.method_10558(tagName));
            } catch (final IllegalArgumentException e) {
                // This can only happen if someone messes with the save.
                LogManager.getLogger(API.MOD_ID).warn("Broken save, enum value is invalid.", e);
                return clazz.getEnumConstants()[0];
            }
        } else {
            return clazz.getEnumConstants()[tag.method_10571(tagName)];
        }
    }

    public static <T extends Enum<T>> void save(final Enum<T> value, final String tagName, final class_2487 tag) {
        tag.method_10567(tagName, (byte) value.ordinal());
    }

    // --------------------------------------------------------------------- //

    private EnumUtils() {
    }
}
