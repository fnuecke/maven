/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.common.provider.serial;

import li.cil.tis3d.api.serial.SerialInterface;
import li.cil.tis3d.api.serial.SerialInterfaceProvider;
import li.cil.tis3d.api.serial.SerialProtocolDocumentationReference;
import li.cil.tis3d.util.EnumUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3866;
import java.util.Objects;
import java.util.Optional;

public final class SerialInterfaceProviderFurnace implements SerialInterfaceProvider {
    private static final class_2561 DOCUMENTATION_TITLE = class_2561.method_43471("tis3d.manual.serial_protocols.furnace");
    private static final String DOCUMENTATION_LINK = "minecraft_furnace.md";
    private static final SerialProtocolDocumentationReference DOCUMENTATION_REFERENCE = new SerialProtocolDocumentationReference(DOCUMENTATION_TITLE, DOCUMENTATION_LINK);

    // --------------------------------------------------------------------- //
    // SerialInterfaceProvider

    @Override
    public boolean matches(final class_1937 level, final class_2338 position, final class_2350 side) {
        return level.method_8321(position) instanceof class_3866;
    }

    @Override
    public Optional<SerialInterface> getInterface(final class_1937 level, final class_2338 position, final class_2350 side) {
        final class_3866 furnace = Objects.requireNonNull((class_3866) level.method_8321(position));
        return Optional.of(new SerialInterfaceFurnace(furnace));
    }

    @Override
    public Optional<SerialProtocolDocumentationReference> getDocumentationReference() {
        return Optional.of(DOCUMENTATION_REFERENCE);
    }

    @Override
    public boolean stillValid(final class_1937 level, final class_2338 position, final class_2350 side, final SerialInterface serialInterface) {
        return serialInterface instanceof SerialInterfaceFurnace;
    }

    // --------------------------------------------------------------------- //

    private static final class SerialInterfaceFurnace implements SerialInterface {
        private static final String TAG_MODE = "mode";

        private enum Mode {
            PercentageFuel,
            PercentageProgress
        }

        private final class_3866 furnace;
        private Mode mode = Mode.PercentageFuel;

        SerialInterfaceFurnace(final class_3866 furnace) {
            this.furnace = furnace;
        }

        @Override
        public boolean canWrite() {
            return true;
        }

        @Override
        public void write(final short value) {
            if (value == 0) {
                mode = Mode.PercentageFuel;
            } else {
                mode = Mode.PercentageProgress;
            }
        }

        @Override
        public boolean canRead() {
            return true;
        }

        @Override
        public short peek() {
            switch (mode) {
                case PercentageFuel -> {
                    final int value = furnace.field_11981;
                    final int total = furnace.field_11980;
                    if (total > 0) {
                        return (short) (value * 100 / total);
                    }
                }
                case PercentageProgress -> {
                    final int value = furnace.field_11989;
                    final int total = furnace.field_11988;
                    if (total > 0) {
                        return (short) (value * 100 / total);
                    }
                }
            }
            return (short) 0;
        }

        @Override
        public void skip() {
        }

        @Override
        public void reset() {
            mode = Mode.PercentageFuel;
        }

        @Override
        public void load(final class_2487 tag) {
            mode = EnumUtils.load(SerialInterfaceFurnace.Mode.class, TAG_MODE, tag);
        }

        @Override
        public void save(final class_2487 tag) {
            EnumUtils.save(mode, TAG_MODE, tag);
        }
    }
}
