/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.api.prefab.module;

import io.netty.buffer.ByteBuf;
import li.cil.tis3d.api.machine.Casing;
import li.cil.tis3d.api.machine.Face;
import li.cil.tis3d.api.machine.Pipe;
import li.cil.tis3d.api.machine.Port;
import li.cil.tis3d.api.module.Module;
import li.cil.tis3d.api.util.RenderContext;
import li.cil.tis3d.api.util.TransformUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import org.jetbrains.annotations.ApiStatus;

import javax.annotation.Nullable;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Base implementation of a module, taking care of the boilerplate code.
 */
public abstract class AbstractModule implements Module {
    // --------------------------------------------------------------------- //
    // Computed data

    private final Casing casing;
    private final Face face;
    private boolean isDisposed;

    protected AbstractModule(final Casing casing, final Face face) {
        this.casing = casing;
        this.face = face;
    }

    @SuppressWarnings("removal")
    @Override
    protected void finalize() {
        if (!isDisposed) {
            MainThreadDisposer.add(this);
        }
    }

    // --------------------------------------------------------------------- //
    // Communication utility

    /**
     * Cancel writing on all ports.
     */
    protected void cancelWrite() {
        for (final Port port : Port.VALUES) {
            final Pipe sendingPipe = getCasing().getSendingPipe(getFace(), port);
            sendingPipe.cancelWrite();
        }
    }

    /**
     * Cancel reading on all ports.
     */
    protected void cancelRead() {
        for (final Port port : Port.VALUES) {
            final Pipe receivingPipe = getCasing().getReceivingPipe(getFace(), port);
            receivingPipe.cancelRead();
        }
    }

    // --------------------------------------------------------------------- //
    // Rendering utility

    /**
     * Utility method for determining whether the player is currently looking at this module.
     *
     * @param hitResult the current hit result.
     * @return <tt>true</tt> if the observer is looking at the module, <tt>false</tt> otherwise.
     */
    protected boolean isHitFace(@Nullable final class_239 hitResult) {
        if (!(hitResult instanceof final class_3965 blockHitResult)) {
            return false;
        }

        final class_2338 pos = blockHitResult.method_17777();
        return Objects.equals(getCasing().getPosition(), pos) &&
            blockHitResult.method_17780() == getWorldSide();
    }

    /**
     * Utility method for determining the hit coordinate on the module's face the player is
     * looking at. This will return {@code null} if the player is not currently looking
     * at the module.
     * <p>
     * Note that this will return the unadjusted X, Y and Z components. To transform this
     * coordinate to a UV coordinate mapped to the module's face, pass this into
     * {@link #hitToUV}. Note that this method is overridden in {@link AbstractModuleWithRotation}
     * to also take into account the module's rotation.
     *
     * @param hitResult the current hit result.
     * @return the UV coordinate the observer is looking at as the X and Y components.
     */
    @Nullable
    protected class_243 getLocalHitPosition(@Nullable final class_239 hitResult) {
        if (!(hitResult instanceof final class_3965 blockHitResult)) {
            return null;
        }

        final class_2338 pos = blockHitResult.method_17777();
        if (!Objects.equals(getCasing().getPosition(), pos)) {
            return null;
        }
        if (blockHitResult.method_17780() != getWorldSide()) {
            return null;
        }

        return hitResult.method_17784().method_1023(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    // --------------------------------------------------------------------- //
    // General utility

    /**
     * Project a hit position on the surface of a casing to a UV coordinate on
     * the face of this module.
     * <p>
     * Note that this is also overridden in {@link AbstractModuleWithRotation} to
     * take into account the module's rotation.
     *
     * @param hitPos the hit position to project.
     * @return the projected UV coordinate, with the Z component being 0.
     * @see #getLocalHitPosition(class_239)
     * @see Module#use(class_1657, class_1268, class_243)
     */
    protected class_243 hitToUV(final class_243 hitPos) {
        return TransformUtil.hitToUV(getWorldSide(), hitPos);
    }

    /**
     * Convenience check for determining whether a module is actually visible.
     * <p>
     * This can allow for some optimizations, such as sending state updates
     * much more or infrequently (or not at all) while invisible. If rendering
     * a module's overlay is exceptionally complex,
     *
     * @return whether the module is currently visible.
     */
    protected boolean isVisible() {
        final class_1937 level = getCasing().getCasingLevel();
        final class_2338 neighborPos = getCasing().getPosition().method_10093(getWorldSide());
        if (!level.method_8477(neighborPos)) {
            // If the neighbor isn't loaded, we can assume we're also not visible on that side.
            return false;
        }

        // Otherwise check if the neighboring block blocks visibility to our face.
        final class_2680 neighborState = level.method_8320(neighborPos);
        return !neighborState.method_26216(level, neighborPos);
    }

    /**
     * The {@link class_2350} the {@link Module} is installed on in its {@link Casing}.
     *
     * @return the direction the face of the casing this module is installed in points in.
     */
    protected final class_2350 getWorldSide() {
        return getCasing().toWorld(getFace());
    }

    // --------------------------------------------------------------------- //
    // Module

    @Override
    public Casing getCasing() {
        return casing;
    }

    @Override
    public Face getFace() {
        return face;
    }

    @Override
    public void step() {
    }

    @Override
    public void onInstalled(final class_1799 stack) {
    }

    @Override
    public void onUninstalled(final class_1799 stack) {
    }

    @Override
    public void onEnabled() {
    }

    @Override
    public void onDisabled() {
    }

    @Override
    public void onDisposed() {
        isDisposed = true;
    }

    @Override
    public void onBeforeWriteComplete(final Port port) {
    }

    @Override
    public void onWriteComplete(final Port port) {
    }

    @Override
    public boolean use(final class_1657 player, final class_1268 hand, final class_243 hit) {
        return false;
    }

    @Override
    public void onData(final class_2487 data) {
    }

    @Override
    public void onData(final ByteBuf data) {
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void render(final RenderContext context) {
    }

    @Override
    public void load(final class_2487 tag) {
    }

    @Override
    public void save(final class_2487 tag) {
    }

    // --------------------------------------------------------------------- //

    /**
     * Used to make absolutely sure we call onDisposed on modules. There are some cases
     * where we cannot guarantee that this is called regularly, e.g. on level unload.
     * We want to make sure to call it though, because some modules may own unmanaged
     * resources such as GPU memory.
     */
    @ApiStatus.Internal
    public static final class MainThreadDisposer {
        private static final ConcurrentLinkedQueue<Module> modules = new ConcurrentLinkedQueue<>();

        static void add(final Module module) {
            modules.add(module);
        }

        public static void disposeModules() {
            Module module;
            while ((module = modules.poll()) != null) {
                module.onDisposed();
            }
        }
    }
}
