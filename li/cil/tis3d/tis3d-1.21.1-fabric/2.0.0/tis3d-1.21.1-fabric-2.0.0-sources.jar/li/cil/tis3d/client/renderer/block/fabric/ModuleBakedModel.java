/* SPDX-License-Identifier: MIT */

package li.cil.tis3d.client.renderer.block.fabric;

import li.cil.tis3d.api.module.traits.fabric.ModuleWithBakedModelFabric;
import li.cil.tis3d.common.block.entity.CasingBlockEntity;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

public final class ModuleBakedModel implements class_1087, FabricBakedModel {
    private final class_1087 proxy;
    private final class_2350 direction;

    // --------------------------------------------------------------------- //

    ModuleBakedModel(final class_1087 proxy, final class_2350 direction) {
        this.proxy = proxy;
        this.direction = direction;
    }

    // --------------------------------------------------------------------- //
    // FabricBakedModel

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(final class_1920 blockView, final class_2680 state, final class_2338 pos, final Supplier<class_5819> randomSupplier, final RenderContext context) {
        if (!(blockView.method_8321(pos) instanceof final CasingBlockEntity casing)) {
            return;
        }

        final var module = casing.getModule(casing.toLocal(direction));
        if (module instanceof final ModuleWithBakedModelFabric moduleWithModel && moduleWithModel.hasModel()) {
            moduleWithModel.emitBlockQuads(blockView, state, pos, direction, randomSupplier, context);
        } else {
            proxy.emitBlockQuads(blockView, state, pos, randomSupplier, context);
        }
    }

    @Override
    public void emitItemQuads(final class_1799 stack, final Supplier<class_5819> randomSupplier, final RenderContext context) {
    }

    // --------------------------------------------------------------------- //
    // BakedModel

    @Override
    public List<class_777> method_4707(@Nullable final class_2680 blockState, @Nullable final class_2350 direction, final class_5819 randomSource) {
        return Collections.emptyList();
    }

    @Override
    public boolean method_4708() {
        return proxy.method_4708();
    }

    @Override
    public boolean method_4712() {
        return proxy.method_4712();
    }

    @Override
    public boolean method_24304() {
        return proxy.method_24304();
    }

    @Override
    public boolean method_4713() {
        return proxy.method_4713();
    }

    @Override
    public class_1058 method_4711() {
        return proxy.method_4711();
    }

    @Override
    public class_809 method_4709() {
        return proxy.method_4709();
    }

    @Override
    public class_806 method_4710() {
        return proxy.method_4710();
    }
}
