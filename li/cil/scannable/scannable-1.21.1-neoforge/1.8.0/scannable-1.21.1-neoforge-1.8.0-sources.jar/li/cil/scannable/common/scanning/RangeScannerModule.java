/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.common.config.ServerConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;

public enum RangeScannerModule implements ScannerModule {
    INSTANCE;

    @Override
    public int getEnergyCost(final ItemStack module) {
        return ServerConfig.energyCostModuleRange;
    }

    @Override
    public boolean hasResultProvider() {
        return false;
    }

    @Nullable
    @Environment(EnvType.CLIENT)
    @Override
    public ScanResultProvider getResultProvider() {
        return null;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public float adjustGlobalRange(final float range) {
        return range + Mth.ceil(ServerConfig.baseScanRadius * ServerConfig.rangeModifierModuleRange);
    }
}
