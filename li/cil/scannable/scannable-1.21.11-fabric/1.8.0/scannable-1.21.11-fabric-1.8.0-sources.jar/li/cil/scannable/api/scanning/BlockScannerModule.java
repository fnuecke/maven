/* SPDX-License-Identifier: MIT */

package li.cil.scannable.api.scanning;

import java.util.function.Predicate;
import net.minecraft.class_1799;
import net.minecraft.class_2680;

/**
 * Specialized interface for using the built-in block scan result provider.
 * <p>
 * When implementing this interface, return the result provider implementation
 * obtained from the provider registry like so:
 * <pre>
 * RegistryManager.ACTIVE.getRegistry(ScanResultProvider.class).getValue(API.SCAN_RESULT_PROVIDER_BLOCKS);
 * </pre>
 */
public interface BlockScannerModule extends ScannerModule {
    /**
     * Modifies the local range of the scan. Modules can boost or reduce the range
     * for only their own filtering via {@link #getFilter(class_1799)}.
     *
     * @param range the input range.
     * @return the adjusted range.
     */
    default float adjustLocalRange(final float range) {
        return range;
    }

    /**
     * Get a filter that will be used for testing whether blocks should be included
     * in the scan result.
     *
     * @param module the module to get the filter for.
     * @return the filter to use.
     */
    Predicate<class_2680> getFilter(final class_1799 module);
}
