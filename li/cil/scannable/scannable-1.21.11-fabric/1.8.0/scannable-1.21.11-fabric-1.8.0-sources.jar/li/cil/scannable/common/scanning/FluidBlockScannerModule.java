/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.BlockScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.BlockCacheScanFilter;
import li.cil.scannable.client.scanning.filter.FluidTagScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public enum FluidBlockScannerModule implements BlockScannerModule {
    INSTANCE;

    private Predicate<class_2680> filter;

    public static void clearCache() {
        INSTANCE.filter = null;
    }

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleFluid;
    }

    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.blocks();
    }

    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleFluid;
    }

    @Override
    public Predicate<class_2680> getFilter(final class_1799 module) {
        validateFilter();
        return filter;
    }

    private void validateFilter() {
        if (filter != null) {
            return;
        }

        final List<Predicate<class_2680>> filters = new ArrayList<>();
        class_7923.field_41173.method_40272().forEach(namedTag -> {
            final class_6862<class_3611> tag = namedTag.method_40251();
            if (!ServerConfig.ignoredFluidTags.contains(tag.comp_327())) {
                filters.add(new FluidTagScanFilter(tag));
            }
        });
        filter = new BlockCacheScanFilter(filters);
    }
}
