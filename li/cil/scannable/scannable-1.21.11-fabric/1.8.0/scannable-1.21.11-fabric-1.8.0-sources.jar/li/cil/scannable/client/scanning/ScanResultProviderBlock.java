/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning;

import com.google.common.base.Strings;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.netty.util.collection.IntObjectHashMap;
import io.netty.util.collection.IntObjectMap;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import li.cil.scannable.api.API;
import li.cil.scannable.api.prefab.AbstractScanResultProvider;
import li.cil.scannable.api.scanning.BlockScannerModule;
import li.cil.scannable.api.scanning.ScanResult;
import li.cil.scannable.api.scanning.ScanResultRenderContext;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.client.ClientConfig;
import li.cil.scannable.client.shader.ScanPipelines;
import li.cil.scannable.common.item.ScannerModuleItem;
import li.cil.scannable.common.scanning.filter.IgnoredBlocks;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_276;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2826;
import net.minecraft.class_2841;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_4076;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryStack;

import javax.annotation.Nullable;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;

public final class ScanResultProviderBlock extends AbstractScanResultProvider {
    private static final int TIME_UNIFORM_SIZE = new Std140SizeCalculator().putVec4().get();

    // Sanity performance check. Maybe some day I'll do some research on how to
    // do the clustering more efficiently, but for now this is good enough. We
    // really only need this when scanning for stupid stuff like stone.
    private static final int MAX_RESULTS_PER_BLOCK = 8192;
    private static final int DEFAULT_COLOR = 0x4466CC;

    private final List<ScanFilterLayer> scanFilterLayers = new ArrayList<>();
    private final List<ChunkSectionPos> pendingChunkSections = new ArrayList<>();
    private int currentChunkSection, chunkSectionsPerTick;
    private final Map<class_2248, Map<class_2338, BlockScanResult>> resultClusters = new HashMap<>();
    private final List<BlockScanResult> results = new ArrayList<>();

    private long renderStartTime;
    @Nullable private GpuBuffer timeUniformBuffer;

    // --------------------------------------------------------------------- //
    // ScanResultProvider

    @Override
    public void initialize(final class_1657 player, final Collection<class_1799> modules, final class_243 center, final float radius, final int scanTicks) {
        super.initialize(player, modules, center, radius, scanTicks);

        scanFilterLayers.clear();

        final IntObjectMap<List<Predicate<class_2680>>> filterByRadius = new IntObjectHashMap<>();
        for (final class_1799 stack : modules) {
            final Optional<ScannerModule> capability = ScannerModuleItem.getModule(stack);
            capability.ifPresent(module -> {
                if (module instanceof BlockScannerModule blockModule) {
                    final Predicate<class_2680> filter = blockModule.getFilter(stack);
                    final int localRadius = (int) Math.ceil(blockModule.adjustLocalRange(this.radius));
                    filterByRadius.computeIfAbsent(localRadius, r -> new ArrayList<>()).add(filter);
                }
            });
        }

        final IntList scanFilterKeys = new IntArrayList();
        scanFilterKeys.addAll(filterByRadius.keySet());
        scanFilterKeys.sort((a, b) -> -Integer.compare(a, b));

        if (!scanFilterKeys.isEmpty()) {
            this.radius = scanFilterKeys.getInt(0);
            for (final int r : scanFilterKeys) {
                scanFilterLayers.add(new ScanFilterLayer(r, filterByRadius.get(r)));
            }

            final class_2338 minBlockPos = class_2338.method_49638(center).method_10069(-this.radius, -this.radius, -this.radius);
            final class_2338 maxBlockPos = class_2338.method_49638(center).method_10069(this.radius, this.radius, this.radius);
            final class_1923 minChunkPos = new class_1923(minBlockPos);
            final class_1923 maxChunkPos = new class_1923(maxBlockPos);

            final int minChunkSectionIndex = Math.max(player.method_73183().method_31602(minBlockPos.method_10264()), 0);
            final int maxChunkSectionIndex = Math.min(player.method_73183().method_31602(maxBlockPos.method_10264()), player.method_73183().method_32890() - 1);

            for (int chunkSectionIndex = minChunkSectionIndex; chunkSectionIndex <= maxChunkSectionIndex; chunkSectionIndex++) {
                for (int chunkZ = minChunkPos.field_9180; chunkZ <= maxChunkPos.field_9180; chunkZ++) {
                    for (int chunkX = minChunkPos.field_9181; chunkX <= maxChunkPos.field_9181; chunkX++) {
                        final class_1923 chunkPos = new class_1923(chunkX, chunkZ);
                        final int chunkY = player.method_73183().method_31604(chunkSectionIndex);

                        final double dx = Math.min(
                            Math.abs(chunkPos.method_8326() - center.field_1352),
                            Math.abs(chunkPos.method_8327() - center.field_1352));
                        final double dz = Math.min(
                            Math.abs(chunkPos.method_8328() - center.field_1350),
                            Math.abs(chunkPos.method_8329() - center.field_1350));
                        final double dy = Math.min(
                            Math.abs(class_4076.method_32205(chunkY, 0) - center.field_1351),
                            Math.abs(class_4076.method_32205(chunkY, class_4076.field_33099) - center.field_1351));
                        final double squareDistToCenter = dx * dx + dy * dy + dz * dz;

                        if (squareDistToCenter > radius * radius) {
                            continue;
                        }

                        pendingChunkSections.add(new ChunkSectionPos(chunkX, chunkZ, chunkSectionIndex, squareDistToCenter));
                    }
                }
            }

            pendingChunkSections.sort(Comparator.comparingDouble(p -> p.squareDistToCenter));

            chunkSectionsPerTick = class_3532.method_15386(pendingChunkSections.size() / (float) scanTicks);
            this.currentChunkSection = 0;
        }
    }

    @Override
    public void computeScanResults() {
        final class_1937 level = player.method_73183();
        for (int i = 0; i < chunkSectionsPerTick; i++) {
            if (currentChunkSection >= pendingChunkSections.size()) {
                return;
            }

            final ChunkSectionPos chunkSectionPos = pendingChunkSections.get(currentChunkSection);
            currentChunkSection++;

            final int chunkX = chunkSectionPos.chunkX;
            final int chunkZ = chunkSectionPos.chunkZ;
            final int chunkSectionIndex = chunkSectionPos.chunkSectionIndex;

            final class_2791 chunk = level.method_8402(chunkX, chunkZ, class_2806.field_12803, false);
            if (chunk == null) {
                continue;
            }

            final class_2826[] sections = chunk.method_12006();
            final class_2826 section = sections[chunkSectionIndex];
            if (section == null || section.method_38292()) {
                continue;
            }

            final int bottomBlockY = class_4076.method_18688(chunk.method_31604(chunkSectionIndex));
            final class_2841<class_2680> palette = section.method_12265();
            final class_2338 origin = chunk.method_12004().method_8323().method_10069(0, bottomBlockY, 0);
            final int originX = origin.method_10263();
            final int originY = origin.method_10264();
            final int originZ = origin.method_10260();
            for (int index = 0; index < 16 * 16 * 16; index++) {
                final class_2680 state = palette.method_12331(index);
                final class_2248 block = state.method_26204();
                final Map<class_2338, BlockScanResult> clusters = resultClusters.computeIfAbsent(block, b -> new HashMap<>());
                if (clusters.size() > MAX_RESULTS_PER_BLOCK) {
                    continue;
                }

                if (IgnoredBlocks.contains(state)) {
                    continue;
                }

                final int x = index & 0xf;
                final int z = (index >> 4) & 0xf;
                final int y = (index >> 8) & 0xf;

                final int globalX = originX + x;
                final int globalY = originY + y;
                final int globalZ = originZ + z;

                final double squaredDistance = center.method_1028(globalX + 0.5, globalY + 0.5, globalZ + 0.5);

                outer:
                for (final ScanFilterLayer layer : scanFilterLayers) {
                    if (squaredDistance > layer.radius * layer.radius) {
                        break; // Filters radii only get smaller in the sorted filter list.
                    }

                    for (final Predicate<class_2680> filter : layer.filters) {
                        if (filter.test(state)) {
                            final class_2338 pos = new class_2338(globalX, globalY, globalZ);
                            if (!tryAddToCluster(clusters, pos)) {
                                final BlockScanResult result = new BlockScanResult(state.method_26204(), pos);
                                clusters.put(pos, result);
                                results.add(result);
                            }
                            break outer;
                        }
                    }
                }
            }
        }
    }

    @Override
    public void collectScanResults(final class_1922 level, final Consumer<ScanResult> callback) {
        for (final BlockScanResult result : results) {
            if (result.isRoot()) {
                result.bake(level);
                callback.accept(result);
            }
        }

        renderStartTime = System.currentTimeMillis();
    }

    @Override
    public void render(final ScanResultRenderContext context, final class_4597 bufferSource, final class_4587 poseStack, final class_4184 renderInfo, final float partialTicks, final List<ScanResult> results) {
        switch (context) {
            case WORLD -> renderBlocks(poseStack, results);
            case GUI -> renderBlockIcons(bufferSource, poseStack, renderInfo, results);
        }
    }

    @Override
    public void reset() {
        super.reset();
        scanFilterLayers.clear();
        currentChunkSection = chunkSectionsPerTick = 0;
        pendingChunkSections.clear();
        resultClusters.clear();
        results.clear();
    }

    // --------------------------------------------------------------------- //

    private void renderBlocks(final class_4587 poseStack, final List<ScanResult> results) {
        final class_276 target = class_310.method_1551().method_1522();
        final GpuBufferSlice transform = RenderSystem.getDynamicUniforms().method_71106(
            poseStack.method_23760().method_23761(), new Vector4f(1, 1, 1, 1), new Vector3f(), new Matrix4f());

        final float time = (System.currentTimeMillis() - renderStartTime) / 1000.0f;
        final GpuBuffer timeUniform = updateTimeUniform(time);

        final RenderSystem.class_5590 indices = RenderSystem.getSequentialBuffer(VertexFormat.class_5596.field_27382);

        try (RenderPass renderPass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
            () -> "Scannable block scan results",
            target.method_71639(),
            OptionalInt.empty(),
            target.field_1478 ? target.method_71640() : null,
            OptionalDouble.empty())) {
            renderPass.setPipeline(ScanPipelines.SCAN_RESULT);
            RenderSystem.bindDefaultUniforms(renderPass);
            renderPass.setUniform("DynamicTransforms", transform);
            renderPass.setUniform(ScanPipelines.SCAN_RESULT_UNIFORM, timeUniform);

            for (final ScanResult result : results) {
                final BlockScanResult blockResult = (BlockScanResult) result;
                if (blockResult.vertexBuffer == null || blockResult.indexCount <= 0) {
                    continue;
                }

                renderPass.setVertexBuffer(0, blockResult.vertexBuffer);
                renderPass.setIndexBuffer(indices.method_68274(blockResult.indexCount), indices.method_31924());
                renderPass.drawIndexed(0, 0, blockResult.indexCount, 1);
            }
        }
    }

    private GpuBuffer updateTimeUniform(final float time) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            final ByteBuffer data = Std140Builder.onStack(stack, TIME_UNIFORM_SIZE).putVec4(time, 0, 0, 0).get();
            if (timeUniformBuffer == null) {
                timeUniformBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "Scannable scan result uniforms",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    data);
            } else {
                RenderSystem.getDevice().createCommandEncoder().writeToBuffer(timeUniformBuffer.slice(), data);
            }
            return timeUniformBuffer;
        }
    }

    private void renderBlockIcons(final class_4597 bufferSource, final class_4587 poseStack, final class_4184 renderInfo, final List<ScanResult> results) {
        final class_243 lookVec = new class_243(renderInfo.method_19335());
        final class_243 viewerEyes = renderInfo.method_71156();
        final float yaw = renderInfo.method_19330();
        final float pitch = renderInfo.method_19329();
        final boolean showDistance = renderInfo.method_19331().method_5715();

        // Order results by distance to center of screen (deviation from look
        // vector) so that labels we're looking at are in front of others.
        results.sort(Comparator.comparing(result -> {
            final BlockScanResult blockResult = (BlockScanResult) result;
            final class_243 resultPos = blockResult.getPosition();
            final class_243 toResult = resultPos.method_1020(viewerEyes);
            return lookVec.method_1026(toResult.method_1029());
        }));

        for (final ScanResult result : results) {
            final BlockScanResult blockResult = (BlockScanResult) result;

            final class_243 resultPos = result.getPosition();
            final class_243 toResult = resultPos.method_1020(viewerEyes);
            final float lookDirDot = (float) lookVec.method_1026(toResult.method_1029());

            final class_2248 block = blockResult.block;
            final class_2561 label = block.method_9518();
            if (lookDirDot > 0.98f && !Strings.isNullOrEmpty(label.getString())) {
                final float distance = showDistance ? (float) resultPos.method_1020(viewerEyes).method_1033() : 0f;
                renderIconLabel(bufferSource, poseStack, yaw, pitch, lookVec, viewerEyes, distance, resultPos, API.ICON_INFO, label);
            }
        }
    }

    private boolean tryAddToCluster(final Map<class_2338, BlockScanResult> clusters, final class_2338 pos) {
        BlockScanResult root = null;
        root = tryAddToCluster(clusters, pos, pos.method_10078(), root);
        root = tryAddToCluster(clusters, pos, pos.method_10067(), root);
        root = tryAddToCluster(clusters, pos, pos.method_10095(), root);
        root = tryAddToCluster(clusters, pos, pos.method_10072(), root);
        root = tryAddToCluster(clusters, pos, pos.method_10084(), root);
        root = tryAddToCluster(clusters, pos, pos.method_10074(), root);
        return root != null;
    }

    @Nullable
    private BlockScanResult tryAddToCluster(final Map<class_2338, BlockScanResult> clusters, final class_2338 pos, final class_2338 clusterPos, @Nullable BlockScanResult root) {
        final BlockScanResult cluster = clusters.get(clusterPos);
        if (cluster == null) {
            return root;
        }

        if (root == null) {
            root = cluster.getRoot();
            root.add(pos);
            clusters.put(pos, root);
        } else {
            cluster.getRoot().setRoot(root);
        }

        return root;
    }

    private record ScanFilterLayer(int radius, List<Predicate<class_2680>> filters) {
    }

    private record ChunkSectionPos(int chunkX, int chunkZ, int chunkSectionIndex, double squareDistToCenter) {
    }

    // --------------------------------------------------------------------- //

    private static final class BlockScanResult implements ScanResult {
        private final class_2248 block;
        private class_238 bounds;
        @Nullable private BlockScanResult parent;
        private final Set<class_2338> blocks;
        private int color;
        @Nullable private GpuBuffer vertexBuffer;
        private int indexCount;

        BlockScanResult(final class_2248 block, final class_2338 pos) {
            this.block = block;
            bounds = new class_238(pos);
            blocks = new HashSet<>();
            blocks.add(pos);
        }

        void bake(final class_1922 level) {
            final class_2680 blockState = block.method_9564();

            color = blockState.method_26205(level, class_2338.method_49638(bounds.method_1005())).field_16011;

            final class_3610 fluidState = blockState.method_26227();
            if (!fluidState.method_15769()) {
                if (ClientConfig.fluidColors.containsKey(class_7923.field_41173.method_10221(fluidState.method_15772()))) {
                    color = ClientConfig.fluidColors.getInt(class_7923.field_41173.method_10221(fluidState.method_15772()));
                } else {
                    ClientConfig.fluidTagColors.forEach((k, v) -> {
                        final var tag = class_6862.method_40092(class_7924.field_41270, k);
                        if (fluidState.method_15767(tag)) {
                            color = v;
                        }
                    });
                }
            } else {
                if (ClientConfig.blockColors.containsKey(class_7923.field_41175.method_10221(blockState.method_26204()))) {
                    color = ClientConfig.blockColors.getInt(class_7923.field_41175.method_10221(blockState.method_26204()));
                } else {
                    ClientConfig.blockTagColors.forEach((k, v) -> {
                        final var tag = class_6862.method_40092(class_7924.field_41254, k);
                        if (blockState.method_26164(tag)) {
                            color = v;
                        }
                    });
                }
            }

            if (color == 0) { // E.g. glass.
                color = DEFAULT_COLOR;
            }

            final class_287 buffer = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1575);
            render(buffer, new class_4587());
            try (class_9801 mesh = buffer.method_60794()) {
                if (mesh == null) {
                    return;
                }

                indexCount = mesh.method_60822().comp_751();
                vertexBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "Scannable scan result geometry",
                    GpuBuffer.USAGE_VERTEX,
                    mesh.method_60818());
            }
        }

        boolean isRoot() {
            return parent == null;
        }

        BlockScanResult getRoot() {
            if (parent != null) {
                return parent.getRoot();
            }
            return this;
        }

        @SuppressWarnings("PMD.CompareObjectsWithEquals")
        void setRoot(final BlockScanResult root) {
            if (root == this) {
                return;
            }

            assert parent == null;

            root.bounds = root.bounds.method_991(bounds);
            root.blocks.addAll(blocks);
            blocks.clear();
            parent = root;
        }

        void add(final class_2338 pos) {
            assert parent == null : "Trying to add to non-root node.";
            bounds = bounds.method_991(new class_238(pos));
            blocks.add(pos);
        }

        void render(final class_4588 buffer, final class_4587 poseStack) {
            final var matrix = poseStack.method_23760().method_23761();

            final float colorNormalizer = 1 / 255f;
            final float r = ((color >> 16) & 0xFF) * colorNormalizer;
            final float g = ((color >> 8) & 0xFF) * colorNormalizer;
            final float b = (color & 0xFF) * colorNormalizer;

            final float sizeUvX = (float) (1.0 / bounds.method_17939());
            final float sizeUvY = (float) (1.0 / bounds.method_17940());
            final float sizeUvZ = (float) (1.0 / bounds.method_17941());
            for (final class_2338 cell : blocks) {
                if (!blocks.contains(cell.method_10069(-1, 0, 0))) {
                    final float x = cell.method_10263();
                    final float minY = cell.method_10264();
                    final float maxY = cell.method_10264() + 1;
                    final float minZ = cell.method_10260();
                    final float maxZ = cell.method_10260() + 1;
                    final float u0 = (minY - (float) bounds.field_1322) * sizeUvY;
                    final float u1 = u0 + sizeUvY;
                    final float v0 = (minZ - (float) bounds.field_1321) * sizeUvZ;
                    final float v1 = v0 + sizeUvZ;
                    buffer.method_22918(matrix, x, minY, minZ).method_22913(u0, v0).method_22915(r, g, b, 0.8f);
                    buffer.method_22918(matrix, x, minY, maxZ).method_22913(u0, v1).method_22915(r, g, b, 0.8f);
                    buffer.method_22918(matrix, x, maxY, maxZ).method_22913(u1, v1).method_22915(r, g, b, 0.8f);
                    buffer.method_22918(matrix, x, maxY, minZ).method_22913(u1, v0).method_22915(r, g, b, 0.8f);
                }
                if (!blocks.contains(cell.method_10069(1, 0, 0))) {
                    final float x = cell.method_10263() + 1;
                    final float minY = cell.method_10264();
                    final float maxY = cell.method_10264() + 1;
                    final float minZ = cell.method_10260();
                    final float maxZ = cell.method_10260() + 1;
                    final float u0 = (minY - (float) bounds.field_1322) * sizeUvY;
                    final float u1 = u0 + sizeUvY;
                    final float v0 = (minZ - (float) bounds.field_1321) * sizeUvZ;
                    final float v1 = v0 + sizeUvZ;
                    buffer.method_22918(matrix, x, minY, minZ).method_22913(u0, v0).method_22915(r, g, b, 0.8f);
                    buffer.method_22918(matrix, x, maxY, minZ).method_22913(u1, v0).method_22915(r, g, b, 0.8f);
                    buffer.method_22918(matrix, x, maxY, maxZ).method_22913(u1, v1).method_22915(r, g, b, 0.8f);
                    buffer.method_22918(matrix, x, minY, maxZ).method_22913(u0, v1).method_22915(r, g, b, 0.8f);
                }
                if (!blocks.contains(cell.method_10069(0, -1, 0))) {
                    final float y = cell.method_10264();
                    final float minX = cell.method_10263();
                    final float maxX = cell.method_10263() + 1;
                    final float minZ = cell.method_10260();
                    final float maxZ = cell.method_10260() + 1;
                    final float u0 = (minX - (float) bounds.field_1323) * sizeUvX;
                    final float u1 = u0 + sizeUvX;
                    final float v0 = (minZ - (float) bounds.field_1321) * sizeUvZ;
                    final float v1 = v0 + sizeUvZ;
                    buffer.method_22918(matrix, minX, y, minZ).method_22913(u0, v0).method_22915(r, g, b, 0.7f);
                    buffer.method_22918(matrix, maxX, y, minZ).method_22913(u1, v0).method_22915(r, g, b, 0.7f);
                    buffer.method_22918(matrix, maxX, y, maxZ).method_22913(u1, v1).method_22915(r, g, b, 0.7f);
                    buffer.method_22918(matrix, minX, y, maxZ).method_22913(u0, v1).method_22915(r, g, b, 0.7f);
                }
                if (!blocks.contains(cell.method_10069(0, 1, 0))) {
                    final float y = cell.method_10264() + 1;
                    final float minX = cell.method_10263();
                    final float maxX = cell.method_10263() + 1;
                    final float minZ = cell.method_10260();
                    final float maxZ = cell.method_10260() + 1;
                    final float u0 = (minX - (float) bounds.field_1323) * sizeUvX;
                    final float u1 = u0 + sizeUvX;
                    final float v0 = (minZ - (float) bounds.field_1321) * sizeUvZ;
                    final float v1 = v0 + sizeUvZ;
                    buffer.method_22918(matrix, minX, y, minZ).method_22913(u0, v0).method_22915(r, g, b, 1.0f);
                    buffer.method_22918(matrix, minX, y, maxZ).method_22913(u0, v1).method_22915(r, g, b, 1.0f);
                    buffer.method_22918(matrix, maxX, y, maxZ).method_22913(u1, v1).method_22915(r, g, b, 1.0f);
                    buffer.method_22918(matrix, maxX, y, minZ).method_22913(u1, v0).method_22915(r, g, b, 1.0f);
                }
                if (!blocks.contains(cell.method_10069(0, 0, -1))) {
                    final float z = cell.method_10260();
                    final float minX = cell.method_10263();
                    final float maxX = cell.method_10263() + 1;
                    final float minY = cell.method_10264();
                    final float maxY = cell.method_10264() + 1;
                    final float u0 = (minX - (float) bounds.field_1323) * sizeUvX;
                    final float u1 = u0 + sizeUvX;
                    final float v0 = (minY - (float) bounds.field_1322) * sizeUvY;
                    final float v1 = v0 + sizeUvY;
                    buffer.method_22918(matrix, minX, minY, z).method_22913(u0, v0).method_22915(r, g, b, 0.9f);
                    buffer.method_22918(matrix, minX, maxY, z).method_22913(u0, v1).method_22915(r, g, b, 0.9f);
                    buffer.method_22918(matrix, maxX, maxY, z).method_22913(u1, v1).method_22915(r, g, b, 0.9f);
                    buffer.method_22918(matrix, maxX, minY, z).method_22913(u1, v0).method_22915(r, g, b, 0.9f);
                }
                if (!blocks.contains(cell.method_10069(0, 0, 1))) {
                    final float z = cell.method_10260() + 1;
                    final float minX = cell.method_10263();
                    final float maxX = cell.method_10263() + 1;
                    final float minY = cell.method_10264();
                    final float maxY = cell.method_10264() + 1;
                    final float u0 = (minX - (float) bounds.field_1323) * sizeUvX;
                    final float u1 = u0 + sizeUvX;
                    final float v0 = (minY - (float) bounds.field_1322) * sizeUvY;
                    final float v1 = v0 + sizeUvY;
                    buffer.method_22918(matrix, minX, minY, z).method_22913(u0, v0).method_22915(r, g, b, 0.9f);
                    buffer.method_22918(matrix, maxX, minY, z).method_22913(u1, v0).method_22915(r, g, b, 0.9f);
                    buffer.method_22918(matrix, maxX, maxY, z).method_22913(u1, v1).method_22915(r, g, b, 0.9f);
                    buffer.method_22918(matrix, minX, maxY, z).method_22913(u0, v1).method_22915(r, g, b, 0.9f);
                }
            }
        }

        // --------------------------------------------------------------------- //
        // ScanResult

        @Nullable
        @Override
        public class_238 getRenderBounds() {
            return bounds;
        }

        @Override
        public class_243 getPosition() {
            return bounds.method_1005();
        }

        @Override
        public void close() {
            if (vertexBuffer != null) {
                vertexBuffer.close();
                vertexBuffer = null;
                indexCount = 0;
            }
        }
    }
}
