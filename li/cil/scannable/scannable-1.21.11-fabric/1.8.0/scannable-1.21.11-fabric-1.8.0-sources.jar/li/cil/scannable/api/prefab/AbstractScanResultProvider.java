/* SPDX-License-Identifier: MIT */

package li.cil.scannable.api.prefab;

import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.shader.ScanPipelines;
import net.minecraft.class_12247;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Quaternionf;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static li.cil.scannable.util.UnitConversion.toRadians;

/**
 * Helper base class for scan result providers, providing some common
 * functionality for drawing result information.
 */
public abstract class AbstractScanResultProvider implements ScanResultProvider {
    private static final class_1921 OVERLAY_LAYER = class_1921.method_75940("scan_result_overlay",
        class_12247.method_75927(ScanPipelines.SCAN_RESULT_OVERLAY).method_75938());
    private static final Map<class_2960, class_1921> TEXTURED_OVERLAY_LAYERS = new ConcurrentHashMap<>();

    protected class_1657 player;
    protected class_243 center;
    protected int radius;

    // --------------------------------------------------------------------- //
    // ScanResultProvider

    @Override
    public void initialize(final class_1657 player, final Collection<class_1799> modules, final class_243 center, final float radius, final int scanTicks) {
        this.player = player;
        this.center = center;
        this.radius = (int)radius;
    }

    @Override
    public void reset() {
        player = null;
        center = null;
        radius = 0;
    }

    // --------------------------------------------------------------------- //

    /**
     * Renders an icon with a label that is only shown when looked at. This is
     * what's used to render the entity labels for example.
     *
     * @param bufferSource    the buffer source to use for batch rendering.
     * @param poseStack       the pose stack for rendering.
     * @param yaw             the interpolated yaw of the viewer.
     * @param pitch           the interpolated pitch of the viewer.
     * @param lookVec         the look vector of the viewer.
     * @param viewerEyes      the eye position of the viewer.
     * @param displayDistance the distance to show in the label. Zero or negative to hide.
     * @param resultPos       the interpolated position of the result.
     * @param icon            the icon to display.
     * @param label           the label text. May be null.
     */
    protected static void renderIconLabel(final class_4597 bufferSource, final class_4587 poseStack, final float yaw, final float pitch, final class_243 lookVec, final class_243 viewerEyes, final float displayDistance, final class_243 resultPos, final class_2960 icon, @Nullable final class_2561 label) {
        final class_243 toResult = resultPos.method_1020(viewerEyes);
        final float distance = (float) toResult.method_1033();
        final float lookDirDot = (float) lookVec.method_1026(toResult.method_1029());
        final float sqLookDirDot = lookDirDot * lookDirDot;
        final float sq2LookDirDot = sqLookDirDot * sqLookDirDot;
        final float focusScale = class_3532.method_15363(sq2LookDirDot * sq2LookDirDot + 0.005f, 0.5f, 1f);
        final float scale = distance * focusScale * 0.005f;

        poseStack.method_22903();
        poseStack.method_22904(resultPos.field_1352, resultPos.field_1351, resultPos.field_1350);
        poseStack.method_22907(new Quaternionf().rotationY(toRadians(-yaw)));
        poseStack.method_22907(new Quaternionf().rotationX(toRadians(pitch)));
        poseStack.method_22905(-scale, -scale, scale);

        if (lookDirDot > 0.999f && label != null) {
            final class_2561 text;
            if (displayDistance > 0) {
                text = withDistance(label, class_3532.method_15386(displayDistance));
            } else {
                text = label;
            }

            final class_327 font = class_310.method_1551().field_1772;
            final int width = font.method_27525(text) + 16;

            poseStack.method_22903();
            poseStack.method_46416(width / 2f, 0, 0);

            drawQuad(bufferSource.method_73477(getRenderLayer()), poseStack, width, font.field_2000 + 5, 0, 0, 0, 0.6f);

            poseStack.method_22909();
            font.method_27522(text, 12, -4, 0xFFFFFFFF, true, poseStack.method_23760().method_23761(), bufferSource, class_327.class_6415.field_33994, 0, 0xf000f0);
            // HACK This is a workaround for text shadow rendering on top of main text in 1.20.  Can't figure out why.
            font.method_27522(text, 12, -4, 0xFFFFFFFF, false, poseStack.method_23760().method_23761(), bufferSource, class_327.class_6415.field_33994, 0, 0xf000f0);
        }

        drawQuad(bufferSource.method_73477(getRenderLayer(icon)), poseStack, 16, 16);

        poseStack.method_22909();
    }

    // --------------------------------------------------------------------- //
    // Drawing simple primitives in an existing buffer.

    protected static void drawQuad(final class_4588 buffer, final class_4587 poseStack, final float width, final float height) {
        drawQuad(buffer, poseStack, width, height, 1, 1, 1, 1);
    }

    protected static void drawQuad(final class_4588 buffer, final class_4587 poseStack, final float width, final float height, final float r, final float g, final float b, final float a) {
        final var matrix = poseStack.method_23760().method_23761();
        buffer.method_22918(matrix, -width * 0.5f, height * 0.5f, 0).method_22915(r, g, b, a).method_22913(0, 1f);
        buffer.method_22918(matrix, width * 0.5f, height * 0.5f, 0).method_22915(r, g, b, a).method_22913(1f, 1f);
        buffer.method_22918(matrix, width * 0.5f, -height * 0.5f, 0).method_22915(r, g, b, a).method_22913(1f, 0);
        buffer.method_22918(matrix, -width * 0.5f, -height * 0.5f, 0).method_22915(r, g, b, a).method_22913(0, 0);
    }

    // --------------------------------------------------------------------- //
    // Simple render layers for result rendering.

    protected static class_1921 getRenderLayer() {
        return OVERLAY_LAYER;
    }

    protected static class_1921 getRenderLayer(final class_2960 textureLocation) {
        return TEXTURED_OVERLAY_LAYERS.computeIfAbsent(textureLocation, location ->
            class_1921.method_75940("scan_result_overlay_textured",
                class_12247.method_75927(ScanPipelines.SCAN_RESULT_OVERLAY_TEXTURED)
                    .method_75934("Sampler0", location)
                    .method_75938()));
    }

    // --------------------------------------------------------------------- //

    private static class_2561 withDistance(final class_2561 caption, final float distance) {
        return class_2561.method_43469("gui.scannable.overlay.distance", caption, class_3532.method_15386(distance));
    }
}
