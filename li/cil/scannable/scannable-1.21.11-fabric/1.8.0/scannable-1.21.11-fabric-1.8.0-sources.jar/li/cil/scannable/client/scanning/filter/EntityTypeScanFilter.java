/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1299;

public record EntityTypeScanFilter(class_1299<?> entityType) implements Predicate<class_1297> {
    @Override
    public boolean test(final class_1297 entity) {
        return Objects.equals(entityType, entity.method_5864());
    }
}
