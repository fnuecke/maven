/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.fabric;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.scannable.api.API;
import li.cil.scannable.client.ScanManager;
import li.cil.scannable.client.gui.ConfigurableBlockScannerModuleContainerScreen;
import li.cil.scannable.client.gui.ConfigurableEntityScannerModuleContainerScreen;
import li.cil.scannable.client.gui.ScannerContainerScreen;
import li.cil.scannable.client.renderer.OverlayRenderer;
import li.cil.scannable.client.renderer.ScannerRenderer;
import li.cil.scannable.common.container.Containers;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3929;
import org.joml.Matrix4f;

public final class ClientSetupFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_3929.method_17542(Containers.SCANNER_CONTAINER.get(), ScannerContainerScreen::new);
        class_3929.method_17542(Containers.BLOCK_MODULE_CONTAINER.get(), ConfigurableBlockScannerModuleContainerScreen::new);
        class_3929.method_17542(Containers.ENTITY_MODULE_CONTAINER.get(), ConfigurableEntityScannerModuleContainerScreen::new);

        ClientTickEvents.END_CLIENT_TICK.register(instance -> ScanManager.tick());

        WorldRenderEvents.END_MAIN.register(context -> {
            final class_310 mc = class_310.method_1551();
            final Matrix4f viewMatrix = new Matrix4f(RenderSystem.getModelViewMatrix());
            final float partialTick = mc.method_61966().method_60637(false);
            final Matrix4f projectionMatrix = mc.field_1773.method_22973(
                mc.field_1773.method_3196(mc.field_1773.method_19418(), partialTick, true));

            ScannerRenderer.render(viewMatrix, projectionMatrix);

            ScanManager.setMatrices(viewMatrix, projectionMatrix);
            ScanManager.renderLevel(partialTick);
        });

        HudElementRegistry.addLast(class_2960.method_60655(API.MOD_ID, "scanner_results"),
            (graphics, tickCounter) -> {
                final float partialTick = tickCounter.method_60637(false);
                ScanManager.renderGui(partialTick);
                OverlayRenderer.render(graphics, partialTick);
            });
    }
}
