/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item.fabric;

import li.cil.scannable.api.fabric.Lookups;
import li.cil.scannable.api.scanning.ScannerModule;
import net.minecraft.class_1799;
import java.util.Optional;

public final class ScannerModuleItemImpl {
    public static Optional<ScannerModule> getModule(final class_1799 stack) {
        return Optional.ofNullable(Lookups.SCANNER_MODULE.find(stack, null));
    }
}
