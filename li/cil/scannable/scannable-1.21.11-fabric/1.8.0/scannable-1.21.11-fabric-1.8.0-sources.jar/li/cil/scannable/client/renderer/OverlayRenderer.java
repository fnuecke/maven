/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import li.cil.scannable.api.API;
import li.cil.scannable.client.shader.ScanPipelines;
import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.item.ScannerItem;
import net.minecraft.class_11231;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9848;
import org.joml.Matrix3x2f;

public final class OverlayRenderer {
    private static final class_2960 PROGRESS = class_2960.method_60655(API.MOD_ID, "textures/gui/overlay/scanner_progress.png");
    private static final int PROGRESS_SIZE = 64;
    private static final int PROGRESS_COLOR = class_9848.method_61318(0.66f, 0.66f, 0.8f, 0.93f);

    public static void render(final class_332 graphics, final float partialTick) {
        final class_310 mc = class_310.method_1551();
        final class_1657 player = mc.field_1724;
        if (player == null) {
            return;
        }

        final class_1799 stack = player.method_6030();
        if (stack.method_7960()) {
            return;
        }

        if (!ScannerItem.isScanner(stack)) {
            return;
        }

        final int total = stack.method_7935(player);
        final int remaining = player.method_6014();

        final float progress = class_3532.method_15363(1 - (remaining - partialTick) / total, 0, 1);

        final int screenWidth = mc.method_22683().method_4486();
        final int screenHeight = mc.method_22683().method_4502();

        final int midX = screenWidth / 2;
        final int midY = screenHeight / 2;

        final var texture = mc.method_1531().method_4619(PROGRESS);
        graphics.field_59826.method_70919(new ScannerProgressRenderState(
            ScanPipelines.SCANNER_PROGRESS,
            class_11231.method_70900(texture.method_71659(), RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST)),
            new Matrix3x2f(graphics.method_51448()),
            midX, midY,
            PROGRESS_SIZE,
            progress,
            PROGRESS_COLOR,
            null));

        final class_2561 label = Strings.progress(class_3532.method_15375(progress * 100));
        graphics.method_51439(mc.field_1772, label, midX + PROGRESS_SIZE / 2 + 12, midY - mc.field_1772.field_2000 / 2, 0xCCAACCEE, true);
    }

    private OverlayRenderer() {
    }
}
