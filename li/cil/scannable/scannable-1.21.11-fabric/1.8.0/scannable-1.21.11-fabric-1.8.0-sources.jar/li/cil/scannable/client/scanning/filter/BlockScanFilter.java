/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import java.util.function.Predicate;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public record BlockScanFilter(class_2248 block) implements Predicate<class_2680> {
    @Override
    public boolean test(final class_2680 state) {
        return block == state.method_26204();
    }
}
