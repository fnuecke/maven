/* SPDX-License-Identifier: MIT */

package li.cil.scannable.mixin.fabric.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.function.BiConsumer;
import net.minecraft.class_10405;
import net.minecraft.class_10411;
import net.minecraft.class_2960;
import net.minecraft.class_4915;

@Mixin(class_4915.class)
public interface ItemModelGeneratorAccessor {
    @Accessor("modelOutput")
    BiConsumer<class_2960, class_10411> getModelOutput();

    @Accessor("itemModelOutput")
    class_10405 getItemModelOutput();
}
