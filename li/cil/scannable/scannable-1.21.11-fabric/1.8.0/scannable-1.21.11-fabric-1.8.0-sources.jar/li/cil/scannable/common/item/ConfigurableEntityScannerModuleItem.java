/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item;

import dev.architectury.registry.menu.MenuRegistry;
import li.cil.scannable.common.config.Constants;
import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.container.EntityModuleContainerMenu;
import li.cil.scannable.common.scanning.ConfigurableEntityScannerModule;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public final class ConfigurableEntityScannerModuleItem extends ScannerModuleItem {
    public static boolean isLocked(final class_1799 stack) {
        return stack.method_58695(ModDataComponents.LOCKED.get(), false);
    }

    public static List<class_1299<?>> getEntityTypes(final class_1799 stack) {
        final List<class_2960> ids = getEntityTypeIds(stack);
        if (ids.isEmpty()) {
            return Collections.emptyList();
        }

        final List<class_1299<?>> result = new ArrayList<>(ids.size());
        for (final class_2960 id : ids) {
            class_1299.method_5898(id.toString()).ifPresent(result::add);
        }

        return result;
    }

    private static boolean addEntityType(final class_1799 stack, final class_1299<?> entityType) {
        final Optional<class_5321<class_1299<?>>> registryName = class_7923.field_41177.method_29113(entityType);
        if (registryName.isEmpty()) {
            return false;
        }

        if (isLocked(stack)) {
            return false;
        }

        final class_2960 id = registryName.get().method_29177();
        final List<class_2960> ids = new ArrayList<>(getEntityTypeIds(stack));
        if (ids.contains(id)) {
            return true;
        }
        if (ids.size() >= Constants.CONFIGURABLE_MODULE_SLOTS) {
            return false;
        }

        ids.add(id);
        setEntityTypeIds(stack, ids);
        return true;
    }

    public static void setEntityTypeAt(final class_1799 stack, final int index, final class_1299<?> entityType) {
        if (index < 0 || index >= Constants.CONFIGURABLE_MODULE_SLOTS) {
            return;
        }

        final Optional<class_5321<class_1299<?>>> registryName = class_7923.field_41177.method_29113(entityType);
        if (registryName.isEmpty()) {
            return;
        }

        if (isLocked(stack)) {
            return;
        }

        final class_2960 id = registryName.get().method_29177();
        final List<class_2960> ids = new ArrayList<>(getEntityTypeIds(stack));
        final int oldIndex = ids.indexOf(id);
        if (oldIndex == index) {
            return;
        }

        if (index >= ids.size()) {
            ids.add(id);
        } else {
            ids.set(index, id);
        }

        if (oldIndex >= 0) {
            ids.remove(oldIndex);
        }

        setEntityTypeIds(stack, ids);
    }

    public static void removeEntityTypeAt(final class_1799 stack, final int index) {
        if (index < 0 || index >= Constants.CONFIGURABLE_MODULE_SLOTS) {
            return;
        }

        if (isLocked(stack)) {
            return;
        }

        final List<class_2960> ids = new ArrayList<>(getEntityTypeIds(stack));
        if (index < ids.size()) {
            ids.remove(index);
            setEntityTypeIds(stack, ids);
        }
    }

    // --------------------------------------------------------------------- //

    private static List<class_2960> getEntityTypeIds(final class_1799 stack) {
        return stack.method_58695(ModDataComponents.ENTITY_TYPES.get(), Collections.emptyList());
    }

    private static void setEntityTypeIds(final class_1799 stack, final List<class_2960> ids) {
        stack.method_57379(ModDataComponents.ENTITY_TYPES.get(), List.copyOf(ids));
    }

    // --------------------------------------------------------------------- //

    public ConfigurableEntityScannerModuleItem(final class_1793 properties) {
        super(properties, ConfigurableEntityScannerModule.INSTANCE);
    }

    // --------------------------------------------------------------------- //
    // Item

    @Override
    public void method_67187(final class_1799 stack, final class_1792.class_9635 context, final class_10712 display, final Consumer<class_2561> tooltip, final class_1836 flag) {
        super.method_67187(stack, context, display, tooltip, flag);

        final List<class_1299<?>> entities = getEntityTypes(stack);
        if (!entities.isEmpty()) {
            tooltip.accept(Strings.TOOLTIP_ENTITIES_LIST_CAPTION);
            entities.forEach(e -> tooltip.accept(Strings.listItem(e.method_5897())));
        }
    }

    @Override
    public class_1269 method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        final class_1799 stack = player.method_5998(hand);
        if (player.method_5715()) {
            return class_1269.field_5811;
        }

        if (!level.method_8608() && player instanceof class_3222 serverPlayer) {
            MenuRegistry.openExtendedMenu(serverPlayer, new class_3908() {
                @Override
                public class_2561 method_5476() {
                    return stack.method_7964();
                }

                @Override
                public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                    return new EntityModuleContainerMenu(id, inventory, hand);
                }
            }, buffer -> buffer.method_10817(hand));
        }

        return class_1269.field_5812;
    }

    @Override
    public class_1269 method_7847(final class_1799 stack, final class_1657 player, final class_1309 target, final class_1268 hand) {
        // NOT adding to `stack` parameter, because that's a copy in creative mode.
        if (addEntityType(player.method_5998(hand), target.method_5864())) {
            player.method_6104(hand);
            player.method_31548().method_5431();
        } else {
            if (!player.method_73183().method_8608() && !ConfigurableEntityScannerModuleItem.isLocked(stack)) {
                player.method_7353(Strings.MESSAGE_NO_FREE_SLOTS, true);
            }
        }

        // Always succeed to prevent opening item UI.
        return class_1269.field_5812;
    }
}
