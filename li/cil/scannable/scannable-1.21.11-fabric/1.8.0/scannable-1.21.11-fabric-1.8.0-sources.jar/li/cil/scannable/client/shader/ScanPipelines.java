/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.shader;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import li.cil.scannable.api.API;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_290;
import net.minecraft.class_2960;

public final class ScanPipelines {
    // See scan_effect.fsh.
    public static final String SCAN_EFFECT_UNIFORM = "ScanEffect";
    public static final String SCAN_EFFECT_DEPTH_SAMPLER = "depthTexSampler";

    // See scan_result.fsh.
    public static final String SCAN_RESULT_UNIFORM = "ScanResult";

    // Matches vanilla.
    private static final String DYNAMIC_TRANSFORMS_UNIFORM = "DynamicTransforms";
    private static final String PROJECTION_UNIFORM = "Projection";

    // --------------------------------------------------------------------- //

    public static final RenderPipeline SCAN_EFFECT = RenderPipeline.builder(class_10799.field_56838)
        .withLocation(id("pipeline/scan_effect"))
        .withVertexShader(id("core/scan_effect"))
        .withFragmentShader(id("core/scan_effect"))
        .withSampler(SCAN_EFFECT_DEPTH_SAMPLER)
        .withUniform(SCAN_EFFECT_UNIFORM, class_10789.field_60031)
        .withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379)
        .withBlend(BlendFunction.ADDITIVE)
        .withCull(false)
        .build();

    public static final RenderPipeline SCAN_RESULT = RenderPipeline.builder()
        .withLocation(id("pipeline/scan_result"))
        .withVertexShader(id("core/scan_result"))
        .withFragmentShader(id("core/scan_result"))
        .withUniform(DYNAMIC_TRANSFORMS_UNIFORM, class_10789.field_60031)
        .withUniform(PROJECTION_UNIFORM, class_10789.field_60031)
        .withUniform(SCAN_RESULT_UNIFORM, class_10789.field_60031)
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .withBlend(BlendFunction.ADDITIVE)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .withCull(false)
        .build();

    public static final RenderPipeline SCAN_RESULT_OVERLAY = RenderPipeline.builder()
        .withLocation(id("pipeline/scan_result_overlay"))
        .withVertexShader("core/position_color")
        .withFragmentShader("core/position_color")
        .withUniform(DYNAMIC_TRANSFORMS_UNIFORM, class_10789.field_60031)
        .withUniform(PROJECTION_UNIFORM, class_10789.field_60031)
        .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
        .withBlend(BlendFunction.TRANSLUCENT)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .build();

    public static final RenderPipeline SCAN_RESULT_OVERLAY_TEXTURED = RenderPipeline.builder()
        .withLocation(id("pipeline/scan_result_overlay_textured"))
        .withVertexShader("core/position_tex_color")
        .withFragmentShader("core/position_tex_color")
        .withUniform(DYNAMIC_TRANSFORMS_UNIFORM, class_10789.field_60031)
        .withUniform(PROJECTION_UNIFORM, class_10789.field_60031)
        .withSampler("Sampler0")
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .withBlend(BlendFunction.TRANSLUCENT)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .build();

    public static final RenderPipeline SCANNER_PROGRESS = RenderPipeline.builder()
        .withLocation(id("pipeline/scanner_progress"))
        .withVertexShader("core/position_tex_color")
        .withFragmentShader("core/position_tex_color")
        .withUniform(DYNAMIC_TRANSFORMS_UNIFORM, class_10789.field_60031)
        .withUniform(PROJECTION_UNIFORM, class_10789.field_60031)
        .withSampler("Sampler0")
        .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
        .withBlend(BlendFunction.TRANSLUCENT)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .withCull(false)
        .build();

    // --------------------------------------------------------------------- //

    private static class_2960 id(final String path) {
        return class_2960.method_60655(API.MOD_ID, path);
    }

    private ScanPipelines() {
    }
}
