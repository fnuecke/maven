/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item;

import li.cil.scannable.util.TooltipUtils;
import net.minecraft.class_10712;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import java.util.function.Consumer;

public class ModItem extends class_1792 {
    protected ModItem(final class_1793 properties) {
        super(properties);
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("deprecation")
    @Override
    public void method_67187(final class_1799 stack, final class_1792.class_9635 context, final class_10712 display, final Consumer<class_2561> tooltip, final class_1836 flag) {
        super.method_67187(stack, context, display, tooltip, flag);
        TooltipUtils.tryAddDescription(stack, tooltip);
    }
}
