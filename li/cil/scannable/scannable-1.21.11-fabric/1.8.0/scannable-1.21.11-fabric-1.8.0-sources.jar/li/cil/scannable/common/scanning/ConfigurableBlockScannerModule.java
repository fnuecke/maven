/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.BlockScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.BlockCacheScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.item.ConfigurableBlockScannerModuleItem;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import java.util.List;
import java.util.function.Predicate;

public enum ConfigurableBlockScannerModule implements BlockScannerModule {
    INSTANCE;

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleBlock;
    }

    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.blocks();
    }

    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleBlock;
    }

    @Override
    public Predicate<class_2680> getFilter(final class_1799 module) {
        final List<class_2248> blocks = ConfigurableBlockScannerModuleItem.getBlocks(module);
        return new BlockCacheScanFilter(blocks);
    }
}
