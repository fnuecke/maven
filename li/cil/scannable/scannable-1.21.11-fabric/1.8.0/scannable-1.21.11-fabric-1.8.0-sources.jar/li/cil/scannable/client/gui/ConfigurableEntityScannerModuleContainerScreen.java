/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.gui;

import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.container.EntityModuleContainerMenu;
import li.cil.scannable.common.item.ConfigurableEntityScannerModuleItem;
import li.cil.scannable.common.network.Network;
import li.cil.scannable.common.network.message.SetConfiguredModuleItemAtMessage;
import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3730;
import net.minecraft.class_4048;
import net.minecraft.class_7923;
import net.minecraft.class_897;
import net.minecraft.class_898;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static li.cil.scannable.util.UnitConversion.toRadians;

public class ConfigurableEntityScannerModuleContainerScreen extends AbstractConfigurableScannerModuleContainerScreen<EntityModuleContainerMenu, class_1299<?>> {
    private static final Map<class_1299<?>, class_1297> RENDER_ENTITIES = new HashMap<>();

    private static final float PREVIEW_TILT = -20;
    private static final float PREVIEW_YAW = -30;

    public ConfigurableEntityScannerModuleContainerScreen(final EntityModuleContainerMenu container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title, Strings.GUI_ENTITIES_LIST_CAPTION);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected List<class_1299<?>> getConfiguredItems(final class_1799 stack) {
        return ConfigurableEntityScannerModuleItem.getEntityTypes(stack);
    }

    @Override
    protected class_2561 getItemName(final class_1299<?> entityType) {
        return entityType.method_5897();
    }

    @Override
    protected void renderConfiguredItem(final class_332 graphics, final class_1299<?> entityType, final int x, final int y) {
        renderEntity(graphics, x, y, entityType);
    }

    @Override
    protected void configureItemAt(final class_1799 stack, final int slot, final class_1799 value) {
        if (value.method_7909() instanceof class_1826) {
            final class_1299<?> entityType = ((class_1826) value.method_7909()).method_8015(value);
            class_7923.field_41177.method_29113(entityType).ifPresent(entityTypeResourceKey ->
                    Network.sendToServer(new SetConfiguredModuleItemAtMessage(field_2797.field_7763, slot, entityTypeResourceKey.method_29177())));
        }
    }

    private void renderEntity(final class_332 graphics, final int x, final int y, final class_1299<?> entityType) {
        final class_1297 entity = getRenderEntity(entityType);
        if (entity == null) {
            return;
        }

        entity.method_51502(field_2797.getPlayer().method_73183());

        final class_10017 renderState = extractRenderState(entity);
        if (renderState == null) {
            return;
        }

        final class_4048 bounds = entityType.method_18386();
        final float size = Math.max(bounds.comp_2185(), bounds.comp_2186());
        final float scale = 11.0f / size;

        final Quaternionf cameraOrientation = new Quaternionf().rotationX(toRadians(PREVIEW_TILT));
        cameraOrientation.mul(new Quaternionf().rotationY(toRadians(PREVIEW_YAW)));

        final Quaternionf rotation = new Quaternionf().rotationZ(toRadians(180));
        rotation.mul(cameraOrientation);

        final Vector3f translation = new Vector3f(0, renderState.field_53330 / 2.0f, 0);

        final int screenX = field_2776 + x;
        final int screenY = field_2800 + y;

        graphics.method_70856(renderState, scale, translation, rotation, cameraOrientation,
            screenX, screenY, screenX + 16, screenY + 16);
    }

    @Nullable
    private static class_10017 extractRenderState(final class_1297 entity) {
        final class_898 dispatcher = class_310.method_1551().method_1561();
        final class_897<? super class_1297, ?> renderer = dispatcher.method_3953(entity);
        final class_10017 renderState = renderer.method_62425(entity, 1.0f);
        renderState.field_61820 = 0xf000f0;
        renderState.field_61823.clear();
        renderState.field_61821 = class_10017.field_61824;

        if (renderState instanceof final class_10042 livingRenderState) {
            livingRenderState.field_53446 = 180;
            livingRenderState.field_53447 = 0;
            livingRenderState.field_53448 = 0;
        }

        return renderState;
    }

    @Nullable
    private class_1297 getRenderEntity(final class_1299<?> entityType) {
        return RENDER_ENTITIES.computeIfAbsent(entityType, t -> t.method_5883(field_2797.getPlayer().method_73183(), class_3730.field_52444));
    }
}
