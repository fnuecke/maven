/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.EntityScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.FriendlyEntityScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import java.util.function.Predicate;

public enum FriendlyEntityScannerModule implements EntityScannerModule {
    INSTANCE;

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleAnimal;
    }

    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleAnimal;
    }

    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.entities();
    }

    @Override
    public Predicate<class_1297> getFilter(final class_1799 module) {
        return FriendlyEntityScanFilter.INSTANCE;
    }
}
