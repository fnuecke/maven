/* SPDX-License-Identifier: MIT */

package li.cil.scannable.api.scanning;

import li.cil.scannable.api.API;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Specialized interface for using the built-in entity scan result provider.
 * <p>
 * When implementing this interface, return the result provider implementation
 * obtained from the provider registry like so:
 * <pre>
 * RegistryManager.ACTIVE.getRegistry(ScanResultProvider.class).getValue(API.SCAN_RESULT_PROVIDER_ENTITIES);
 * </pre>
 */
public interface EntityScannerModule extends ScannerModule {
    /**
     * Modifies the local range of the scan. Modules can boost or reduce the range
     * for only their own filtering via {@link #getFilter(class_1799)}.
     *
     * @param range the input range.
     * @return the adjusted range.
     */
    default float adjustLocalRange(final float range) {
        return range;
    }

    /**
     * The icon to display for the specified entity if it is included in a scan result.
     * <p>
     * Only called if the entity was matched by the filter returned by {@link #getFilter(class_1799)}.
     *
     * @param entity the entity to get the icon for.
     * @return the icon to use; if an {@link Optional#empty()} is returned {@link API#ICON_INFO} is used.
     */
    default Optional<class_2960> getIcon(final class_1297 entity) {
        return Optional.empty();
    }

    /**
     * Get a filter that will be used for testing whether entities should be included
     * in the scan result.
     *
     * @param module the module to get the filter for.
     * @return the filter to use.
     */
    Predicate<class_1297> getFilter(final class_1799 module);
}
