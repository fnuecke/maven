/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1297;

public record EntityListScanFilter(List<Predicate<class_1297>> filters) implements Predicate<class_1297> {
    @Override
    public boolean test(final class_1297 entity) {
        return filters.stream().anyMatch(f -> f.test(entity));
    }
}
