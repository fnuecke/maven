/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.scannable.api.API;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.common.scanning.*;
import li.cil.scannable.util.RegistryUtils;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import java.util.function.Function;

public final class Items {
    private static final DeferredRegister<class_1792> ITEMS = RegistryUtils.get(class_7924.field_41197);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1792> SCANNER = register("scanner", ScannerItem::new);

    public static final RegistrySupplier<class_1792> BLANK_MODULE = register("blank_module", ModItem::new);
    public static final RegistrySupplier<class_1792> RANGE_MODULE = registerModule("range_module", RangeScannerModule.INSTANCE);
    public static final RegistrySupplier<class_1792> ENTITY_MODULE = register("entity_module", ConfigurableEntityScannerModuleItem::new);
    public static final RegistrySupplier<class_1792> FRIENDLY_ENTITY_MODULE = registerModule("friendly_entity_module", FriendlyEntityScannerModule.INSTANCE);
    public static final RegistrySupplier<class_1792> HOSTILE_ENTITY_MODULE = registerModule("hostile_entity_module", HostileEntityScannerModule.INSTANCE);
    public static final RegistrySupplier<class_1792> BLOCK_MODULE = register("block_module", ConfigurableBlockScannerModuleItem::new);
    public static final RegistrySupplier<class_1792> COMMON_ORES_MODULE = registerModule("common_ores_module", CommonOresBlockScannerModule.INSTANCE);
    public static final RegistrySupplier<class_1792> RARE_ORES_MODULE = registerModule("rare_ores_module", RareOresBlockScannerModule.INSTANCE);
    public static final RegistrySupplier<class_1792> FLUID_MODULE = registerModule("fluid_module", FluidBlockScannerModule.INSTANCE);
    public static final RegistrySupplier<class_1792> CHEST_MODULE = registerModule("chest_module", ChestScannerModule.INSTANCE);

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    // --------------------------------------------------------------------- //

    private static RegistrySupplier<class_1792> registerModule(final String name, final ScannerModule module) {
        return register(name, properties -> new ScannerModuleItem(properties, module));
    }

    private static RegistrySupplier<class_1792> register(final String name, final Function<class_1792.class_1793, class_1792> factory) {
        return ITEMS.register(name, () -> factory.apply(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(API.MOD_ID, name)))));
    }

    private Items() {
    }
}
