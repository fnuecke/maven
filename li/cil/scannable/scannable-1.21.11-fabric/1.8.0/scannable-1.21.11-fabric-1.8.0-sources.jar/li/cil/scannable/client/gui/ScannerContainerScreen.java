/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.gui;

import li.cil.scannable.api.API;
import li.cil.scannable.common.container.ScannerContainerMenu;
import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import javax.annotation.Nullable;

public class ScannerContainerScreen extends class_465<ScannerContainerMenu> {
    private static final class_2960 BACKGROUND = class_2960.method_60655(API.MOD_ID, "textures/gui/container/scanner.png");
    private static final class_2561 SCANNER_MODULES_TEXT = class_2561.method_43471("gui.scannable.scanner.active_modules");
    private static final class_2561 SCANNER_MODULES_TOOLTIP = class_2561.method_43471("gui.scannable.scanner.active_modules.desc");
    private static final class_2561 SCANNER_MODULES_INACTIVE_TEXT = class_2561.method_43471("gui.scannable.scanner.inactive_modules");
    private static final class_2561 SCANNER_MODULES_INACTIVE_TOOLTIP = class_2561.method_43471("gui.scannable.scanner.inactive_modules.desc");

    // --------------------------------------------------------------------- //

    public ScannerContainerScreen(final ScannerContainerMenu container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title);
        field_2779 = 159;
        field_25269 = 8;
        field_25270 = 65;
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        if (method_2378(8, 23, field_22793.method_27525(SCANNER_MODULES_TEXT), field_22793.field_2000, mouseX, mouseY)) {
            graphics.method_51438(field_22793, SCANNER_MODULES_TOOLTIP, mouseX, mouseY);
        }
        if (method_2378(8, 49, field_22793.method_27525(SCANNER_MODULES_INACTIVE_TEXT), field_22793.field_2000, mouseX, mouseY)) {
            graphics.method_51438(field_22793, SCANNER_MODULES_INACTIVE_TOOLTIP, mouseX, mouseY);
        }

        method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2388(final class_332 graphics, final int mouseX, final int mouseY) {
        super.method_2388(graphics, mouseX, mouseY);

        graphics.method_51439(field_22793, SCANNER_MODULES_TEXT, 8, 23, 0x404040, false);
        graphics.method_51439(field_22793, SCANNER_MODULES_INACTIVE_TEXT, 8, 49, 0x404040, false);
    }

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        final int x = (field_22789 - field_2792) / 2;
        final int y = (field_22790 - field_2779) / 2;
        graphics.method_25290(class_10799.field_56883, BACKGROUND, x, y, 0, 0, field_2792, field_2779, 256, 256);
    }

    @Override
    protected void method_2383(@Nullable final class_1735 slot, final int slotId, final int mouseButton, final class_1713 type) {
        if (slot != null) {
            final class_1799 scannerItemStack = field_2797.getPlayer().method_5998(field_2797.getHand());
            if (slot.method_7677() == scannerItemStack) {
                return;
            }
            if (type == class_1713.field_7791 && field_2797.getPlayer().method_31548().method_5438(mouseButton) == scannerItemStack) {
                return;
            }
        }

        //noinspection ConstantConditions Missing nullable annotation, base method tests for null.
        super.method_2383(slot, slotId, mouseButton, type);
    }
}
