/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_7923;

public final class BlockCacheScanFilter implements Predicate<class_2680> {
    private final Collection<class_2248> blocks;

    public BlockCacheScanFilter(final Collection<Predicate<class_2680>> filters) {
        blocks = buildCache(filters);
    }

    public BlockCacheScanFilter(final List<class_2248> blocks) {
        this.blocks = new HashSet<>(blocks);
    }

    @Override
    public boolean test(final class_2680 state) {
        return blocks.contains(state.method_26204());
    }

    private static Collection<class_2248> buildCache(final Collection<Predicate<class_2680>> filters) {
        final Set<class_2248> cache = new HashSet<>();
        class_7923.field_41175.forEach(block -> {
            final class_2680 blockState = block.method_9564();
            if (filters.stream().anyMatch(f -> f.test(blockState))) {
                cache.add(blockState.method_26204());
            }
        });
        return cache;
    }
}
