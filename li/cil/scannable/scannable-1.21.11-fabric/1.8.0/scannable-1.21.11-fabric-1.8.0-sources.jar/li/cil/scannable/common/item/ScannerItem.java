/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item;

import dev.architectury.registry.menu.MenuRegistry;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.client.ScanManager;
import li.cil.scannable.client.audio.SoundManager;
import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.container.ScannerContainerMenu;
import li.cil.scannable.common.energy.ItemEnergyStorage;
import li.cil.scannable.common.inventory.ScannerContainer;
import net.minecraft.class_10712;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3908;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public final class ScannerItem extends ModItem {
    public static boolean isScanner(final class_1799 stack) {
        return stack.method_7909() == Items.SCANNER.get();
    }

    // --------------------------------------------------------------------- //

    public ScannerItem(final class_1793 properties) {
        super(properties.method_7889(1));
    }

    // --------------------------------------------------------------------- //
    // Item

    @Override
    public void method_67187(final class_1799 stack, final class_1792.class_9635 context, final class_10712 display, final Consumer<class_2561> tooltip, final class_1836 flag) {
        super.method_67187(stack, context, display, tooltip, flag);

        if (ServerConfig.useEnergy) {
            ItemEnergyStorage.of(stack).ifPresent(energy ->
                tooltip.accept(Strings.energyStorage(energy.getEnergyStored(), energy.getMaxEnergyStored())));
        }
    }

    @Override
    public boolean method_31567(final class_1799 stack) {
        return ServerConfig.useEnergy;
    }

    @Override
    public int method_31569(final class_1799 stack) {
        return (int) (getRelativeEnergy(stack) * field_30889);
    }

    @Override
    public int method_31571(final class_1799 stack) {
        return class_3532.method_15369(getRelativeEnergy(stack) / 3f, 1, 1);
    }

    @Override
    public class_1269 method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        final class_1799 stack = player.method_5998(hand);
        if (player.method_5715()) {
            if (!level.method_8608() && player instanceof class_3222 serverPlayer) {
                MenuRegistry.openExtendedMenu(serverPlayer, new class_3908() {
                    @Override
                    public class_2561 method_5476() {
                        return stack.method_7964();
                    }

                    @Override
                    public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                        return new ScannerContainerMenu(id, inventory, hand, ScannerContainer.of(stack));
                    }
                }, buffer -> buffer.method_10817(hand));
            }
        } else {
            final List<class_1799> modules = new ArrayList<>();
            if (!collectModules(stack, modules)) {
                if (!level.method_8608()) {
                    player.method_7353(Strings.MESSAGE_NO_SCAN_MODULES, true);
                }
                player.method_7357().method_62835(stack, 10);
                return class_1269.field_5814;
            }

            if (!tryConsumeEnergy(player, stack, modules, true)) {
                if (!level.method_8608()) {
                    player.method_7353(Strings.MESSAGE_NOT_ENOUGH_ENERGY, true);
                }
                player.method_7357().method_62835(stack, 10);
                return class_1269.field_5814;
            }

            player.method_6019(hand);
            if (level.method_8608()) {
                ScanManager.beginScan(player, modules);
                SoundManager.playChargingSound();
            }
        }

        return class_1269.field_5812;
    }

    @Override
    public int method_7881(final class_1799 stack, final class_1309 entity) {
        return ScanManager.SCAN_COMPUTE_DURATION;
    }

    @Override
    public void method_7852(final class_1937 level, final class_1309 entity, final class_1799 stack, final int count) {
        super.method_7852(level, entity, stack, count);
        if (entity.method_73183().method_8608()) {
            ScanManager.updateScan(entity, false);
        }
    }

    @Override
    public boolean method_7840(final class_1799 stack, final class_1937 level, final class_1309 entity, final int timeLeft) {
        if (level.method_8608()) {
            ScanManager.cancelScan();
            SoundManager.stopChargingSound();
        }
        return super.method_7840(stack, level, entity, timeLeft);
    }

    @Override
    public class_1799 method_7861(final class_1799 stack, final class_1937 level, final class_1309 entity) {
        if (!(entity instanceof final class_1657 player)) {
            return stack;
        }

        final List<class_1799> modules = new ArrayList<>();
        if (!collectModules(stack, modules)) {
            return stack;
        }

        final boolean hasEnergy = tryConsumeEnergy((class_1657) entity, stack, modules, false);
        if (level.method_8608()) {
            SoundManager.stopChargingSound();

            if (hasEnergy) {
                ScanManager.updateScan(entity, true);
                SoundManager.playActivateSound();
            } else {
                ScanManager.cancelScan();
            }
        }

        player.method_7357().method_62835(stack, 40);

        return stack;
    }

    // --------------------------------------------------------------------- //

    private static float getRelativeEnergy(final class_1799 stack) {
        if (!ServerConfig.useEnergy) {
            return 0;
        }

        return ItemEnergyStorage.of(stack)
            .map(storage -> storage.getEnergyStored() / (float) storage.getMaxEnergyStored())
            .orElse(0f);
    }

    private static boolean tryConsumeEnergy(final class_1657 player, final class_1799 scanner, final List<class_1799> modules, final boolean simulate) {
        if (!ServerConfig.useEnergy) {
            return true;
        }

        if (player.method_68878()) {
            return true;
        }

        final Optional<ItemEnergyStorage> energyStorage = ItemEnergyStorage.of(scanner);
        if (energyStorage.isEmpty()) {
            return false;
        }

        long totalCostAccumulator = 0;
        for (final class_1799 module : modules) {
            totalCostAccumulator += ScannerModuleItem.getModuleEnergyCost(module);
        }
        final long totalCost = totalCostAccumulator;

        final long extracted = energyStorage.map(storage -> storage.extractEnergy(totalCost, simulate)).orElse(0L);

        return extracted >= totalCost;
    }

    private static boolean collectModules(final class_1799 scanner, final List<class_1799> modules) {
        final ScannerContainer container = ScannerContainer.of(scanner);
        final class_1263 activeModules = container.getActiveModules();
        boolean hasScannerModules = false;
        for (int slot = 0; slot < activeModules.method_5439(); slot++) {
            final class_1799 module = activeModules.method_5438(slot);
            if (module.method_7960()) {
                continue;
            }

            modules.add(module);

            hasScannerModules |= ScannerModuleItem.getModule(module)
                .map(ScannerModule::hasResultProvider).orElse(false);
        }
        return hasScannerModules;
    }
}
