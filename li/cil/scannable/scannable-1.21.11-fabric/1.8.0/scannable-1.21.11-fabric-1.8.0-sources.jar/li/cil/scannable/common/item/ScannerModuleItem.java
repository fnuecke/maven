/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item;

import dev.architectury.injectables.annotations.ExpectPlatform;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.config.Strings;
import net.minecraft.class_10712;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Contract;

import java.util.Optional;
import java.util.function.Consumer;

public class ScannerModuleItem extends ModItem {
    private final ScannerModule module;

    // --------------------------------------------------------------------- //

    ScannerModuleItem(final class_1792.class_1793 properties, final ScannerModule module) {
        super(properties.method_7889(1));
        this.module = module;
    }

    public ScannerModule getModule() {
        return module;
    }

    @SuppressWarnings("Contract")
    @Contract("_ -> !null")
    @ExpectPlatform
    public static Optional<ScannerModule> getModule(final class_1799 stack) {
        throw new AssertionError();
    }

    public static int getModuleEnergyCost(final class_1799 stack) {
        if (!ServerConfig.useEnergy) {
            return 0;
        }

        return getModule(stack)
            .map(module -> module.getEnergyCost(stack)).orElse(0);
    }

    // --------------------------------------------------------------------- //
    // Item

    @Override
    public void method_67187(final class_1799 stack, final class_1792.class_9635 context, final class_10712 display, final Consumer<class_2561> tooltip, final class_1836 flag) {
        super.method_67187(stack, context, display, tooltip, flag);

        final int cost = getModuleEnergyCost(stack);
        if (cost > 0) {
            tooltip.accept(Strings.energyUsage(cost));
        }
    }
}
