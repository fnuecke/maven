/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.EntityScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.EntityListScanFilter;
import li.cil.scannable.client.scanning.filter.EntityTypeScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.item.ConfigurableEntityScannerModuleItem;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public enum ConfigurableEntityScannerModule implements EntityScannerModule {
    INSTANCE;

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleEntity;
    }

    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleEntity;
    }

    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.entities();
    }

    @Override
    public Predicate<class_1297> getFilter(final class_1799 module) {
        final List<class_1299<?>> entityType = ConfigurableEntityScannerModuleItem.getEntityTypes(module);
        return new EntityListScanFilter(entityType.stream().map(EntityTypeScanFilter::new).collect(Collectors.toList()));
    }
}
