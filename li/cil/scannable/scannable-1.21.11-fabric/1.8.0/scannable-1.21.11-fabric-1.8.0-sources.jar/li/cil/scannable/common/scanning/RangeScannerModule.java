/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.common.config.ServerConfig;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import javax.annotation.Nullable;

public enum RangeScannerModule implements ScannerModule {
    INSTANCE;

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleRange;
    }

    @Override
    public boolean hasResultProvider() {
        return false;
    }

    @Nullable
    @Override
    public ScanResultProvider getResultProvider() {
        return null;
    }

    @Override
    public float adjustGlobalRange(final float range) {
        return range + class_3532.method_15386(ServerConfig.baseScanRadius * ServerConfig.rangeModifierModuleRange);
    }
}
