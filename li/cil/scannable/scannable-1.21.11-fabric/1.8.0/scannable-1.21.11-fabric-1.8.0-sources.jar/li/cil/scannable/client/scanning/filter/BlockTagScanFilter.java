/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import java.util.function.Predicate;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_6862;

public record BlockTagScanFilter(class_6862<class_2248> tag) implements Predicate<class_2680> {
    @Override
    public boolean test(final class_2680 state) {
        return state.method_26164(tag);
    }
}
