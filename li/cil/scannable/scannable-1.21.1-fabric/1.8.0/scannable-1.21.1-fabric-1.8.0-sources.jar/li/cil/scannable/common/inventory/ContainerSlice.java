/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.inventory;

import org.jetbrains.annotations.NotNull;

import java.util.Iterator;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public final class ContainerSlice implements class_1263, Iterable<class_1799> {
    private final class_1263 container;
    private final int offset;
    private final int length;

    // --------------------------------------------------------------------- //

    public ContainerSlice(final class_1263 container, final int offset, final int length) {
        this.container = container;
        this.offset = offset;
        this.length = length;
    }

    // --------------------------------------------------------------------- //
    // Container

    @Override
    public int method_5439() {
        return length;
    }

    @Override
    public boolean method_5442() {
        for (int i = 0; i < length; i++) {
            final class_1799 stack = container.method_5438(offset + i);
            if (!stack.method_7960()) {
                return false;
            }
        }

        return true;
    }

    @Override
    public class_1799 method_5438(final int index) {
        return isIndexInBounds(index) ? container.method_5438(offset + index) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5434(final int index, final int count) {
        return isIndexInBounds(index) ? container.method_5434(offset + index, count) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5441(final int index) {
        return isIndexInBounds(index) ? container.method_5441(offset + index) : class_1799.field_8037;
    }

    @Override
    public void method_5447(final int index, final class_1799 stack) {
        if (isIndexInBounds(index)) {
            container.method_5447(offset + index, stack);
        }
    }

    @Override
    public void method_5431() {
        container.method_5431();
    }

    @Override
    public boolean method_5443(final class_1657 player) {
        return container.method_5443(player);
    }

    @Override
    public void method_5435(final class_1657 player) {
        container.method_5435(player);
    }

    @Override
    public void method_5432(final class_1657 player) {
        container.method_5432(player);
    }

    @Override
    public boolean method_5437(final int i, final class_1799 itemStack) {
        return container.method_5437(i, itemStack);
    }

    // --------------------------------------------------------------------- //
    // Clearable

    @Override
    public void method_5448() {
        for (int i = 0; i < length; i++) {
            container.method_5441(offset + i);
        }

        container.method_5431();
    }

    // --------------------------------------------------------------------- //
    // Iterable<ItemStack>

    @NotNull
    @Override
    public Iterator<class_1799> iterator() {
        return new Iterator<>() {
            private int index;

            @Override
            public boolean hasNext() {
                return index < method_5439();
            }

            @Override
            public class_1799 next() {
                final class_1799 stack = method_5438(index);
                index++;
                return stack;
            }
        };
    }

    // --------------------------------------------------------------------- //

    private boolean isIndexInBounds(final int index) {
        return index >= 0 && index < length;
    }
}
