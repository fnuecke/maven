/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item.fabric;

import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.api.scanning.ScannerModuleProvider;
import net.minecraft.class_1799;
import java.util.Optional;

public final class ScannerModuleItemImpl {
    public static Optional<ScannerModule> getModule(final class_1799 stack) {
        if (stack.method_7909() instanceof ScannerModuleProvider provider) {
            return provider.getScannerModule(stack);
        } else {
            return Optional.empty();
        }
    }
}
