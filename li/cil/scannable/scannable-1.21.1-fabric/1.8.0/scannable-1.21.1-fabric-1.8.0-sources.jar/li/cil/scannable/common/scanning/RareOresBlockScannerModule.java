/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.BlockScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.BlockCacheScanFilter;
import li.cil.scannable.client.scanning.filter.BlockScanFilter;
import li.cil.scannable.client.scanning.filter.BlockTagScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.scanning.filter.IgnoredBlocks;
import li.cil.scannable.common.tags.CommonTags;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public enum RareOresBlockScannerModule implements BlockScannerModule {
    INSTANCE;

    private Predicate<class_2680> filter;

    public static void clearCache() {
        INSTANCE.filter = null;
    }

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleOreRare;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.BLOCKS.get();
    }

    @Environment(EnvType.CLIENT)
    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleOreRare;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public Predicate<class_2680> getFilter(final class_1799 module) {
        validateFilter();
        return filter;
    }

    @Environment(EnvType.CLIENT)
    private void validateFilter() {
        if (filter != null) {
            return;
        }

        final List<Predicate<class_2680>> filters = new ArrayList<>();
        for (final class_2960 location : ServerConfig.rareOreBlocks) {
            class_7923.field_41175.method_17966(location).ifPresent(block ->
                filters.add(new BlockScanFilter(block)));
        }
        class_7923.field_41175.method_40273().forEach(tag -> {
            if (ServerConfig.rareOreBlockTags.contains(tag.comp_327())) {
                filters.add(new BlockTagScanFilter(tag));
            }
        });

        // Treat all blocks tagged as ores but not part of the common ore category as rare.
        final class_6862<class_2248> topLevelOreTag = getTopLevelOreTag();
        filters.add(state -> !IgnoredBlocks.contains(state) &&
            state.method_26164(topLevelOreTag) &&
            !CommonOresBlockScannerModule.INSTANCE.getFilter(class_1799.field_8037).test(state));

        filter = new BlockCacheScanFilter(filters);
    }

    private static class_6862<class_2248> getTopLevelOreTag() {
        return CommonTags.ORES;
    }
}
