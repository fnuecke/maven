@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.shader;

import javax.annotation.ParametersAreNonnullByDefault;
