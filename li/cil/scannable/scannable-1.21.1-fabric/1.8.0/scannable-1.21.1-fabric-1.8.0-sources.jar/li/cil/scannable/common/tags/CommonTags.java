/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.tags;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class CommonTags {
    public static final String NAMESPACE = "c";

    // --------------------------------------------------------------------- //
    // Blocks

    public static final class_6862<class_2248> ORES = blockTag("ores");

    public static final class_6862<class_2248> ORES_COAL = blockTag("ores/coal");
    public static final class_6862<class_2248> ORES_COPPER = blockTag("ores/copper");
    public static final class_6862<class_2248> ORES_DIAMOND = blockTag("ores/diamond");
    public static final class_6862<class_2248> ORES_EMERALD = blockTag("ores/emerald");
    public static final class_6862<class_2248> ORES_GOLD = blockTag("ores/gold");
    public static final class_6862<class_2248> ORES_IRON = blockTag("ores/iron");
    public static final class_6862<class_2248> ORES_LAPIS = blockTag("ores/lapis");
    public static final class_6862<class_2248> ORES_QUARTZ = blockTag("ores/quartz");
    public static final class_6862<class_2248> ORES_REDSTONE = blockTag("ores/redstone");

    // Not defined by either loader, but conventional names commonly used by mods.
    public static final class_6862<class_2248> ORES_LEAD = blockTag("ores/lead");
    public static final class_6862<class_2248> ORES_MITHRIL = blockTag("ores/mithril");
    public static final class_6862<class_2248> ORES_NICKEL = blockTag("ores/nickel");
    public static final class_6862<class_2248> ORES_PLATINUM = blockTag("ores/platinum");
    public static final class_6862<class_2248> ORES_SILVER = blockTag("ores/silver");
    public static final class_6862<class_2248> ORES_TIN = blockTag("ores/tin");

    public static final class_6862<class_2248> BARRELS_WOODEN = blockTag("barrels/wooden");
    public static final class_6862<class_2248> CHESTS = blockTag("chests");
    public static final class_6862<class_2248> SHULKER_BOXES = blockTag("shulker_boxes");

    // --------------------------------------------------------------------- //
    // Items

    public static final class_6862<class_1792> BONES = itemTag("bones");
    public static final class_6862<class_1792> DUSTS_GLOWSTONE = itemTag("dusts/glowstone");
    public static final class_6862<class_1792> DUSTS_REDSTONE = itemTag("dusts/redstone");
    public static final class_6862<class_1792> DYES_GREEN = itemTag("dyes/green");
    public static final class_6862<class_1792> ENDER_PEARLS = itemTag("ender_pearls");
    public static final class_6862<class_1792> GEMS_DIAMOND = itemTag("gems/diamond");
    public static final class_6862<class_1792> GEMS_QUARTZ = itemTag("gems/quartz");
    public static final class_6862<class_1792> INGOTS_GOLD = itemTag("ingots/gold");
    public static final class_6862<class_1792> INGOTS_IRON = itemTag("ingots/iron");
    public static final class_6862<class_1792> LEATHERS = itemTag("leathers");
    public static final class_6862<class_1792> NUGGETS_GOLD = itemTag("nuggets/gold");
    public static final class_6862<class_1792> STONES = itemTag("stones");

    // --------------------------------------------------------------------- //

    public static class_2960 id(final String name) {
        return class_2960.method_60655(NAMESPACE, name);
    }

    private static class_6862<class_2248> blockTag(final String name) {
        return class_6862.method_40092(class_7924.field_41254, id(name));
    }

    private static class_6862<class_1792> itemTag(final String name) {
        return class_6862.method_40092(class_7924.field_41197, id(name));
    }

    private CommonTags() {
    }
}
