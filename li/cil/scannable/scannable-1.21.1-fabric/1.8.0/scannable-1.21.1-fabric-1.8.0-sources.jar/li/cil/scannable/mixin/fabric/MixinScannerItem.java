/* SPDX-License-Identifier: MIT */

package li.cil.scannable.mixin.fabric;

import li.cil.scannable.common.item.ScannerItem;
import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(ScannerItem.class)
public abstract class MixinScannerItem implements FabricItem {
    @Override
    public boolean allowComponentsUpdateAnimation(final class_1657 player, final class_1268 hand, final class_1799 oldStack, final class_1799 newStack) {
        return oldStack.method_7909() != newStack.method_7909();
    }
}
