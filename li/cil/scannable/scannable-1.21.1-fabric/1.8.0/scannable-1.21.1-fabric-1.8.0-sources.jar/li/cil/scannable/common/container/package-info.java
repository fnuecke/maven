@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.container;

import javax.annotation.ParametersAreNonnullByDefault;
