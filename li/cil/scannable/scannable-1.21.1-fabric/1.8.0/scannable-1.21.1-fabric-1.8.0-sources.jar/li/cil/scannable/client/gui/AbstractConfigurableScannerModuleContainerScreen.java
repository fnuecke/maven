/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.gui;

import li.cil.scannable.api.API;
import li.cil.scannable.common.config.Constants;
import li.cil.scannable.common.container.AbstractModuleContainerMenu;
import li.cil.scannable.common.network.Network;
import li.cil.scannable.common.network.message.RemoveConfiguredModuleItemAtMessage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import javax.annotation.Nullable;
import java.util.List;

@Environment(EnvType.CLIENT)
public abstract class AbstractConfigurableScannerModuleContainerScreen<TContainer extends AbstractModuleContainerMenu, TItem> extends class_465<TContainer> {
    private static final class_2960 BACKGROUND = class_2960.method_60655(API.MOD_ID, "textures/gui/container/configurable_module.png");
    public static final int SLOTS_ORIGIN_X = 62;
    public static final int SLOTS_ORIGIN_Y = 20;
    public static final int SLOT_SIZE = 18;

    private final class_2561 listCaption;
    private final class_1661 inventory;

    // --------------------------------------------------------------------- //

    public AbstractConfigurableScannerModuleContainerScreen(final TContainer container, final class_1661 inventory, final class_2561 title, final class_2561 listCaption) {
        super(container, inventory, title);
        this.listCaption = listCaption;
        this.inventory = inventory;

        field_2779 = 133;
        field_25269 = 8;
        field_25270 = 39;
    }

    private class_1799 getHeldItem() {
        return field_2797.getPlayer().method_5998(field_2797.getHand());
    }

    protected abstract List<TItem> getConfiguredItems(final class_1799 stack);

    protected abstract class_2561 getItemName(final TItem item);

    protected abstract void renderConfiguredItem(final class_332 graphics, final TItem item, final int x, final int y);

    protected void configureItemAt(final class_1799 stack, final int slot, final class_1799 value) {
    }

    // --------------------------------------------------------------------- //

    @Override
    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float partialTicks) {
        method_25420(graphics, mouseX, mouseY, partialTicks);
        super.method_25394(graphics, mouseX, mouseY, partialTicks);
        method_2380(graphics, mouseX, mouseY);

        final class_1799 stack = getHeldItem();
        final List<TItem> items = getConfiguredItems(stack);
        for (int slot = 0; slot < Math.min(items.size(), Constants.CONFIGURABLE_MODULE_SLOTS); slot++) {
            final int x = SLOTS_ORIGIN_X + slot * SLOT_SIZE;
            final int y = SLOTS_ORIGIN_Y;

            if (method_2378(x, y, 16, 16, mouseX, mouseY)) {
                final TItem item = items.get(slot);
                graphics.method_51438(field_22793, getItemName(item), mouseX, mouseY);
            }
        }
    }

    @Override
    protected void method_2388(final class_332 graphics, final int mouseX, final int mouseY) {
        super.method_2388(graphics, mouseX, mouseY);
        graphics.method_51439(field_22793, listCaption, 8, 23, 0x404040, false);

        final class_1799 stack = getHeldItem();
        final List<TItem> items = getConfiguredItems(stack);
        for (int slot = 0; slot < Constants.CONFIGURABLE_MODULE_SLOTS; slot++) {
            final int x = SLOTS_ORIGIN_X + slot * SLOT_SIZE;
            final int y = SLOTS_ORIGIN_Y;

            if (method_2378(x, y, 16, 16, mouseX, mouseY)) {
                method_33285(graphics, x, y, 400);
            }

            if (slot < items.size()) {
                final TItem item = items.get(slot);
                renderConfiguredItem(graphics, item, x, y);
            }
        }
    }

    @Override
    protected void method_2389(final class_332 graphics, final float partialTicks, final int mouseX, final int mouseY) {
        final int x = (field_22789 - field_2792) / 2;
        final int y = (field_22790 - field_2779) / 2;
        graphics.method_25302(BACKGROUND, x, y, 0, 0, field_2792, field_2779);
    }

    @Override
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        for (int slot = 0; slot < Constants.CONFIGURABLE_MODULE_SLOTS; slot++) {
            final int x = SLOTS_ORIGIN_X + slot * SLOT_SIZE;
            final int y = SLOTS_ORIGIN_Y;

            if (method_2378(x, y, SLOT_SIZE, SLOT_SIZE, mouseX, mouseY)) {
                final class_1799 heldItemStack = field_2797.method_34255();
                if (!heldItemStack.method_7960()) {
                    configureItemAt(getHeldItem(), slot, heldItemStack);
                } else {
                    Network.sendToServer(new RemoveConfiguredModuleItemAtMessage(field_2797.field_7763, slot));
                }
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    protected void method_2383(@Nullable final class_1735 slot, final int slotId, final int mouseButton, final class_1713 type) {
        if (slot != null) {
            final class_1799 heldItem = getHeldItem();
            if (slot.method_7677() == heldItem) {
                return;
            }
            if (type == class_1713.field_7791 && inventory.method_5438(mouseButton) == heldItem) {
                return;
            }
        }

        //noinspection ConstantConditions Missing nullable annotation, base method tests for null.
        super.method_2383(slot, slotId, mouseButton, type);
    }
}
