/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.container;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3917;

public abstract class AbstractModuleContainerMenu extends class_1703 {
    private final class_1657 player;
    private final class_1268 hand;
    private final class_1799 stack;

    // --------------------------------------------------------------------- //

    protected AbstractModuleContainerMenu(final class_3917<?> type, final int windowId, final class_1661 inventory, final class_1268 hand) {
        super(type, windowId);

        this.player = inventory.field_7546;
        this.hand = hand;
        this.stack = player.method_5998(hand);

        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                method_7621(new class_1735(inventory, col + row * 9 + 9, 8 + col * 18, row * 18 + 51));
            }
        }

        for (int slot = 0; slot < 9; ++slot) {
            method_7621(new class_1735(inventory, slot, 8 + slot * 18, 109));
        }
    }

    public class_1657 getPlayer() {
        return player;
    }

    public class_1268 getHand() {
        return hand;
    }

    public abstract void removeItemAt(final int index);

    public abstract void setItemAt(final int index, final class_2960 value);

    // --------------------------------------------------------------------- //
    // Container

    @Override
    public boolean method_7597(final class_1657 player) {
        return player == this.player && class_1799.method_7973(player.method_5998(hand), stack);
    }

    @Override
    public class_1799 method_7601(final class_1657 player, final int index) {
        return class_1799.field_8037;
    }
}
