/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.inventory;

import li.cil.scannable.common.item.Items;
import li.cil.scannable.common.item.ModDataComponents;
import li.cil.scannable.common.item.ScannerItem;
import li.cil.scannable.common.item.ScannerModuleItem;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_9288;
import java.util.ArrayList;
import java.util.List;

public final class ScannerContainer extends class_1277 {
    private static final int ACTIVE_MODULE_COUNT = 3;
    private static final int INACTIVE_MODULE_COUNT = 6;
    private static final int TOTAL_MODULE_COUNT = ACTIVE_MODULE_COUNT + INACTIVE_MODULE_COUNT;

    private final class_1799 container;

    public ScannerContainer(final class_1799 container) {
        super(TOTAL_MODULE_COUNT);
        this.container = container;

        final class_9288 contents = container.method_57824(ModDataComponents.MODULES.get());
        if (contents != null) {
            final class_2371<class_1799> items = class_2371.method_10213(TOTAL_MODULE_COUNT, class_1799.field_8037);
            contents.method_57492(items);
            for (int slot = 0; slot < TOTAL_MODULE_COUNT; slot++) {
                method_5447(slot, items.get(slot));
            }
        }
    }

    public static ScannerContainer of(final class_1799 container) {
        if (container.method_7909() instanceof ScannerItem) {
            return new ScannerContainer(container);
        } else {
            return new ScannerContainer(new class_1799(Items.SCANNER.get()));
        }
    }

    public ContainerSlice getActiveModules() {
        return new ContainerSlice(this, 0, ACTIVE_MODULE_COUNT);
    }

    public ContainerSlice getInactiveModules() {
        return new ContainerSlice(this, ACTIVE_MODULE_COUNT, INACTIVE_MODULE_COUNT);
    }

    // --------------------------------------------------------------------- //
    // Container

    @Override
    public void method_5447(final int i, final class_1799 itemStack) {
        if (method_5437(i, itemStack)) {
            super.method_5447(i, itemStack);
        }
    }

    @Override
    public boolean method_5437(final int i, final class_1799 stack) {
        return isModule(stack) && super.method_5437(i, stack);
    }

    @Override
    public void method_5431() {
        super.method_5431();

        final List<class_1799> items = new ArrayList<>(method_5439());
        for (int slot = 0; slot < method_5439(); slot++) {
            items.add(method_5438(slot));
        }
        container.method_57379(ModDataComponents.MODULES.get(), class_9288.method_57493(items));
    }

    // --------------------------------------------------------------------- //
    // SimpleContainer

    @Override
    public class_1799 method_5491(final class_1799 stack) {
        if (method_27070(stack)) {
            return super.method_5491(stack);
        } else {
            return stack;
        }
    }

    @Override
    public boolean method_27070(final class_1799 stack) {
        return isModule(stack) && super.method_27070(stack);
    }

    // --------------------------------------------------------------------- //

    private boolean isModule(final class_1799 stack) {
        // All built-in modules, including those without capability such as the range module.
        if (stack.method_7909() instanceof ScannerModuleItem) {
            return true;
        }

        // External modules declared via capability/interface.
        if (ScannerModuleItem.getModule(stack).isPresent()) {
            return true;
        }

        return false;
    }
}
