/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public record FluidTagScanFilter(class_6862<class_3611> tag) implements Predicate<class_2680> {
    @Override
    public boolean test(final class_2680 state) {
        final class_3610 fluidState = state.method_26227();
        return !fluidState.method_15769() && fluidState.method_15767(tag);
    }
}
