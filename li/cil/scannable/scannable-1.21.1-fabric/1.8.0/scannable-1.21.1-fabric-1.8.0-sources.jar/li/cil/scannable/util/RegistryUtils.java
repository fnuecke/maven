/* SPDX-License-Identifier: MIT */

package li.cil.scannable.util;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrarBuilder;
import dev.architectury.registry.registries.RegistrarManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

public final class RegistryUtils {
    private enum Phase {
        PRE_INIT,
        INIT,
        POST_INIT,
    }

    private static final List<DeferredRegister<?>> ENTRIES = new ArrayList<>();
    private static Phase phase = Phase.PRE_INIT;
    private static String modId;

    @SafeVarargs
    @SuppressWarnings("varargs")
    public static <T> RegistrarBuilder<T> builder(class_5321<class_2378<T>> registryKey, T... typeGetter) {
        return RegistrarManager.get(modId).builder(registryKey.method_29177(), typeGetter);
    }

    public static <T> DeferredRegister<T> get(final class_5321<class_2378<T>> registryKey) {
        if (phase != Phase.INIT) throw new IllegalStateException();

        final DeferredRegister<T> entry = DeferredRegister.create(modId, registryKey);
        ENTRIES.add(entry);
        return entry;
    }

    public static void begin(final String modId) {
        RegistryUtils.modId = modId;
        if (phase != Phase.PRE_INIT) throw new IllegalStateException();
        phase = Phase.INIT;
    }

    public static void finish() {
        if (phase != Phase.INIT) throw new IllegalStateException();
        phase = Phase.POST_INIT;

        for (final DeferredRegister<?> register : ENTRIES) {
            register.register();
        }

        ENTRIES.clear();
    }

    private RegistryUtils() {
    }
}
