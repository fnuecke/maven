@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
