/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.API;
import li.cil.scannable.api.scanning.EntityScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.HostileEntityScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import java.util.Optional;
import java.util.function.Predicate;

public enum HostileEntityScannerModule implements EntityScannerModule {
    INSTANCE;

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleMonster;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleMonster;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.ENTITIES.get();
    }

    @Environment(EnvType.CLIENT)
    @Override
    public Optional<class_2960> getIcon(final class_1297 entity) {
        return Optional.of(API.ICON_WARNING);
    }

    @Environment(EnvType.CLIENT)
    @Override
    public Predicate<class_1297> getFilter(final class_1799 module) {
        return HostileEntityScanFilter.INSTANCE;
    }
}
