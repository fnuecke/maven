/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.container;

import li.cil.scannable.common.item.ConfigurableEntityScannerModuleItem;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class EntityModuleContainerMenu extends AbstractModuleContainerMenu {
    public static EntityModuleContainerMenu create(final int windowId, final class_1661 inventory, final class_2540 buffer) {
        final class_1268 hand = buffer.method_10818(class_1268.class);
        return new EntityModuleContainerMenu(windowId, inventory, hand);
    }

    // --------------------------------------------------------------------- //

    public EntityModuleContainerMenu(final int windowId, final class_1661 inventory, final class_1268 hand) {
        super(Containers.ENTITY_MODULE_CONTAINER.get(), windowId, inventory, hand);
    }

    @Override
    public void removeItemAt(final int index) {
        final class_1799 stack = getPlayer().method_5998(getHand());
        ConfigurableEntityScannerModuleItem.removeEntityTypeAt(stack, index);
    }

    @Override
    public void setItemAt(final int index, final class_2960 name) {
        final class_1799 stack = getPlayer().method_5998(getHand());
        class_7923.field_41177.method_17966(name).ifPresent(type ->
            ConfigurableEntityScannerModuleItem.setEntityTypeAt(stack, index, type));
    }
}
