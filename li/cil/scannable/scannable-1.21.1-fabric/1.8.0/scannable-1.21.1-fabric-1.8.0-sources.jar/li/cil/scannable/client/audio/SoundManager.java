/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.audio;

import li.cil.scannable.api.API;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import javax.annotation.Nullable;

@Environment(EnvType.CLIENT)
public final class SoundManager {
    private static final class_3414 SCANNER_CHARGE = class_3414.method_47908(class_2960.method_60655(API.MOD_ID, "scanner_charge"));
    private static final class_3414 SCANNER_ACTIVATE = class_3414.method_47908(class_2960.method_60655(API.MOD_ID, "scanner_activate"));

    @Nullable
    private static class_1109 currentChargingSound;

    public static void playChargingSound() {
        currentChargingSound = class_1109.method_4758(SCANNER_CHARGE, 1);
        class_310.method_1551().method_1483().method_4873(currentChargingSound);
    }

    public static void stopChargingSound() {
        if (currentChargingSound != null) {
            class_310.method_1551().method_1483().method_4870(currentChargingSound);
            currentChargingSound = null;
        }
    }

    public static void playActivateSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_4758(SCANNER_ACTIVATE, 1));
    }
}
