/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.scannable.api.API;
import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.item.ScannerItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_757;

@Environment(EnvType.CLIENT)
public final class OverlayRenderer {
    private static final class_2960 PROGRESS = class_2960.method_60655(API.MOD_ID, "textures/gui/overlay/scanner_progress.png");

    public static void render(final class_332 graphics, final float partialTick) {
        final class_310 mc = class_310.method_1551();
        final class_1657 player = mc.field_1724;
        if (player == null) {
            return;
        }

        final class_1799 stack = player.method_6030();
        if (stack.method_7960()) {
            return;
        }

        if (!ScannerItem.isScanner(stack)) {
            return;
        }

        final int total = stack.method_7935(player);
        final int remaining = player.method_6014();

        final float progress = class_3532.method_15363(1 - (remaining - partialTick) / total, 0, 1);

        final int screenWidth = mc.method_22683().method_4486();
        final int screenHeight = mc.method_22683().method_4502();

        RenderSystem.enableBlend();
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(0.66f, 0.8f, 0.93f, 0.66f);
        RenderSystem.setShaderTexture(0, PROGRESS);

        final class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27379, class_290.field_1585);

        final int width = 64;
        final int height = 64;
        final int midX = screenWidth / 2;
        final int midY = screenHeight / 2;
        final int left = midX - width / 2;
        final int right = midX + width / 2;
        final int top = midY - height / 2;
        final int bottom = midY + height / 2;

        final float angle = (float) (progress * Math.PI * 2);
        final float tx = class_3532.method_15374(angle);
        final float ty = class_3532.method_15362(angle);

        buffer.method_22912(midX, top, 0).method_22913(0.5f, 1);
        if (progress < 0.125) { // Top right.
            buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);

            final float x = tx / ty * 0.5f;
            buffer.method_22912(midX + x * width, top, 0).method_22913(0.5f + x, 1);
        } else {
            buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);
            buffer.method_22912(right, top, 0).method_22913(1, 1);

            buffer.method_22912(right, top, 0).method_22913(1, 1);
            if (progress < 0.375) { // Right.
                buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);

                final float y = Math.abs(ty / tx - 1) * 0.5f;
                buffer.method_22912(right, top + y * height, 0).method_22913(1, 1 - y);
            } else {
                buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);
                buffer.method_22912(right, bottom, 0).method_22913(1, 0);

                buffer.method_22912(right, bottom, 0).method_22913(1, 0);
                if (progress < 0.625) { // Bottom.
                    buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);

                    final float x = Math.abs(tx / ty - 1) * 0.5f;
                    buffer.method_22912(left + x * width, bottom, 0).method_22913(x, 0);
                } else {
                    buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);
                    buffer.method_22912(left, bottom, 0).method_22913(0, 0);

                    buffer.method_22912(left, bottom, 0).method_22913(0, 0);
                    if (progress < 0.875) { // Left.
                        buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);

                        final float y = (ty / tx + 1) * 0.5f;
                        buffer.method_22912(left, top + y * height, 0).method_22913(0, 1 - y);
                    } else {
                        buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);
                        buffer.method_22912(left, top, 0).method_22913(0, 1);

                        buffer.method_22912(left, top, 0).method_22913(0, 1);
                        if (progress < 1) { // Top left.
                            buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);

                            final float x = Math.abs(tx / ty) * 0.5f;
                            buffer.method_22912(midX - x * width, top, 0).method_22913(0.5f - x, 1);
                        } else {
                            buffer.method_22912(midX, midY, 0).method_22913(0.5f, 0.5f);
                            buffer.method_22912(midX, top, 0).method_22913(0.5f, 1);
                        }
                    }
                }
            }
        }

        class_286.method_43433(buffer.method_60800());

        final class_2561 label = Strings.progress(class_3532.method_15375(progress * 100));
        graphics.method_51439(mc.field_1772, label, right + 12, midY - mc.field_1772.field_2000 / 2, 0xCCAACCEE, true);
    }
}
