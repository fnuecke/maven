/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.gui;

import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.container.BlockModuleContainerMenu;
import li.cil.scannable.common.item.ConfigurableBlockScannerModuleItem;
import li.cil.scannable.common.network.Network;
import li.cil.scannable.common.network.message.SetConfiguredModuleItemAtMessage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_7923;
import java.util.List;

@Environment(EnvType.CLIENT)
public class ConfigurableBlockScannerModuleContainerScreen extends AbstractConfigurableScannerModuleContainerScreen<BlockModuleContainerMenu, class_2248> {
    public ConfigurableBlockScannerModuleContainerScreen(final BlockModuleContainerMenu container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title, Strings.GUI_BLOCKS_LIST_CAPTION);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected List<class_2248> getConfiguredItems(final class_1799 stack) {
        return ConfigurableBlockScannerModuleItem.getBlocks(stack);
    }

    @Override
    protected class_2561 getItemName(final class_2248 block) {
        return block.method_9518();
    }

    @Override
    protected void renderConfiguredItem(final class_332 graphics, final class_2248 block, final int x, final int y) {
        graphics.method_51445(new class_1799(block.method_8389()), x, y);
    }

    @Override
    protected void configureItemAt(final class_1799 stack, final int slot, final class_1799 value) {
        final class_2248 block = class_2248.method_9503(value.method_7909());
        if (block != class_2246.field_10124) {
            class_7923.field_41175.method_29113(block).ifPresent(blockResourceKey ->
                Network.sendToServer(new SetConfiguredModuleItemAtMessage(field_2797.field_7763, slot, blockResourceKey.method_29177())));
        }
    }
}
