/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.energy;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.Optional;
import net.minecraft.class_1799;

public interface ItemEnergyStorage {
    @ExpectPlatform
    static Optional<ItemEnergyStorage> of(final class_1799 stack) {
        throw new AssertionError();
    }

    long receiveEnergy(long amount, boolean simulate);

    long extractEnergy(long amount, boolean simulate);

    long getEnergyStored();

    long getMaxEnergyStored();
}
