/* SPDX-License-Identifier: MIT */

package li.cil.scannable.mixin.fabric;

import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.api.scanning.ScannerModuleProvider;
import li.cil.scannable.common.item.ScannerModuleItem;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Optional;

@Mixin(ScannerModuleItem.class)
public abstract class MixinScannerModuleItem implements ScannerModuleProvider {
    @Shadow(remap = false)
    public abstract ScannerModule getModule();

    // --------------------------------------------------------------------- //
    // ScannerModuleProvider

    @Override
    public Optional<ScannerModule> getScannerModule(final class_1799 module) {
        if (module.method_31574(this.method_8389())) {
            return Optional.of(getModule());
        } else {
            return Optional.empty();
        }
    }
}
