@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.api.scanning;

import javax.annotation.ParametersAreNonnullByDefault;
