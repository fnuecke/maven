@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.scanning;

import javax.annotation.ParametersAreNonnullByDefault;
