/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.scannable.api.scanning.ScanResult;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.api.scanning.ScanResultRenderContext;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.client.renderer.ScannerRenderer;
import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.item.ScannerModuleItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_8251;
import net.minecraft.class_9799;
import org.joml.Matrix4f;

import javax.annotation.Nullable;
import java.util.*;

@Environment(EnvType.CLIENT)
public final class ScanManager {
    // The number of ticks over which to compute scan results. Which is at the
    // same time the use time of the scanner item.
    public static final int SCAN_COMPUTE_DURATION = 40;
    // Initial radius of the scan wave.
    private static final int SCAN_INITIAL_RADIUS = 10;
    // Scan wave growth time offset to avoid super slow start speed.
    private static final int SCAN_TIME_OFFSET = 200;
    // How long the ping takes to reach the end of the visible area.
    private static final int SCAN_GROWTH_DURATION = 2000;
    // Reference render distance the above constants are relative to.
    private static final int REFERENCE_RENDER_DISTANCE = 12;

    // --------------------------------------------------------------------- //

    private static float computeTargetRadius() {
        return class_310.method_1551().field_1773.method_3193();
    }

    public static int computeScanGrowthDuration() {
        return SCAN_GROWTH_DURATION * class_310.method_1551().field_1690.method_42503().method_41753() / REFERENCE_RENDER_DISTANCE;
    }

    public static float computeRadius(final long start, final float duration) {
        // Scan wave speeds up exponentially. To avoid the initial speed being
        // near zero due to that we offset the time and adjust the remaining
        // parameters accordingly. Base equation is:
        //   r = a + (t + b)^2 * c
        // with r := 0 and target radius and t := 0 and target time this yields:
        //   c = r1/((t1 + b)^2 - b*b)
        //   a = -r1*b*b/((t1 + b)^2 - b*b)

        final float r1 = computeTargetRadius();
        final float t1 = duration;
        final float b = SCAN_TIME_OFFSET;
        final float n = 1f / ((t1 + b) * (t1 + b) - b * b);
        final float a = -r1 * b * b * n;
        final float c = r1 * n;

        final float t = System.currentTimeMillis() - start;

        return SCAN_INITIAL_RADIUS + a + (t + b) * (t + b) * c;
    }

    // --------------------------------------------------------------------- //

    // List of providers currently used to scan.
    private static final Set<ScanResultProvider> collectingProviders = new HashSet<>();
    // List for collecting results during an active scan.
    private static final Map<ScanResultProvider, List<ScanResult>> collectingResults = new HashMap<>();

    // Results get copied from the collectingResults list in here when a scan
    // completes. This is to avoid clearing active results by *starting* a scan.
    private static final Map<ScanResultProvider, List<ScanResult>> pendingResults = new HashMap<>();
    private static final Map<ScanResultProvider, List<ScanResult>> renderingResults = new HashMap<>();
    // Temporary, re-used list to collect visible results each frame.
    private static final List<ScanResult> renderingList = new ArrayList<>();
    // Backing buffer for the immediate buffer source used while rendering results.
    private static final class_9799 BYTE_BUFFER_BUILDER = new class_9799(1536);

    private static int scanningTicks = -1;
    private static long currentStart = -1;
    @Nullable private static class_1937 lastScanLevel;
    @Nullable private static class_243 lastScanCenter;

    private static class_4587 worldViewModelStack;
    private static Matrix4f worldProjectionMatrix;

    // --------------------------------------------------------------------- //

    public static void beginScan(final class_1657 player, final List<class_1799> stacks) {
        cancelScan();

        float scanRadius = ServerConfig.baseScanRadius;

        final List<ScannerModule> modules = new ArrayList<>();
        for (final class_1799 stack : stacks) {
            final Optional<ScannerModule> module = ScannerModuleItem.getModule(stack);
            module.ifPresent(modules::add);
        }
        for (final ScannerModule module : modules) {
            final ScanResultProvider provider = module.getResultProvider();
            if (provider != null) {
                collectingProviders.add(provider);
            }

            scanRadius = module.adjustGlobalRange(scanRadius);
        }

        if (collectingProviders.isEmpty()) {
            return;
        }

        lastScanLevel = player.method_37908();

        final class_243 center = player.method_19538();
        for (final ScanResultProvider provider : collectingProviders) {
            provider.initialize(player, stacks, center, scanRadius, SCAN_COMPUTE_DURATION);
        }
    }

    public static void updateScan(final class_1297 entity, final boolean finish) {
        final int remaining = SCAN_COMPUTE_DURATION - scanningTicks;

        if (!finish) {
            if (remaining <= 0) {
                return;
            }

            for (final ScanResultProvider provider : collectingProviders) {
                provider.computeScanResults();
            }

            ++scanningTicks;

            return;
        }

        for (int i = 0; i < remaining; i++) {
            for (final ScanResultProvider provider : collectingProviders) {
                provider.computeScanResults();
            }
        }

        for (final ScanResultProvider provider : collectingProviders) {
            provider.collectScanResults(entity.method_37908(), result -> collectingResults.computeIfAbsent(provider, p -> new ArrayList<>()).add(result));
            provider.reset();
        }

        clear();

        lastScanLevel = entity.method_37908();
        lastScanCenter = Objects.requireNonNull(entity.method_19538());
        currentStart = System.currentTimeMillis();

        pendingResults.putAll(collectingResults);
        pendingResults.values().forEach(list -> list.sort(Comparator.comparing(result -> -lastScanCenter.method_1022(result.getPosition()))));

        ScannerRenderer.INSTANCE.ping(lastScanCenter);

        cancelScan();
    }

    public static void cancelScan() {
        collectingProviders.forEach(ScanResultProvider::reset);
        collectingProviders.clear();
        collectingResults.clear();
        scanningTicks = 0;
    }

    @SuppressWarnings("PMD.CompareObjectsWithEquals")
    public static void tick() {
        if (lastScanLevel != null && lastScanLevel != class_310.method_1551().field_1687) {
            cancelScan();
            clear();
            return;
        }

        if (lastScanCenter == null || currentStart < 0) {
            return;
        }

        removeInvalidResults();

        if (ServerConfig.scanStayDuration < (int) (System.currentTimeMillis() - currentStart)) {
            pendingResults.forEach((provider, results) -> results.forEach(ScanResult::close));
            pendingResults.clear();
            synchronized (renderingResults) {
                if (!renderingResults.isEmpty()) {
                    for (final Iterator<Map.Entry<ScanResultProvider, List<ScanResult>>> iterator = renderingResults.entrySet().iterator(); iterator.hasNext(); ) {
                        final Map.Entry<ScanResultProvider, List<ScanResult>> entry = iterator.next();
                        final List<ScanResult> list = entry.getValue();
                        for (int i = class_3532.method_15386(list.size() * 0.5f); i > 0; i--) {
                            list.remove(list.size() - 1).close();
                        }
                        if (list.isEmpty()) {
                            iterator.remove();
                        }
                    }
                }

                if (renderingResults.isEmpty()) {
                    clear();
                }
            }
            return;
        }

        if (pendingResults.isEmpty()) {
            return;
        }

        final float radius = computeRadius(currentStart, computeScanGrowthDuration());
        final float sqRadius = radius * radius;

        final Iterator<Map.Entry<ScanResultProvider, List<ScanResult>>> iterator = pendingResults.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry<ScanResultProvider, List<ScanResult>> entry = iterator.next();
            final ScanResultProvider provider = entry.getKey();
            final List<ScanResult> results = entry.getValue();

            while (!results.isEmpty()) {
                final int index = results.size() - 1;
                final class_243 position = results.get(index).getPosition();
                if (lastScanCenter.method_1025(position) <= sqRadius) {
                    final ScanResult result = results.remove(index);
                    if (!result.isValid()) {
                        result.close();
                        continue;
                    }
                    synchronized (renderingResults) {
                        renderingResults.computeIfAbsent(provider, p -> new ArrayList<>()).add(result);
                    }
                } else {
                    break; // List is sorted, so nothing else is in range.
                }
            }

            if (results.isEmpty()) {
                iterator.remove();
            }
        }
    }

    /**
     * @param viewMatrix       the camera/view matrix. Note that as of MC 1.21 the
     *                         {@link class_4587} used during level rendering is identity;
     *                         the camera transform lives in this matrix instead.
     * @param projectionMatrix the projection matrix used for level rendering.
     */
    public static void setMatrices(final Matrix4f viewMatrix, final Matrix4f projectionMatrix) {
        worldViewModelStack = new class_4587();
        worldViewModelStack.method_23760().method_23761().set(viewMatrix);
        worldProjectionMatrix = projectionMatrix;
    }

    public static void renderLevel(final float partialTick) {
        synchronized (renderingResults) {
            if (renderingResults.isEmpty()) {
                return;
            }

            render(ScanResultRenderContext.WORLD, partialTick, worldViewModelStack, worldProjectionMatrix);
        }
    }

    public static void renderGui(final float partialTick) {
        synchronized (renderingResults) {
            if (renderingResults.isEmpty()) {
                return;
            }

            // Using shaders, so we render as game overlay; restore matrices as used for level rendering.
            RenderSystem.backupProjectionMatrix();
            RenderSystem.setProjectionMatrix(worldProjectionMatrix, class_8251.field_43361);
            RenderSystem.getModelViewStack().pushMatrix().identity();
            RenderSystem.applyModelViewMatrix();

            render(ScanResultRenderContext.GUI, partialTick, worldViewModelStack, worldProjectionMatrix);

            RenderSystem.getModelViewStack().popMatrix();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.restoreProjectionMatrix();
        }
    }

    private static void render(final ScanResultRenderContext context, final float partialTicks, final class_4587 poseStack, final Matrix4f projectionMatrix) {
        final class_4184 camera = class_310.method_1551().field_1773.method_19418();
        final class_243 pos = camera.method_19326();

        final class_4604 frustum = new class_4604(poseStack.method_23760().method_23761(), projectionMatrix);
        frustum.method_23088(pos.method_10216(), pos.method_10214(), pos.method_10215());

        RenderSystem.disableDepthTest();
        RenderSystem.setShaderColor(1, 1, 1, 1);

        poseStack.method_22903();
        poseStack.method_22904(-pos.field_1352, -pos.field_1351, -pos.field_1350);

        // We render all results in batches, grouped by their provider.
        // This allows providers to do more optimized rendering, in e.g.
        // setting up the render state once before rendering all visuals,
        // or even set up display lists or VBOs.
        final class_4597.class_4598 renderTypeBuffer = class_4597.method_22991(BYTE_BUFFER_BUILDER);
        try {
            for (final Map.Entry<ScanResultProvider, List<ScanResult>> entry : renderingResults.entrySet()) {
                // Quick and dirty frustum culling.
                for (final ScanResult result : entry.getValue()) {
                    final class_238 bounds = result.getRenderBounds();
                    if (bounds == null || frustum.method_23093(bounds)) {
                        renderingList.add(result);
                    }
                }

                if (!renderingList.isEmpty()) {
                    entry.getKey().render(context, renderTypeBuffer, poseStack, camera, partialTicks, renderingList);
                    renderingList.clear();
                }
            }
        } finally {
            renderingList.clear();
        }

        renderTypeBuffer.method_22993();

        poseStack.method_22909();

        RenderSystem.enableDepthTest();
    }

    // --------------------------------------------------------------------- //

    private static void clear() {
        pendingResults.clear();

        synchronized (renderingResults) {
            renderingResults.forEach((provider, results) -> {
                provider.reset();
                results.forEach(ScanResult::close);
            });
            renderingResults.clear();
        }

        lastScanLevel = null;
        lastScanCenter = null;
        currentStart = -1;
    }

    private static void removeInvalidResults() {
        synchronized (renderingResults) {
            renderingResults.values().removeIf(results -> {
                results.removeIf(result -> {
                    if (result.isValid()) {
                        return false;
                    }
                    result.close();
                    return true;
                });
                return results.isEmpty();
            });
        }
    }
}
