/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.container;

import li.cil.scannable.common.inventory.ScannerContainer;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2540;

public final class ScannerContainerMenu extends class_1703 {
    public static ScannerContainerMenu create(final int windowId, final class_1661 inventory, final class_2540 buffer) {
        final class_1268 hand = buffer.method_10818(class_1268.class);
        return new ScannerContainerMenu(windowId, inventory, hand, new ScannerContainer(inventory.field_7546.method_5998(hand)));
    }

    // --------------------------------------------------------------------- //

    private final class_1657 player;
    private final class_1268 hand;
    private final class_1799 stack;

    // --------------------------------------------------------------------- //

    public ScannerContainerMenu(final int windowId, final class_1661 inventory, final class_1268 hand, final ScannerContainer itemHandler) {
        super(Containers.SCANNER_CONTAINER.get(), windowId);

        this.player = inventory.field_7546;
        this.hand = hand;
        this.stack = player.method_5998(hand);

        final class_1263 activeModules = itemHandler.getActiveModules();
        for (int slot = 0; slot < activeModules.method_5439(); ++slot) {
            method_7621(new ScannerSlot(activeModules, slot, 62 + slot * 18, 20));
        }

        final class_1263 storedModules = itemHandler.getInactiveModules();
        for (int slot = 0; slot < storedModules.method_5439(); ++slot) {
            method_7621(new ScannerSlot(storedModules, slot, 62 + slot * 18, 46));
        }

        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                method_7621(new ScannerSlot(inventory, col + row * 9 + 9, 8 + col * 18, row * 18 + 77));
            }
        }

        for (int slot = 0; slot < 9; ++slot) {
            method_7621(new ScannerSlot(inventory, slot, 8 + slot * 18, 135));
        }
    }

    public class_1657 getPlayer() {
        return player;
    }

    public class_1268 getHand() {
        return hand;
    }

    // --------------------------------------------------------------------- //
    // Container

    @Override
    public boolean method_7597(final class_1657 player) {
        return player == this.player && class_1799.method_7973(player.method_5998(hand), stack);
    }

    @Override
    public class_1799 method_7601(final class_1657 player, final int index) {
        final class_1735 from = field_7761.get(index);
        final class_1799 stack = from.method_7677().method_7972();
        if (stack.method_7960()) {
            return class_1799.field_8037;
        }

        final boolean intoPlayerInventory = from.field_7871 != player.method_31548();
        final class_1799 fromStack = from.method_7677();

        final int step, begin;
        if (intoPlayerInventory) {
            step = -1;
            begin = field_7761.size() - 1;
        } else {
            step = 1;
            begin = 0;
        }

        if (fromStack.method_7914() > 1) {
            for (int i = begin; i >= 0 && i < field_7761.size(); i += step) {
                final class_1735 into = field_7761.get(i);
                if (into.field_7871 == from.field_7871) {
                    continue;
                }

                final class_1799 intoStack = into.method_7677();
                if (intoStack.method_7960()) {
                    continue;
                }

                final boolean itemsAreEqual = class_1799.method_31577(fromStack, intoStack);
                if (!itemsAreEqual) {
                    continue;
                }

                final int maxSizeInSlot = Math.min(fromStack.method_7914(), into.method_7676(stack));
                final int spaceInSlot = maxSizeInSlot - intoStack.method_7947();
                if (spaceInSlot <= 0) {
                    continue;
                }

                final int itemsMoved = Math.min(spaceInSlot, fromStack.method_7947());
                if (itemsMoved <= 0) {
                    continue;
                }

                intoStack.method_7933(from.method_7671(itemsMoved).method_7947());
                into.method_7668();

                if (from.method_7677().method_7960()) {
                    break;
                }
            }
        }

        for (int i = begin; i >= 0 && i < field_7761.size(); i += step) {
            if (from.method_7677().method_7960()) {
                break;
            }

            final class_1735 into = field_7761.get(i);
            if (into.field_7871 == from.field_7871) {
                continue;
            }

            if (into.method_7681()) {
                continue;
            }

            if (!into.method_7680(fromStack)) {
                continue;
            }

            final int maxSizeInSlot = Math.min(fromStack.method_7914(), into.method_7676(fromStack));
            final int itemsMoved = Math.min(maxSizeInSlot, fromStack.method_7947());
            into.method_7673(from.method_7671(itemsMoved));
        }

        return from.method_7677().method_7947() < stack.method_7947() ? from.method_7677() : class_1799.field_8037;
    }
}
