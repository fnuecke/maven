@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.util;

import javax.annotation.ParametersAreNonnullByDefault;
