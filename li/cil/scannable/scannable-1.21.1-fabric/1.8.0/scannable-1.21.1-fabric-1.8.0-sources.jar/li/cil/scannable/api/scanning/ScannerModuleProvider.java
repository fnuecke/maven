/* SPDX-License-Identifier: MIT */

package li.cil.scannable.api.scanning;

import java.util.Optional;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;

/**
 * Implement this interface on an {@link class_1792} to have the mod treat it as a scanner module.
 */
public interface ScannerModuleProvider extends class_1935 {
    /**
     * Return the module implementation associated with this scanner module.
     * <p/>
     * The passed {@code module} should be of this {@link class_1792} instance.
     *
     * @param module the item stack representing a module.
     * @return the module implementation of this item.
     */
    Optional<ScannerModule> getScannerModule(final class_1799 module);
}
