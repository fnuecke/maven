/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.gui;

import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.container.EntityModuleContainerMenu;
import li.cil.scannable.common.item.ConfigurableEntityScannerModuleItem;
import li.cil.scannable.common.network.Network;
import li.cil.scannable.common.network.message.SetConfiguredModuleItemAtMessage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4048;
import net.minecraft.class_4587;
import net.minecraft.class_7923;
import net.minecraft.class_898;
import org.joml.Quaternionf;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static li.cil.scannable.util.UnitConversion.toRadians;

@Environment(EnvType.CLIENT)
public class ConfigurableEntityScannerModuleContainerScreen extends AbstractConfigurableScannerModuleContainerScreen<EntityModuleContainerMenu, class_1299<?>> {
    private static final Map<class_1299<?>, class_1297> RENDER_ENTITIES = new HashMap<>();

    public ConfigurableEntityScannerModuleContainerScreen(final EntityModuleContainerMenu container, final class_1661 inventory, final class_2561 title) {
        super(container, inventory, title, Strings.GUI_ENTITIES_LIST_CAPTION);
    }

    // --------------------------------------------------------------------- //

    @Override
    protected List<class_1299<?>> getConfiguredItems(final class_1799 stack) {
        return ConfigurableEntityScannerModuleItem.getEntityTypes(stack);
    }

    @Override
    protected class_2561 getItemName(final class_1299<?> entityType) {
        return entityType.method_5897();
    }

    @Override
    protected void renderConfiguredItem(final class_332 graphics, final class_1299<?> entityType, final int x, final int y) {
        renderEntity(graphics, x + 8, y + 13, entityType);
    }

    @Override
    protected void configureItemAt(final class_1799 stack, final int slot, final class_1799 value) {
        if (value.method_7909() instanceof class_1826) {
            final class_1299<?> entityType = ((class_1826) value.method_7909()).method_8015(value);
            class_7923.field_41177.method_29113(entityType).ifPresent(entityTypeResourceKey ->
                    Network.sendToServer(new SetConfiguredModuleItemAtMessage(field_2797.field_7763, slot, entityTypeResourceKey.method_29177())));
        }
    }

    private void renderEntity(final class_332 graphics, final int x, final int y, final class_1299<?> entityType) {
        final class_1297 entity = getRenderEntity(entityType);
        if (entity == null) {
            return;
        }

        entity.method_51502(field_2797.getPlayer().method_37908());
        final class_4048 bounds = entityType.method_18386();
        final float size = Math.max(bounds.comp_2185(), bounds.comp_2186());
        final float scale = 11.0f / size;

        final class_4587 poseStack = graphics.method_51448();
        poseStack.method_22903();

        poseStack.method_46416(x, y, 100);
        poseStack.method_22905(scale, scale, scale);
        final var quaternion = new Quaternionf().rotationZ(toRadians(180));
        quaternion.mul(new Quaternionf().rotationX(toRadians(20)));
        quaternion.mul(new Quaternionf().rotationY(toRadians(30)));
        poseStack.method_22907(quaternion);

        final class_898 renderManager = class_310.method_1551().method_1561();
        quaternion.conjugate();
        renderManager.method_24196(quaternion);
        renderManager.method_3948(false);

        renderManager.method_3954(entity, 0, 0, 0, 0, 1, poseStack, graphics.method_51450(), 0xf000f0);

        renderManager.method_3948(true);
        poseStack.method_22909();
    }

    @Nullable
    private class_1297 getRenderEntity(final class_1299<?> entityType) {
        return RENDER_ENTITIES.computeIfAbsent(entityType, t -> t.method_5883(field_2797.getPlayer().method_37908()));
    }
}
