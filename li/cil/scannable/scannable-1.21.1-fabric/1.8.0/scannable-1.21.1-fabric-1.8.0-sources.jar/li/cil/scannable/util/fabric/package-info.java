@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.util.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
