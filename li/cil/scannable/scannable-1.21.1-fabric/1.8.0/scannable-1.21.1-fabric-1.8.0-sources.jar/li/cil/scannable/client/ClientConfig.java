/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import li.cil.scannable.common.tags.CommonTags;
import li.cil.scannable.util.config.*;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_3486;
import net.minecraft.class_3620;

@Type(ConfigType.CLIENT)
public final class ClientConfig {
    @WorldRestart
    @Comment("""
        The colors for blocks used when rendering their result bounding box
        by block name. Each entry must be a key-value pair separated by a `=`,
        with the key being the tag name and the value being the hexadecimal
        RGB value of the color.""")
    @KeyValueTypes(keyType = class_2960.class, valueType = int.class,
        valueSerializer = @CustomSerializer(serializer = "toHexString", deserializer = "fromHexString"))
    public static Object2IntMap<class_2960> blockColors = new Object2IntOpenHashMap<>();

    @WorldRestart
    @Comment("The colors for blocks used when rendering their result bounding box\n" +
        "by block tag. See `blockColors` for format entries have to be in.")
    @KeyValueTypes(keyType = class_2960.class, valueType = int.class,
        valueSerializer = @CustomSerializer(serializer = "toHexString", deserializer = "fromHexString"))
    public static Object2IntMap<class_2960> blockTagColors = getDefaultBlockTagColors();

    @WorldRestart
    @Comment("The colors for fluids used when rendering their result bounding box\n" +
        "by fluid name. See `blockColors` for format entries have to be in.")
    @KeyValueTypes(keyType = class_2960.class, valueType = int.class,
        valueSerializer = @CustomSerializer(serializer = "toHexString", deserializer = "fromHexString"))
    public static Object2IntMap<class_2960> fluidColors = new Object2IntOpenHashMap<>();

    @WorldRestart
    @Comment("The colors for fluids used when rendering their result bounding box\n" +
        "by fluid tag. See `blockColors` for format entries have to be in.")
    @KeyValueTypes(keyType = class_2960.class, valueType = int.class,
        valueSerializer = @CustomSerializer(serializer = "toHexString", deserializer = "fromHexString"))
    public static Object2IntMap<class_2960> fluidTagColors = class_156.method_654(new Object2IntOpenHashMap<>(), c -> {
        c.put(class_3486.field_15517.comp_327(), class_3620.field_16019.field_16011);
        c.put(class_3486.field_15518.comp_327(), class_3620.field_15981.field_16011);
    });

    @SuppressWarnings("unused") // Referenced in annotations.
    public static String toHexString(final Object value) {
        return "0x" + Integer.toHexString((int) value);
    }

    @SuppressWarnings("unused") // Referenced in annotations.
    public static Object fromHexString(final String value) {
        return Integer.decode(value);
    }

    private static Object2IntMap<class_2960> getDefaultBlockTagColors() {
        return class_156.method_654(new Object2IntOpenHashMap<>(), c -> {
            // Minecraft
            c.put(CommonTags.ORES_COAL.comp_327(), class_3620.field_15978.field_16011);
            c.put(CommonTags.ORES_IRON.comp_327(), class_3620.field_15977.field_16011); // MaterialColor.IRON is also gray, so...
            c.put(CommonTags.ORES_GOLD.comp_327(), class_3620.field_15994.field_16011);
            c.put(CommonTags.ORES_LAPIS.comp_327(), class_3620.field_15980.field_16011);
            c.put(CommonTags.ORES_DIAMOND.comp_327(), class_3620.field_15983.field_16011);
            c.put(CommonTags.ORES_REDSTONE.comp_327(), class_3620.field_16020.field_16011);
            c.put(CommonTags.ORES_EMERALD.comp_327(), class_3620.field_16001.field_16011);
            c.put(CommonTags.ORES_QUARTZ.comp_327(), class_3620.field_16025.field_16011);

            // Common modded ores
            c.put(CommonTags.ORES_TIN.comp_327(), class_3620.field_16026.field_16011);
            c.put(CommonTags.ORES_COPPER.comp_327(), class_3620.field_15981.field_16011);
            c.put(CommonTags.ORES_LEAD.comp_327(), class_3620.field_16015.field_16011);
            c.put(CommonTags.ORES_SILVER.comp_327(), class_3620.field_15993.field_16011);
            c.put(CommonTags.ORES_NICKEL.comp_327(), class_3620.field_16024.field_16011);
            c.put(CommonTags.ORES_PLATINUM.comp_327(), class_3620.field_16003.field_16011);
            c.put(CommonTags.ORES_MITHRIL.comp_327(), class_3620.field_16014.field_16011);
        });
    }
}
