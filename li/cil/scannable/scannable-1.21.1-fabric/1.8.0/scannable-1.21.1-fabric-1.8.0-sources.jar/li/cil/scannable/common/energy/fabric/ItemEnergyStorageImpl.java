/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.energy.fabric;

import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.energy.ItemEnergyStorage;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.base.SingleStackStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1799;
import team.reborn.energy.api.EnergyStorage;

import java.util.Optional;

public final class ItemEnergyStorageImpl {
    public static Optional<ItemEnergyStorage> of(final class_1799 container) {
        if (!ServerConfig.useEnergy) {
            return Optional.empty();
        }

        final ContainerItemContext context = ContainerItemContext.ofSingleSlot(new SingleStackStorage() {
            private class_1799 current = container;

            @Override
            protected class_1799 getStack() {
                return current;
            }

            @Override
            protected void setStack(final class_1799 stack) {
                current = stack;
            }

            @Override
            protected void onFinalCommit() {
                container.method_57366(current.method_57380());
            }
        });

        return Optional.ofNullable(context.find(EnergyStorage.ITEM))
            .map(storage -> new ItemEnergyStorage() {
                @Override
                public long receiveEnergy(final long amount, final boolean simulate) {
                    final long inserted;
                    try (Transaction transaction = Transaction.openOuter()) {
                        inserted = storage.insert(amount, transaction);
                        if (!simulate)
                            transaction.commit();
                    }
                    return inserted;
                }

                @Override
                public long extractEnergy(final long amount, final boolean simulate) {
                    final long extracted;
                    try (Transaction transaction = Transaction.openOuter()) {
                        extracted = storage.extract(amount, transaction);
                        if (!simulate)
                            transaction.commit();
                    }
                    return extracted;
                }

                @Override
                public long getEnergyStored() {
                    return storage.getAmount();
                }

                @Override
                public long getMaxEnergyStored() {
                    return storage.getCapacity();
                }
            });
    }
}
