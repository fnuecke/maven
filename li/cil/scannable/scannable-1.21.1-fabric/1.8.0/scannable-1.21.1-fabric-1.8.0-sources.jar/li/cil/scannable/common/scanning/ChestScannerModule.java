/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.BlockScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.BlockCacheScanFilter;
import li.cil.scannable.client.scanning.filter.BlockScanFilter;
import li.cil.scannable.client.scanning.filter.BlockTagScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public enum ChestScannerModule implements BlockScannerModule {
    INSTANCE;

    private Predicate<class_2680> filter;

    public static void clearCache() {
        INSTANCE.filter = null;
    }

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleChest;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.BLOCKS.get();
    }

    @Environment(EnvType.CLIENT)
    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleChest;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public Predicate<class_2680> getFilter(final class_1799 module) {
        validateFilter();
        return filter;
    }

    @Environment(EnvType.CLIENT)
    private void validateFilter() {
        if (filter != null) {
            return;
        }

        final List<Predicate<class_2680>> filters = new ArrayList<>();
        for (final class_2960 location : ServerConfig.commonChestBlocks) {
            class_7923.field_41175.method_17966(location).ifPresent(block ->
                filters.add(new BlockScanFilter(block)));
        }
        class_7923.field_41175.method_40273().forEach(tag -> {
            if (ServerConfig.commonChestTags.contains(tag.comp_327())) {
                filters.add(new BlockTagScanFilter(tag));
            }
        });
        filter = new BlockCacheScanFilter(filters);
    }
}
