/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.config;

import li.cil.scannable.common.tags.CommonTags;
import li.cil.scannable.util.config.*;
import net.minecraft.class_156;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.HashSet;
import java.util.Set;

@Type(ConfigType.SERVER)
public final class ServerConfig {
    @Path("energy") @WorldRestart
    @Comment("Whether to consume energy when performing a scan. Will make the scanner a chargeable item.")
    public static boolean useEnergy = true;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy that can be stored in a scanner.")
    public static int energyCapacityScanner = 5000;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the range module per scan.")
    public static int energyCostModuleRange = 100;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the animal module per scan.")
    public static int energyCostModuleAnimal = 25;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the monster module per scan.")
    public static int energyCostModuleMonster = 50;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the common ore module per scan.")
    public static int energyCostModuleOreCommon = 75;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the rare ore module per scan.")
    public static int energyCostModuleOreRare = 100;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the block module per scan.")
    public static int energyCostModuleBlock = 100;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the fluid module per scan.")
    public static int energyCostModuleFluid = 50;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the entity module per scan.")
    public static int energyCostModuleEntity = 75;

    @Path("energy") @WorldRestart @Min(0)
    @Comment("Amount of energy used by the chest module per scan.")
    public static int energyCostModuleChest = 100;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative amount of base scan radius added by each installed range module.")
    public static float rangeModifierModuleRange = 0.5f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the common ore module.")
    public static float rangeModifierModuleOreCommon = 0.25f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the rare ore module.")
    public static float rangeModifierModuleOreRare = 0.25f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the block module.")
    public static float rangeModifierModuleBlock = 0.5f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the fluid module.")
    public static float rangeModifierModuleFluid = 0.5f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the chest module.")
    public static float rangeModifierModuleChest = 0.25f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the animal module.")
    public static float rangeModifierModuleAnimal = 1.0f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the monster module.")
    public static float rangeModifierModuleMonster = 1.0f;

    @Path("range") @WorldRestart @Min(0) @Max(1)
    @Comment("Relative effective range of the entity module.")
    public static float rangeModifierModuleEntity = 1.0f;

    // TODO Migrate to range category in next major version.
    @Path("general") @WorldRestart @Min(16) @Max(128)
    @Comment("The basic scan radius without range modules. Higher values mean more computational\n" +
        "overhead and thus potentially worse performance while scanning.")
    public static int baseScanRadius = 64;

    @Path("general") @Min(1000) @Max(60000 * 5)
    @Comment("How long the results from a scan should remain visible, in milliseconds.")
    public static int scanStayDuration = 10000;

    @Path("blocks") @WorldRestart
    @Comment("""
        Registry names of blocks that should be ignored.
        Blocks in this list will be excluded from the default ore list based on the c:ores
        tag and it will be impossible to tune the entity module to this block.""")
    @ItemType(class_2960.class)
    public static Set<class_2960> ignoredBlocks = class_156.method_654(new HashSet<>(), c -> {
        c.add(class_7923.field_41175.method_10221(class_2246.field_10525));
    });

    @Path("blocks") @WorldRestart
    @Comment("""
        Tag names of block tags that should be ignored.
        Blocks matching a tag in this list will be excluded from the default ore list based on the
        c:ores tag and it will be impossible to tune the entity module to this block.""")
    @ItemType(class_2960.class)
    public static Set<class_2960> ignoredBlockTags = new HashSet<>();

    @Path("ores") @WorldRestart
    @Comment("Registry names of blocks considered 'common ores', requiring the common ore scanner module.")
    @ItemType(class_2960.class)
    public static Set<class_2960> commonOreBlocks = class_156.method_654(new HashSet<>(), c -> {
        c.add(class_7923.field_41175.method_10221(class_2246.field_10460));
    });

    @Path("ores") @WorldRestart
    @Comment("Block tags of blocks considered 'common ores', requiring the common ore scanner module.")
    @ItemType(class_2960.class)
    public static Set<class_2960> commonOreBlockTags = getDefaultCommonOreTags();

    @Path("ores") @WorldRestart
    @Comment("Registry names of blocks considered 'rare ores', requiring the rare ore scanner module.")
    @ItemType(class_2960.class)
    public static Set<class_2960> rareOreBlocks = class_156.method_654(new HashSet<>(), c -> {
        c.add(class_7923.field_41175.method_10221(class_2246.field_10171));
    });

    @Path("ores") @WorldRestart
    @Comment("""
        Block tags of blocks considered 'rare ores', requiring the common ore scanner module.
        Any block with the c:ores tag is implicitly in this list, unless the block also
        matches an ignored or common ore block tag, or is an ignored or common block.""")
    @ItemType(class_2960.class)
    public static Set<class_2960> rareOreBlockTags = new HashSet<>();

    @Path("fluids") @WorldRestart
    @Comment("Fluid tags of fluids that should be ignored.")
    @ItemType(class_2960.class)
    public static Set<class_2960> ignoredFluidTags = new HashSet<>();

    @Path("chests") @WorldRestart
    @Comment("Registry names of blocks considered 'chests', requiring the chest scanner module.")
    @ItemType(class_2960.class)
    public static Set<class_2960> commonChestBlocks = new HashSet<>();

    @Path("chests") @WorldRestart
    @Comment("Registry names of blocks considered 'chests', requiring the chest scanner module.")
    @ItemType(class_2960.class)
    public static Set<class_2960> commonChestTags = getDefaultChestsTags();

    private static Set<class_2960> getDefaultCommonOreTags() {
        return class_156.method_654(new HashSet<>(), c -> {
            c.add(CommonTags.ORES_COAL.comp_327());
            c.add(CommonTags.ORES_IRON.comp_327());
            c.add(CommonTags.ORES_REDSTONE.comp_327());
            c.add(CommonTags.ORES_QUARTZ.comp_327());
            c.add(CommonTags.ORES_COPPER.comp_327());
            c.add(CommonTags.ORES_TIN.comp_327());
        });
    }

    private static Set<class_2960> getDefaultChestsTags() {
        return class_156.method_654(new HashSet<>(), c -> {
            c.add(CommonTags.CHESTS.comp_327());
            c.add(CommonTags.BARRELS_WOODEN.comp_327());
            c.add(CommonTags.SHULKER_BOXES.comp_327());
        });
    }
}
