/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import java.util.Objects;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public record EntityTypeScanFilter(class_1299<?> entityType) implements Predicate<class_1297> {
    @Override
    public boolean test(final class_1297 entity) {
        return Objects.equals(entityType, entity.method_5864());
    }
}
