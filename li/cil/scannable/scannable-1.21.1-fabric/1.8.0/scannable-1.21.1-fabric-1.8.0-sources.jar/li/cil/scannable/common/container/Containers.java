/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.container;

import dev.architectury.registry.menu.MenuRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.scannable.util.RegistryUtils;
import net.minecraft.class_3917;
import net.minecraft.class_7924;

public final class Containers {
    public static final DeferredRegister<class_3917<?>> CONTAINERS = RegistryUtils.get(class_7924.field_41207);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_3917<ScannerContainerMenu>> SCANNER_CONTAINER = CONTAINERS.register("scanner", () -> MenuRegistry.ofExtended(ScannerContainerMenu::create));
    public static final RegistrySupplier<class_3917<BlockModuleContainerMenu>> BLOCK_MODULE_CONTAINER = CONTAINERS.register("block_module", () -> MenuRegistry.ofExtended(BlockModuleContainerMenu::create));
    public static final RegistrySupplier<class_3917<EntityModuleContainerMenu>> ENTITY_MODULE_CONTAINER = CONTAINERS.register("entity_module", () -> MenuRegistry.ofExtended(EntityModuleContainerMenu::create));

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }
}
