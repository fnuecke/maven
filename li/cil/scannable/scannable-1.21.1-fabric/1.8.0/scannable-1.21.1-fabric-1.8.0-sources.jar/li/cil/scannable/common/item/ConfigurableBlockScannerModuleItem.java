/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item;

import dev.architectury.registry.menu.MenuRegistry;
import li.cil.scannable.common.config.Constants;
import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.container.BlockModuleContainerMenu;
import li.cil.scannable.common.scanning.ConfigurableBlockScannerModule;
import li.cil.scannable.common.scanning.filter.IgnoredBlocks;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public final class ConfigurableBlockScannerModuleItem extends ScannerModuleItem {
    public static boolean isLocked(final class_1799 stack) {
        return stack.method_57825(ModDataComponents.LOCKED.get(), false);
    }

    public static List<class_2248> getBlocks(final class_1799 stack) {
        final List<class_2960> ids = getBlockIds(stack);
        if (ids.isEmpty()) {
            return Collections.emptyList();
        }

        final List<class_2248> result = new ArrayList<>(ids.size());
        for (final class_2960 id : ids) {
            class_7923.field_41175.method_17966(id).ifPresent(result::add);
        }

        return result;
    }

    public static boolean addBlock(final class_1799 stack, final class_2248 block) {
        final Optional<class_5321<class_2248>> registryName = class_7923.field_41175.method_29113(block);
        if (registryName.isEmpty()) {
            return false;
        }

        if (isLocked(stack)) {
            return false;
        }

        final class_2960 id = registryName.get().method_29177();
        final List<class_2960> ids = new ArrayList<>(getBlockIds(stack));
        if (ids.contains(id)) {
            return true;
        }
        if (ids.size() >= Constants.CONFIGURABLE_MODULE_SLOTS) {
            return false;
        }

        ids.add(id);
        setBlockIds(stack, ids);
        return true;
    }

    public static void setBlockAt(final class_1799 stack, final int index, final class_2248 block) {
        if (index < 0 || index >= Constants.CONFIGURABLE_MODULE_SLOTS) {
            return;
        }

        final Optional<class_5321<class_2248>> registryName = class_7923.field_41175.method_29113(block);
        if (registryName.isEmpty()) {
            return;
        }

        if (isLocked(stack)) {
            return;
        }

        final class_2960 id = registryName.get().method_29177();
        final List<class_2960> ids = new ArrayList<>(getBlockIds(stack));
        final int oldIndex = ids.indexOf(id);
        if (oldIndex == index) {
            return;
        }

        if (index >= ids.size()) {
            ids.add(id);
        } else {
            ids.set(index, id);
        }

        if (oldIndex >= 0) {
            ids.remove(oldIndex);
        }

        setBlockIds(stack, ids);
    }

    public static void removeBlockAt(final class_1799 stack, final int index) {
        if (index < 0 || index >= Constants.CONFIGURABLE_MODULE_SLOTS) {
            return;
        }

        if (isLocked(stack)) {
            return;
        }

        final List<class_2960> ids = new ArrayList<>(getBlockIds(stack));
        if (index < ids.size()) {
            ids.remove(index);
            setBlockIds(stack, ids);
        }
    }

    // --------------------------------------------------------------------- //

    private static List<class_2960> getBlockIds(final class_1799 stack) {
        return stack.method_57825(ModDataComponents.BLOCKS.get(), Collections.emptyList());
    }

    private static void setBlockIds(final class_1799 stack, final List<class_2960> ids) {
        stack.method_57379(ModDataComponents.BLOCKS.get(), List.copyOf(ids));
    }

    // --------------------------------------------------------------------- //

    public ConfigurableBlockScannerModuleItem() {
        super(ConfigurableBlockScannerModule.INSTANCE);
    }

    // --------------------------------------------------------------------- //
    // Item

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flag) {
        super.method_7851(stack, context, tooltip, flag);

        final List<class_2248> blocks = getBlocks(stack);
        if (!blocks.isEmpty()) {
            tooltip.add(Strings.TOOLTIP_BLOCKS_LIST_CAPTION);
            blocks.forEach(b -> tooltip.add(Strings.listItem(b.method_9518())));
        }
    }

    @Override
    public class_1271<class_1799> method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        final class_1799 stack = player.method_5998(hand);
        if (player.method_5715()) {
            return class_1271.method_22430(stack);
        }

        if (!level.method_8608() && player instanceof class_3222 serverPlayer) {
            MenuRegistry.openExtendedMenu(serverPlayer, new class_3908() {
                @Override
                public class_2561 method_5476() {
                    return stack.method_7964();
                }

                @Override
                public class_1703 createMenu(final int id, final class_1661 inventory, final class_1657 player) {
                    return new BlockModuleContainerMenu(id, inventory, hand);
                }
            }, buffer -> buffer.method_10817(hand));
        }

        return class_1271.method_22427(stack);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1937 level = context.method_8045();
        if (level.method_22347(context.method_8037())) {
            return class_1269.field_5811;
        }

        final class_1657 player = context.method_8036();
        if (player == null) {
            return class_1269.field_5811;
        }

        final class_1799 stack = context.method_8041();
        final class_2680 state = level.method_8320(context.method_8037());

        if (IgnoredBlocks.contains(state)) {
            if (!level.method_8608()) {
                player.method_7353(Strings.MESSAGE_BLOCK_IGNORED, true);
            }
            player.method_7357().method_7906(this, 10);
            return class_1269.method_29236(context.method_8045().method_8608());
        }

        if (!addBlock(stack, state.method_26204())) {
            if (!level.method_8608() && !ConfigurableBlockScannerModuleItem.isLocked(stack)) {
                player.method_7353(Strings.MESSAGE_NO_FREE_SLOTS, true);
            }
        }

        // Always succeed to prevent opening item UI.
        return class_1269.method_29236(context.method_8045().method_8608());
    }
}
