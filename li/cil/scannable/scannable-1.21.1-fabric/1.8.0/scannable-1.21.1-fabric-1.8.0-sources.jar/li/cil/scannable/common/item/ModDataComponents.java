/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.item;

import com.mojang.serialization.Codec;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.scannable.util.RegistryUtils;
import net.minecraft.class_2960;
import net.minecraft.class_7924;
import net.minecraft.class_9135;
import net.minecraft.class_9288;
import net.minecraft.class_9331;
import java.util.List;

/**
 * Item data components replacing the item NBT used before MC 1.20.5.
 */
public final class ModDataComponents {
    private static final DeferredRegister<class_9331<?>> COMPONENTS = RegistryUtils.get(class_7924.field_49659);

    // --------------------------------------------------------------------- //

    /**
     * Modules stored inside a scanner.
     */
    public static final RegistrySupplier<class_9331<class_9288>> MODULES = COMPONENTS.register("modules", () ->
        class_9331.<class_9288>method_57873()
            .method_57881(class_9288.field_49335)
            .method_57882(class_9288.field_49336)
            .method_57880());

    /**
     * Blocks configured on a configurable block scanner module.
     */
    public static final RegistrySupplier<class_9331<List<class_2960>>> BLOCKS = COMPONENTS.register("blocks", ModDataComponents::resourceLocationList);

    /**
     * Entity types configured on a configurable entity scanner module.
     */
    public static final RegistrySupplier<class_9331<List<class_2960>>> ENTITY_TYPES = COMPONENTS.register("entity_types", ModDataComponents::resourceLocationList);

    /**
     * Set on configurable modules that may not be reconfigured.
     */
    public static final RegistrySupplier<class_9331<Boolean>> LOCKED = COMPONENTS.register("locked", () ->
        class_9331.<Boolean>method_57873()
            .method_57881(Codec.BOOL)
            .method_57882(class_9135.field_48547)
            .method_57880());

    /**
     * Energy stored in a scanner. Only used on NeoForge; on Fabric the energy API
     * brings its own component.
     */
    public static final RegistrySupplier<class_9331<Integer>> ENERGY = COMPONENTS.register("energy", () ->
        class_9331.<Integer>method_57873()
            .method_57881(Codec.INT)
            .method_57882(class_9135.field_48550)
            .method_57880());

    // --------------------------------------------------------------------- //

    public static void initialize() {
    }

    // --------------------------------------------------------------------- //

    private static class_9331<List<class_2960>> resourceLocationList() {
        return class_9331.<List<class_2960>>method_57873()
            .method_57881(class_2960.field_25139.listOf())
            .method_57882(class_2960.field_48267.method_56433(class_9135.method_56363()))
            .method_57880();
    }

    private ModDataComponents() {
    }
}
