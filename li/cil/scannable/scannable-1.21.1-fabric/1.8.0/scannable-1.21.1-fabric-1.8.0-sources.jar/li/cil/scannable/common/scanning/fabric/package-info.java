@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.scanning.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
