@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.config;

import javax.annotation.ParametersAreNonnullByDefault;
