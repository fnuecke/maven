/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.container;

import li.cil.scannable.common.item.ConfigurableBlockScannerModuleItem;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class BlockModuleContainerMenu extends AbstractModuleContainerMenu {
    public static BlockModuleContainerMenu create(final int id, final class_1661 playerInventory, final class_2540 data) {
        final class_1268 hand = data.method_10818(class_1268.class);
        return new BlockModuleContainerMenu(id, playerInventory, hand);
    }

    // --------------------------------------------------------------------- //

    public BlockModuleContainerMenu(final int windowId, final class_1661 inventory, final class_1268 hand) {
        super(Containers.BLOCK_MODULE_CONTAINER.get(), windowId, inventory, hand);
    }

    @Override
    public void removeItemAt(final int index) {
        ConfigurableBlockScannerModuleItem.removeBlockAt(getPlayer().method_5998(getHand()), index);
    }

    @Override
    public void setItemAt(final int index, final class_2960 name) {
        class_7923.field_41175.method_17966(name).ifPresent(block -> {
            final class_1799 stack = getPlayer().method_5998(getHand());
            ConfigurableBlockScannerModuleItem.setBlockAt(stack, index, block);
        });
    }
}
