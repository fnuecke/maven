/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.renderer;

import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.architectury.injectables.annotations.ExpectPlatform;
import li.cil.scannable.client.ScanManager;
import li.cil.scannable.client.shader.Shaders;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_5944;
import net.minecraft.class_6364;
import net.minecraft.class_6367;
import net.minecraft.class_8251;
import org.joml.Matrix4f;

import static org.lwjgl.opengl.GL11.GL_NONE;
import static org.lwjgl.opengl.GL11.glDrawBuffer;
import static org.lwjgl.opengl.GL30.GL_FRAMEBUFFER;
import static org.lwjgl.opengl.GL30.glBindFramebuffer;

@Environment(EnvType.CLIENT)
public enum ScannerRenderer {
    INSTANCE;

    // --------------------------------------------------------------------- //

    private DepthOnlyRenderTarget mainCameraDepth = new DepthOnlyRenderTarget(class_6364.field_33724, class_6364.field_33725);

    // --------------------------------------------------------------------- //

    private long currentStart;
    private class_243 currentCenter;

    // --------------------------------------------------------------------- //

    public void ping(final class_243 pos) {
        currentStart = System.currentTimeMillis();
        currentCenter = pos;
    }

    public static void render(final Matrix4f viewMatrix, final Matrix4f projectionMatrix) {
        INSTANCE.doRender(viewMatrix, projectionMatrix);
    }

    private void doRender(final Matrix4f viewMatrix, final Matrix4f projectionMatrix) {
        if (shouldRender()) {
            grabDepthBuffer();
            renderEffect(viewMatrix, projectionMatrix);
        }
    }

    private boolean shouldRender() {
        final int adjustedDuration = ScanManager.computeScanGrowthDuration();
        return currentStart > 0 && adjustedDuration > (int) (System.currentTimeMillis() - currentStart);
    }

    private void grabDepthBuffer() {
        final class_276 mainRenderTarget = class_310.method_1551().method_1522();
        if (mainRenderTarget.field_1482 != mainCameraDepth.field_1482 || mainRenderTarget.field_1481 != mainCameraDepth.field_1481) {
            mainCameraDepth.method_1234(mainRenderTarget.field_1482, mainRenderTarget.field_1481, class_310.field_1703);
        }
        mainCameraDepth = ScannerRenderer.copyBufferSettings(mainRenderTarget, mainCameraDepth);
        mainCameraDepth.method_29329(mainRenderTarget);
        mainRenderTarget.method_1235(false);
    }

    private void renderEffect(final Matrix4f viewMatrix, final Matrix4f projectionMatrix) {
        final class_5944 shader = Shaders.getScanEffectShader();
        if (shader == null) {
            return;
        }

        final class_276 target = class_310.method_1551().method_1522();

        updateShaderUniforms(shader, viewMatrix, projectionMatrix);

        blit(target);
    }

    private void updateShaderUniforms(final class_5944 shader, final Matrix4f viewMatrix, final Matrix4f projectionMatrix) {
        final Matrix4f invertedViewMatrix = new Matrix4f(viewMatrix);
        invertedViewMatrix.invert();

        // Must be the projection used for level rendering; RenderSystem's current
        // projection is not guaranteed to be that at the point we render from.
        final Matrix4f invertedProjectionMatrix = new Matrix4f(projectionMatrix);
        invertedProjectionMatrix.invert();

        final class_243 cameraPosition = class_310.method_1551().field_1773.method_19418().method_19326();

        final int adjustedDuration = ScanManager.computeScanGrowthDuration();
        final float radius = ScanManager.computeRadius(currentStart, (float) adjustedDuration);

        shader.method_34583("depthTex", mainCameraDepth.method_30278());
        shader.method_35785("center").method_34413(currentCenter.method_46409());
        shader.method_35785("invViewMat").method_1250(invertedViewMatrix);
        shader.method_35785("invProjMat").method_1250(invertedProjectionMatrix);
        shader.method_35785("pos").method_34413(cameraPosition.method_46409());
        shader.method_35785("radius").method_1251(radius);
    }

    private void blit(final class_276 target) {
        final int width = target.field_1482;
        final int height = target.field_1481;

        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();

        final class_5944 oldShader = RenderSystem.getShader();
        RenderSystem.setShader(Shaders::getScanEffectShader);

        RenderSystem.backupProjectionMatrix();
        RenderSystem.setProjectionMatrix(new Matrix4f().setOrtho(0, width, 0, height, 1, 100), class_8251.field_43361);

        // This is a screen space quad, so it must not inherit the camera transform.
        // Depending on which hook we render from, the model view matrix may still hold
        // it: as of MC 1.21 LevelRenderer.renderLevel pushes the camera transform onto
        // the model view stack and only pops it at the very end. Fabric's
        // WorldRenderEvents.LAST fires before that pop, NeoForge's AFTER_LEVEL after it.
        RenderSystem.getModelViewStack().pushMatrix().identity();
        RenderSystem.applyModelViewMatrix();

        final class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        buffer.method_22912(0, 0, -50).method_22913(0, 0);
        buffer.method_22912(width, 0, -50).method_22913(1, 0);
        buffer.method_22912(width, height, -50).method_22913(1, 1);
        buffer.method_22912(0, height, -50).method_22913(0, 1);
        class_286.method_43433(buffer.method_60800());

        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();

        RenderSystem.restoreProjectionMatrix();

        RenderSystem.setShader(() -> oldShader);

        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    // --------------------------------------------------------------------- //

    public static final class DepthOnlyRenderTarget extends class_6367 {
        public DepthOnlyRenderTarget(final int width, final int height) {
            super(width, height, true, class_310.field_1703);
        }

        @Override
        public void method_1231(final int width, final int height, final boolean isOnOSX) {
            super.method_1231(width, height, isOnOSX);
            if (field_1475 > -1) {
                if (field_1476 > -1) {
                    glBindFramebuffer(GL_FRAMEBUFFER, field_1476);
                    glDrawBuffer(GL_NONE);
                    glBindFramebuffer(GL_FRAMEBUFFER, 0);
                }
                TextureUtil.releaseTextureId(this.field_1475);
                this.field_1475 = -1;
            }
        }
    }

    @SuppressWarnings("PMD.UnusedFormalParameter")
    @ExpectPlatform
    private static DepthOnlyRenderTarget copyBufferSettings(final class_276 mainRenderTarget, final DepthOnlyRenderTarget depthRenderTarget) {
        throw new AssertionError();
    }
}
