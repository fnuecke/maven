/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.scannable.api.API;
import li.cil.scannable.common.container.AbstractModuleContainerMenu;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record RemoveConfiguredModuleItemAtMessage(int windowId, int index) implements class_8710 {
    public static final class_8710.class_9154<RemoveConfiguredModuleItemAtMessage> TYPE =
        new class_8710.class_9154<>(class_2960.method_60655(API.MOD_ID, "remove_module_item"));

    public static final class_9139<class_9129, RemoveConfiguredModuleItemAtMessage> STREAM_CODEC =
        class_9139.method_56435(
            class_9135.field_48550, RemoveConfiguredModuleItemAtMessage::windowId,
            class_9135.field_48550, RemoveConfiguredModuleItemAtMessage::index,
            RemoveConfiguredModuleItemAtMessage::new);

    // --------------------------------------------------------------------- //

    public void handleMessage(final NetworkManager.PacketContext context) {
        if (context.getPlayer() instanceof class_3222 player &&
            player.field_7512 != null &&
            player.field_7512.field_7763 == windowId &&
            player.field_7512 instanceof AbstractModuleContainerMenu menu) {
            menu.removeItemAt(index);
        }
    }

    // --------------------------------------------------------------------- //
    // CustomPacketPayload

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
