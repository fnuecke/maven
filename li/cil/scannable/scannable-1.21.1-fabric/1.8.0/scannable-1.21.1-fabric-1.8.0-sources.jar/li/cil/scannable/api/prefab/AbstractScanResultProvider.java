/* SPDX-License-Identifier: MIT */

package li.cil.scannable.api.prefab;

import li.cil.scannable.api.scanning.ScanResultProvider;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;
import net.minecraft.class_757;
import org.joml.Quaternionf;

import javax.annotation.Nullable;
import java.util.Collection;

import static li.cil.scannable.util.UnitConversion.toRadians;

/**
 * Helper base class for scan result providers, providing some common
 * functionality for drawing result information.
 */
@Environment(EnvType.CLIENT)
public abstract class AbstractScanResultProvider implements ScanResultProvider {
    protected class_1657 player;
    protected class_243 center;
    protected int radius;

    // --------------------------------------------------------------------- //
    // ScanResultProvider

    @Override
    public void initialize(final class_1657 player, final Collection<class_1799> modules, final class_243 center, final float radius, final int scanTicks) {
        this.player = player;
        this.center = center;
        this.radius = (int)radius;
    }

    @Override
    public void reset() {
        player = null;
        center = null;
        radius = 0;
    }

    // --------------------------------------------------------------------- //

    /**
     * Renders an icon with a label that is only shown when looked at. This is
     * what's used to render the entity labels for example.
     *
     * @param bufferSource    the buffer source to use for batch rendering.
     * @param poseStack       the pose stack for rendering.
     * @param yaw             the interpolated yaw of the viewer.
     * @param pitch           the interpolated pitch of the viewer.
     * @param lookVec         the look vector of the viewer.
     * @param viewerEyes      the eye position of the viewer.
     * @param displayDistance the distance to show in the label. Zero or negative to hide.
     * @param resultPos       the interpolated position of the result.
     * @param icon            the icon to display.
     * @param label           the label text. May be null.
     */
    protected static void renderIconLabel(final class_4597 bufferSource, final class_4587 poseStack, final float yaw, final float pitch, final class_243 lookVec, final class_243 viewerEyes, final float displayDistance, final class_243 resultPos, final class_2960 icon, @Nullable final class_2561 label) {
        final class_243 toResult = resultPos.method_1020(viewerEyes);
        final float distance = (float) toResult.method_1033();
        final float lookDirDot = (float) lookVec.method_1026(toResult.method_1029());
        final float sqLookDirDot = lookDirDot * lookDirDot;
        final float sq2LookDirDot = sqLookDirDot * sqLookDirDot;
        final float focusScale = class_3532.method_15363(sq2LookDirDot * sq2LookDirDot + 0.005f, 0.5f, 1f);
        final float scale = distance * focusScale * 0.005f;

        poseStack.method_22903();
        poseStack.method_22904(resultPos.field_1352, resultPos.field_1351, resultPos.field_1350);
        poseStack.method_22907(new Quaternionf().rotationY(toRadians(-yaw)));
        poseStack.method_22907(new Quaternionf().rotationX(toRadians(pitch)));
        poseStack.method_22905(-scale, -scale, scale);

        if (lookDirDot > 0.999f && label != null) {
            final class_2561 text;
            if (displayDistance > 0) {
                text = withDistance(label, class_3532.method_15386(displayDistance));
            } else {
                text = label;
            }

            final class_327 font = class_310.method_1551().field_1772;
            final int width = font.method_27525(text) + 16;

            poseStack.method_22903();
            poseStack.method_46416(width / 2f, 0, 0);

            drawQuad(bufferSource.getBuffer(getRenderLayer()), poseStack, width, font.field_2000 + 5, 0, 0, 0, 0.6f);

            poseStack.method_22909();
            font.method_30882(text, 12, -4, 0xFFFFFFFF, true, poseStack.method_23760().method_23761(), bufferSource, class_327.class_6415.field_33994, 0, 0xf000f0);
            // HACK This is a workaround for text shadow rendering on top of main text in 1.20.  Can't figure out why.
            font.method_30882(text, 12, -4, 0xFFFFFFFF, false, poseStack.method_23760().method_23761(), bufferSource, class_327.class_6415.field_33994, 0, 0xf000f0);
        }

        drawQuad(bufferSource.getBuffer(getRenderLayer(icon)), poseStack, 16, 16);

        poseStack.method_22909();
    }

    // --------------------------------------------------------------------- //
    // Drawing simple primitives in an existing buffer.

    protected static void drawQuad(final class_4588 buffer, final class_4587 poseStack, final float width, final float height) {
        drawQuad(buffer, poseStack, width, height, 1, 1, 1, 1);
    }

    protected static void drawQuad(final class_4588 buffer, final class_4587 poseStack, final float width, final float height, final float r, final float g, final float b, final float a) {
        final var matrix = poseStack.method_23760().method_23761();
        buffer.method_22918(matrix, -width * 0.5f, height * 0.5f, 0).method_22915(r, g, b, a).method_22913(0, 1f);
        buffer.method_22918(matrix, width * 0.5f, height * 0.5f, 0).method_22915(r, g, b, a).method_22913(1f, 1f);
        buffer.method_22918(matrix, width * 0.5f, -height * 0.5f, 0).method_22915(r, g, b, a).method_22913(1f, 0);
        buffer.method_22918(matrix, -width * 0.5f, -height * 0.5f, 0).method_22915(r, g, b, a).method_22913(0, 0);
    }

    // --------------------------------------------------------------------- //
    // Simple render layers for result rendering.

    protected static class_1921 getRenderLayer() {
        return class_1921.method_24048("scan_result",
            class_290.field_1576,
            class_293.class_5596.field_27382, 65536,
            class_1921.class_4688.method_23598()
                .method_34578(new class_4668.class_5942(class_757::method_34540))
                .method_23615(class_1921.field_21370)
                .method_23604(class_4668.field_21346)
                .method_23616(class_4668.field_21350)
                .method_23617(false));
    }

    protected static class_1921 getRenderLayer(final class_2960 textureLocation) {
        return class_1921.method_24048("scan_result",
            class_290.field_1585,
            class_293.class_5596.field_27382, 65536,
            class_1921.class_4688.method_23598()
                .method_34578(new class_4668.class_5942(class_757::method_34542))
                .method_34577(new class_4668.class_4683(textureLocation, false, false))
                .method_23615(class_1921.field_21370)
                .method_23604(class_4668.field_21346)
                .method_23616(class_4668.field_21350)
                .method_23617(false));
    }

    // --------------------------------------------------------------------- //

    private static class_2561 withDistance(final class_2561 caption, final float distance) {
        return class_2561.method_43469("gui.scannable.overlay.distance", caption, class_3532.method_15386(distance));
    }
}
