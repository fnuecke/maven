/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.container;

import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public final class ScannerSlot extends class_1735 {
    public ScannerSlot(final class_1263 container, final int index, final int x, final int y) {
        super(container, index, x, y);
    }

    @Override
    public boolean method_7680(final class_1799 itemStack) {
        return field_7871.method_5437(field_7874, itemStack);
    }
}
