/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning;

import li.cil.scannable.api.API;
import li.cil.scannable.api.prefab.AbstractScanResultProvider;
import li.cil.scannable.api.scanning.EntityScannerModule;
import li.cil.scannable.api.scanning.ScanResult;
import li.cil.scannable.api.scanning.ScanResultRenderContext;
import li.cil.scannable.api.scanning.ScannerModule;
import li.cil.scannable.common.item.ScannerModuleItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public final class ScanResultProviderEntity extends AbstractScanResultProvider {
    private final List<ModuleFilter> filters = new ArrayList<>();
    private float maxSqRadius;
    private final ArrayList<class_1297> entities = new ArrayList<>();
    private int currentEntityIndex, entitiesStep;
    private final List<ScanResultEntity> results = new ArrayList<>();

    // --------------------------------------------------------------------- //
    // ScanResultProvider

    @Override
    public void initialize(final class_1657 player, final Collection<class_1799> modules, final class_243 center, final float radius, final int scanTicks) {
        super.initialize(player, modules, center, radius, scanTicks);

        filters.clear();
        maxSqRadius = 0;
        for (final class_1799 stack : modules) {
            final Optional<ScannerModule> capability = ScannerModuleItem.getModule(stack);
            capability.ifPresent(module -> {
                if (module instanceof EntityScannerModule entityModule) {
                    final float localRadius = entityModule.adjustLocalRange(radius);
                    final float sqRadius = localRadius * localRadius;
                    filters.add(new ModuleFilter(entityModule.getFilter(stack), entityModule, sqRadius));
                    maxSqRadius = Math.max(maxSqRadius, sqRadius);
                }
            });
        }

        entities.clear();
        for (final class_1297 entity : player.method_37908().method_31592().method_31803()) {
            entities.add(entity);
        }
        currentEntityIndex = 0;
        entitiesStep = class_3532.method_15386(entities.size() / (float) scanTicks);
    }

    @Override
    public void computeScanResults() {
        for (final int end = Math.min(currentEntityIndex + entitiesStep, entities.size()); currentEntityIndex < end; currentEntityIndex++) {
            final class_1297 entity = entities.get(currentEntityIndex);
            if (!entity.method_5805()) {
                continue;
            }

            final class_243 position = entity.method_19538();
            final double sqDistance = center.method_1025(position);
            if (sqDistance < maxSqRadius) {
                class_2960 icon = API.ICON_INFO;
                boolean hasMatch = false;
                for (final ModuleFilter filter : filters) {
                    if (sqDistance < filter.sqRadius() && filter.filter().test(entity)) {
                        hasMatch = true;
                        final Optional<class_2960> filterIcon = filter.module().getIcon(entity);
                        if (filterIcon.isPresent()) {
                            icon = filterIcon.get();
                            break;
                        }
                    }
                }
                if (hasMatch) {
                    results.add(new ScanResultEntity(entity, icon));
                }
            }
        }
    }

    @Override
    public void collectScanResults(final class_1922 level, final Consumer<ScanResult> callback) {
        results.forEach(callback);
    }

    @Override
    public void render(final ScanResultRenderContext context, final class_4597 bufferSource, final class_4587 poseStack, final class_4184 renderInfo, final float partialTicks, final List<ScanResult> results) {
        if (context != ScanResultRenderContext.GUI) {
            return;
        }

        final float yaw = renderInfo.method_19330();
        final float pitch = renderInfo.method_19329();

        final class_243 lookVec = new class_243(renderInfo.method_19335());
        final class_243 viewerEyes = renderInfo.method_19326();

        final boolean showDistance = renderInfo.method_19331().method_5715();

        // Order results by distance to center of screen (deviation from look
        // vector) so that labels we're looking at are in front of others.
        results.sort(Comparator.comparing(result -> {
            final ScanResultEntity resultEntity = (ScanResultEntity) result;
            final class_243 entityEyes = resultEntity.entity.method_5836(partialTicks);
            final class_243 toResult = entityEyes.method_1020(viewerEyes);
            return lookVec.method_1026(toResult.method_1029());
        }));

        for (final ScanResult result : results) {
            final ScanResultEntity resultEntity = (ScanResultEntity) result;
            final class_2561 name = resultEntity.entity.method_5477();
            final class_2960 icon = resultEntity.getIcon();
            final class_243 resultPos = resultEntity.entity.method_5836(partialTicks);
            final float distance = showDistance ? (float) resultPos.method_1020(viewerEyes).method_1033() : 0f;
            renderIconLabel(bufferSource, poseStack, yaw, pitch, lookVec, viewerEyes, distance, resultPos, icon, name);
        }
    }

    @Override
    public void reset() {
        super.reset();
        filters.clear();
        maxSqRadius = 0;
        currentEntityIndex = 0;
        entitiesStep = 0;
        entities.clear();
        results.clear();
    }

    // --------------------------------------------------------------------- //

    private record ModuleFilter(Predicate<class_1297> filter, EntityScannerModule module, float sqRadius) {
    }

    private record ScanResultEntity(class_1297 entity, class_2960 icon) implements ScanResult {
        public class_2960 getIcon() {
            return icon;
        }

        // --------------------------------------------------------------------- //
        // ScanResult

        @Override
        public class_243 getPosition() {
            return entity.method_19538();
        }

        @Override
        public class_238 getRenderBounds() {
            return entity.method_5830();
        }

        @Override
        public boolean isValid() {
            return entity.method_5805();
        }
    }
}
