/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.scanning.filter;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public enum FriendlyEntityScanFilter implements Predicate<class_1297> {
    INSTANCE;

    @Override
    public boolean test(final class_1297 entity) {
        return entity instanceof class_1309 &&
            !(entity instanceof class_1657) &&
            entity.method_5864().method_5891().method_6136();
    }
}
