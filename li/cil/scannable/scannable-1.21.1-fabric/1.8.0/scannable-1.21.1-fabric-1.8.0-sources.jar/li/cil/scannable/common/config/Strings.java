/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.config;

import static net.minecraft.class_124.*;

import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class Strings {
    private static final String TOOLTIP_LIST_ITEM_FORMAT = "tooltip.scannable.list_item";

    public static final class_2561 CREATIVE_TAB_TITLE = class_2561.method_43471("itemGroup.scannable.common");

    public static final class_2561 TOOLTIP_BLOCKS_LIST_CAPTION = class_2561.method_43471("item.scannable.block_module.list").method_27692(field_1080);
    public static final class_2561 TOOLTIP_ENTITIES_LIST_CAPTION = class_2561.method_43471("item.scannable.entity_module.list").method_27692(field_1080);

    public static final class_2561 GUI_BLOCKS_LIST_CAPTION = class_2561.method_43471("gui.scannable.block_module.list");
    public static final class_2561 GUI_ENTITIES_LIST_CAPTION = class_2561.method_43471("gui.scannable.entity_module.list");

    public static final class_2561 MESSAGE_NO_SCAN_MODULES = class_2561.method_43471("message.scannable.no_scan_modules").method_27692(field_1061);
    public static final class_2561 MESSAGE_NOT_ENOUGH_ENERGY = class_2561.method_43471("message.scannable.not_enough_energy").method_27692(field_1061);
    public static final class_2561 MESSAGE_NO_FREE_SLOTS = class_2561.method_43471("message.scannable.no_free_slots").method_27692(field_1061);
    public static final class_2561 MESSAGE_BLOCK_IGNORED = class_2561.method_43471("message.scannable.block_ignored").method_27692(field_1061);

    public static class_2561 listItem(final class_2561 value) {
        return class_2561.method_43469(Strings.TOOLTIP_LIST_ITEM_FORMAT, value);
    }

    public static class_2561 energyStorage(final long stored, final long capacity) {
        final class_5250 storedText = class_2561.method_43470(String.valueOf(stored)).method_27692(field_1060);
        final class_5250 capacityText = class_2561.method_43470(String.valueOf(capacity)).method_27692(field_1060);
        return class_2561.method_43469("item.scannable.scanner.energy", storedText, capacityText).method_27692(field_1080);
    }

    public static class_2561 energyUsage(final int value) {
        final class_5250 energyText = class_2561.method_43470(String.valueOf(value)).method_27692(field_1060);
        return class_2561.method_43469("tooltip.scannable.module.energy_cost", energyText).method_27692(field_1080);
    }

    public static class_2561 progress(final int value) {
        return class_2561.method_43469("gui.scannable.scanner.progress", value);
    }
}
