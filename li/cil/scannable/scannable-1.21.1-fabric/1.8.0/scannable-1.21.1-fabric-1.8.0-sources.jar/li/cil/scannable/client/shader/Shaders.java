/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import li.cil.scannable.api.API;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_3304;
import net.minecraft.class_4013;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

@Environment(EnvType.CLIENT)
public final class Shaders implements class_4013 {
    private static final Shaders INSTANCE = new Shaders();
    private static final List<ShaderReference> SHADERS = new ArrayList<>();

    public static class_5944 scanEffectShader;
    public static class_5944 scanResultShader;

    public static void initialize() {
        addShader("scan_effect", class_290.field_1585, shader -> scanEffectShader = shader);
        addShader("scan_result", class_290.field_1575, shader -> scanResultShader = shader);

        loadAndListenToReload();
    }

    @Nullable
    public static class_5944 getScanEffectShader() {
        return scanEffectShader;
    }

    @Nullable
    public static class_5944 getScanResultShader() {
        return scanResultShader;
    }

    @Override
    public void method_14491(final class_3300 manager) {
        reloadShaders(manager);
    }

    private static void loadAndListenToReload() {
        class_310.method_1551().method_5382(() -> {
            final class_3300 manager = class_310.method_1551().method_1478();
            INSTANCE.method_14491(manager);
            if (manager instanceof class_3304 reloadableManager) {
                reloadableManager.method_14477(INSTANCE);
            }
        });
    }

    private static void reloadShaders(final class_5912 provider) {
        RenderSystem.assertOnRenderThread();
        SHADERS.forEach(reference -> reference.reload(provider));
    }

    private static void addShader(final String name, final class_293 format, final Consumer<class_5944> reloadAction) {
        SHADERS.add(new ShaderReference(name, format, reloadAction));
    }

    private static final class ShaderReference {
        private static final Logger LOGGER = LogManager.getLogger();

        private final String name;
        private final class_293 format;
        private final Consumer<class_5944> reloadAction;
        private class_5944 shader;

        public ShaderReference(final String name, final class_293 format, final Consumer<class_5944> reloadAction) {
            this.name = name;
            this.format = format;
            this.reloadAction = reloadAction;
        }

        public void reload(final class_5912 provider) {
            if (shader != null) {
                shader.close();
                shader = null;
            }

            try {
                shader = new class_5944(location -> provider.method_14486(class_2960.method_60655(API.MOD_ID, location.method_12832())).or(() -> provider.method_14486(location)), name, format);
            } catch (final Exception e) {
                LOGGER.error(e);
            }

            reloadAction.accept(shader);
        }
    }

    private Shaders() {
    }
}
