/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common;

import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.scannable.api.API;
import li.cil.scannable.common.config.ServerConfig;
import li.cil.scannable.common.config.Strings;
import li.cil.scannable.common.energy.ItemEnergyStorage;
import li.cil.scannable.common.item.Items;
import li.cil.scannable.common.item.ModItem;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModCreativeTabs {
    public static final DeferredRegister<class_1761> TABS = DeferredRegister.create(API.MOD_ID, class_7924.field_44688);

    public static final RegistrySupplier<class_1761> COMMON = TABS.register("common", () ->
            CreativeTabRegistry.create(builder -> {
                builder.method_47320(() -> new class_1799(Items.SCANNER.get()));
                builder.method_47321(Strings.CREATIVE_TAB_TITLE);
                builder.method_47317((parameters, output) -> {
                    if (ServerConfig.useEnergy) {
                        final var stack = new class_1799(Items.SCANNER.get());
                        ItemEnergyStorage.of(stack).ifPresent(energy -> {
                            energy.receiveEnergy(Integer.MAX_VALUE, false);
                            output.method_45420(stack);
                        });
                    }

                    class_7923.field_41178.method_10220()
                            .filter(item -> item instanceof ModItem)
                            .forEach(item -> output.method_45420(new class_1799(item)));
                });
            }));

    public static void initialize() {
        TABS.register();
    }
}
