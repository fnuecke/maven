@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.item;

import javax.annotation.ParametersAreNonnullByDefault;
