/* SPDX-License-Identifier: MIT */

package li.cil.scannable.api;

import net.minecraft.class_2960;

public final class API {
    public static final String MOD_ID = "scannable";

    // --------------------------------------------------------------------- //
    // Built-in icons that may be useful when rendering scan results.

    public static final class_2960 ICON_INFO = class_2960.method_60655(MOD_ID, "textures/gui/overlay/info.png");
    public static final class_2960 ICON_WARNING = class_2960.method_60655(MOD_ID, "textures/gui/overlay/warning.png");

    // --------------------------------------------------------------------- //
    // Registry names of reusable built-in scan providers.

    public static final class_2960 SCAN_RESULT_PROVIDER_BLOCKS = class_2960.method_60655(MOD_ID, "blocks");
    public static final class_2960 SCAN_RESULT_PROVIDER_ENTITIES = class_2960.method_60655(MOD_ID, "entities");

    // --------------------------------------------------------------------- //

    private API() {
    }
}
