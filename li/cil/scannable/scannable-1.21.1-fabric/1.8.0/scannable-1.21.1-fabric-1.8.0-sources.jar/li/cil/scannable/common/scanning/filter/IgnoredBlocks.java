/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning.filter;

import li.cil.scannable.common.config.ServerConfig;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public enum IgnoredBlocks {
    INSTANCE;

    private Set<class_2248> ignoredBlocks;

    public static void clearCache() {
        INSTANCE.ignoredBlocks = null;
    }

    public static boolean contains(final class_2680 state) {
        INSTANCE.validateFilter();
        return INSTANCE.ignoredBlocks.contains(state.method_26204());
    }

    private void validateFilter() {
        if (ignoredBlocks != null) {
            return;
        }

        final Set<class_2248> ignoredBlocks = new HashSet<>();
        for (final class_2960 location : ServerConfig.ignoredBlocks) {
            class_7923.field_41175.method_17966(location).ifPresent(ignoredBlocks::add);
        }

        final List<class_6862<class_2248>> ignoredTags = new ArrayList<>();
        class_7923.field_41175.method_40273().forEach(namedTag -> {
            if (ServerConfig.ignoredBlockTags.contains(namedTag.comp_327())) {
                ignoredTags.add(namedTag);
            }
        });

        for (final class_2248 block : class_7923.field_41175) {
            final class_2680 blockState = block.method_9564();
            if (ignoredTags.stream().anyMatch(blockState::method_26164)) {
                ignoredBlocks.add(blockState.method_26204());
            }
        }

        this.ignoredBlocks = ignoredBlocks;
    }
}
