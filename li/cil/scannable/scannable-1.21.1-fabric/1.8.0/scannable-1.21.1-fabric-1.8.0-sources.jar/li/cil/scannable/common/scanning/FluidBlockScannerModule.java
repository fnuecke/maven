/* SPDX-License-Identifier: MIT */

package li.cil.scannable.common.scanning;

import li.cil.scannable.api.scanning.BlockScannerModule;
import li.cil.scannable.api.scanning.ScanResultProvider;
import li.cil.scannable.client.scanning.ScanResultProviders;
import li.cil.scannable.client.scanning.filter.BlockCacheScanFilter;
import li.cil.scannable.client.scanning.filter.FluidTagScanFilter;
import li.cil.scannable.common.config.ServerConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public enum FluidBlockScannerModule implements BlockScannerModule {
    INSTANCE;

    private Predicate<class_2680> filter;

    public static void clearCache() {
        INSTANCE.filter = null;
    }

    @Override
    public int getEnergyCost(final class_1799 module) {
        return ServerConfig.energyCostModuleFluid;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public ScanResultProvider getResultProvider() {
        return ScanResultProviders.BLOCKS.get();
    }

    @Environment(EnvType.CLIENT)
    @Override
    public float adjustLocalRange(final float range) {
        return range * ServerConfig.rangeModifierModuleFluid;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public Predicate<class_2680> getFilter(final class_1799 module) {
        validateFilter();
        return filter;
    }

    @Environment(EnvType.CLIENT)
    private void validateFilter() {
        if (filter != null) {
            return;
        }

        final List<Predicate<class_2680>> filters = new ArrayList<>();
        class_7923.field_41173.method_40273().forEach(tag -> {
            if (!ServerConfig.ignoredFluidTags.contains(tag.comp_327())) {
                filters.add(new FluidTagScanFilter(tag));
            }
        });
        filter = new BlockCacheScanFilter(filters);
    }
}
