/* SPDX-License-Identifier: MIT */

package li.cil.scannable.client.renderer.fabric;

import li.cil.scannable.client.renderer.ScannerRenderer;
import net.minecraft.class_276;

public final class ScannerRendererImpl {
    public static ScannerRenderer.DepthOnlyRenderTarget copyBufferSettings(final class_276 mainRenderTarget, final ScannerRenderer.DepthOnlyRenderTarget depthRenderTarget) {
        return depthRenderTarget;
    }
}
