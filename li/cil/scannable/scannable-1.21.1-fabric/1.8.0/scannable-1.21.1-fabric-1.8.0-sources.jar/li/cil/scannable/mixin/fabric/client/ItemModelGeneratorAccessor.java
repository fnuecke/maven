/* SPDX-License-Identifier: MIT */

package li.cil.scannable.mixin.fabric.client;

import com.google.gson.JsonElement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_4915;

@Mixin(class_4915.class)
public interface ItemModelGeneratorAccessor {
    @Accessor("output")
    BiConsumer<class_2960, Supplier<JsonElement>> getOutput();
}
