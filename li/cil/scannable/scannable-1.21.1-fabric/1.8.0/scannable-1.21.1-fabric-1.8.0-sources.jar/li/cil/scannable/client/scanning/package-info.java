@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.scanning;

import javax.annotation.ParametersAreNonnullByDefault;
