/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.scanning;

import javax.annotation.ParametersAreNonnullByDefault;
