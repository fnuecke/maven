/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.api;

import javax.annotation.ParametersAreNonnullByDefault;
