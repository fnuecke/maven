/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.scanning.filter;

import javax.annotation.ParametersAreNonnullByDefault;
