/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.renderer.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
