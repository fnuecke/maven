/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.energy;

import javax.annotation.ParametersAreNonnullByDefault;
