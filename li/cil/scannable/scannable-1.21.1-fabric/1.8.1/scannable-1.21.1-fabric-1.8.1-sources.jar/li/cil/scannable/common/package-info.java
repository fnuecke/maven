/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common;

import javax.annotation.ParametersAreNonnullByDefault;
