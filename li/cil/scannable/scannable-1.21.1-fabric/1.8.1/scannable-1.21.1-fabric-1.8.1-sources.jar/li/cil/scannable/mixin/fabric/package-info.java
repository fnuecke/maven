/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.mixin.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
