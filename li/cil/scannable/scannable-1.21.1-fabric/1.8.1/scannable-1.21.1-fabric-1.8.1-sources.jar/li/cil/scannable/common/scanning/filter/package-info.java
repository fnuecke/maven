/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.scanning.filter;

import javax.annotation.ParametersAreNonnullByDefault;
