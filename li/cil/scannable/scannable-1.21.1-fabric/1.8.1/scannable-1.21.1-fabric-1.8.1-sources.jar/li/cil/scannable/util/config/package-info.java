/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.util.config;

import javax.annotation.ParametersAreNonnullByDefault;
