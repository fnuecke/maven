/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.tags;

import javax.annotation.ParametersAreNonnullByDefault;
