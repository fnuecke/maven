/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.network.message;

import javax.annotation.ParametersAreNonnullByDefault;
