/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.mixin.fabric.client;

import javax.annotation.ParametersAreNonnullByDefault;
