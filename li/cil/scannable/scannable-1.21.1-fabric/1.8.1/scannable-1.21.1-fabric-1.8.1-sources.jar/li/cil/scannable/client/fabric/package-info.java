/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
