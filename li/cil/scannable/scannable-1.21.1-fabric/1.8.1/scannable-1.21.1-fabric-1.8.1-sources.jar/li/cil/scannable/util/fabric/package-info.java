/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.util.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
