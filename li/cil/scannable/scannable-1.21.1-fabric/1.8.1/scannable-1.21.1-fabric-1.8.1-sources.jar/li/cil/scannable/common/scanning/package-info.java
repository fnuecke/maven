/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.scanning;

import javax.annotation.ParametersAreNonnullByDefault;
