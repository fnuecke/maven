/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.shader;

import javax.annotation.ParametersAreNonnullByDefault;
