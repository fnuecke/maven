/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.gui;

import javax.annotation.ParametersAreNonnullByDefault;
