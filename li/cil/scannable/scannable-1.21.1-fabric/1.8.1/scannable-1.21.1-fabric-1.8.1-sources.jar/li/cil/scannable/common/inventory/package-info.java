/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.inventory;

import javax.annotation.ParametersAreNonnullByDefault;
