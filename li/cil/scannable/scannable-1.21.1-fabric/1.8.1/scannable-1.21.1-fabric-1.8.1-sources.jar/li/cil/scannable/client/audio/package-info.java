/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.audio;

import javax.annotation.ParametersAreNonnullByDefault;
