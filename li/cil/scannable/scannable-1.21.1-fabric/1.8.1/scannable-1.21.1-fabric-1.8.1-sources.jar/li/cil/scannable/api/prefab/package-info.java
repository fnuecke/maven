/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.api.prefab;

import javax.annotation.ParametersAreNonnullByDefault;
