/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.energy.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
