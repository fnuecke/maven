/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.client.renderer;

import javax.annotation.ParametersAreNonnullByDefault;
