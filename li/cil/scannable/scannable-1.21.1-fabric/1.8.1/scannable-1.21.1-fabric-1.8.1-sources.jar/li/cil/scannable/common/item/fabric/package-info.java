/* SPDX-License-Identifier: MIT */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.scannable.common.item.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
