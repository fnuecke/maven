@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.bedrockores.common.util.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
