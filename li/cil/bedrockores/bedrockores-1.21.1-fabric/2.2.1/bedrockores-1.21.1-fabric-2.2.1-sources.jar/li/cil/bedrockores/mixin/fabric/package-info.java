@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.bedrockores.mixin.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
