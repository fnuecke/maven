@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.bedrockores.common.block.entity.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
