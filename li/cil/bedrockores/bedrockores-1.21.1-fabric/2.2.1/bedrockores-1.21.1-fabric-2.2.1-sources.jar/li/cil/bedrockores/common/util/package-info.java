@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package li.cil.bedrockores.common.util;

import javax.annotation.ParametersAreNonnullByDefault;
