/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.util;

import javax.annotation.Nullable;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_4538;

public final class LevelUtils {
    @SuppressWarnings("deprecation")
    @Nullable
    public static class_2586 getBlockEntityIfChunkLoaded(final class_1922 level, final class_2338 pos) {
        if (level instanceof final class_4538 reader && !reader.method_22340(pos)) {
            return null;
        }
        return level.method_8321(pos);
    }

    private LevelUtils() {
    }
}
