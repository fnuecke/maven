/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.client.render.fabric;

import net.fabricmc.fabric.api.blockview.v2.FabricBlockView;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Supplier;

public final class BedrockOreBakedModel implements class_1087, FabricBakedModel {
    private final class_1058 particle;

    public BedrockOreBakedModel(final class_1058 particle) {
        this.particle = particle;
    }

    // --------------------------------------------------------------------- //
    // FabricBakedModel

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(final class_1920 blockView, final class_2680 state, final class_2338 pos, final Supplier<class_5819> randomSupplier, final RenderContext context) {
        if (!(blockView instanceof final FabricBlockView fabricBlockView)) {
            return;
        }

        if (!(fabricBlockView.getBlockEntityRenderData(pos) instanceof final class_2680 oreState)) {
            return;
        }

        final var oreModel = class_310.method_1551().method_1541().method_3349(oreState);

        final var material = materialFor(oreState);
        if (material != null) {
            context.pushTransform(quad -> {
                quad.material(material);
                return true;
            });
        }

        try {
            oreModel.emitBlockQuads(blockView, oreState, pos, randomSupplier, context);
        } finally {
            if (material != null) {
                context.popTransform();
            }
        }
    }

    @Nullable
    private static RenderMaterial materialFor(final class_2680 oreState) {
        final var renderer = RendererAccess.INSTANCE.getRenderer();
        if (renderer == null) {
            return null;
        }

        return renderer.materialFinder().clear()
                .blendMode(BlendMode.fromRenderLayer(class_4696.method_23679(oreState)))
                .find();
    }

    @Override
    public void emitItemQuads(final class_1799 stack, final Supplier<class_5819> randomSupplier, final RenderContext context) {
    }

    // --------------------------------------------------------------------- //
    // BakedModel

    @Override
    public List<class_777> method_4707(@Nullable final class_2680 state, @Nullable final class_2350 side, final class_5819 random) {
        return List.of();
    }

    @Override
    public boolean method_4708() {
        return true;
    }

    @Override
    public boolean method_4712() {
        return false;
    }

    @Override
    public boolean method_24304() {
        return true;
    }

    @Override
    public boolean method_4713() {
        return false;
    }

    @Override
    public class_1058 method_4711() {
        return particle;
    }

    @Override
    public class_809 method_4709() {
        return class_809.field_4301;
    }

    @Override
    public class_806 method_4710() {
        return class_806.field_4292;
    }
}
