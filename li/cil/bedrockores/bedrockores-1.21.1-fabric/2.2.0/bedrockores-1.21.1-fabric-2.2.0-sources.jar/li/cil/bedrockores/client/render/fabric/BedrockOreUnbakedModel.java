/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.client.render.fabric;

import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_1723;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.client.resources.model.*;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;

public final class BedrockOreUnbakedModel implements class_1100 {
    public static final class_2960 ID = class_2960.method_60655(Constants.MOD_ID, "block/bedrock_ore");

    public static final BedrockOreUnbakedModel INSTANCE = new BedrockOreUnbakedModel();

    private static final class_4730 PARTICLE = new class_4730(class_1723.field_21668,
        class_2960.method_60655(Constants.MOD_ID, "block/bedrock_ore_mask"));

    // --------------------------------------------------------------------- //

    @Override
    public Collection<class_2960> method_4755() {
        return List.of();
    }

    @Override
    public void method_45785(final Function<class_2960, class_1100> resolver) {
    }

    @Override
    public class_1087 method_4753(final class_7775 baker, final Function<class_4730, class_1058> spriteGetter, final class_3665 state) {
        return new BedrockOreBakedModel(spriteGetter.apply(PARTICLE));
    }

    private BedrockOreUnbakedModel() {
    }
}
