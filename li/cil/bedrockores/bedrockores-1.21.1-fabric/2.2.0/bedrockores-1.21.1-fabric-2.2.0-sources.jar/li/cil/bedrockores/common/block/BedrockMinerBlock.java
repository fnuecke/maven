/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.bedrockores.common.block.entity.BedrockOreMinerBlockEntity;
import li.cil.bedrockores.common.block.entity.BlockEntities;
import li.cil.bedrockores.common.config.Constants;
import li.cil.bedrockores.common.config.Settings;
import net.minecraft.class_124;
import net.minecraft.class_1264;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import net.minecraft.class_5558;
import javax.annotation.Nullable;
import java.util.List;

public final class BedrockMinerBlock extends class_2237 {
    public static final MapCodec<BedrockMinerBlock> CODEC = MapCodec.unit(BedrockMinerBlock::new);

    // --------------------------------------------------------------------- //

    public BedrockMinerBlock() {
        super(class_2251.method_9637()
                .method_31710(class_3620.field_16005)
                .method_9629(5, 10)
                .method_9626(class_2498.field_11533));
    }

    // --------------------------------------------------------------------- //
    // BaseEntityBlock

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.MINER.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        if (level.method_8608()) {
            return method_31618(type, BlockEntities.MINER.get(), BedrockOreMinerBlockEntity::clientTick);
        } else {
            return method_31618(type, BlockEntities.MINER.get(), BedrockOreMinerBlockEntity::serverTick);
        }
    }

    @Override
    public class_2464 method_9604(final class_2680 state) {
        return class_2464.field_11458;
    }

    // --------------------------------------------------------------------- //
    // Block

    @Override
    public boolean method_9498(final class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(final class_2680 blockState, final class_1937 level, final class_2338 pos) {
        if (level.method_8321(pos) instanceof final BedrockOreMinerBlockEntity miner) {
            return miner.isWorking() ? 15 : 0;
        } else {
            return super.method_9572(blockState, level, pos);
        }
    }

    @Override
    public void method_9536(final class_2680 oldState, final class_1937 level, final class_2338 pos, final class_2680 newState, final boolean movedByPiston) {
        if (!oldState.method_27852(newState.method_26204()) && level.method_8321(pos) instanceof final BedrockOreMinerBlockEntity miner) {
            class_1264.method_5451(level, pos, miner);
            level.method_8455(pos, this);
        }
        super.method_9536(oldState, level, pos, newState, movedByPiston);
    }

    @Override
    public void method_9568(final class_1799 stack, final class_1792.class_9635 context, final List<class_2561> tooltip, final class_1836 flags) {
        super.method_9568(stack, context, tooltip, flags);
        final var edgeLength = (Settings.minerAreaRadius.get() - 1) * 2 + 1;
        final var layers = Settings.minerAreaLayers.get();
        tooltip.add(class_2561.method_43469(Constants.TOOLTIP_BEDROCK_MINER, edgeLength, layers, edgeLength).method_27692(class_124.field_1080));
    }
}
