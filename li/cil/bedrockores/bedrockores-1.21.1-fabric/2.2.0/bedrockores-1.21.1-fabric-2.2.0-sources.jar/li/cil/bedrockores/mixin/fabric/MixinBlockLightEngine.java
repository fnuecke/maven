/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.mixin.fabric;

import li.cil.bedrockores.common.block.Blocks;
import li.cil.bedrockores.common.block.entity.BedrockOreBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3552;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3552.class)
public abstract class MixinBlockLightEngine {
    @Inject(method = "getEmission", at = @At("HEAD"), cancellable = true)
    private void bedrockores$getWrappedOreEmission(final long packedPos, final class_2680 state, final CallbackInfoReturnable<Integer> cir) {
        if (!state.method_27852(Blocks.BEDROCK_ORE.get())) {
            return;
        }

        final var pos = class_2338.method_10092(packedPos);
        final var level = ((LightEngineAccessor) this).bedrockores$getChunkSource().method_16399();
        final var blockEntity = level.method_8321(pos);

        if (blockEntity instanceof final BedrockOreBlockEntity bedrockOre) {
            cir.setReturnValue(bedrockOre.getOreBlockState().method_26213());
        }
    }
}
