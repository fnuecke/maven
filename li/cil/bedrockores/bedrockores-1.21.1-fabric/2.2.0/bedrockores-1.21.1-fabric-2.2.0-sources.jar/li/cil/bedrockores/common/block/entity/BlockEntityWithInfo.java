/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import li.cil.bedrockores.common.network.Network;
import li.cil.bedrockores.common.network.message.InfoRequestMessage;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import javax.annotation.Nullable;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.TemporalAmount;

public abstract class BlockEntityWithInfo extends class_2586 {
    public static final TemporalAmount UPDATE_INTERVAL = Duration.ofMillis(500);

    @Nullable
    private class_2561 currentInfo;
    private Instant infoValidUntil = Instant.MIN;

    // --------------------------------------------------------------------- //

    protected BlockEntityWithInfo(final class_2591<?> type, final class_2338 pos, final class_2680 state) {
        super(type, pos, state);
    }

    // --------------------------------------------------------------------- //
    // LookAtInfoProvider

    @Nullable
    public final class_2561 getLookAtInfo() {
        final var level = method_10997();
        if (level == null) {
            return null;
        }

        if (Instant.now().isAfter(infoValidUntil)) {
            infoValidUntil = Instant.now().plus(UPDATE_INTERVAL);
            if (level.method_8608()) {
                Network.sendToServer(new InfoRequestMessage(method_11016()));
            } else {
                currentInfo = buildInfo();
            }
        }

        return currentInfo;
    }

    public void setInfoClient(@Nullable final class_2561 info) {
        this.currentInfo = info;
    }

    protected abstract class_2561 buildInfo();
}
