/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.util.Objects;
import java.util.OptionalInt;

import static java.util.Objects.requireNonNull;
import static li.cil.bedrockores.common.block.Blocks.BEDROCK_ORE;

public class BedrockOreBlockEntity extends BlockEntityWithInfo {
    // --------------------------------------------------------------------- //
    // Persisted data

    private class_2680 oreBlockState = class_2246.field_10124.method_9564();
    @Nullable
    private Integer amount;

    // --------------------------------------------------------------------- //
    // Computed data

    private static final String TAG_STATE = "state";
    private static final String TAG_AMOUNT = "amount";

    private class_1799 droppedStack = class_1799.field_8037;

    // --------------------------------------------------------------------- //

    public BedrockOreBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.BEDROCK_ORE.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    public class_2680 getOreBlockState() {
        return oreBlockState;
    }

    public void setOreBlockState(final class_2680 state) {
        if (state.method_27852(BEDROCK_ORE.get())) {
            throw new IllegalArgumentException("Bedrock ore cannot contain itself.");
        }

        if (Objects.equals(state, oreBlockState)) {
            return;
        }

        final var oldState = oreBlockState;

        oreBlockState = state;
        droppedStack = new class_1799(state.method_26204().method_8389());

        final var level = method_10997();
        if (level != null) {
            if (level.method_8608()) {
                setChangedAndSendUpdateClient();
            } else {
                setChangedAndSendUpdateServer();
            }
            if (oreBlockState.method_26213() != oldState.method_26213() ||
                oreBlockState.method_26193(level, method_11016()) != oldState.method_26193(level, method_11016())) {
                level.method_8398().method_12130().method_15513(method_11016());
            }
        }
    }

    public OptionalInt getAmount() {
        if (oreBlockState.method_26215()) {
            return OptionalInt.of(0);
        }
        if (isInfinite()) {
            return OptionalInt.empty();
        }
        return OptionalInt.of(amount);
    }

    public void setAmount(final int value) {
        amount = value;
    }

    public boolean isInfinite() {
        return amount == null;
    }

    public void setInfinite() {
        amount = null;
    }

    public boolean isUnconfigured() {
        return oreBlockState.method_26215();
    }

    public boolean isEmpty() {
        final var amount = getAmount();
        if (amount.isPresent()) {
            return amount.getAsInt() <= 0;
        } else {
            return false; // infinite
        }
    }

    public class_1799 extract() {
        final class_1937 level = method_10997();
        if (level == null || level.method_8608()) {
            return class_1799.field_8037;
        }

        final var wasEmpty = isEmpty();
        if (!isInfinite()) {
            if (!wasEmpty) { // paranoia underflow guard
                --amount;
            }
            if (isEmpty()) {
                level.method_8652(method_11016(), class_2246.field_9987.method_9564(), class_2248.field_31036);
            } else {
                method_5431();
            }
        }

        return wasEmpty ? class_1799.field_8037 : droppedStack.method_7972();
    }

    // --------------------------------------------------------------------- //
    // BlockEntityWithInfo

    @Override
    protected class_2561 buildInfo() {
        if (isInfinite()) {
            return class_2561.method_43469(Constants.GUI_EXPECTED_YIELD, class_2561.method_43471(Constants.GUI_INFINITE));
        } else {
            return class_2561.method_43469(Constants.GUI_EXPECTED_YIELD, amount);
        }
    }

    // --------------------------------------------------------------------- //
    // BlockEntity

    @Override
    public void method_10996() {
        super.method_10996();

        refreshLighting();
        scheduleRemoveUnconfigured();
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        return method_38244(registries);
    }

    @Override
    protected void method_11007(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        class_2680.field_24734
                .encodeStart(class_2509.field_11560, oreBlockState).result()
                .ifPresent(stateNbt -> tag.method_10566(TAG_STATE, stateNbt));
        if (!isInfinite()) {
            tag.method_10569(TAG_AMOUNT, amount);
        } else {
            tag.method_10551(TAG_AMOUNT);
        }
    }

    @Override
    protected void method_11014(final class_2487 tag, final class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        final var oldState = oreBlockState;

        oreBlockState = class_2680.field_24734
                .parse(class_2509.field_11560, tag.method_10580(TAG_STATE)).result()
                .orElse(class_2246.field_10124.method_9564());
        droppedStack = new class_1799(oreBlockState.method_26204().method_8389());
        if (tag.method_10573(TAG_AMOUNT, class_2520.field_33253)) {
            setAmount(tag.method_10550(TAG_AMOUNT));
        } else {
            setInfinite();
        }

        // This is also the path network updates take, so the model has to be rebuilt when the
        // wrapped ore changed under us.
        final var level = method_10997();
        if (level != null && level.method_8608() && oreBlockState != oldState) {
            onRenderDataChanged();
            level.method_16109(method_11016(), method_11010(), method_11010());
            refreshLighting();
        }
    }

    // --------------------------------------------------------------------- //

    protected void onRenderDataChanged() {
    }

    /**
     * Chunk lighting is computed before block entities are loaded, so at that point nothing knows
     * which ore this block wraps and a glowing one contributes no light. Once the block entity is
     * in place, nudge the light engine so it picks the emission up.
     */
    private void refreshLighting() {
        final var level = method_10997();
        if (level == null || oreBlockState.method_26213() <= 0) {
            return;
        }

        final var pos = method_11016();
        if (level instanceof final class_3218 serverLevel) {
            serverLevel.method_8503().execute(() -> {
                if (!method_11015()) {
                    serverLevel.method_14178().method_17293().method_15513(pos);
                }
            });
        } else {
            level.method_8398().method_12130().method_15513(pos);
        }
    }

    private void scheduleRemoveUnconfigured() {
        if (method_10997() instanceof final class_3218 level) {
            UnconfiguredOreCleanup.schedule(level, method_11016());
        }
    }

    private void setChangedAndSendUpdateServer() {
        method_5431();
        requireNonNull(method_10997()).method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
    }

    private void setChangedAndSendUpdateClient() {
        onRenderDataChanged();
        requireNonNull(method_10997()).method_16109(method_11016(), method_11010(), method_11010());
    }
}
