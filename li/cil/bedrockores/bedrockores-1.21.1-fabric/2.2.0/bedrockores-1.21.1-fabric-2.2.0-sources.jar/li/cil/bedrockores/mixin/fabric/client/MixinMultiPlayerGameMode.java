/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.mixin.fabric.client;

import li.cil.bedrockores.common.block.Blocks;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class MixinMultiPlayerGameMode {
    @Inject(method = "destroyBlock", at = @At("HEAD"), cancellable = true)
    private void bedrockores$dontPredictBedrockOreRemoval(final class_2338 pos, final CallbackInfoReturnable<Boolean> cir) {
        final var minecraft = class_310.method_1551();
        final var level = minecraft.field_1687;
        final var player = minecraft.field_1724;
        if (level == null || player == null || player.method_7337()) {
            return;
        }

        if (!level.method_8320(pos).method_27852(Blocks.BEDROCK_ORE.get())) {
            return;
        }

        cir.setReturnValue(true);
    }
}
