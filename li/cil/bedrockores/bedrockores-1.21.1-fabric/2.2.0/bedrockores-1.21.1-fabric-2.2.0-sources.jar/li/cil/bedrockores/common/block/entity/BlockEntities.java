/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.bedrockores.common.block.Blocks;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_7924;

public final class BlockEntities {
    private static final DeferredRegister<class_2591<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(Constants.MOD_ID, class_7924.field_41255);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_2591<BedrockOreBlockEntity>> BEDROCK_ORE = register("bedrock_ore", Blocks.BEDROCK_ORE, BedrockOreBlockEntityFactory::create);
    public static final RegistrySupplier<class_2591<BedrockOreMinerBlockEntity>> MINER = register("bedrock_miner", Blocks.BEDROCK_MINER, BedrockOreMinerBlockEntity::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        BLOCK_ENTITY_TYPES.register();
    }

    // --------------------------------------------------------------------- //

    @SuppressWarnings("DataFlowIssue") // .build(null) is fine
    private static <B extends class_2248, T extends class_2586> RegistrySupplier<class_2591<T>> register(final String name, final RegistrySupplier<B> block, final class_2591.class_5559<T> factory) {
        return BLOCK_ENTITY_TYPES.register(name, () -> class_2591.class_2592.method_20528(factory, block.get()).method_11034(null));
    }
}
