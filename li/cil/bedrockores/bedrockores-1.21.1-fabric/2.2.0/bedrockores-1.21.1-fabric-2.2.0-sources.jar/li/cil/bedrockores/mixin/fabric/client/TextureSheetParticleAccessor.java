/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.mixin.fabric.client;

import net.minecraft.class_1058;
import net.minecraft.class_4003;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4003.class)
public interface TextureSheetParticleAccessor {
    @Invoker("setSprite")
    void bedrockores$setSprite(class_1058 sprite);
}
