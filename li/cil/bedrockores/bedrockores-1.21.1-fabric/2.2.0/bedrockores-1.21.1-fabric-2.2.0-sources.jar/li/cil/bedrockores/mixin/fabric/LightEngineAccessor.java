/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.mixin.fabric;

import net.minecraft.class_2823;
import net.minecraft.class_3558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3558.class)
public interface LightEngineAccessor {
    @Accessor("chunkSource")
    class_2823 bedrockores$getChunkSource();
}
