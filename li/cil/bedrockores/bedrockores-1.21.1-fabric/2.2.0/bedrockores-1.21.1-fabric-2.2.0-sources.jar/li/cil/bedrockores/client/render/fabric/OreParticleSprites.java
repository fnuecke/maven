/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.client.render.fabric;

import li.cil.bedrockores.common.block.Blocks;
import li.cil.bedrockores.common.block.entity.BedrockOreBlockEntity;
import li.cil.bedrockores.mixin.fabric.client.TextureSheetParticleAccessor;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_727;
import javax.annotation.Nullable;

public final class OreParticleSprites {
    public static void apply(final class_727 particle, @Nullable final class_638 level, final class_2680 state, @Nullable final class_2338 pos) {
        if (level == null || pos == null || !state.method_27852(Blocks.BEDROCK_ORE.get())) {
            return;
        }

        final var bedrockOre = findBedrockOre(level, pos);
        if (bedrockOre == null) {
            return;
        }

        final var oreState = bedrockOre.getOreBlockState();
        if (oreState.method_26215()) {
            return;
        }

        final var sprite = class_310.method_1551().method_1541().method_3351().method_3339(oreState);
        ((TextureSheetParticleAccessor) particle).bedrockores$setSprite(sprite);
    }

    @Nullable
    private static BedrockOreBlockEntity findBedrockOre(final class_638 level, final class_2338 pos) {
        if (level.method_8321(pos) instanceof final BedrockOreBlockEntity bedrockOre) {
            return bedrockOre;
        }

        // Landing and running particles spawn slightly *above* the block that spawned them, so
        // the position derived from their spawn coordinates is one block off.
        if (level.method_8321(pos.method_10074()) instanceof final BedrockOreBlockEntity bedrockOre) {
            return bedrockOre;
        }

        return null;
    }

    private OreParticleSprites() {
    }
}
