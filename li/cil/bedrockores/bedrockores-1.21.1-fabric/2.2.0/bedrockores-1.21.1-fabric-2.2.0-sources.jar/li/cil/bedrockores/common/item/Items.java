/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.item;

import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.bedrockores.common.block.Blocks;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_7706;
import net.minecraft.class_7924;

public final class Items {
    private static final DeferredRegister<class_1792> ITEMS = DeferredRegister.create(Constants.MOD_ID, class_7924.field_41197);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1792> BEDROCK_MINER = ITEMS.register("bedrock_miner", () -> new class_1747(Blocks.BEDROCK_MINER.get(), new class_1792.class_1793()));

    // --------------------------------------------------------------------- //

    @SuppressWarnings("unchecked")
    public static void initialize() {
        ITEMS.register();

        CreativeTabRegistry.append(class_7706.field_40197, BEDROCK_MINER);
    }
}
