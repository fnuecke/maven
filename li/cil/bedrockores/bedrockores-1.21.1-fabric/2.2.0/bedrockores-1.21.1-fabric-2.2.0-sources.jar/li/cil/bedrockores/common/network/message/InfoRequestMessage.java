/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.bedrockores.common.block.entity.BlockEntityWithInfo;
import li.cil.bedrockores.common.config.Constants;
import li.cil.bedrockores.common.network.Network;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.Optional;

public record InfoRequestMessage(class_2338 position) implements class_8710 {
    public static final class_9154<InfoRequestMessage> TYPE = new class_9154<>(class_2960.method_60655(Constants.MOD_ID, "info_request"));

    public static final class_9139<class_9129, InfoRequestMessage> STREAM_CODEC = class_9139.method_56434(
            class_2338.field_48404, InfoRequestMessage::position,
            InfoRequestMessage::new);

    // --------------------------------------------------------------------- //

    public static void handle(final InfoRequestMessage message, final NetworkManager.PacketContext context) {
        context.queue(() -> {
            if (!(context.getPlayer() instanceof final class_3222 player)) {
                return;
            }

            MessageUtils.withBlockEntity(player.method_37908(), message.position(), BlockEntityWithInfo.class, blockEntity ->
                    Network.sendToPlayer(player, new InfoResponseMessage(
                            blockEntity.method_11016(),
                            Optional.ofNullable(blockEntity.getLookAtInfo()))));
        });
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
