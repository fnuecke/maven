/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.mixin.fabric.client;

import li.cil.bedrockores.client.render.fabric.OreParticleSprites;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import net.minecraft.class_727;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_727.class)
public class MixinTerrainParticle {
    @Inject(
            method = "<init>(Lnet/minecraft/client/multiplayer/ClientLevel;DDDDDDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)V",
            at = @At("RETURN"))
    private void bedrockores$applyOreSprite(final class_638 level, final double x, final double y, final double z, final double vx, final double vy, final double vz, final class_2680 state, final class_2338 pos, final CallbackInfo ci) {
        OreParticleSprites.apply((class_727) (Object) this, level, state, pos);
    }
}
