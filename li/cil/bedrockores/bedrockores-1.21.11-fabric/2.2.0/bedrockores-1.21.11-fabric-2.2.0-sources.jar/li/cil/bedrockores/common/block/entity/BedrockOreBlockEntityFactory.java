/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class BedrockOreBlockEntityFactory {
    @ExpectPlatform
    public static BedrockOreBlockEntity create(final class_2338 pos, final class_2680 state) {
        throw new AssertionError();
    }

    private BedrockOreBlockEntityFactory() {
    }
}
