/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.fabric;

import li.cil.bedrockores.common.BedrockOres;
import li.cil.bedrockores.common.block.entity.BlockEntities;
import li.cil.bedrockores.common.config.Constants;
import li.cil.bedrockores.common.world.BedrockOrePlacements;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.fabricmc.fabric.api.event.registry.DynamicRegistrySetupCallback;
import net.minecraft.class_2378;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_6796;
import net.minecraft.class_6908;
import net.minecraft.class_7924;
import team.reborn.energy.api.EnergyStorage;

public final class BedrockOresFabric implements ModInitializer {
    private class_2378<class_6796> placedFeatures;

    @Override
    public void onInitialize() {
        BedrockOres.initialize();

        DynamicRegistrySetupCallback.EVENT.register(registries ->
                registries.getOptional(class_7924.field_41245).ifPresent(registry -> placedFeatures = registry));

        BiomeModifications
                .create(class_2960.method_60655(Constants.MOD_ID, "overworld_veins"))
                .add(ModificationPhase.ADDITIONS, BiomeSelectors.tag(class_6908.field_37393), context -> {
                    for (final var vein : placedFeatures.method_40286(BedrockOrePlacements.OVERWORLD_VEINS)) {
                        context.getGenerationSettings().addFeature(
                                class_2893.class_2895.field_13176,
                                vein.method_40230().orElseThrow());
                    }
                });

        BiomeModifications.addFeature(
                BiomeSelectors.tag(class_6908.field_37393),
                class_2893.class_2895.field_13179,
                BedrockOrePlacements.UNCONFIGURED_ORE_CLEANUP);

        EnergyStorage.SIDED.registerForBlockEntity(
                (miner, side) -> side != null && side.method_10166().method_10179() && miner.getEnergyCapacity() > 0
                        ? new MinerEnergyStorage(miner)
                        : null,
                BlockEntities.MINER.get());
    }
}
