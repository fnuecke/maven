/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity.fabric;

import li.cil.bedrockores.common.block.entity.BedrockOreBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class BedrockOreBlockEntityFactoryImpl {
    public static BedrockOreBlockEntity create(final class_2338 pos, final class_2680 state) {
        return new BedrockOreBlockEntityFabric(pos, state);
    }

    private BedrockOreBlockEntityFactoryImpl() {
    }
}
