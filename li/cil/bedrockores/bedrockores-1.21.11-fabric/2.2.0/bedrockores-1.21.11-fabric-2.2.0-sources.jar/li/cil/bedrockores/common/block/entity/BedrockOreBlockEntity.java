/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import com.mojang.logging.LogUtils;
import li.cil.bedrockores.common.block.BedrockOreBlock;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7225;
import org.slf4j.Logger;

import javax.annotation.Nullable;
import java.util.Objects;
import java.util.OptionalInt;

import static java.util.Objects.requireNonNull;
import static li.cil.bedrockores.common.block.Blocks.BEDROCK_ORE;

public class BedrockOreBlockEntity extends BlockEntityWithInfo {
    private static final Logger LOGGER = LogUtils.getLogger();

    // --------------------------------------------------------------------- //
    // Persisted data

    private class_2680 oreBlockState = class_2246.field_10124.method_9564();
    @Nullable
    private Integer amount;

    // --------------------------------------------------------------------- //
    // Computed data

    private static final String TAG_STATE = "state";
    private static final String TAG_AMOUNT = "amount";

    private class_1799 droppedStack = class_1799.field_8037;

    // --------------------------------------------------------------------- //

    public BedrockOreBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.BEDROCK_ORE.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    public class_2680 getOreBlockState() {
        return oreBlockState;
    }

    public void setOreBlockState(final class_2680 state) {
        if (state.method_27852(BEDROCK_ORE.get())) {
            LOGGER.error("Tried to wrap a bedrock ore inside a bedrock ore at {}.", method_11016());
            return;
        }

        if (Objects.equals(state, oreBlockState)) {
            return;
        }

        oreBlockState = state;
        droppedStack = new class_1799(state.method_26204().method_8389());

        final var level = method_10997();
        if (level != null) {
            if (level.method_8608()) {
                setChangedAndSendUpdateClient();
            } else {
                setChangedAndSendUpdateServer();
            }
            syncLightProperty();
        }
    }

    public OptionalInt getAmount() {
        if (oreBlockState.method_26215()) {
            return OptionalInt.of(0);
        }
        if (isInfinite()) {
            return OptionalInt.empty();
        }
        return OptionalInt.of(amount);
    }

    public void setAmount(final int value) {
        amount = value;
    }

    public boolean isInfinite() {
        return amount == null;
    }

    public void setInfinite() {
        amount = null;
    }

    public boolean isUnconfigured() {
        return oreBlockState.method_26215();
    }

    public boolean isEmpty() {
        final var amount = getAmount();
        if (amount.isPresent()) {
            return amount.getAsInt() <= 0;
        } else {
            return false; // infinite
        }
    }

    public class_1799 extract() {
        final class_1937 level = method_10997();
        if (level == null || level.method_8608()) {
            return class_1799.field_8037;
        }

        final var wasEmpty = isEmpty();
        if (!isInfinite()) {
            if (!wasEmpty) { // paranoia underflow guard
                --amount;
            }
            if (isEmpty()) {
                level.method_8652(method_11016(), class_2246.field_9987.method_9564(), class_2248.field_31036);
            } else {
                method_5431();
            }
        }

        return wasEmpty ? class_1799.field_8037 : droppedStack.method_7972();
    }

    // --------------------------------------------------------------------- //
    // BlockEntityWithInfo

    @Override
    protected class_2561 buildInfo() {
        if (isInfinite()) {
            return class_2561.method_43469(Constants.GUI_EXPECTED_YIELD, class_2561.method_43471(Constants.GUI_INFINITE));
        } else {
            return class_2561.method_43469(Constants.GUI_EXPECTED_YIELD, amount);
        }
    }

    // --------------------------------------------------------------------- //
    // BlockEntity

    @Override
    public void method_10996() {
        super.method_10996();

        scheduleRemoveUnconfigured();
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final var tag = new class_2487();
        class_2680.field_24734
                .encodeStart(class_2509.field_11560, oreBlockState).result()
                .ifPresent(encoded -> tag.method_10566(TAG_STATE, encoded));
        return tag;
    }

    @Override
    protected void method_11007(final class_11372 output) {
        super.method_11007(output);

        output.method_71468(TAG_STATE, class_2680.field_24734, oreBlockState);
        if (!isInfinite()) {
            output.method_71465(TAG_AMOUNT, amount);
        }
    }

    @Override
    protected void method_11014(final class_11368 input) {
        super.method_11014(input);

        final var oldState = oreBlockState;

        oreBlockState = input.method_71426(TAG_STATE, class_2680.field_24734).orElse(class_2246.field_10124.method_9564());
        droppedStack = new class_1799(oreBlockState.method_26204().method_8389());
        input.method_71439(TAG_AMOUNT).ifPresentOrElse(this::setAmount, this::setInfinite);

        // This is also the path network updates take, so the model has to be rebuilt when the
        // wrapped ore changed under us.
        final var level = method_10997();
        if (level != null && level.method_8608() && oreBlockState != oldState) {
            onRenderDataChanged();
            level.method_16109(method_11016(), method_11010(), method_11010());
        }
    }

    // --------------------------------------------------------------------- //

    protected void onRenderDataChanged() {
    }

    private void syncLightProperty() {
        final var level = method_10997();
        if (level == null || level.method_8608()) {
            return;
        }

        final var state = method_11010();
        if (!state.method_28498(BedrockOreBlock.LIGHT)) {
            return;
        }

        final var light = oreBlockState.method_26213();
        if (state.method_11654(BedrockOreBlock.LIGHT) != light) {
            level.method_8652(method_11016(), state.method_11657(BedrockOreBlock.LIGHT, light), class_2248.field_31036);
        }
    }

    private void scheduleRemoveUnconfigured() {
        if (method_10997() instanceof final class_3218 level) {
            UnconfiguredOreCleanup.schedule(level, method_11016());
        }
    }

    private void setChangedAndSendUpdateServer() {
        method_5431();
        requireNonNull(method_10997()).method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
    }

    private void setChangedAndSendUpdateClient() {
        onRenderDataChanged();
        requireNonNull(method_10997()).method_16109(method_11016(), method_11010(), method_11010());
    }
}
