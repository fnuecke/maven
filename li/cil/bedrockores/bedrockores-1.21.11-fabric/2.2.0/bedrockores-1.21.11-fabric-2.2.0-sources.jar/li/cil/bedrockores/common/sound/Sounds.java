/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.sound;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7924;

public final class Sounds {
    private static final DeferredRegister<class_3414> SOUND_EVENTS = DeferredRegister.create(Constants.MOD_ID, class_7924.field_41225);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_3414> MINER = SOUND_EVENTS.register("bedrock_miner", () -> class_3414.method_47908(class_2960.method_60655(Constants.MOD_ID, "bedrock_miner")));

    // --------------------------------------------------------------------- //

    public static void initialize() {
        SOUND_EVENTS.register();
    }
}
