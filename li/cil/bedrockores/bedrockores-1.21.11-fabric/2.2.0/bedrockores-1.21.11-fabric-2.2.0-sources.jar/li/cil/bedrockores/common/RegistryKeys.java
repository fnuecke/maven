/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common;

import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class RegistryKeys {
    public static final String BEDROCK_ORE = "bedrock_ore";
    public static final String BEDROCK_MINER = "bedrock_miner";

    // --------------------------------------------------------------------- //

    public static class_5321<class_2248> block(final String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Constants.MOD_ID, name));
    }

    public static class_5321<class_1792> item(final String name) {
        return class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Constants.MOD_ID, name));
    }

    private RegistryKeys() {
    }
}
