/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.world;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_3037;
import net.minecraft.class_3819;
import net.minecraft.class_3825;
import net.minecraft.class_6016;
import net.minecraft.class_6017;

public record BedrockOreConfiguration(class_2680 ore,
                                      Either<class_6017, String> amount,
                                      class_6017 radius,
                                      class_6017 height,
                                      float density,
                                      class_3825 rule
) implements class_3037 {
    public static final Codec<String> INFINITE_CODEC = Codec.STRING.flatXmap(BedrockOreConfiguration::verifyInfinite, BedrockOreConfiguration::verifyInfinite);
    public static final Codec<BedrockOreConfiguration> CODEC = RecordCodecBuilder.create((builder) -> builder.group(
            class_2680.field_24734.fieldOf("ore").forGetter(BedrockOreConfiguration::ore),
            Codec.either(class_6017.field_33451, INFINITE_CODEC).fieldOf("amount").forGetter(BedrockOreConfiguration::amount),
            class_6017.method_35004(0, 8).optionalFieldOf("radius", class_6016.method_34998(4)).forGetter(BedrockOreConfiguration::radius),
            class_6017.field_33451.optionalFieldOf("height", class_6016.method_34998(8)).forGetter(BedrockOreConfiguration::height),
            Codec.floatRange(0, 1).optionalFieldOf("density", 0.75f).forGetter(BedrockOreConfiguration::density),
            class_3825.field_25012.optionalFieldOf("rule", new class_3819(class_2246.field_9987)).forGetter(BedrockOreConfiguration::rule)
    ).apply(builder, BedrockOreConfiguration::new));

    private static DataResult<? extends String> verifyInfinite(final String value) {
        return "infinite".equals(value) ? DataResult.success(value) : DataResult.error(() -> "Expected 'infinite' or an integer value");
    }
}
