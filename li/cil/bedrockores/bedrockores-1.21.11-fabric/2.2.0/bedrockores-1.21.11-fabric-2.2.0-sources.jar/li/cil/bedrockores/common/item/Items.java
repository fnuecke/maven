/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.item;

import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.bedrockores.common.RegistryKeys;
import li.cil.bedrockores.common.block.Blocks;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_1792;
import net.minecraft.class_7706;
import net.minecraft.class_7924;

public final class Items {
    private static final DeferredRegister<class_1792> ITEMS = DeferredRegister.create(Constants.MOD_ID, class_7924.field_41197);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_1792> BEDROCK_MINER = ITEMS.register(RegistryKeys.BEDROCK_MINER, () -> new BedrockMinerBlockItem(Blocks.BEDROCK_MINER.get(), new class_1792.class_1793().method_63686(RegistryKeys.item(RegistryKeys.BEDROCK_MINER)).method_63685()));

    // --------------------------------------------------------------------- //

    @SuppressWarnings("unchecked")
    public static void initialize() {
        ITEMS.register();

        CreativeTabRegistry.append(class_7706.field_40197, BEDROCK_MINER);
    }
}
