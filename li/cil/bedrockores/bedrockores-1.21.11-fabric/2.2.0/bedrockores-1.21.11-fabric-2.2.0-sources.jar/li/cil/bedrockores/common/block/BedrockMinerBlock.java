/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block;

import com.mojang.serialization.MapCodec;
import li.cil.bedrockores.common.RegistryKeys;
import li.cil.bedrockores.common.block.entity.BedrockOreMinerBlockEntity;
import li.cil.bedrockores.common.block.entity.BlockEntities;
import net.minecraft.class_1264;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3620;
import net.minecraft.class_5558;
import javax.annotation.Nullable;

public final class BedrockMinerBlock extends class_2237 {
    public static final MapCodec<BedrockMinerBlock> CODEC = MapCodec.unit(BedrockMinerBlock::new);

    // --------------------------------------------------------------------- //

    public BedrockMinerBlock() {
        super(class_2251.method_9637()
                .method_63500(RegistryKeys.block(RegistryKeys.BEDROCK_MINER))
                .method_31710(class_3620.field_16005)
                .method_9629(5, 10)
                .method_9626(class_2498.field_11533));
    }

    // --------------------------------------------------------------------- //
    // BaseEntityBlock

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.MINER.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
        if (level.method_8608()) {
            return method_31618(type, BlockEntities.MINER.get(), BedrockOreMinerBlockEntity::clientTick);
        } else {
            return method_31618(type, BlockEntities.MINER.get(), BedrockOreMinerBlockEntity::serverTick);
        }
    }

    @Override
    public class_2464 method_9604(final class_2680 state) {
        return class_2464.field_11458;
    }

    // --------------------------------------------------------------------- //
    // Block

    @Override
    public boolean method_9498(final class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(final class_2680 blockState, final class_1937 level, final class_2338 pos, final class_2350 side) {
        if (level.method_8321(pos) instanceof final BedrockOreMinerBlockEntity miner) {
            return miner.isWorking() ? 15 : 0;
        } else {
            return super.method_9572(blockState, level, pos, side);
        }
    }

    @Override
    public void method_66388(final class_2680 state, final class_3218 level, final class_2338 pos, final boolean movedByPiston) {
        if (level.method_8321(pos) instanceof final BedrockOreMinerBlockEntity miner) {
            class_1264.method_5451(level, pos, miner);
        }
        level.method_8455(pos, this);
    }
}
