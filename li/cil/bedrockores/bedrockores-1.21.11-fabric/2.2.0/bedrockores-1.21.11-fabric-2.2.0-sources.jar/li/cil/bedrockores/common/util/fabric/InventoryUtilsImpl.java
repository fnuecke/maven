/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.util.fabric;

import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import javax.annotation.Nullable;

public final class InventoryUtilsImpl {
    @Nullable
    public static class_1799 insert(final class_1937 level, final class_2338 pos, final class_2350 side, final class_1799 stack) {
        final var storage = findStorage(level, pos, side);
        if (storage == null) {
            return null;
        }

        final long inserted;
        try (var transaction = Transaction.openOuter()) {
            inserted = storage.insert(ItemVariant.of(stack), stack.method_7947(), transaction);
            transaction.commit();
        }

        final var remainder = stack.method_7972();
        remainder.method_7934((int) inserted);
        return remainder;
    }

    @Nullable
    private static Storage<ItemVariant> findStorage(final class_1937 level, final class_2338 pos, final class_2350 side) {
        final var blockStorage = ItemStorage.SIDED.find(level, pos, side);
        if (blockStorage != null) {
            return blockStorage;
        }

        // Chest minecarts and the like; the Transfer API's sided lookup is block-only.
        final var entities = level.method_8333((class_1297) null, new class_238(pos), entity -> entity instanceof class_1263);
        if (entities.isEmpty()) {
            return null;
        }

        final var entity = entities.get(level.field_9229.method_43048(entities.size()));
        return InventoryStorage.of((class_1263) entity, side);
    }

    private InventoryUtilsImpl() {
    }
}
