/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.bedrockores.common.RegistryKeys;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_2248;
import net.minecraft.class_7924;

public final class Blocks {
    private static final DeferredRegister<class_2248> BLOCKS = DeferredRegister.create(Constants.MOD_ID, class_7924.field_41254);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<BedrockOreBlock> BEDROCK_ORE = BLOCKS.register(RegistryKeys.BEDROCK_ORE, BedrockOreBlockFactory::create);
    public static final RegistrySupplier<BedrockMinerBlock> BEDROCK_MINER = BLOCKS.register(RegistryKeys.BEDROCK_MINER, BedrockMinerBlock::new);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        BLOCKS.register();
    }
}
