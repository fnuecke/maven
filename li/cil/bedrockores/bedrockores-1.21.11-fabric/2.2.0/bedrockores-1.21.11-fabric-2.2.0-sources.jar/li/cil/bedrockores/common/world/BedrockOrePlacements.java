/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.world;

import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class BedrockOrePlacements {
    private static final Logger LOGGER = LogManager.getLogger();

    public static final class_6862<class_6796> OVERWORLD_VEINS = class_6862.method_40092(class_7924.field_41245, id("overworld_veins"));

    public static final class_5321<class_6796> UNCONFIGURED_ORE_CLEANUP = key("unconfigured_ore_cleanup");

    // --------------------------------------------------------------------- //

    public static void checkOverworldVeins(final MinecraftServer server) {
        final var veins = server.method_30611().method_30530(class_7924.field_41245).method_46733(OVERWORLD_VEINS);
        if (veins.isPresent() && veins.get().method_40247() > 0) {
            return;
        }

        LOGGER.error("""
            No bedrock ore veins will generate: the tag {} is empty or was not loaded.
            A data pack listing a placed feature that does not exist makes the game discard the entire tag; \
            look for a preceding "Couldn't load tag" error naming the offending entry and data pack. \
            Data packs extending this tag should mark entries that may be absent as {}.""",
            OVERWORLD_VEINS.comp_327(), "{\"id\": \"...\", \"required\": false}");
    }

    // --------------------------------------------------------------------- //

    private static class_5321<class_6796> key(final String name) {
        return class_5321.method_29179(class_7924.field_41245, id(name));
    }

    private static class_2960 id(final String name) {
        return class_2960.method_60655(Constants.MOD_ID, name);
    }

    private BedrockOrePlacements() {
    }
}
