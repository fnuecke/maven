/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.client.render;

import li.cil.bedrockores.common.block.entity.BlockEntityWithInfo;
import li.cil.bedrockores.common.config.Settings;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_9799;

public final class InfoRenderer {
    private static final class_4597.class_4598 BUFFER =
            class_4597.method_22991(new class_9799(1536));

    public static void render(final class_4587 stack, final class_4184 camera) {
        final var mc = class_310.method_1551();
        final var player = mc.field_1724;
        if (player == null) {
            return;
        }

        final var level = player.method_73183();

        if (Settings.uiOnlyWhenSneaking.get() && !player.method_18276()) {
            return;
        }

        if (!(mc.field_1765 instanceof final class_3965 hit)) {
            return;
        }

        final var blockPos = hit.method_17777();
        if (!(level.method_8321(blockPos) instanceof final BlockEntityWithInfo info)) {
            return;
        }

        final var text = info.getLookAtInfo();
        if (text == null) {
            return;
        }

        stack.method_22903();

        stack.method_22904(0.5, 1.5, 0.5);

        stack.method_22904(
                blockPos.method_10263() - camera.method_71156().field_1352,
                blockPos.method_10264() - camera.method_71156().field_1351,
                blockPos.method_10260() - camera.method_71156().field_1350);

        stack.method_22907(camera.method_23767());

        stack.method_22905(0.025f, -0.025f, 0.025f);

        final var matrix = stack.method_23760().method_23761();

        final class_327 font = mc.field_1772;

        final float horizontalTextOffset = -font.method_27525(text) * 0.5f;
        final float backgroundOpacity = mc.field_1690.method_19343(0.25F);
        final int backgroundColor = (int) (backgroundOpacity * 255.0F) << 24;
        final int packedLight = class_765.method_23687(15, 15);

        font.method_27522(text, horizontalTextOffset, 0, 0xffffffff,
                false, matrix, BUFFER, class_327.class_6415.field_33994, backgroundColor, packedLight);
        font.method_27522(text, horizontalTextOffset, 0, 0xffffffff,
                false, matrix, BUFFER, class_327.class_6415.field_33993, 0, packedLight);

        BUFFER.method_22993();

        stack.method_22909();
    }

    private InfoRenderer() {
    }
}
