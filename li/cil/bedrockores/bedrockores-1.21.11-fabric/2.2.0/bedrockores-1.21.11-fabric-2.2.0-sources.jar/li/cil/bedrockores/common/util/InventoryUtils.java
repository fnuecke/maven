/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.util;

import dev.architectury.injectables.annotations.ExpectPlatform;
import javax.annotation.Nullable;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public final class InventoryUtils {
    @ExpectPlatform
    @Nullable
    public static class_1799 insert(final class_1937 level, final class_2338 pos, final class_2350 side, final class_1799 stack) {
        throw new AssertionError();
    }

    private InventoryUtils() {
    }
}
