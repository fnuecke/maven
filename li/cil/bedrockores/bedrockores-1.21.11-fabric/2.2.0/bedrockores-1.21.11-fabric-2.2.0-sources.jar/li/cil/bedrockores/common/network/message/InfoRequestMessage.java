/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.network.message;

import dev.architectury.networking.NetworkManager;
import li.cil.bedrockores.common.block.entity.BlockEntityWithInfo;
import li.cil.bedrockores.common.config.Constants;
import li.cil.bedrockores.common.network.Network;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;

public record InfoRequestMessage(class_2338 position) implements class_8710 {
    public static final class_9154<InfoRequestMessage> TYPE = new class_9154<>(class_2960.method_60655(Constants.MOD_ID, "info_request"));

    public static final class_9139<class_9129, InfoRequestMessage> STREAM_CODEC = class_9139.method_56434(
            class_2338.field_48404, InfoRequestMessage::position,
            InfoRequestMessage::new);

    private static final double REACH_PADDING = 3;
    private static final long MIN_REQUEST_INTERVAL_MS = 200;
    private static final Map<class_3222, Long> LAST_REQUEST = new WeakHashMap<>();

    // --------------------------------------------------------------------- //

    public static void handle(final InfoRequestMessage message, final NetworkManager.PacketContext context) {
        context.queue(() -> {
            if (!(context.getPlayer() instanceof final class_3222 player)) {
                return;
            }

            if (!player.method_56093(message.position(), REACH_PADDING)) {
                return;
            }

            final var now = System.currentTimeMillis();
            final var last = LAST_REQUEST.get(player);
            if (last != null && now - last < MIN_REQUEST_INTERVAL_MS) {
                return;
            }
            LAST_REQUEST.put(player, now);

            MessageUtils.withBlockEntity(player.method_51469(), message.position(), BlockEntityWithInfo.class, blockEntity ->
                    Network.sendToPlayer(player, new InfoResponseMessage(
                            blockEntity.method_11016(),
                            Optional.ofNullable(blockEntity.getLookAtInfo()))));
        });
    }

    // --------------------------------------------------------------------- //

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
