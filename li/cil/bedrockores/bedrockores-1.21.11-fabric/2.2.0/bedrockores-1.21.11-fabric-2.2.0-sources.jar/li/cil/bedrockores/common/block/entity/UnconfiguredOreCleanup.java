/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import dev.architectury.event.events.common.LifecycleEvent;
import dev.architectury.event.events.common.TickEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_3218;
import net.minecraft.class_4076;

import static li.cil.bedrockores.common.block.Blocks.BEDROCK_ORE;

public final class UnconfiguredOreCleanup {
    private static final int MAX_REMOVALS_PER_TICK = 64;

    private static final Map<class_3218, List<class_2338>> PENDING = new WeakHashMap<>();

    // --------------------------------------------------------------------- //

    public static void initialize() {
        TickEvent.SERVER_LEVEL_POST.register(UnconfiguredOreCleanup::processPending);
        LifecycleEvent.SERVER_LEVEL_UNLOAD.register(PENDING::remove);
    }

    public static int removeUnconfiguredFromChunk(final class_1936 level, final class_2791 chunk) {
        final var sections = chunk.method_12006();
        final var origin = chunk.method_12004().method_8323();
        final var pos = new class_2338.class_2339();

        var removed = 0;
        for (var sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            final var section = sections[sectionIndex];
            if (!section.method_19523(UnconfiguredOreCleanup::isBedrockOre)) {
                continue;
            }

            final var sectionY = class_4076.method_18688(chunk.method_31604(sectionIndex));
            for (var y = 0; y < class_4076.field_33097; y++) {
                for (var z = 0; z < class_4076.field_33097; z++) {
                    for (var x = 0; x < class_4076.field_33097; x++) {
                        if (!isBedrockOre(section.method_12254(x, y, z))) {
                            continue;
                        }

                        pos.method_10103(origin.method_10263() + x, sectionY + y, origin.method_10260() + z);
                        if (isUnconfigured(chunk, pos)) {
                            level.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31035);
                            removed++;
                        }
                    }
                }
            }
        }

        return removed;
    }

    public static void schedule(final class_3218 level, final class_2338 pos) {
        PENDING.computeIfAbsent(level, unused -> new ArrayList<>()).add(pos.method_10062());
    }

    // --------------------------------------------------------------------- //

    private static void processPending(final class_3218 level) {
        final var positions = PENDING.get(level);
        if (positions == null) {
            return;
        }

        var removed = 0;
        while (removed < MAX_REMOVALS_PER_TICK && !positions.isEmpty()) {
            final var pos = positions.removeLast();
            if (!isLoaded(level, pos)) {
                continue;
            }
            if (level.method_8321(pos) instanceof final BedrockOreBlockEntity bedrockOre && bedrockOre.isUnconfigured()) {
                level.method_8650(pos, false);
                level.method_14178().method_17293().method_15513(pos);
                removed++;
            }
        }

        if (positions.isEmpty()) {
            PENDING.remove(level);
        }
    }

    private static boolean isBedrockOre(final class_2680 state) {
        return state.method_27852(BEDROCK_ORE.get());
    }

    private static boolean isUnconfigured(final class_2791 chunk, final class_2338 pos) {
        return !(chunk.method_8321(pos) instanceof final BedrockOreBlockEntity bedrockOre) || bedrockOre.isUnconfigured();
    }

    private static boolean isLoaded(final class_3218 level, final class_2338 pos) {
        return level.method_14178().method_12123(
            class_4076.method_18675(pos.method_10263()),
            class_4076.method_18675(pos.method_10260()));
    }

    // --------------------------------------------------------------------- //

    private UnconfiguredOreCleanup() {
    }
}
