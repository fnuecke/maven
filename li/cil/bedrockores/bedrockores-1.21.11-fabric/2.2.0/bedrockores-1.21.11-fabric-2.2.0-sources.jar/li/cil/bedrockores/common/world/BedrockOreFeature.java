/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.world;

import com.mojang.serialization.Codec;
import li.cil.bedrockores.common.block.BedrockOreBlock;
import li.cil.bedrockores.common.block.Blocks;
import li.cil.bedrockores.common.block.entity.BedrockOreBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_3031;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class BedrockOreFeature extends class_3031<BedrockOreConfiguration> {
    public BedrockOreFeature(final Codec<BedrockOreConfiguration> config) {
        super(config);
    }

    public boolean method_13151(class_5821<BedrockOreConfiguration> context) {
        final var config = context.method_33656();
        final var origin = context.method_33655();
        final var level = context.method_33652();
        final var random = context.method_33654();

        final var radius = config.radius().method_35008(random);
        final var height = config.height().method_35008(random);

        if (radius <= 0 || height <= 0) {
            return false;
        }

        final var y = origin.method_10264();
        final var yShift = height / 2;
        final var yMaxInclusive = y + height - 1 - yShift;
        final var yMinInclusive = y - yShift;

        var didPlace = false;
        var tempPos = new class_2338.class_2339();
        for (final class_2338 pos : class_2338.method_10097(origin.method_10069(-radius, 0, -radius), origin.method_10069(radius, 0, radius))) {
            int dx = pos.method_10263() - origin.method_10263();
            int dz = pos.method_10260() - origin.method_10260();
            if (dx * dx + dz * dz <= radius * radius) {
                didPlace |= this.placeColumn(config, level, random, tempPos.method_10101(pos), yMinInclusive, yMaxInclusive);
            }
        }
        return didPlace;
    }

    protected boolean placeColumn(BedrockOreConfiguration config, class_5281 level, class_5819 random, class_2338.class_2339 pos, int yMinInclusive, int yMaxInclusive) {
        var didPlace = false;
        for (int y = yMaxInclusive; y >= yMinInclusive; --y) {
            pos.method_33098(y);

            if (!config.rule().method_16768(level.method_8320(pos), random)) {
                continue;
            }
            if (random.method_43057() >= config.density()) {
                continue;
            }

            method_13153(level, pos, Blocks.BEDROCK_ORE.get().method_9564()
                    .method_11657(BedrockOreBlock.LIGHT, config.ore().method_26213()));
            if (level.method_8321(pos) instanceof BedrockOreBlockEntity bedrockOre) {
                bedrockOre.setOreBlockState(config.ore());
                config.amount()
                        .ifLeft(amount -> bedrockOre.setAmount(amount.method_35008(random)))
                        .ifRight(infinite -> bedrockOre.setInfinite());
            }
            didPlace = true;
        }
        return didPlace;
    }
}
