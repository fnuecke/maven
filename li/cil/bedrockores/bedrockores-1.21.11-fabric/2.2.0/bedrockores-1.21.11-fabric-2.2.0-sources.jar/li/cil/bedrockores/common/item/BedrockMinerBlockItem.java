/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.item;

import li.cil.bedrockores.common.config.Constants;
import li.cil.bedrockores.common.config.Settings;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import java.util.function.Consumer;

/**
 * Carries the miner's area-size tooltip.
 * <p>
 * {@code Block#appendHoverText} no longer exists as of 1.21.11 — tooltips for blocks have to be
 * contributed by their item.
 */
public final class BedrockMinerBlockItem extends class_1747 {
    public BedrockMinerBlockItem(final class_2248 block, final class_1793 properties) {
        super(block, properties);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_67187(final class_1799 stack, final class_9635 context, final class_10712 display, final Consumer<class_2561> tooltip, final class_1836 flags) {
        super.method_67187(stack, context, display, tooltip, flags);

        final var edgeLength = (Settings.minerAreaRadius.get() - 1) * 2 + 1;
        final var layers = Settings.minerAreaLayers.get();
        tooltip.accept(class_2561.method_43469(Constants.TOOLTIP_BEDROCK_MINER, edgeLength, layers, edgeLength).method_27692(class_124.field_1080));
    }
}
