/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import dev.architectury.registry.fuel.FuelRegistry;
import li.cil.bedrockores.common.config.Constants;
import li.cil.bedrockores.common.config.Settings;
import li.cil.bedrockores.common.sound.Sounds;
import li.cil.bedrockores.common.util.InventoryUtils;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1278;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import javax.annotation.Nullable;
import java.util.OptionalInt;
import java.util.Spliterators;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.partitioningBy;

public final class BedrockOreMinerBlockEntity extends BlockEntityWithInfo implements class_1278 {
    // --------------------------------------------------------------------- //
    // Persisted data

    private final class_2371<class_1799> items = class_2371.method_10213(SLOT_COUNT, class_1799.field_8037);

    private int energyStored;
    private int remainingBurnTime;
    private int extractionCooldown = -1;
    private int transferCooldown = 20;

    // --------------------------------------------------------------------- //
    // Computed data

    private static final String TAG_ITEMS = "Items";
    private static final String TAG_ENERGY_STORAGE = "energyStorage";
    private static final String TAG_REMAINING_BURN_TIME = "burnTime";
    private static final String TAG_EXTRACTION_COOLDOWN = "extractionCooldown";
    private static final String TAG_WORKING = "working";

    private static final long SEND_WORKING_STATE_DELAY_TICKS = 20;

    public static final int SLOT_FUEL = 0;
    public static final int SLOT_OUTPUT_FIRST = 1;
    private static final int SLOT_OUTPUT_COUNT = 6;
    private static final int SLOT_COUNT = SLOT_OUTPUT_FIRST + SLOT_OUTPUT_COUNT;

    private static final int[] SLOTS_FUEL = {SLOT_FUEL};
    private static final int[] SLOTS_OUTPUT = {1, 2, 3, 4, 5, 6};
    private static final int[] SLOTS_NONE = {};

    private static final int RF_PER_BURN_TIME = 10;

    private static final int SOUND_INTERVAL = 30; // in ticks

    private static final long NO_PENDING_UPDATE = -1;

    @Nullable
    private BedrockOreBlockEntity currentOre;
    private boolean hasNoMoreOres;

    // We delay sending the working state to clients a little to avoid small
    // hiccups causing unnecessary update packets being sent.
    private boolean isWorkingServer, isWorkingClient;
    private long sendUpdateTagAtTick = NO_PENDING_UPDATE;

    private int soundCooldown;

    private int cachedEnergyCapacity = -1;
    private double cachedEnergyCapacityEfficiency = Double.NaN;

    // --------------------------------------------------------------------- //

    public BedrockOreMinerBlockEntity(final class_2338 pos, final class_2680 state) {
        super(BlockEntities.MINER.get(), pos, state);
    }

    // --------------------------------------------------------------------- //

    public boolean isWorking() {
        return isWorkingServer;
    }

    // --------------------------------------------------------------------- //
    // Energy

    public int getEnergyStored() {
        return energyStored;
    }

    public void setEnergyStored(final int value) {
        energyStored = value;
    }

    public int getEnergyCapacity() {
        final var efficiency = getExternalPowerEfficiency();
        if (efficiency <= 0) {
            return 0;
        }

        if (cachedEnergyCapacity < 0 || cachedEnergyCapacityEfficiency != efficiency) {
            final var capacity = Math.max(100, class_3532.method_15384(getFuelBurnTime(new class_1799(class_1802.field_8713)) / (RF_PER_BURN_TIME * efficiency)));
            if (method_10997() == null) {
                return capacity;
            }
            cachedEnergyCapacityEfficiency = efficiency;
            cachedEnergyCapacity = capacity;
        }
        return cachedEnergyCapacity;
    }

    private int getFuelBurnTime(final class_1799 stack) {
        final var level = method_10997();
        if (level == null || stack.method_7960()) {
            return 0;
        }
        return FuelRegistry.get(stack, class_3956.field_17546, level.method_61269());
    }

    public int receiveEnergy(final int amount, final boolean simulate) {
        if (getExternalPowerEfficiency() <= 0) {
            return 0;
        }

        final var accepted = Math.min(amount, getEnergyCapacity() - energyStored);
        if (accepted > 0 && !simulate) {
            energyStored += accepted;
            method_5431();
        }
        return Math.max(0, accepted);
    }

    // --------------------------------------------------------------------- //

    public static void clientTick(final class_1937 ignoredLevel, final class_2338 ignoredPos, final class_2680 ignoredState, final BedrockOreMinerBlockEntity miner) {
        miner.clientTick();
    }

    public static void serverTick(final class_1937 ignoredLevel, final class_2338 ignoredPos, final class_2680 ignoredState, final BedrockOreMinerBlockEntity miner) {
        miner.serverTick();
    }

    private void clientTick() {
        updateEffects();
    }

    private void serverTick() {
        flushWorkingState();

        flushOutput();
        if (!hasAvailableOutputSlot()) {
            setWorking(false);
            return;
        }

        findBedrockOre();
        if (!hasAvailableInputOre()) {
            setWorking(false);
            return;
        }

        if (getInternalPowerEfficiency() > 0 || getExternalPowerEfficiency() > 0) {
            updateBurnTime();
            if (!hasRemainingBurnTime()) {
                setWorking(false);
                return;
            }
        }

        extractBedrockOre();
        setWorking(true);
    }

    // --------------------------------------------------------------------- //
    // BlockEntityWithInfo

    @Override
    protected class_2561 buildInfo() {
        final var ores = findBedrockOres().
                map(BedrockOreBlockEntity::getAmount).
                collect(partitioningBy(OptionalInt::isPresent));

        // If there are any infinite ore spawns within range, we can consider this miner to have infinite yield.
        final var infiniteOres = ores.get(false);
        if (!infiniteOres.isEmpty()) {
            return class_2561.method_43469(Constants.GUI_EXPECTED_YIELD, class_2561.method_43471(Constants.GUI_INFINITE));
        }

        final var finiteOres = ores.get(true);
        @SuppressWarnings("OptionalGetWithoutIsPresent") final int yield = finiteOres.stream().
                map(OptionalInt::getAsInt).
                reduce(Integer::sum).
                orElse(0);
        if (yield > 0) {
            return class_2561.method_43469(Constants.GUI_EXPECTED_YIELD, yield);
        } else {
            return class_2561.method_43471(Constants.GUI_EXHAUSTED);
        }
    }

    // --------------------------------------------------------------------- //
    // BlockEntity

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(final class_7225.class_7874 registries) {
        final var tag = new class_2487();
        tag.method_10556(TAG_WORKING, isWorkingServer);
        return tag;
    }

    @Override
    protected void method_11007(final class_11372 output) {
        super.method_11007(output);

        class_1262.method_5426(output, items);
        output.method_71465(TAG_ENERGY_STORAGE, energyStored);
        output.method_71465(TAG_REMAINING_BURN_TIME, remainingBurnTime);
        output.method_71465(TAG_EXTRACTION_COOLDOWN, extractionCooldown);
    }

    @Override
    protected void method_11014(final class_11368 input) {
        super.method_11014(input);

        // Both the full load and the network update tag come through here, and the update tag only
        // carries the working flag — so every field defaults to what it already holds rather than
        // to zero, or a client-side update would wipe the values it does not send.
        if (input.method_71436(TAG_ITEMS).isPresent()) {
            items.clear();
            class_1262.method_5429(input, items);
        }
        energyStored = input.method_71424(TAG_ENERGY_STORAGE, energyStored);
        remainingBurnTime = input.method_71424(TAG_REMAINING_BURN_TIME, remainingBurnTime);
        extractionCooldown = input.method_71424(TAG_EXTRACTION_COOLDOWN, extractionCooldown);
        isWorkingClient = input.method_71433(TAG_WORKING, isWorkingClient);
    }

    // --------------------------------------------------------------------- //
    // Container

    @Override
    public int method_5439() {
        return SLOT_COUNT;
    }

    @Override
    public boolean method_5442() {
        for (final var stack : items) {
            if (!stack.method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_5438(final int slot) {
        return items.get(slot);
    }

    @Override
    public class_1799 method_5434(final int slot, final int amount) {
        final var result = class_1262.method_5430(items, slot, amount);
        if (!result.method_7960()) {
            method_5431();
        }
        return result;
    }

    @Override
    public class_1799 method_5441(final int slot) {
        return class_1262.method_5428(items, slot);
    }

    @Override
    public void method_5447(final int slot, final class_1799 stack) {
        items.set(slot, stack);
        stack.method_58408(method_5444());
        method_5431();
    }

    @Override
    public int method_5444() {
        return 1;
    }

    @Override
    public boolean method_5443(final class_1657 player) {
        return class_1263.method_49105(this, player);
    }

    @Override
    public void method_5448() {
        items.clear();
    }

    @Override
    public boolean method_5437(final int slot, final class_1799 stack) {
        return slot == SLOT_FUEL && getInternalPowerEfficiency() > 0 && getScaledFuelBurnTime(stack) > 0;
    }

    // --------------------------------------------------------------------- //
    // WorldlyContainer

    @Override
    public int[] method_5494(final class_2350 side) {
        if (side == class_2350.field_11036) {
            return SLOTS_OUTPUT;
        }
        if (side.method_10166().method_10179() && getInternalPowerEfficiency() > 0) {
            return SLOTS_FUEL;
        }
        return SLOTS_NONE;
    }

    @Override
    public boolean method_5492(final int slot, final class_1799 stack, @Nullable final class_2350 side) {
        return side != null && side.method_10166().method_10179() && method_5437(slot, stack);
    }

    @Override
    public boolean method_5493(final int slot, final class_1799 stack, final class_2350 side) {
        return side == class_2350.field_11036 && slot >= SLOT_OUTPUT_FIRST;
    }

    // --------------------------------------------------------------------- //

    private void updateEffects() {
        if (!isWorkingClient) {
            return;
        }

        if (soundCooldown > 0) {
            soundCooldown--;
        }

        final var level = method_10997();
        if (level == null) {
            return;
        }

        if (soundCooldown <= 0) {
            soundCooldown = SOUND_INTERVAL;
            final var player = class_310.method_1551().field_1724;
            if (player != null) {
                final var pos = class_243.method_24953(method_11016());
                final var volume = 1.0f;
                final var range = Sounds.MINER.get().method_43044(volume);
                if (player.method_5707(pos) < range * range) {
                    level.method_8486(pos.method_10216(), pos.method_10214(), pos.method_10215(), Sounds.MINER.get(), class_3419.field_15245, volume, 1, false);
                }
            }
        }

        final var rng = level.field_9229;
        for (final var facing : class_2350.class_2353.field_11062) {
            final var direction = new class_243(facing.method_10148(), facing.method_10164(), facing.method_10165());

            final var up = new class_243(0, 1, 0);
            final var right = direction.method_1036(up);
            final var dx = (rng.method_43057() - 0.5f) * 0.3f;
            final var dy = (rng.method_43057() - 0.5f) * 0.3f;

            final var origin = class_243.method_24953(method_11016()).
                    method_1019(direction.method_1021(0.5)).
                    method_1019(right.method_1021(dx)).
                    method_1019(up.method_1021(dy));
            final var velocity = direction.method_1021(0.05);

            level.method_8406(class_2398.field_11251, origin.field_1352, origin.field_1351, origin.field_1350, velocity.field_1352, velocity.field_1351, velocity.field_1350);
        }
    }

    private void flushOutput() {
        final var level = method_10997();
        if (level == null) {
            return;
        }

        final var outputSlot = findFirstNonEmptyOutputSlot();
        if (outputSlot < 0) {
            return;
        }

        if (transferCooldown > 0) {
            --transferCooldown;
        }
        if (transferCooldown > 0) {
            return;
        }

        final var stack = items.get(outputSlot);
        final var remainder = InventoryUtils.insert(level, method_11016().method_10084(), class_2350.field_11033, stack.method_7972());
        if (remainder == null) {
            transferCooldown = 20;
            return;
        }

        if (!class_1799.method_7973(stack, remainder)) {
            items.set(outputSlot, remainder);
            method_5431();
        }

        transferCooldown = 10;
    }

    private int findFirstNonEmptyOutputSlot() {
        for (var slot = SLOT_OUTPUT_FIRST; slot < SLOT_COUNT; ++slot) {
            if (!items.get(slot).method_7960()) {
                return slot;
            }
        }
        return -1;
    }

    private boolean hasAvailableOutputSlot() {
        for (var slot = SLOT_OUTPUT_FIRST; slot < SLOT_COUNT; ++slot) {
            if (items.get(slot).method_7960()) {
                return true;
            }
        }
        return false;
    }

    private void insertIntoOutput(final class_1799 stack) {
        if (stack.method_7960()) {
            return;
        }
        for (var slot = SLOT_OUTPUT_FIRST; slot < SLOT_COUNT; ++slot) {
            if (items.get(slot).method_7960()) {
                items.set(slot, stack);
                return;
            }
        }
    }

    private void findBedrockOre() {
        if (hasNoMoreOres) {
            return;
        }

        if (currentOre == null || currentOre.method_11015() || currentOre.isEmpty()) {
            currentOre = findBedrockOres().findFirst().orElse(null);
            if (currentOre == null) {
                hasNoMoreOres = true;
                setWorking(false);
            }
        }
    }

    private boolean hasAvailableInputOre() {
        return currentOre != null;
    }

    private void updateBurnTime() {
        if (remainingBurnTime > 0) {
            --remainingBurnTime;
        }

        if (remainingBurnTime <= 0 && getExternalPowerEfficiency() > 0) {
            final var energyBurnTime = consumeEnergyForBurnTime();
            final var scaledBurnTime = class_3532.method_15384(energyBurnTime * getExternalPowerEfficiency());
            if (scaledBurnTime > 0) {
                remainingBurnTime = scaledBurnTime;
                method_5431();
            }
        }

        if (remainingBurnTime <= 0 && getInternalPowerEfficiency() > 0) {
            final var scaledBurnTime = getScaledFuelBurnTime(items.get(SLOT_FUEL));
            if (scaledBurnTime > 0) {
                items.set(SLOT_FUEL, class_1799.field_8037);
                remainingBurnTime = scaledBurnTime;
                method_5431();
            }
        }
    }

    private int consumeEnergyForBurnTime() {
        final var availableBurnTime = energyStored / RF_PER_BURN_TIME;
        final var usedEnergy = Math.min(energyStored, availableBurnTime * RF_PER_BURN_TIME);
        energyStored -= usedEnergy;
        return availableBurnTime;
    }

    private int getScaledFuelBurnTime(final class_1799 stack) {
        return class_3532.method_15384(getFuelBurnTime(stack) * getInternalPowerEfficiency());
    }

    private boolean hasRemainingBurnTime() {
        return remainingBurnTime > 0;
    }

    private void extractBedrockOre() {
        final var bedrockOre = requireNonNull(currentOre);

        if (extractionCooldown > 0) {
            extractionCooldown--;
            return;
        }

        final var level = requireNonNull(method_10997());
        final var pos = bedrockOre.method_11016();

        insertIntoOutput(bedrockOre.extract());
        method_5431();

        extractionCooldown = Settings.minerExtractionCooldown.get();

        final var oreState = bedrockOre.getOreBlockState();
        final var soundType = oreState.method_26231();
        final var blockCenter = class_243.method_24953(pos);
        level.method_43128(null, blockCenter.method_10216(), blockCenter.method_10214(), blockCenter.method_10215(), soundType.method_10595(), class_3419.field_15245, soundType.method_10597(), soundType.method_10599());
    }

    private Stream<BedrockOreBlockEntity> findBedrockOres() {
        return StreamSupport.stream(new ScanAreaSpliterator(), false);
    }

    private void setWorking(final boolean value) {
        isWorkingServer = value;

        if (isWorkingServer == isWorkingClient) {
            sendUpdateTagAtTick = NO_PENDING_UPDATE;
        } else if (sendUpdateTagAtTick == NO_PENDING_UPDATE) {
            sendUpdateTagAtTick = requireNonNull(method_10997()).method_75260() + SEND_WORKING_STATE_DELAY_TICKS;
        }
    }

    private void flushWorkingState() {
        if (sendUpdateTagAtTick == NO_PENDING_UPDATE) {
            return;
        }

        final var level = requireNonNull(method_10997());
        if (level.method_75260() < sendUpdateTagAtTick) {
            return;
        }

        sendUpdateTagAtTick = NO_PENDING_UPDATE;
        isWorkingClient = isWorkingServer;
        level.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
    }

    private static double getInternalPowerEfficiency() {
        return Settings.minerEfficiency.get() * Settings.minerEfficiencyInternalPower.get();
    }

    private static double getExternalPowerEfficiency() {
        return Settings.minerEfficiency.get() * Settings.minerEfficiencyExternalPower.get();
    }

    // --------------------------------------------------------------------- //

    private final class ScanAreaSpliterator extends Spliterators.AbstractSpliterator<BedrockOreBlockEntity> {
        private final int radius, layers;
        private int x, y, z;

        ScanAreaSpliterator() {
            this(Settings.minerAreaRadius.get() - 1, Settings.minerAreaLayers.get());
        }

        private ScanAreaSpliterator(final int radius, final int layers) {
            super(numberOfBlocksInArea(radius, layers), ORDERED | DISTINCT | SIZED | NONNULL | IMMUTABLE | SUBSIZED);
            this.radius = radius;
            this.layers = layers;
            this.x = -radius;
            this.z = -radius;
            this.y = 0;
        }

        @Override
        public boolean tryAdvance(final Consumer<? super BedrockOreBlockEntity> action) {
            final var scanLevel = requireNonNull(method_10997());
            while (y < layers) {
                final var pos = method_11016().method_10074().method_10069(x, -y, z);

                x++;
                if (x > radius) {
                    x = -radius;
                    z++;
                    if (z > radius) {
                        z = -radius;
                        y++;
                    }
                }

                final var blockEntity = scanLevel.method_8321(pos);
                if (blockEntity instanceof final BedrockOreBlockEntity bedrockOre) {
                    action.accept(bedrockOre);
                    return true;
                }
            }
            return false;
        }

        private static int numberOfBlocksInArea(final int radius, final int layers) {
            return (radius * 2 + 1) * (radius * 2 + 1) * layers;
        }
    }
}
