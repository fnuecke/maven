/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import li.cil.bedrockores.common.block.BedrockOreBlock;
import li.cil.bedrockores.common.block.Blocks;
import li.cil.bedrockores.common.block.entity.BedrockOreBlockEntity;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2248;
import net.minecraft.class_2262;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public final class ModCommands {
    public static void register(final CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("bedrock_ores")
                .requires(class_2170.method_71774(class_2170.field_31839))

                .then(class_2170.method_9247("wrap")
                        .then(class_2170.method_9244("pos", class_2262.method_9698())
                                .executes(ModCommands::wrap)))

                .then(class_2170.method_9247("unwrap")
                        .then(class_2170.method_9244("pos", class_2262.method_9698())
                                .executes(ModCommands::unwrap)))

                .then(class_2170.method_9247("amount")
                        .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(ModCommands::amount)))));
    }

    // --------------------------------------------------------------------- //

    private static int wrap(final CommandContext<class_2168> context) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        final var pos = class_2262.method_9696(context, "pos");
        final var level = context.getSource().method_9225();

        final var state = level.method_8320(pos);
        level.method_8652(pos, Blocks.BEDROCK_ORE.get().method_9564()
                .method_11657(BedrockOreBlock.LIGHT, state.method_26213()), class_2248.field_31028);
        if (level.method_8321(pos) instanceof final BedrockOreBlockEntity bedrockOre) {
            bedrockOre.setOreBlockState(state);
            bedrockOre.setAmount(1);
        }

        return SINGLE_SUCCESS;
    }

    private static int unwrap(final CommandContext<class_2168> context) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        final var pos = class_2262.method_9696(context, "pos");
        final var level = context.getSource().method_9225();

        if (level.method_8321(pos) instanceof final BedrockOreBlockEntity bedrockOre) {
            final var state = bedrockOre.getOreBlockState();
            level.method_8652(pos, state, class_2248.field_31028);
        }

        return SINGLE_SUCCESS;
    }

    private static int amount(final CommandContext<class_2168> context) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        final var amount = IntegerArgumentType.getInteger(context, "amount");
        final var pos = class_2262.method_9696(context, "pos");
        final var level = context.getSource().method_9225();

        if (level.method_8321(pos) instanceof final BedrockOreBlockEntity bedrockOre) {
            bedrockOre.setAmount(amount);
        }

        return SINGLE_SUCCESS;
    }

    private ModCommands() {
    }
}
