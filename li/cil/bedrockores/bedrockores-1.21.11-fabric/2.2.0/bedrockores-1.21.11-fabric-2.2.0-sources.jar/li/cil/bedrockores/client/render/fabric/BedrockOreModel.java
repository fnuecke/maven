/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.client.render.fabric;

import net.fabricmc.fabric.api.blockview.v2.FabricBlockView;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBlockStateModel;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_10889;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public final class BedrockOreModel implements class_1087, FabricBlockStateModel {
    private static final class_2350[] FACES = new class_2350[class_2350.values().length + 1];

    static {
        System.arraycopy(class_2350.values(), 0, FACES, 0, class_2350.values().length);
    }

    private final class_1058 particle;

    public BedrockOreModel(final class_1058 particle) {
        this.particle = particle;
    }

    // --------------------------------------------------------------------- //
    // FabricBlockStateModel

    @Override
    public void emitQuads(final QuadEmitter emitter, final class_1920 blockView, final class_2338 pos, final class_2680 state, final class_5819 random, final Predicate<class_2350> cullTest) {
        final var oreState = getOreBlockState(blockView, pos);
        if (oreState == null) {
            return;
        }

        final var oreLayer = class_4696.method_23679(oreState);

        final var parts = new ArrayList<class_10889>();
        class_310.method_1551().method_1541().method_3349(oreState).method_68513(random, parts);

        for (final var part : parts) {
            for (final var face : FACES) {
                for (final var quad : part.method_68509(face)) {
                    emitter.fromBakedQuad(quad);
                    emitter.cullFace(face);
                    emitter.renderLayer(oreLayer);
                    emitter.emit();
                }
            }
        }
    }

    @Override
    public class_1058 particleSprite(final class_1920 blockView, final class_2338 pos, final class_2680 state) {
        final var oreState = getOreBlockState(blockView, pos);
        if (oreState == null) {
            return particle;
        }
        return class_310.method_1551().method_1541().method_3349(oreState).method_68511();
    }

    @Nullable
    @Override
    public Object createGeometryKey(final class_1920 blockView, final class_2338 pos, final class_2680 state, final class_5819 random) {
        return getOreBlockState(blockView, pos);
    }

    // --------------------------------------------------------------------- //
    // BlockStateModel

    @Override
    public void method_68513(final class_5819 random, final List<class_10889> parts) {
        // Position-blind callers get nothing; everything interesting needs the block entity.
    }

    @Override
    public class_1058 method_68511() {
        return particle;
    }

    // --------------------------------------------------------------------- //

    @Nullable
    private static class_2680 getOreBlockState(final class_1920 blockView, final class_2338 pos) {
        if (!(blockView instanceof final FabricBlockView fabricBlockView)) {
            return null;
        }

        if (!(fabricBlockView.getBlockEntityRenderData(pos) instanceof final class_2680 oreState)) {
            return null;
        }

        return oreState.method_26215() ? null : oreState;
    }
}
