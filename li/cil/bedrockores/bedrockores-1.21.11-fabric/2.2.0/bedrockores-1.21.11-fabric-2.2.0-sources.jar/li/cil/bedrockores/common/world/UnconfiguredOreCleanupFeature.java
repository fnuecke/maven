/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.world;

import com.mojang.serialization.Codec;
import li.cil.bedrockores.common.block.entity.UnconfiguredOreCleanup;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5821;

public class UnconfiguredOreCleanupFeature extends class_3031<class_3111> {
    public UnconfiguredOreCleanupFeature(final Codec<class_3111> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(final class_5821<class_3111> context) {
        final var level = context.method_33652();
        return UnconfiguredOreCleanup.removeUnconfiguredFromChunk(level, level.method_22350(context.method_33655())) > 0;
    }
}
