/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity;

import li.cil.bedrockores.common.network.Network;
import li.cil.bedrockores.common.network.message.InfoRequestMessage;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import javax.annotation.Nullable;

public abstract class BlockEntityWithInfo extends class_2586 {
    private static final long UPDATE_INTERVAL_TICKS = 10;

    @Nullable
    private class_2561 currentInfo;
    private long infoValidUntilTick = Long.MIN_VALUE;

    // --------------------------------------------------------------------- //

    protected BlockEntityWithInfo(final class_2591<?> type, final class_2338 pos, final class_2680 state) {
        super(type, pos, state);
    }

    // --------------------------------------------------------------------- //
    // LookAtInfoProvider

    @Nullable
    public final class_2561 getLookAtInfo() {
        final var level = method_10997();
        if (level == null) {
            return null;
        }

        final var now = level.method_75260();
        if (now >= infoValidUntilTick) {
            infoValidUntilTick = now + UPDATE_INTERVAL_TICKS;
            if (level.method_8608()) {
                Network.sendToServer(new InfoRequestMessage(method_11016()));
            } else {
                currentInfo = buildInfo();
            }
        }

        return currentInfo;
    }

    public void setInfoClient(@Nullable final class_2561 info) {
        this.currentInfo = info;
    }

    protected abstract class_2561 buildInfo();
}
