/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block.entity.fabric;

import li.cil.bedrockores.common.block.entity.BedrockOreBlockEntity;
import net.fabricmc.fabric.api.blockview.v2.RenderDataBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import javax.annotation.Nullable;

public final class BedrockOreBlockEntityFabric extends BedrockOreBlockEntity implements RenderDataBlockEntity {
    public BedrockOreBlockEntityFabric(final class_2338 pos, final class_2680 state) {
        super(pos, state);
    }

    // --------------------------------------------------------------------- //

    @Nullable
    @Override
    public Object getRenderData() {
        final var oreBlockState = getOreBlockState();
        return oreBlockState.method_26215() ? null : oreBlockState;
    }
}
