/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.world;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_7924;

public final class BedrockOreFeatures {
    private static final DeferredRegister<class_3031<?>> FEATURES = DeferredRegister.create(Constants.MOD_ID, class_7924.field_41267);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<BedrockOreFeature> BEDROCK_ORE = FEATURES.register("bedrock_ore", () -> new BedrockOreFeature(BedrockOreConfiguration.CODEC));
    public static final RegistrySupplier<UnconfiguredOreCleanupFeature> UNCONFIGURED_ORE_CLEANUP = FEATURES.register("unconfigured_ore_cleanup", () -> new UnconfiguredOreCleanupFeature(class_3111.field_24893));

    // --------------------------------------------------------------------- //

    public static void initialize() {
        FEATURES.register();
    }
}
