/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.world;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_6798;
import net.minecraft.class_7924;

public final class BedrockOrePlacementModifiers {
    private static final DeferredRegister<class_6798<?>> PLACEMENT_MODIFIER_TYPES =
        DeferredRegister.create(Constants.MOD_ID, class_7924.field_41211);

    // --------------------------------------------------------------------- //

    public static final RegistrySupplier<class_6798<AboveWorldBottomPlacement>> ABOVE_WORLD_BOTTOM =
        PLACEMENT_MODIFIER_TYPES.register("above_world_bottom", () -> () -> AboveWorldBottomPlacement.CODEC);

    // --------------------------------------------------------------------- //

    public static void initialize() {
        PLACEMENT_MODIFIER_TYPES.register();
    }
}
