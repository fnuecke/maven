/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.client.render.fabric;

import com.mojang.serialization.MapCodec;
import li.cil.bedrockores.common.config.Constants;
import net.fabricmc.fabric.api.client.model.loading.v1.CustomUnbakedBlockStateModel;
import net.minecraft.class_10526;
import net.minecraft.class_1059;
import net.minecraft.class_10813;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_7775;

public record BedrockOreUnbakedModel() implements CustomUnbakedBlockStateModel {
    public static final class_2960 ID = class_2960.method_60655(Constants.MOD_ID, "bedrock_ore");

    public static final MapCodec<BedrockOreUnbakedModel> CODEC = MapCodec.unit(BedrockOreUnbakedModel::new);

    @SuppressWarnings("deprecation")
    private static final class_4730 PARTICLE = new class_4730(class_1059.field_5275,
            class_2960.method_60655(Constants.MOD_ID, "block/bedrock_ore_mask"));

    private static final class_10813 DEBUG_NAME = ID::toString;

    // --------------------------------------------------------------------- //

    @Override
    public MapCodec<? extends CustomUnbakedBlockStateModel> codec() {
        return CODEC;
    }

    @Override
    public class_1087 method_68521(final class_7775 baker) {
        return new BedrockOreModel(baker.method_65732().method_65739(PARTICLE, DEBUG_NAME));
    }

    @Override
    public void method_62326(final class_10526.class_10103 resolver) {
    }
}
