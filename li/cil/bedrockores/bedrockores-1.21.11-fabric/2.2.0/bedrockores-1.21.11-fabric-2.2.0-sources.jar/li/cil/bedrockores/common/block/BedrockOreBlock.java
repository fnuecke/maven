/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.block;

import com.mojang.serialization.MapCodec;
import dev.architectury.event.EventResult;
import dev.architectury.utils.value.IntValue;
import li.cil.bedrockores.common.RegistryKeys;
import li.cil.bedrockores.common.block.entity.BedrockOreBlockEntity;
import li.cil.bedrockores.common.block.entity.BlockEntities;
import li.cil.bedrockores.common.config.Settings;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2626;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3222;
import net.minecraft.class_3620;
import net.minecraft.class_4538;
import net.minecraft.class_6088;
import javax.annotation.Nullable;

/**
 * This block itself is configured like bedrock; however, it forwards pretty
 * much everything logic related to the underlying ore block, such as hardness
 * checks, harvesting (drops). It only does slightly custom rendering (a mask
 * over the underlying ore's model) and not actually breaking when harvested,
 * but instead reducing the remaining amount by one.
 * <p>
 * The forwarding methods that exist only as loader extensions live in the
 * NeoForge subclass; the ones below are vanilla and work on both platforms.
 */
public class BedrockOreBlock extends class_2237 {
    public static final MapCodec<BedrockOreBlock> field_46280 = MapCodec.unit(BedrockOreBlockFactory::create);

    public static final class_2758 LIGHT = class_2758.method_11867("light", 0, 15);

    // --------------------------------------------------------------------- //

    public BedrockOreBlock() {
        super(class_2251.method_9637()
                .method_63500(RegistryKeys.block(RegistryKeys.BEDROCK_ORE))
                .method_31710(class_3620.field_16023)
                .method_9629(-1F, 3600000)
                .method_42327()
                .method_9631(state -> state.method_11654(LIGHT))
                .method_26235((state, reader, pos, entity) -> false));
        method_9590(method_9564().method_11657(LIGHT, 0));
    }

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(LIGHT);
    }

    // --------------------------------------------------------------------- //

    public static EventResult onBlockBreak(final class_1937 level, final class_2338 pos, final class_2680 state, final class_3222 player, @Nullable final IntValue xp) {
        if (!state.method_27852(Blocks.BEDROCK_ORE.get())) {
            return EventResult.pass();
        }

        if (player.method_68878()) {
            return EventResult.pass();
        }

        if (!Settings.allowPlayerMining.get()) {
            resync(level, pos, player);
            return EventResult.interruptFalse();
        }

        if (level.method_8321(pos) instanceof final BedrockOreBlockEntity bedrockOre) {
            final var oreBlockState = bedrockOre.getOreBlockState();

            final var tool = player.method_6047().method_7972();
            final var canHarvest = player.method_7305(oreBlockState);

            // Ignore result, expect drops to be handled by underlying ore.
            bedrockOre.extract();

            oreBlockState.method_26204().method_9576(level, pos, oreBlockState, player);
            if (canHarvest) {
                oreBlockState.method_26204().method_9556(level, player, pos, oreBlockState, null, tool);
            }

            // The vanilla break is cancelled below, so its effects never fire; play them for the
            // wrapped ore instead. Using the ore's state also gets the right particle texture.
            if (!oreBlockState.method_26215()) {
                level.method_20290(class_6088.field_31144, pos, class_2248.method_9507(oreBlockState));
            }
        }

        // `extract` turns the block into plain bedrock once it runs out; otherwise the block
        // stays put, so the client has to be told its predicted break did not happen.
        resync(level, pos, player);

        return EventResult.interruptFalse();
    }

    private static void resync(final class_1937 level, final class_2338 pos, final class_3222 player) {
        player.field_13987.method_14364(new class_2626(level, pos));

        final var blockEntity = level.method_8321(pos);
        if (blockEntity != null) {
            final var packet = blockEntity.method_38235();
            if (packet != null) {
                player.field_13987.method_14364(packet);
            }
        }
    }

    // --------------------------------------------------------------------- //
    // BaseEntityBlock

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
        return BlockEntities.BEDROCK_ORE.get().method_11032(pos, state);
    }

    @Override
    public class_2464 method_9604(final class_2680 state) {
        return class_2464.field_11458;
    }

    // --------------------------------------------------------------------- //
    // BlockBehaviour


    @Override
    public float method_9594(final class_2680 state, final class_1657 player, final class_1922 level, final class_2338 pos) {
        final var ore = getOreBlockState(level.method_8321(pos));
        if (ore != null) {
            return ore.method_26165(player, level, pos);
        } else {
            return super.method_9594(state, player, level, pos);
        }
    }

    @Override
    public class_1799 method_9574(final class_4538 level, final class_2338 pos, final class_2680 state, final boolean includeData) {
        final var ore = getOreBlockState(level.method_8321(pos));
        if (ore != null) {
            return ore.method_65171(level, pos, includeData);
        } else {
            return super.method_9574(level, pos, state, includeData);
        }
    }

    // --------------------------------------------------------------------- //

    @Nullable
    protected static class_2680 getOreBlockState(@Nullable final class_2586 blockEntity) {
        if (blockEntity instanceof final BedrockOreBlockEntity bedrockOre) {
            return bedrockOre.getOreBlockState();
        }
        return null;
    }
}
