/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.network.message;

import javax.annotation.Nullable;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import java.util.function.Consumer;

public final class MessageUtils {
    public static <T extends class_2586> void withBlockEntity(@Nullable final class_1937 level, final class_2338 position, final Class<T> type, final Consumer<T> callback) {
        if (level == null) {
            return;
        }

        final var chunkPos = new class_1923(position);
        if (!level.method_8393(chunkPos.field_9181, chunkPos.field_9180)) {
            return;
        }

        final var blockEntity = level.method_8321(position);
        if (type.isInstance(blockEntity)) {
            callback.accept(type.cast(blockEntity));
        }
    }

    private MessageUtils() {
    }
}
