/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.network.message;

import li.cil.bedrockores.common.config.Constants;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.Optional;

public record InfoResponseMessage(class_2338 position, Optional<class_2561> info) implements class_8710 {
    public static final class_9154<InfoResponseMessage> TYPE = new class_9154<>(class_2960.method_60655(Constants.MOD_ID, "info_response"));

    public static final class_9139<class_9129, InfoResponseMessage> STREAM_CODEC = class_9139.method_56435(
            class_2338.field_48404, InfoResponseMessage::position,
            class_9135.method_56382(class_8824.field_48540), InfoResponseMessage::info,
            InfoResponseMessage::new);

    // --------------------------------------------------------------------- //

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
