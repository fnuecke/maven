/* SPDX-License-Identifier: MIT */

package li.cil.bedrockores.common.world;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.stream.Stream;
import net.minecraft.class_2338;
import net.minecraft.class_5444;
import net.minecraft.class_5819;
import net.minecraft.class_6017;
import net.minecraft.class_6797;
import net.minecraft.class_6798;

public final class AboveWorldBottomPlacement extends class_6797 {
    public static final MapCodec<AboveWorldBottomPlacement> CODEC = RecordCodecBuilder.mapCodec(builder -> builder.group(
        class_6017.field_33450.fieldOf("offset").forGetter(placement -> placement.offset)
    ).apply(builder, AboveWorldBottomPlacement::new));

    private final class_6017 offset;

    public AboveWorldBottomPlacement(final class_6017 offset) {
        this.offset = offset;
    }

    @Override
    public Stream<class_2338> method_14452(final class_5444 context, final class_5819 random, final class_2338 pos) {
        return Stream.of(pos.method_33096(context.method_33868() + offset.method_35008(random)));
    }

    @Override
    public class_6798<?> method_39615() {
        return BedrockOrePlacementModifiers.ABOVE_WORLD_BOTTOM.get();
    }
}
